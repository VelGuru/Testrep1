﻿using System.Collections.Generic;
using System.Linq;
using Xunit;
using Newtonsoft.Json.Linq;
using System.Collections;
using Microsoft.Extensions.Configuration;
using System;
using RestSharp;
using RestSharp.Authenticators;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using SupplyRegressionTestSuite.TestScripts;
using SupplyRegressionTestSuite;
using SupplyRegressionTestSuite.TestScripts.Model;

namespace APITestSuite
{
    public class TestGrade
    {
        

        [Theory]
        [ClassData(typeof(TestGradeDataGenerator))]
        public static void RunGradeTest(SupplyProductionInputData supplyProductionInputData)
        {

            List<string> errors = new List<string>();

            SupplyResponseData rd = SupplyRestUtil.GetMethod(supplyProductionInputData.inputData,true);
            
            ProductionGradeData responseProductionData = rd.ResponseGradeValues;

            ProductionGradeData sampleDataToValidate = supplyProductionInputData.sampleGradeDataToValidate;
            /*
            ProductionGradeData responseProductionData = null;

            ProductionGradeData sampleDataToValidate = null;
            */
            if (supplyProductionInputData.validateGraphQuantity.IsValueY()){               

                if (sampleDataToValidate != null)
                {
                    List<ProductionGraphData> sampleGraphDataToValidate = sampleDataToValidate.GraphData;
                    foreach(ProductionGraphData sampleGraphData in sampleGraphDataToValidate)
                    {
                        string dataProviderToValidate = sampleGraphData.DataProvider;

                        ProductionGraphData responseGraphDataForDataProvider = responseProductionData.GetProductionGraphDataForDataProvider(dataProviderToValidate);

                        foreach(ProductionGraphDataProviderData monthData in sampleGraphData.DataProviderData)
                        {
                            DateTime monthToValidate = monthData.Month;

                            ProductionGraphDataProviderData responseGraphDataForMonth = responseGraphDataForDataProvider.GetProductionGraphDataForMonth(monthToValidate);

                            string baseMessage = "For Data Provider = " + dataProviderToValidate + " and Month = " + monthToValidate;
                            string userErrorMessage = baseMessage + " doesnt not match (" + monthData.Quantity + "," + responseGraphDataForMonth.Quantity + ")";

                            if (!monthData.Quantity.CompareWithRounding(responseGraphDataForMonth.Quantity)){
                                errors.Add(userErrorMessage);
                            }
                        }

                    }
                }

            }

            Assert.True(errors.Count == 0, string.Join("\n ", errors.Select(s => $"'{s}'")));


        }                           
        //?startdate=01-01-2020&enddate=12-31-2020&tradeorganisation=3&tradeorganisation=4" 
                          
    }


    

  

    public class TestGradeDataGenerator : IEnumerable<object[]>
    {

        private readonly List<object[]> _data = loadInputData();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        private static List<object[]> loadInputData()
        {
            List<object[]> _inputDataList = new List<object[]>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            string masterDataFile = config["MasterGradeDataTestConfigFile"];
            string text = System.IO.File.ReadAllText(@masterDataFile);

            JArray masterDataInputArray = JArray.Parse(text);
            foreach (JObject masterDateInputObject in masterDataInputArray)
            {
                SupplyProductionInputData inputData = masterDateInputObject.ToObject<SupplyProductionInputData>();
                if (inputData.execute.IsValueY())
                    _inputDataList.Add(new object[] { inputData });
            }
            return _inputDataList;
        }
    }
}

