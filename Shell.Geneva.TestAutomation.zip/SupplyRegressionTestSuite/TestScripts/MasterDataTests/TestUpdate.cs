﻿using System.Collections.Generic;
using System.Linq;
using Xunit;
using Newtonsoft.Json.Linq;
using System.Collections;
using Microsoft.Extensions.Configuration;
using System;
using RestSharp;
using RestSharp.Authenticators;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using SupplyRegressionTestSuite.TestScripts;
using SupplyRegressionTestSuite;
using SupplyRegressionTestSuite.TestScripts.Model;

namespace APITestSuite
{
    public class TestUpdate
    {
        

        [Theory]
        [ClassData(typeof(TestUpdateDataGenerator))]
        public static void RunTest(SupplyProductionUpdateInputData supplyProductionInputData)
        {

            List<string> errors = new List<string>();

            ResponseData rd = SupplyRestUtil.PostMethod(supplyProductionInputData.inputData);

            Assert.True(errors.Count == 0, string.Join("\n ", errors.Select(s => $"'{s}'")));


        }

    }


    

  
    public class TestUpdateDataGenerator : IEnumerable<object[]>
    {

        private readonly List<object[]> _data = loadInputData();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        private static List<object[]> loadInputData()
        {
            List<object[]> _inputDataList = new List<object[]>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            string masterDataFile = config["MasterDataUpdateTestConfigFile"];
            string text = System.IO.File.ReadAllText(@masterDataFile);

            JArray masterDataInputArray = JArray.Parse(text);
            foreach (JObject masterDateInputObject in masterDataInputArray)
            {
                SupplyProductionUpdateInputData inputData = masterDateInputObject.ToObject<SupplyProductionUpdateInputData>();
                if (inputData.execute.IsValueY())
                    _inputDataList.Add(new object[] { inputData });
            }
            return _inputDataList;
        }
    }
}

