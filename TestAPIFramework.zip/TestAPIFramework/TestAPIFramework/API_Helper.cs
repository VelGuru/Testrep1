﻿using RestSharp;
//using RestSharp_API_TestFramework.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace TestAPIFramework
{
    public class API_Helper
    {

        public static string _baseUrl = ConfigurationManager.AppSettings.Get("BaseUrl");


        private static IRestResponse CallingAPI(Method httpMethod, Dictionary<string, string> headers, string endPoint, string jsonData = "")
        {
            var client = new RestClient(endPoint);
            if (RunConfiguration.certExists)
            {
                var certPath = RunConfiguration.certFilePath;
                var certName = RunConfiguration.certFileName;
                var certPass = RunConfiguration.certPassword;
                var certFile = Path.Combine(certPath, certName);
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.DefaultConnectionLimit = 9999;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls | SecurityProtocolType.Ssl3;
                X509Certificate2 certificate = new X509Certificate2(certFile, certPass);
                client.ClientCertificates = new X509CertificateCollection() { certificate };
                client.Proxy = new WebProxy();
            }
            //var client = new RestClient(endPoint);
            var request = new RestRequest(httpMethod);
            if (headers != null)
            {
                foreach (var item in headers)
                {
                    request.AddHeader(item.Key, item.Value);
                }
            }

            if (httpMethod == Method.PUT || httpMethod == Method.POST)
            {
                request.AddParameter(headers["content-type"], jsonData, ParameterType.RequestBody);
            }
            IRestResponse response = client.Execute(request);
            return response;
        }

        public void CertRequest(string certFile, string certName, string certPass)
        {

        }


        // GET Request
        public static IRestResponse GetRequest(string endPoint, Dictionary<string, string> headers)
        {
            return CallingAPI(Method.GET, headers, endPoint);
        }


        //POST Request
        public static IRestResponse PostRequest(string endPoint, Dictionary<string, string> headers, string jsonData)
        {
            return CallingAPI(Method.POST, headers, endPoint, jsonData);
        }

        // PUT Request
        public static IRestResponse PutRequest(string endPoint, Dictionary<string, string> headers, string jsonData)
        {
            return CallingAPI(Method.PUT, headers, endPoint, jsonData);
        }

        // DELETE Request
        public static IRestResponse DeleteRequest(string endPoint, Dictionary<string, string> headers)
        {
            return CallingAPI(Method.DELETE, headers, endPoint);
        }



        //public static bool Check3Spots(List<Student> first, List<Student> second)
        //{
        //    if (first.Count() != second.Count())
        //    {
        //        return false;
        //    }
        //    return (first.First().stEquals(second.First()) &&
        //            (first[first.Count / 2].stEquals(second[second.Count / 2])) &&
        //            (first.Last().stEquals(second.Last())));
        //}
    }
}