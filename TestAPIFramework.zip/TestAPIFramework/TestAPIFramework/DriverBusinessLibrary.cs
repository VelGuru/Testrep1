﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using TestAPIFramework.UIMap;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using OpenQA.Selenium.Remote;
using static TestAPIFramework.DriverAppUtilLibrary;

namespace TestAPIFramework
{
    public class DriverBusinessLibrary
    {
        IWebDriver driver;
        DriverAppUtilLibrary appUtilLibrary;
        FrameworkLibrary frameworkLibrary;
        public DriverBusinessLibrary(IWebDriver driver)
        {
            this.driver = driver;
            // appUtilLibrary = new DriverAppUtilLibrary(driver);
            appUtilLibrary = RunConfiguration.appUtilLibrary;
            frameworkLibrary = RunConfiguration.frameworkLibrary;
        }
        public DriverBusinessLibrary(RemoteWebDriver driver)
        {
            this.driver = driver;
            frameworkLibrary = RunConfiguration.frameworkLibrary;
            appUtilLibrary = RunConfiguration.appUtilLibrary;
        }

        /// <summary>
        /// Test Method to validate Member Portal Login Successful
        /// </summary>
        /// <author>TXR3580- Tarun Raghuram</author>
        public void ValidateInitializeLoginSuccessful()
        {
            // Get the Test Data for Member Portal Login
            string userName = frameworkLibrary.GetTestDataFromEnvSheet("UserName");
            string password = frameworkLibrary.GetTestDataFromEnvSheet("Password");

            {
                // Login to Humana.com
                LoginToIDEApplication(userName, password);
            }
        }
        public void validatego365login(string username, string password)
        {
            //string currentUrl = RunConfiguration.driver.Url;
            //if (!currentUrl.Contains("logon"))
            //{
            //    currentUrl = currentUrl.TrimEnd('/') + "/logon";
            //    RunConfiguration.driver.Url = currentUrl;
            //}
            ExplicitWaitForElement(5);
            CheckForPageLoadErrors("Logon Page");
            IWebElement userNameelement = appUtilLibrary.FindElement(By.XPath("//input[@name='username' and @aria-required='true']"), "Username");
            userNameelement.SendKeys(username);
            frameworkLibrary.UpdateTestLog("Login", "UserName(" + username + ") is entered", Status.PASS);
            IWebElement passWordelement = appUtilLibrary.FindElement(By.XPath("//input[@name='password and @class='gigya-input-password']"), "Password");
            passWordelement.SendKeys(password);
            frameworkLibrary.UpdateTestLog("Login", "Password(" + password + ") is entered", Status.PASS);
            appUtilLibrary.ClickLinkandButtonUsingContains("button", "Sign in", "Welcome", "span", true, null, "li");
            frameworkLibrary.StaticWaitForSeconds(5);
            Console.WriteLine("complete");
        }

        private void ExplicitWaitForElement(int v)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///  Login to Humana.com
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        /// <param name="username">User Name</param>
        /// <param name="password">Password</param>
        public void LoginToIDEApplication(string username, string password)
        {
            #region Variable Declarations
            IWebElement logonFormParent = appUtilLibrary.FindElement(By.CssSelector("form[id='log-on']"), elementDesc: "Logon Form Section");
            IWebElement uIUsernameEdit = appUtilLibrary.FindElement(By.CssSelector("input#UserName"), "UserName TextBox", logonFormParent);
            IWebElement uIPasswordEdit = appUtilLibrary.FindElement(By.CssSelector("input#Password"), "Password TextBox", logonFormParent);
            IWebElement uISigninButton = appUtilLibrary.FindElement(By.XPath("//button/span[.='Sign in']/.."), "Sign in Button", logonFormParent);
            #endregion

            string currentUrl = RunConfiguration.driver.Url;
            if (!currentUrl.Contains("logon"))
            {
                currentUrl = currentUrl.TrimEnd('/') + "/logon";
                RunConfiguration.driver.Url = currentUrl;
            }
            CheckForPageLoadErrors("Logon Page");
            uIUsernameEdit.SendKeys(username);
            frameworkLibrary.UpdateTestLog("Login", "UserName(" + username + ") is entered", Status.PASS);
            uIPasswordEdit.SendKeys(password);
            frameworkLibrary.UpdateTestLog("Login", "Password(" + password + ") is entered", Status.PASS);

            // Click ReCaptcha Option
            IWebElement captchaFrame = appUtilLibrary.FindElement(By.CssSelector("iframe[title='recaptcha widget']"), "", logonFormParent);
            // IWebElement captchaFrame = appUtilLibrary.FindElement(By.XPath("//*[@id=\"recaptcha - anchor\"]/div[5]"));
            if (captchaFrame != null)
            {
                driver.SwitchTo().Frame(captchaFrame);
                IWebElement reCaptcha = appUtilLibrary.FindElement(By.CssSelector("div[class='recaptcha-checkbox-checkmark']"));
                if (reCaptcha != null)
                {
                    reCaptcha.Click();
                    Thread.Sleep(100);
                    frameworkLibrary.WaitTillPageLoaded();
                    Thread.Sleep(100);
                }
                driver.SwitchTo().ParentFrame();
            }

            // Click 'Sign in' Button
            uISigninButton.Click();
            frameworkLibrary.UpdateTestLog("Login", "Clicked Sign In Button is clicked successfully", Status.PASS);

            // Wait Till Page is loaded
            frameworkLibrary.WaitTillPageLoaded(timeOut: 100);
            CheckMembersLoginSuccessful();
        }

        /// <summary>
        ///  Check Dashboard has occured or not
        /// </summary>
        /// <author>TXr3580 -Tarun Raghuram</author>
        public void CheckMembersLoginSuccessful()
        {
            try
            {
                ////*[@class='logo']
                By windowElement = By.XPath("//*[contains(text(),'Welcome')]");
                appUtilLibrary.ExplicitWaitForElement(windowElement);
                IWebElement enterMember = appUtilLibrary.FindElement(windowElement);
                if (enterMember != null)
                {
                    frameworkLibrary.UpdateTestLog("Login to user  is successful", "Login to user is successful", Status.PASS);
                }

                else {
                    frameworkLibrary.UpdateTestLog("Login to the dashboard has not been successful ", "Login to the dashboard has not been successful", Status.FAIL);
                }
                
            }
            
            catch
            {
                frameworkLibrary.UpdateTestLog("Login is unsuccessful", "Login is unsuccessful", Status.FAIL);
            }

        }

        /// <summary>
        ///  Login to Go365.com
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="username">User Name</param>
        /// <param name="password">Password</param>
        public void LoginToGo365Application(string username, string password)
        {
            try
            {
                #region Variable Declarations
                IWebElement logonFormParent = appUtilLibrary.FindElement(By.Id("signin-form"), "Parent form section", null);
                IWebElement uIUsernameEdit = appUtilLibrary.FindElement(By.Id("logInDataModel_UserName"));
                IWebElement uIPasswordEdit = appUtilLibrary.FindElement(By.Id("logInDataModel_Password"), "Password TextBox", logonFormParent);
                IWebElement uISigninButton = appUtilLibrary.FindElement(By.Id("submit-button"), "Sign in Button", logonFormParent);
                #endregion

                // Move mouse
                string currentUrl = RunConfiguration.driver.Url;
                if (!currentUrl.Contains("logon"))
                {
                    currentUrl = currentUrl.TrimEnd('/') + "/logon";
                    RunConfiguration.driver.Url = currentUrl;
                }
                CheckForPageLoadErrors("Logon Page");
                uIUsernameEdit.SendKeys(username);
                uIPasswordEdit.SendKeys(password);
                Thread.Sleep(1000);
                // Click ReCaptcha Option
                IWebElement captchaFrame = appUtilLibrary.FindElement(By.CssSelector("iframe[title='recaptcha widget']"), "", logonFormParent);
                if (captchaFrame != null)
                {
                    driver.SwitchTo().Frame(captchaFrame);
                    IWebElement reCaptcha = appUtilLibrary.FindElement(By.CssSelector("div[class='recaptcha-checkbox-checkmark']"));
                    if (reCaptcha != null)
                    {
                        reCaptcha.Click();
                        Thread.Sleep(1000);
                        frameworkLibrary.WaitTillPageLoaded();
                        Thread.Sleep(1000);
                    }
                    driver.SwitchTo().ParentFrame();
                }

                // Click 'Sign in' Button
                uISigninButton.Click();

                frameworkLibrary.UpdateTestLog("Login", "UserName(" + username + ") is Entered, and Sign In Button is clicked successfully", Status.PASS);
                Thread.Sleep(2000);
                // Wait Till Page is loaded
                frameworkLibrary.WaitTillPageLoaded(timeOut: 180);
            }
            catch
            {
                frameworkLibrary.UpdateTestLog("Login", "Login page is not loaded", Status.FAIL);
            }     
        }

        /// <summary>
        ///  Login to Go365.com with MFA member
        /// </summary>
        /// <author>DXS3878 Deepika Shanmugam</author>
        /// <param name="username">User Name</param>
        /// <param name="password">Password</param>
        public void LoginToGo365Application_MFA(string username, string password)
        {
            try
            {
                string tagName = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataControlsTable, "Tag_Name");
                string[] attributeName = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataControlsTable, "TextBox_ID").Split(';');
                string[] value = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataControlsTable, "TextBox_Desc").Split(';'); 
                string parenttag = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataControlsTable, "ParentSectionHeaderTag");
                string childtag = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataControlsTable, "LabelTagName");
                string headertext = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataControlsTable, "LinkToBePresent");
                string applicationUrl = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "ApplicationUrl");
                string targetUrl = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "TargetUrl");
                string headerName = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataControlsTable, "ParentSectionHeader");
                //ParentSectionHeader
                appUtilLibrary.ClickLinkandButtonUsingContains(parenttag, headertext, "Sign in", childtag, true);
                frameworkLibrary.StaticWaitForSeconds(15);
                //appUtilLibrary.ValidatePageUrl(applicationUrl + "logon/");
                IWebElement uIUsernameEdit = appUtilLibrary.FindElement(By.XPath("//input[@name='username' and @aria-required='true']"), "Username");
                //IWebElement userNameelement = appUtilLibrary.FindElement(By.CssSelector("//input[@name='username'][@type='text']"), "Username");
                IWebElement uIPasswordEdit = appUtilLibrary.FindElement(By.XPath("//input[@name='password' and @aria-required='true']"), "Password");
                appUtilLibrary.Enterinputforlogin(uIUsernameEdit, username.ToString());
                appUtilLibrary.Enterinputforlogin(uIPasswordEdit, password.ToString());
                IWebElement signInButton = appUtilLibrary.FindElement(By.XPath("//input[@value='Sign In']"), "Sign in Button");
                //signInButton.Click();
                appUtilLibrary.ClickLink(signInButton, "Signin");
                //appUtilLibrary.ValidatePageHeaderByName("Review terms of use", parentControl, "h1", true, true);
                // Move mouse
                string currentUrl = RunConfiguration.driver.Url;
                if (!currentUrl.Contains("logon"))
                {
                    IWebElement mismatcherror = appUtilLibrary.FindElement(By.XPath("//div[@class='gigya-error-display gigya-composite-control gigya-composite-control-form-error gigya-error-code-403042 gigya-error-display-active']"), "Invalid Credentials");
                    if (mismatcherror.Displayed)
                    {
                        Console.WriteLine("Username/Password entered is not valid");
                    }
                }
                else if (currentUrl.Contains(targetUrl))
                {
                    CheckForPageLoadErrors("Logon Page");
                    Console.WriteLine("Go365 Member is logged in successfully");
                }
                else if (currentUrl.Contains("logon"))
                {
                    //IWebElement steptwo = appUtilLibrary.FindElement(By.Id("sign-in-container_content_caption"));
                   // appUtilLibrary.ValidatePageHeaderByName(headerName, steptwo, "H1", true, true, false);
                    Console.WriteLine("Non MFA member. Please complete MFA process before login");
                    
                }
                Thread.Sleep(100);
                // Click ReCaptcha Option
                //IWebElement captchaFrame = appUtilLibrary.FindElement(By.CssSelector("iframe[title='recaptcha widget']"), "", logonFormParent);
                //if (captchaFrame != null)
                //{
                //    driver.SwitchTo().Frame(captchaFrame);
                //    IWebElement reCaptcha = appUtilLibrary.FindElement(By.CssSelector("div[class='recaptcha-checkbox-checkmark']"));
                //    if (reCaptcha != null)
                //    {
                //        reCaptcha.Click();
                //        Thread.Sleep(1000);
                //        frameworkLibrary.WaitTillPageLoaded();
                //        Thread.Sleep(1000);
                //    }
                //    driver.SwitchTo().ParentFrame();
                //}
                frameworkLibrary.UpdateTestLog("Login", "UserName(" + username + ") is Entered, and Sign In Button is clicked successfully", Status.PASS);
                //Thread.Sleep(2000);
                // Wait Till Page is loaded
               // frameworkLibrary.WaitTillPageLoaded(timeOut: 180);
            }
            catch (Exception e)
            {
                frameworkLibrary.UpdateTestLog("Error", "Debug Info - " + e.Message, Status.FAIL);
            }
        }
        /// <summary>
        /// Validate Login is successful for Go365 Application
        /// </summary>
        /// <author>Ramesh Kandasamy</author>
        public void ValidateGo365LoginSuccessful()
        {
            try
            {
                CheckGo365LoginSuccessful();
            }
            catch (Exception e)
            {
                if (e.Message.Contains("The web page could not be accessed"))
                {
                    Thread.Sleep(3000);
                    CheckGo365LoginSuccessful();
                }
                else
                {
                    throw;
                }

            }
        }

        /// <summary>
        /// Validate Login is successful for Go365 Application
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        private void CheckGo365LoginSuccessful(string userName = "")
        {
            try
            {
                IWebElement megaNavigationControl = appUtilLibrary.FindElement(By.CssSelector("header[class='header flex-header '][role='banner']"), objectSearchTimeout: 60);

                if (megaNavigationControl != null)
                {
                    frameworkLibrary.UpdateTestLog("Login", userName + "Login is Successful, Dashboard Page is loaded", Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Login", userName + "Login is not successful, Dashboard/Mega Navigation is not loaded", Status.FAIL);
                }
                Thread.Sleep(2000);
            }
            catch
            {
                frameworkLibrary.UpdateTestLog("Login", userName + "Login is not successful, Dashboard/Mega Navigation is not loaded", Status.FAIL);
            }           
        }


        /// <summary>
        /// Validate Login is successful for IDE Application
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        private void ValidateLoginSuccessful(string userName = "")
        {
            frameworkLibrary.WaitTillPageLoaded();
            try
            {
                // Validate Mega Navigation is loaded
                IWebElement megaNavigationControl = appUtilLibrary.FindElement(By.CssSelector("nav.primary-navigation-container"), objectSearchTimeout: 60);
                if (megaNavigationControl != null)
                {
                    frameworkLibrary.UpdateTestLog("Login", userName + " Login is Successful, Dashboard Page is loaded", Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Login", userName + " Login is not successful, Dashboard/Mega Navigation is not loaded", Status.FAIL);
                }
                CheckForPageLoadErrors("Dashboard");
            }
            catch (Exception)
            {
                frameworkLibrary.WaitTillPageLoaded();
                CheckForPageLoadErrors("Dashboard");
            }
        }

        /// <summary>
        /// Check For Page Load Errors
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public bool CheckForPageLoadErrors(string pageDesc = "", string pageUrl = "", bool continueOnFail = false)
        {
            bool pageErrorOccurred = false;
            IWebElement pageErrorControl = null;
            string errorMsg = "";
            // Check 404 Server Error
            if (appUtilLibrary.IsWebElementDisplayed(GenericLocators.GlobalErrorControls.UIWeAreSorryThePageIsNotHere))
            {
                errorMsg = "\"We’re sorry. The page you requested isn’t here anymore.\"";
            }

            // Check 500 Server Error
            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//h1[contains(text(),'server error')]"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"" + pageErrorControl.Text + "\"";
            }

            // Check Internet Explorer can not display Message
            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//h1[text()='Internet Explorer cannot display the webpage']"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"Internet Explorer cannot display the webpage\"";
            }

            // Check Blank page is displayed
            pageErrorControl = appUtilLibrary.FindElement(By.TagName("body"));
            if (pageErrorControl != null)
            {
                if (string.IsNullOrEmpty(pageErrorControl.Text))
                {
                    errorMsg = "\"Blank Page\"";
                }
            }

            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//div[@id='mainTitle'][text()='This page can’t be displayed']"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"This page can’t be displayed\"";
            }

            // Check "Http/1.1 Service Unavailable" Message
            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//body/b[text()='Http/1.1 Service Unavailable']"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"Http/1.1 Service Unavailable\"";
            }

            if (!string.IsNullOrEmpty(errorMsg))
            {
                pageErrorOccurred = true;
                if (!string.IsNullOrEmpty(pageUrl))
                {
                    frameworkLibrary.UpdateTestLog("PageLoadError", "Error: " + errorMsg + " is displayed for <b> URL: " + pageUrl + " </b> Current Page URL: " + RunConfiguration.driver.Url, Status.FAIL, continueOnFail);
                }
                else if (RunConfiguration.envURL.Trim() != string.Empty && pageDesc.Trim() == string.Empty)
                {
                    frameworkLibrary.UpdateTestLog("PageLoadError", "Error: " + errorMsg + " is displayed for <b> Base URL: " + RunConfiguration.envURL + " </b> Current Page URL: " + RunConfiguration.driver.Url, Status.FAIL, continueOnFail);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("PageLoadError", "Error: " + errorMsg + " is displayed in " + pageDesc + " page", Status.FAIL, continueOnFail);
                }
            }
            else
            {
                frameworkLibrary.UpdateTestLog("PageLoadError", "No page load error was thrown for Current Page URL: " + RunConfiguration.driver.Url, Status.PASS, continueOnFail);
            }

            return pageErrorOccurred;
        }


        /// <summary>
        /// Check For Page Load Errors
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void CheckPageLoadErrorForHComTopPages(string pageDesc = "", string pageUrl = "")
        {          
            IWebElement pageErrorControl = null;
            string errorMsg = "";
            // Check 404 Server Error
            if (appUtilLibrary.IsWebElementDisplayed(GenericLocators.GlobalErrorControls.UIWeAreSorryThePageIsNotHere))
            {
                errorMsg = "\"We’re sorry. The page you requested isn’t here anymore.\"";
            }

            // Check 500 Server Error
            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//h1[contains(text(),'Server error')]"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"" + pageErrorControl.Text + "\"";
            }

            // Check Internet Explorer can not display Message
            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//h1[text()='Internet Explorer cannot display the webpage']"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"Internet Explorer cannot display the webpage\"";
            }

            // Check Blank page is displayed
            pageErrorControl = appUtilLibrary.FindElement(By.TagName("body"));
            if (pageErrorControl != null)
            {
                if (string.IsNullOrEmpty(pageErrorControl.Text))
                {
                    errorMsg = "\"Blank Page\"";
                }
            }

            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//div[@id='mainTitle'][text()='This page can’t be displayed']"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"This page can’t be displayed\"";
            }

            // Check "Http/1.1 Service Unavailable" Message
            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//body/b[text()='Http/1.1 Service Unavailable']"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"Http/1.1 Service Unavailable\"";
            }

            if (!string.IsNullOrEmpty(errorMsg))
            {               
                if (!string.IsNullOrEmpty(pageUrl))
                {
                    frameworkLibrary.UpdateTestLog("PageLoadError", "Error: " + errorMsg + " is displayed for <b> URL: " + pageUrl + " </b> Current Page URL: " + RunConfiguration.driver.Url, Status.FAIL);
                }
                else if (RunConfiguration.envURL.Trim() != string.Empty && pageDesc.Trim() == string.Empty)
                {
                    frameworkLibrary.UpdateTestLog("PageLoadError", "Error: " + errorMsg + " is displayed for <b> Base URL: " + RunConfiguration.envURL + " </b> Current Page URL: " + RunConfiguration.driver.Url, Status.FAIL);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("PageLoadError", "Error: " + errorMsg + " is displayed in " + pageDesc + " page", Status.FAIL);
                }
            }
            else
            {
                frameworkLibrary.UpdateTestLog("PageLoadError", "No page load error was thrown for Current Page URL: " + RunConfiguration.driver.Url, Status.PASS);
            }
        }

        /// <summary>
        /// Navigate to target URL, and validate target page header as optional
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void NavigateToTargetURL()
        {
            string targetURL = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "TargetUrl");
            string pageHeader = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "TargetPageHeader");
            string pageHeaderTag = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "TargetPageHeaderTag");
            if (!string.IsNullOrEmpty(targetURL))
            {
                OpenUrl(targetURL);
                frameworkLibrary.WaitTillPageLoaded();
                CheckForPageLoadErrors(pageUrl: targetURL);
            }
            if (!string.IsNullOrEmpty(pageHeader))
            {
                if (string.IsNullOrEmpty(pageHeaderTag))
                {
                    pageHeaderTag = "H1";
                }
                appUtilLibrary.ValidatePageHeaderByName(pageHeader, null, pageHeaderTag, true);
            }
        }

        /// <summary>
        /// Open Provided URL in the existing BrowserWindow
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void OpenUrl(string targetUrl)
        {
            targetUrl = frameworkLibrary.GetEnvPrefixedURL(targetUrl);
            driver.Url = targetUrl;
            frameworkLibrary.UpdateTestLog("OpenPage", "Current WebPage is Navigated to URL: " + targetUrl, Status.DONE);
        }

        /// <summary>
        /// Validate Promo contents Like Promo Header, Promo Image, Promo Links and URLs
        /// </summary>
        /// <author>SXS2595 - Sudha Srinivasan</author>
        /// <param name="promoHeader">Promo Header Name</param>
        /// <param name="promoImageSrc">Promo Image Source</param>
        /// <param name="promoLinksCollection">Promo Links Collection</param>
        /// <param name="promoLinkUrlsCollection">Promo Link URLs Collection</param>
        public void ValidatePromoContentsAvailability(string promoHeader, string promoImageSrc, string promoLinksCollection, string promoLinkUrlsCollection)
        {
            // Get the Promo Element
            IWebElement promoControl = GetCompletePromoSection();
            if (promoControl.Displayed)
            {
                // Validate Promo Header and Image Source
                ValidatePromoHeaderAndImage(promoControl, promoHeader, promoImageSrc);

                // Validate Promo Links Availablity
                appUtilLibrary.ValidateLinksAvailablity(promoControl, promoLinksCollection, promoLinkUrlsCollection, "Promo Section");
            }
        }

        /// <summary>
        /// Validate Promo Header and Image Source
        /// </summary>
        /// <author>SXS2595 - Sudha Srinivasan</author>
        /// <param name="promoControl">Promo Control</param>
        /// <param name="promoHeader">Promo Header</param>
        /// <param name="promoImageSrc">Promo Image Source</param>
        private string ValidatePromoHeaderAndImage(IWebElement promoControl, string promoHeader, string promoImageSrc)
        {
            string promoTag = "";
            // Validate Promo Header
            if (!string.IsNullOrEmpty(promoHeader))
            {
                bool promoHeaderFound = false;
                string[] tagNameCollection = "P;H4;H3;H2;H1".Split(';');
                foreach (string tagName in tagNameCollection)
                {
                    IWebElement promoHeaderUI = appUtilLibrary.FindElement(By.XPath("//" + tagName + "[text()='" + promoHeader + "']"), "Promo Header", promoControl);
                    if (promoHeaderUI.Displayed)
                    {
                        frameworkLibrary.UpdateTestLog("PromoSection", "Promo Header (" + promoHeader + ") is available in the Promo Section", Status.PASS);
                        promoHeaderFound = true;
                        promoTag = tagName;
                        break;
                    }
                }
                if (!promoHeaderFound)
                {
                    frameworkLibrary.UpdateTestLog("PromoSection", "Promo Header (" + promoHeader + ") is not available in the Promo Section", Status.FAIL);
                }
            }

            // Validate Promo Image
            if (!string.IsNullOrEmpty(promoImageSrc))
            {
                IWebElement promoImageHeaderUI = appUtilLibrary.FindElement(By.XPath("//img[@src=" + promoImageSrc + "]"), "PromoImage(ImageSrc :-" + promoImageSrc);
            }
            return promoTag;
        }

        /// <summary>
        /// Promo Control Property
        /// </summary>
        /// <author>SXS2595 - Sudha Srinivasan</author>
        public IWebElement GetCompletePromoSection()
        {
            IWebElement prevPromo = appUtilLibrary.FindElement(By.XPath("//DIV[contains(@class, 'row solid-background')]"));
            IWebElement updatedPromo = appUtilLibrary.FindElement(By.XPath("//DIV[@id='promos']"));
            try
            {
                if (prevPromo.Displayed)
                {
                    return prevPromo;
                }
                else if (updatedPromo.Displayed)
                {
                    return updatedPromo;
                }
            }
            catch (Exception)
            {
                frameworkLibrary.UpdateTestLog("GetCompletePromoSection", "Promo section is not found", Status.FAIL);
            }
            return prevPromo;
        }

        /// <summary>
        /// Reusable Method to Navigate through Mega Navigation 
        /// </summary>
        /// <author>TXR3580-Tarun Raghuram Shetty</author>
        /// <param name="parentLinkText">Parent Link - Mega Navigation</param>
        /// <param name="childLinkText">Inner Link Name - DropDown</param>
        /// <param name="browser">BrowserWindow Object</param>
        public void NavigateThruMegaNavLink(string parentLinkText, string childLinkText, string windowType = "Same", string useParentContains = "No", string useChildContains = "No")
        {
            IWebElement headerUI = appUtilLibrary.FindElement(By.TagName("HEADER"));
            IWebElement parentLink = appUtilLibrary.FindElement(By.LinkText(parentLinkText), "Parent Link(" + parentLinkText + ")");

            // Mouse Hover to Parent Element
            Actions actions = new Actions(driver);
            actions.MoveToElement(parentLink).Perform();
            frameworkLibrary.StaticWaitForSeconds(2);

            // Find Child Link
            IWebElement childLinkElement = appUtilLibrary.FindElement(By.LinkText(childLinkText), "Child Link(" + childLinkText + ")", headerUI);
            appUtilLibrary.ClickLink(childLinkElement, "Child Link(" + childLinkText + ")", true);
        }

        /// <summary>
        /// Reusable Method to Navigate through Mega Navigation 
        /// </summary>
        /// <author>TXR3580-Tarun Raghuram Shetty</author>
        /// <param name="parentLinkText">Parent Link - Mega Navigation</param>
        /// <param name="childLinkText">Inner Link Name - DropDown</param>
        /// <param name="browser">BrowserWindow Object</param>
        public void NavigateThruMegaNavLinks(string parentLinkText, string[] childLinkText, string[] header, bool useParentContains, bool useChildContains)
        {
            By parentsection = null;
            By childsection = null;
            int i = 0;
            foreach (string childLink in childLinkText)
            {
                IWebElement headerUI = appUtilLibrary.FindElement(By.TagName("HEADER"));
                // Mouse Hover to Parent Element
                Actions actions = new Actions(driver);
                if (useParentContains != true && useChildContains != true)
                {
                    parentsection = By.XPath("//button[@class='top-bar-link related-sites-menu-link utility-menu-link']");
                    //parentsection = By.LinkText(parentLinkText);
                    childsection = By.PartialLinkText(childLink);
                }
                else if (useParentContains == true && useChildContains != true)
                {

                    parentsection = By.XPath("//a[contains(text(), '" + parentLinkText + "')]");
                    childsection = By.PartialLinkText(childLink);
                }

                else if (useParentContains != true && useChildContains == true)
                {
                    parentsection = By.LinkText(parentLinkText);
                    childsection = By.XPath("//a[contains(text(), '" + childLink + "')]");
                }

                else
                {
                    parentsection = By.XPath("//a[contains(text(), '" + parentLinkText + "')]");
                    childsection = By.XPath("//a[contains(text(), '" + childLink + "')]");
                }

                IWebElement parentLink = appUtilLibrary.FindElement(parentsection, "Parent Link(" + parentLinkText + ")");
                actions.MoveToElement(parentLink).Perform();
                frameworkLibrary.UpdateTestLog("Clicked " + parentLinkText + "successfully", "Clicked " + parentLinkText + " successfully", Status.PASS);

                IWebElement childLinkElement = appUtilLibrary.FindElement(childsection, "Child Link(" + childLink + ")", headerUI);
                actions.MoveToElement(childLinkElement);
                actions.Click().Perform();
                frameworkLibrary.WaitTillPageLoaded();
                frameworkLibrary.UpdateTestLog("Clicked " + childLink + " successfully", "Clicked " + childLink + " successfully", Status.PASS);
                if (header[i] == null)
                {
                    appUtilLibrary.ValidatePageHeaderByName(childLink);
                }
                else
                {
                    appUtilLibrary.ValidatePageHeaderByName(header[i]);
                }
                i++;
            }
        }

        /// <summary>
        /// Reusable Method to Navigate through Mega Navigation 
        /// </summary>
        /// <author>TXR3580-Tarun Raghuram Shetty</author>
        /// <param name="parentLinkText">Parent Link - Mega Navigation</param>
        /// <param name="childLinkText">Child Link - Mega Navigation</param>
        /// <param name="navigatedPageHeader">Navigated Page Header</param>
        public void ValidateThruMegaNavLinks(string parentLinkText, string[] childLinkText, string[] navigatedPageHeaders, bool useParentContains, bool useChildContains)
        {
            By parentsection = null;
            By childsection = null;
            string pageHeader = null;

            for (int i = 0; i < childLinkText.Length; i++)
            {
                string childLink = childLinkText[i];
                if (navigatedPageHeaders != null && navigatedPageHeaders.Length != 0)
                {
                    pageHeader = navigatedPageHeaders[i];
                }
                IWebElement headerUI = appUtilLibrary.FindElement(By.TagName("HEADER"));
                Actions actions = new Actions(driver);

                if (useParentContains != true && useChildContains != true)
                {
                    parentsection = By.XPath("//button[@class='top-bar-link related-sites-menu-link utility-menu-link']");
                    //parentsection = By.LinkText(parentLinkText);
                    childsection = By.PartialLinkText(childLink);
                }
                else if (useParentContains == true && useChildContains != true)
                {
                    parentsection = By.XPath("//a[contains(text(), '" + parentLinkText + "')]");
                    childsection = By.PartialLinkText(childLink);
                }

                else if (useParentContains != true && useChildContains == true)
                {
                    parentsection = By.LinkText(parentLinkText);
                    childsection = By.XPath("//a[contains(text(), '" + childLink + "')]");
                }
                else
                {
                    parentsection = By.XPath("//a[contains(text(), '" + parentLinkText + "')]");
                    childsection = By.XPath("//a[contains(text(), '" + childLink + "')]");
                }

                // Mouse Hover to Parent Element
                IWebElement parentLink = appUtilLibrary.FindElement(parentsection, "Parent Link (" + parentLinkText + ")");
                actions.MoveToElement(parentLink).Perform();
                frameworkLibrary.UpdateTestLog("MegaNavigationParent", "Parent Link (" + parentLinkText + " ) is displayed successfully", Status.PASS);
                frameworkLibrary.StaticWaitForSeconds(1);

                appUtilLibrary.ExplicitWaitForElement(childsection,9);
                // Click Child Link
                IWebElement childLinkElement = appUtilLibrary.FindElement(childsection, "Child Link (" + childLink + ")", headerUI);
                actions.MoveToElement(childLinkElement);
                actions.Click().Perform();
                frameworkLibrary.WaitTillPageLoaded();
                frameworkLibrary.UpdateTestLog("MegaNavigationChild", "Clicked child link (" + childLink + ") under Parent link ( " + parentLinkText + " ) successfully", Status.PASS);
                CheckForPageLoadErrors(childLink + " navigated page");
                if (pageHeader != null)
                {
                    appUtilLibrary.ValidatePageHeaderByName(pageHeader);
                }

                // Navigate to the main page
                driver.Navigate().Back();
                frameworkLibrary.WaitTillPageLoaded();
            }
        }


        /// <summary>
        /// Validate Log out of test case
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void ValidateLogoutSuccessful()
        {
            IWebElement Signout = appUtilLibrary.FindElement(By.LinkText("Sign out"));
            Signout.Click();
            frameworkLibrary.UpdateTestLog("Signout", "Sign out button is clicked", Status.PASS);
            frameworkLibrary.WaitTillPageLoaded();

            // validate log out is successfull
            appUtilLibrary.ValidatePageHeaderByName("You have signed out successfully");
        }

        /// <summary>
        /// Validate mega naviagation 
        /// </summary>
        /// <author>TXR3580 Tarun Raghuram</author>
        public void ValidateMegaNavigation(bool useParentContains = false, bool useChildContains = false)
        {
            string megaNavParentLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavParentLink");
            string[] megaNavChildLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavChildLink").Split(';');
            string[] megaNavHeader = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavPageHeader").Split(';');
            frameworkLibrary.WaitTillPageLoaded();
            
            appUtilLibrary.ExplicitWaitForElement(By.LinkText(megaNavParentLink));
            // Navigate mega navigation
            NavigateThruMegaNavLinks(megaNavParentLink, megaNavChildLink,megaNavHeader, useParentContains, useChildContains);

            frameworkLibrary.WaitTillPageLoaded();
        }

        /// <summary>
        /// Validate mega naviagation links
        /// </summary>
        /// <author>TXR3580 Tarun Raghuram</author>
        public void ValidateLinksInMegaNavigation(bool useParentContains = false, bool useChildContains = false)
        {
            string megaNavParentLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavParentLink");
            string[] megaNavChildLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavChildLink").Split(';');
            string[] megaNavPageHeader = null;
            string pageHeader = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavPageHeader");
            if (!String.IsNullOrEmpty(pageHeader))
            {
                megaNavPageHeader = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavPageHeader").Split(';');
            }

            // Navigate mega navigation
            ValidateThruMegaNavLinks(megaNavParentLink, megaNavChildLink, megaNavPageHeader, useParentContains, useChildContains);
            frameworkLibrary.WaitTillPageLoaded();
        }

        /// <summary>
        /// Validate Page URL
        /// </summary>
        /// <author>TXR3580- Tarun Raghuram</author>
        /// <param name="expectedUrl">Expected URL</param>
        public void ValidatePageUrl(string expectedUrl)
        {
            // Get the Page Url
            expectedUrl = expectedUrl.TrimEnd('/').Replace("http://", "").Replace("https://", "");
            string pageUrl = driver.Url;

            pageUrl = pageUrl.Replace("http://", "").Replace("https://", "");

            if (string.Equals(pageUrl.Trim(), expectedUrl.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                frameworkLibrary.UpdateTestLog("PageURL", "Page Url is matched with Expected Url, Page Url: " + pageUrl, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("PageURL", "Page Url is not matched with Expected Url, Page Url: " + pageUrl + " Expected URL: " + expectedUrl, Status.FAIL);
            }
        }

        /// <summary>
        /// Validate UI Controls Available
        /// Check and Supperess UI control
        /// </summary>
        /// <author>TXR3580- Tarun Raghuram</author>
        public void ValidateUIControlsAvailable(dynamic parentUI = null, int subIterationNo = 1)
        {
            string controlsComment, linkToBePresent, linkToBeSuppress, labelInnerText;
            string controlPropertyCollection = "";
            // Get the Test Data from Data Table
            controlsComment = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "Controls_Comment", subIterationNo);
            linkToBePresent = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LinkToBePresent", subIterationNo);
            linkToBeSuppress = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LinkToBeSuppress", subIterationNo);
            labelInnerText = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LabelInnerText", subIterationNo);
            try
            {
                controlPropertyCollection = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "UIControlProperty", subIterationNo);
            }
            catch (Exception) { }

            // Get Section Header - Parent
            try
            {
                string parentOrder = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "ParentSectionOrder", subIterationNo);
                string parentSectionHeader = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "ParentSectionHeader", subIterationNo);
                string parentSectionHeaderTag = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "ParentSectionHeaderTag", subIterationNo);
                if (!string.IsNullOrEmpty(parentSectionHeader) && !string.IsNullOrEmpty(parentSectionHeaderTag))
                {
                    parentUI = appUtilLibrary.GetParentControlFromSectionHeader(parentSectionHeader, parentSectionHeaderTag, parentOrder: parentOrder, parentControl: parentUI);
                    appUtilLibrary.UIControlIsDisplayed(parentUI);
                }
                else if (!string.IsNullOrEmpty(controlsComment) && parentUI != null)
                {
                    appUtilLibrary.IsWebElementDisplayed(parentUI, "Control" + parentUI + "is present");
                }
            }
            catch (Exception)
            {
                // Parent Section is optional
            }

            try
            {
                // Validate Links Available
                if (!string.IsNullOrEmpty(linkToBePresent))
                {
                    appUtilLibrary.ValidateLinksAvailablity(parentUI, linkToBePresent, "", controlsComment, continueOnFail: true);
                }

                // Validate Links Not available
                if (!string.IsNullOrEmpty(linkToBeSuppress))
                {
                    //appUtilLibrary.ValidateLinksNotAvailable(parentUI, linkToBeSuppress, controlsComment, continueOnFail: true);
                }

                // Validate Label Contents
                if (!string.IsNullOrEmpty(labelInnerText))
                {
                    // Test Data
                    string[] labelPresenceList = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LabelPresence", subIterationNo).Split(';');
                    string[] labelTagNameList = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LabelTagName", subIterationNo).Split(';');
                    string[] labelInnerTextList = labelInnerText.Split(';');

                    string eachLabel, eachLabelTag, eachLabelPresence;
                    for (int i = 0; i < labelInnerTextList.Length; i++)
                    {
                        eachLabel = labelInnerTextList[i];
                        eachLabelTag = FrameworkLibrary.GetArrayIndexValue(labelTagNameList, i);
                        eachLabelPresence = FrameworkLibrary.GetArrayIndexValue(labelPresenceList, i).ToUpper();
                        switch (eachLabelPresence)
                        {
                            case "YES":
                                if (Regex.IsMatch(eachLabelTag, "H1|H2|H3|H4"))
                                {
                                    appUtilLibrary.ValidatePageHeaderByName(eachLabel, parentUI, eachLabelTag, false, true);
                                }
                                else
                                {
                                    appUtilLibrary.ValidateLabelByInnerText(eachLabel, eachLabelTag, parentUI);
                                }
                                break;
                            case "NO":
                                appUtilLibrary.IsWebElementNotAvailable(By.TagName(eachLabelTag), "WebElement" + eachLabelTag + "is present", parentUI);
                                break;
                            case "REGEXP":
                                if (Regex.IsMatch(eachLabelTag, "H1|H2|H3|H4"))
                                {
                                    //appUtilLibrary.ValidatePageHeaderByPartialName(parentUI, eachLabel, eachLabelTag, false, true);
                                }
                                else
                                {
                                    appUtilLibrary.ValidateLabelByPartialInnerText(eachLabel, eachLabelTag, parentUI);
                                }
                                break;
                            default:
                                appUtilLibrary.ValidateLabelByInnerText(eachLabel, eachLabelTag, parentUI);
                                break;
                        }
                    }
                }
            }
            catch (AssertFailedException e)
            {
                if (!string.IsNullOrEmpty(controlsComment))
                {
                    frameworkLibrary.UpdateTestLog("UIControl", controlsComment + " - " + e.Message, Status.FAIL);
                }
                else
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// Validate BreadCrumb Section, Links & Active Breadcrumb label
        /// </summary>
        /// <author>SXS2595 - Sudha Srinivasan</author>
        /// <param name="activeBreadCrumbPage">Active Breadcrumb Label</param>
        /// <param name="breadcrumbLinksCollection">Breadcrumb Links Collection</param>
        /// <param name="breadcrumbLinkUrlsCollection">Link URLs Collection</param>
        public void ValidateBreadcrumbContents(string activeBreadCrumbPage, string breadcrumbLinksCollection = "", string breadcrumbLinkUrlsCollection = "")
        {
            // Get the Breadcrumb section
            IWebElement breadcrumbSection = driver.FindElement(By.Id("bc"));

            if (breadcrumbSection.Displayed)
            {
                frameworkLibrary.UpdateTestLog("Breadcrumb", "Breadcrumb Section is available in the Page", Status.PASS);

                // Validate Active Breadcrumb Label
                if (!string.IsNullOrEmpty(activeBreadCrumbPage))
                {
                    IWebElement activeBreadcrumbUI = breadcrumbSection.FindElement(By.XPath("//nav/ul/li/span[@itemprop='title']"));
                    if (activeBreadcrumbUI.Displayed)
                    {
                        String actualActiveBreadcrumbText = activeBreadcrumbUI.Text;
                        if (actualActiveBreadcrumbText.Equals(activeBreadCrumbPage))
                        {
                            frameworkLibrary.UpdateTestLog("Breadcrumb", "Active Breadcrumb Page Text (" + actualActiveBreadcrumbText + ") is available in the Breadcrumb Section", Status.PASS);
                        }
                        else
                        {
                            frameworkLibrary.UpdateTestLog("Breadcrumb", "Active Breadcrumb Page Text (" + activeBreadCrumbPage + ") is not available in the Breadcrumb Section, Actual Text - " + actualActiveBreadcrumbText, Status.FAIL);
                        }
                    }
                    else
                    {
                        frameworkLibrary.UpdateTestLog("Breadcrumb", "Active Breadcrumb Page Text (" + activeBreadCrumbPage + ") is not available in the Breadcrumb Section", Status.FAIL);
                    }
                }

                if (!string.IsNullOrEmpty(breadcrumbLinksCollection))
                {
                    // Validate Breadcrumb section Links
                    appUtilLibrary.ValidateLinksAvailablity(breadcrumbSection, breadcrumbLinksCollection, breadcrumbLinkUrlsCollection, "Breadcrumb Section");
                }
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Breadcrumb", "Breadcrumb Section is not available in the Page", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate Promo Contents 
        /// </summary>
        /// <author>SXS2595 - Sudha Srinivasan</author>
        public void ValidatePromoContents()
        {
            IWebElement promoControl = GetCompletePromoSection();
            By promoLocator = By.XPath("//div[contains(@class, 'six columns')]");
            IReadOnlyList<IWebElement> childCollection = appUtilLibrary.GetAllChildren(promoControl, promoLocator);
            IWebElement eachPromo;
            if (childCollection.Count > 0)
            {
                try
                {
                    for (int j = 0; j < childCollection.Count; j++)
                    {
                        promoControl = GetCompletePromoSection();
                        childCollection = appUtilLibrary.GetAllChildren(promoControl, By.XPath("//div[contains(@class, 'six columns')]"));
                        eachPromo = childCollection[j];
                        LinksValidation linksValidation = new LinksValidation(eachPromo);
                        linksValidation.parentPageUrl = driver.Url.ToString();

                        // Validate Promo Header
                        bool promoHeaderFound = false;
                        string promoHeader = "";
                        string[] tagNameCollection = "H4;P;H3;H2;H1".Split(';');
                        foreach (string tagName in tagNameCollection)
                        {
                            try
                            {
                                IWebElement promoHeaderUI = eachPromo.FindElement(By.TagName(tagName));
                                if (tagName.Equals("P"))
                                {
                                    promoHeaderUI = eachPromo.FindElement(By.XPath("//p[contains(class(), 'headline x1']"));
                                }
                                if (promoHeaderUI != null && promoHeaderUI.Displayed)
                                {
                                    promoHeader = promoHeaderUI.Text;
                                    frameworkLibrary.UpdateTestLog("PromoSection", "Promo Header (" + promoHeader + ") is available in the Promo Section", Status.PASS);
                                    promoHeaderFound = true;
                                }
                            }
                            catch (NoSuchElementException) { }
                        }
                        if (!promoHeaderFound)
                        {
                            frameworkLibrary.UpdateTestLog("PromoSection", "Promo Header is not available in the  promo Section", Status.FAIL);
                        }

                        // Validate Promo Image
                        IWebElement promoImageHeaderUI = appUtilLibrary.FindElement(By.TagName("IMG"), parentElement: eachPromo);
                        if (promoImageHeaderUI != null)
                        {
                            frameworkLibrary.UpdateTestLog("PromoImage", "Promo Image is available for the Promo Header - " + promoHeader, Status.PASS);
                        }
                        else
                        {
                            frameworkLibrary.UpdateTestLog("PromoImage", "Promo Image is not available for the Promo Header - " + promoHeader, Status.DONE);
                        }

                        // Validate Promo Links
                        IReadOnlyList<IWebElement> linksList = eachPromo.FindElements(By.TagName("A"));
                        for (int i = 0; i < linksList.Count; i++)
                        {
                            try
                            {
                                // Get the page elements again
                                promoControl = GetCompletePromoSection();
                                promoLocator = By.XPath("//div[contains(@class, 'six columns')]");
                                childCollection = appUtilLibrary.GetAllChildren(promoControl, promoLocator);
                                eachPromo = childCollection[j];
                                IReadOnlyList<IWebElement> newLinksList = eachPromo.FindElements(By.TagName("A"));
                                if (newLinksList != null)
                                {
                                    IWebElement currentLink = newLinksList[i];
                                    linksValidation.linkName = currentLink.Text;
                                    RunConfiguration.appUtilLibrary.ClickLink(currentLink, currentLink.Text);
                                    frameworkLibrary.WaitTillPageLoaded(timeOut: 10);
                                    if (!linksValidation.IsLinkOpenedInSameWindow(true))
                                    {
                                        OpenUrl(linksValidation.parentPageUrl);
                                        frameworkLibrary.WaitTillPageLoaded();
                                    }
                                }
                            }
                            catch (StaleElementReferenceException)
                            {
                                // Get the page elements again
                                promoControl = GetCompletePromoSection();
                                promoLocator = By.XPath("//div[contains(@class, 'six columns')]");
                                childCollection = appUtilLibrary.GetAllChildren(promoControl, promoLocator);
                                for (j = 0; j < childCollection.Count;)
                                {
                                    eachPromo = childCollection[j];
                                    break;
                                }
                            }
                        }
                    }
                }
                catch (StaleElementReferenceException)
                {
                    // Get the page elements again
                    promoControl = GetCompletePromoSection();
                    promoLocator = By.XPath("//div[contains(@class, 'six columns')]");
                    childCollection = appUtilLibrary.GetAllChildren(promoControl, promoLocator);
                    for (int j = 0; j < childCollection.Count;)
                    {
                        eachPromo = childCollection[j];
                        break;
                    }
                }
            }
        }
    }
}
