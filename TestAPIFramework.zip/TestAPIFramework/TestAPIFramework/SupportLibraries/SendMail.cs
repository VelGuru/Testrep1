﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Net.Mail;

namespace TestAPIFramework
{
    public class SendMail
    {
        ReportFactory objReportFactory = new ReportFactory();

        public bool SendEmail(DataTable resultSet)
        {
            DataTable toEmailIdList = objReportFactory.GetEmailIdDetails("To");
            DataTable ccEmailIdList = objReportFactory.GetEmailIdDetails("Cc");

            string subject = "Execution Results";
            string body = "";

            try
            {
                var mail = new MailMessage();
                var smtpServer = new SmtpClient("pobox.Humana.com");
                smtpServer.Port = 25;
                smtpServer.EnableSsl = false;

                mail.From = new MailAddress("pobox@humana.com");

                foreach (DataRow row in toEmailIdList.Rows)
                {
                    mail.To.Add(row["EmailID"].ToString().Trim());
                }

                foreach (DataRow row in ccEmailIdList.Rows)
                {
                    mail.CC.Add(row["EmailID"].ToString().Trim());
                }

                mail.Subject = subject;
                mail.IsBodyHtml = true;
                mail.Body = body;
                mail.Body = "<html xmlns:v=\"urn:schemas-microsoft-com:vml\"xmlns:o=\"urn:schemas-microsoft-com:office:office\"xmlns:w=\"urn:schemas-microsoft-com:office:word\"xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\"xmlns=\"http://www.w3.org/TR/REC-html40\">";
                mail.Body = mail.Body + "Hi All </BR></BR> <table align=\"center\" border=\"1\" cellpadding=\"5\" cellspacing=\"0\" width=\"800\">";
                mail.Body = mail.Body + "<tr bgcolor=\"#70bbd9\"><th>Functional TC Name</th><th>Workstream</th><th>Run Category</th><th>Coded UI Test Name</th><th>Execution Status</th></tr>";

                foreach (DataRow row in resultSet.Rows)
                {
                    string FUNCTIONAL_TC_NAME = row["FUNCTIONAL_TC_NAME"].ToString().Trim();
                    string WORKSTREAM = row["WORKSTREAM"].ToString().Trim();
                    string RUN_CATEGORY = row["RUN_CATEGORY"].ToString().Trim();
                    string CODEDUI_TEST_NAME = row["CODEDUI_TEST_NAME"].ToString().Trim();


                    mail.Body = mail.Body + "<tr bgcolor=\"#ffffff\"><td>" + row["FUNCTIONAL_TC_NAME"].ToString().Trim() + "</td><td>" + row["WORKSTREAM"].ToString().Trim() + "</td><td>" + row["RUN_CATEGORY"].ToString().Trim() + "</td><td>" + row["CODEDUI_TEST_NAME"].ToString().Trim() + "</td>";

                    if (row["TEST_RESULT"].ToString().Trim() == "PASSED")
                    {
                        mail.Body = mail.Body + "<td> <font color=\"Green\">" + row["TEST_RESULT"].ToString().Trim() + "</font></td>";
                    }
                    else
                    {
                        mail.Body = mail.Body + "<td> <font color=\"Red\">" + row["TEST_RESULT"].ToString().Trim() + "</font></td>";
                    }
                }

                mail.Body = mail.Body + "</tr></table></html>";
                smtpServer.Send(mail);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
