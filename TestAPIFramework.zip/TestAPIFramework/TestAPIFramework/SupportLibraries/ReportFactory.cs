﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace TestAPIFramework
{
    /// <summary>
    /// Class to Read Write Coded UI Test Logs to Database 
    /// </summary>
    public class ReportFactory
    {
        // Current Test Run Attributes - Will hold the RUN ID & execution Category (Smoke, BVT or Regression) for the current Iteration 
        public static string currentRunID = null;
        public static int iterationGroupingID = 0;
        public static string currentRunCategory = "REGRESSION";

        // Data Connection Configurations 
        //public static string dataSource = @"WKR90C4MG5\SQLEXPRESS"; 

        //public static string dataSource = @"LOUSSPWTS89\SQLEXPRESS";
        //public static string dbName = "CodedUI";
        //// DB Table Name
        //public static string TESTRESULTS = dbName + ".dbo.TEST_RESULTS";
        //public static string TESTSTEPDETAILS = dbName + ".dbo.TESTSTEP_DETAILS";
        //public static string SCREENSHOTS = dbName + ".dbo.SCREENSHOTS";
        //// SQL User Credentials
        ////public static string dbUserName = "DigitalDevOpsUser", dbPwd = "1234567a";
        //public static string dbUserName = "testuser", dbPwd = "1234567c";
        //// Connection String 
        //public static string connectionString = "user id=" + dbUserName + ";password=" + dbPwd
        //                                        + ";Data Source=" + dataSource + ";Initial Catalog=" + dbName
        //                                       + ";Persist Security Info=True;";
        //public static string dataSource = @"tcp:humanadigitaldevops.database.windows.net,1433";
        //public static string dbName = "legacytestingautomation";
        // DB Table Name
        public static string dataSource = ConfigurationManager.AppSettings["DataSource"];
        public static string dbName = ConfigurationManager.AppSettings["DatabaseName"];
        public static string TESTRESULTS = dbName + ".dbo.TEST_RESULTS";
        public static string TESTSTEPDETAILS = dbName + ".dbo.TESTSTEP_DETAILS";
        public static string SCREENSHOTS = dbName + ".dbo.SCREENSHOTS";
        // SQL User Credentials
        //public static string dbUserName = "DigitalDevOpsUser", dbPwd = "1234567a";
        //public static string dbUserName = "gsodini@humana.com", dbPwd = "mickey#1";

        // Connection String 
        public static string dbUserName = ConfigurationManager.AppSettings["UserName"];
        public static string dbPwd = ConfigurationManager.AppSettings["Password"];
        public static string connectionString = "Server=" + dataSource + ";Initial Catalog=" + dbName
                                          + ";Persist Security Info=False;user id = " + dbUserName + "; password=" + dbPwd
                                           + ";MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False";
        //public static string connectionString = ConfigurationManager.ConnectionStrings["connectionAzureDB"].ConnectionString;

        public const string curTimeStamp = "CURRENT_TIMESTAMP";
        // Static Coded UI DB Connection 
        public static SqlConnection codedUIDbConn = new SqlConnection(connectionString);
        public static SqlCommand sqlCommand;
        public static SqlDataReader sqlDataReader = null;
        public static SqlDataAdapter sqlDataAdapter = null;

        public ReportFactory()
        {
            //connectionString = "Server=" + dataSource + ";Initial Catalog=" + dbName
            //                              + ";Persist Security Info=False;user id = " + dbUserName + "; password=" + dbPwd
            //                               + ";MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Authentication=Active Directory Password";

            //string connectionString = ConfigurationManager.ConnectionStrings["connectionAzureDB"].ConnectionString;
            codedUIDbConn = new SqlConnection(connectionString);

            //TESTRESULTS = RunConfiguration.dbName + ".dbo.TEST_RESULTS";
            TESTRESULTS = dbName + ".dbo.TEST_RESULTS";
            //TESTSTEPDETAILS = RunConfiguration.dbName + ".dbo.TESTSTEP_DETAILS";
            TESTSTEPDETAILS = dbName + ".dbo.TESTSTEP_DETAILS";

            //SCREENSHOTS = RunConfiguration.dbName + ".dbo.SCREENSHOTS";
            SCREENSHOTS = dbName + ".dbo.SCREENSHOTS";
        }

        /// <summary>
        /// Method to Write Step Staus into Data Base. Step Order will be updated using TimeStamp 
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        /// <param name="testStepDetails"></param>
        public void InsertStepStatus(TestStepDetails testStepDetails)
        {
            testStepDetails.FormatValuesForSQL();

            string insertQuery = "INSERT INTO " + TESTSTEPDETAILS + " (" + CTestStepDetails.TESTRUN_ID + ", "
                + CTestStepDetails.STEP_NAME + ", " + CTestStepDetails.STEP_DESCRIPTION + ", " + CTestStepDetails.STEP_STATUS + ", "
                + CTestStepDetails.SCREENSHOT_PATH + ", " + CTestStepDetails.LASTUPDATE_TIMESTAMP + ") VALUES ("
                + testStepDetails.TESTRUN_ID + ", '" + testStepDetails.STEP_NAME + "', '" + testStepDetails.STEP_DESCRIPTION + "', '"
                + testStepDetails.STEP_STATUS + "', '" + testStepDetails.SCREENSHOT_PATH + "', " + testStepDetails.LASTUPDATE_TIMESTAMP + ")";

            FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
            frameworkLibrary.ExecuteSQLWriteCommand(insertQuery, codedUIDbConn);
        }

        /// <summary>
        /// Method to Wrap Up Test Execution for Every Iteration. This method will udpate execution  duration, status etc in DB
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        /// <param name="testResults"></param>
        public void UpdateTestRunCompletion(TestResults testResults)
        {
            testResults.FormatValuesForSQL();
            // Build Query for insert status 
            string updateQuery = "UPDATE " + TESTRESULTS + " SET " + CTestResults.TEST_RESULT + " = '" + testResults.TEST_RESULT + "', "
               + CTestResults.ISSUE_TYPE + " = '" + testResults.ISSUE_TYPE + "', "
               + CTestResults.TEST_ENDTIME + " = " + testResults.TEST_ENDTIME + ", " + CTestResults.LASTUPDATE_TIMESTAMP + " = "
               + testResults.LASTUPDATE_TIMESTAMP + " WHERE " + CTestResults.TESTRUN_ID + " = " + testResults.TESTRUN_ID;

            FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
            frameworkLibrary.ExecuteSQLWriteCommand(updateQuery, codedUIDbConn);

            // Calculate test duration and insert 
            updateQuery = "UPDATE " + TESTRESULTS + " SET " + CTestResults.TEST_DURATION + " = " + testResults.TEST_DURATION
                        + " WHERE " + CTestResults.TESTRUN_ID + " = " + testResults.TESTRUN_ID;
            sqlCommand = new SqlCommand(updateQuery, codedUIDbConn);

            frameworkLibrary.ExecuteSQLWriteCommand(updateQuery, codedUIDbConn);
        }

        /// <summary>
        /// MEthod to Insert a new Record for every iteration. Will create and assing a Unique test id for each row 
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        /// <param name="testResults"></param>
        public void InsertStartTestRunRecord(TestResults testResults)
        {
            int probableNewRunID = 0;
            bool retryWithNewRunID = true;
            FrameworkLibrary frameworkLibrary = new FrameworkLibrary();

            testResults.FormatValuesForSQL();

            while (retryWithNewRunID)
                try
                {
                    TestResultInformation objTestResultInformation = new TestResultInformation();
                    objTestResultInformation.BATCHRUN_ID = testResults.BATCHRUN_ID;
                    objTestResultInformation.RELEASE_NAME = testResults.RELEASE_NAME;
                    objTestResultInformation.CODEDUI_TEST_NAME = testResults.CODEDUI_TEST_NAME;
                    objTestResultInformation.TEST_ITERATION = testResults.TEST_ITERATION;

                    TestResultInformation testResultInformation = GetTestResultDetails(objTestResultInformation);

                    if (testResultInformation.IS_RECORD_AVILABLE)
                    {
                        currentRunID = testResultInformation.TESTRUN_ID;
                        retryWithNewRunID = false;
                        DeleteTestStepDetailsByTest_RunID();
                    }
                    else
                    {
                        probableNewRunID = GenerateARunID();
                        string insertQuery = "INSERT INTO " + TESTRESULTS + "(" + CTestResults.TESTRUN_ID + "," + CTestResults.BATCHRUN_ID + ","
                                             + CTestResults.FUNCTIONAL_TC_NAME + "," + CTestResults.WORKSTREAM + ","
                                             + CTestResults.RUN_CATEGORY + "," + CTestResults.TESTCASE_CATEGORY + ","
                                             + CTestResults.CODEDUI_TEST_NAME + "," + CTestResults.CODEDUI_TEST_DESCRIPTIPON + ","
                                             + CTestResults.TEST_RESULT + "," + CTestResults.ISSUE_TYPE + "," + CTestResults.TEST_ITERATION + ","
                                             + CTestResults.TEST_STARTTIME + "," + CTestResults.LASTUPDATE_TIMESTAMP + "," + CTestResults.FUNCTIONAL_DESC + ", " + CTestResults.ENVIRONMENT + ", " + CTestResults.FUNCTIONALITY_IMPACTED + ", " + CTestResults.RELEASE_NAME + ", " + CTestResults.TEST_DATA_TYPE + ", " + CTestResults.TEST_DATA_CATEGORY + ") VALUES (" +
                                             +probableNewRunID + ",'" + testResults.BATCHRUN_ID + "','"
                                             + testResults.FUNCTIONAL_TC_NAME + "','"
                                             + testResults.WORKSTREAM + "','" + testResults.RUN_CATEGORY + "','" + testResults.TESTCASE_CATEGORY + "','"
                                             + testResults.CODEDUI_TEST_NAME + "','"
                                             + testResults.CODEDUI_TEST_DESCRIPTIPON + "','" + testResults.TEST_RESULT + "','" + testResults.ISSUE_TYPE + "','"
                                             + testResults.TEST_ITERATION + "'," + testResults.TEST_STARTTIME + ","
                                             + testResults.LASTUPDATE_TIMESTAMP + ",'" + testResults.FUNCTIONAL_DESC + "','" + testResults.ENVIRONMENT + "','" + testResults.FUNCTIONALITY_IMPACTED + "','" + testResults.RELEASE_NAME + "','" + testResults.TEST_DATA_TYPE + "','" + testResults.TEST_DATA_CATEGORY + "')";

                        frameworkLibrary.ExecuteSQLWriteCommand(insertQuery, codedUIDbConn);
                        currentRunID = probableNewRunID.ToString();
                        retryWithNewRunID = false;
                    }
                }
                catch (SqlException sqlExcelption)
                {
                    if (sqlExcelption.Message.Contains("Cannot insert duplicate key"))
                    {
                        retryWithNewRunID = true;
                    }
                    else
                    {
                        retryWithNewRunID = false;
                        throw new Exception("Issues in Inserting New Run Results to Coded UI - Digital DB. Exception: " + sqlExcelption.Message);
                    }
                }
        }

        public TestResultInformation GetTestResultDetails(TestResultInformation TestResultInformation)
        {
            TestResultInformation objResultInformation = new TestResultInformation();
            try
            {
                string query = "SELECT [AssetID] FROM " + ReportFactory.TESTRESULTS + " where [BATCHRUN_ID]='" + TestResultInformation.BATCHRUN_ID + "' and [CODEDUI_TEST_NAME]='" + TestResultInformation.CODEDUI_TEST_NAME + "' and [TEST_ITERATION]='" + TestResultInformation.TEST_ITERATION + "'";

                codedUIDbConn.Open();
                sqlDataAdapter = new SqlDataAdapter(query, codedUIDbConn);
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);

                //Check if rows are returned 
                if (dataSet.Tables[0].Rows.Count != 0)
                {
                    DataRow row = dataSet.Tables[0].Rows[0];
                    objResultInformation.TESTRUN_ID = row["AssetID"].ToString().Trim();
                    objResultInformation.IS_RECORD_AVILABLE = true;
                }
            }
            catch
            {
                codedUIDbConn.Close();
            }
            codedUIDbConn.Close();
            return objResultInformation;
        }

        /// <summary>
        /// Get test result details By TestRunId.
        /// </summary>
        /// <author> RXK4098 - Ramesh Kandasamy </author>       
        public DataTable GetTestResultDetailsByTestRunId(string AssetId)
        {
            DataTable objTestResultDetails = new DataTable();
            try
            {
                codedUIDbConn.Open();
                string query = "SELECT [AssetID],[FUNCTIONAL_TC_NAME],[WORKSTREAM],[RUN_CATEGORY],[TESTCASE_CATEGORY],[CODEDUI_TEST_NAME],[TEST_RESULT] FROM[dbo].[TEST_RESULTS] where AssetID =" + AssetId;
                sqlDataAdapter = new SqlDataAdapter(query, codedUIDbConn);
                sqlDataAdapter.Fill(objTestResultDetails);
            }
            catch
            {
                codedUIDbConn.Close();
            }
            codedUIDbConn.Close();
            return objTestResultDetails;
        }

        /// <summary>
        /// Get emailid details
        /// </summary>
        /// <author> RXK4098 - Ramesh Kandasamy </author>       
        public DataTable GetEmailIdDetails(string AddressType)
        {
            DataTable objTestDataDetails = new DataTable();

            try
            {
                codedUIDbConn.Open();
                string query = "SELECT [EmailID] FROM [CodedUI].[dbo].[EmailDetails] where AddressType = '" + AddressType + "' and IsActive = 'true'";
                sqlDataAdapter = new SqlDataAdapter(query, codedUIDbConn);
                sqlDataAdapter.Fill(objTestDataDetails);
            }
            catch
            {
                codedUIDbConn.Close();
            }
            codedUIDbConn.Close();
            return objTestDataDetails;
        }



        /// <summary>
        /// Update Results Comment
        /// </summary>
        /// <param name="comments">Comment to Add in Result Log</param>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void UpdateTestResultComments(string comments)
        {
            FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
            try
            {
                string updateQuery = "UPDATE " + TESTRESULTS + " SET " + CTestResults.COMMENTS
                        + " = '" + comments + "' WHERE " + CTestResults.TESTRUN_ID + " = " + currentRunID;
                frameworkLibrary.ExecuteSQLWriteCommand(updateQuery, codedUIDbConn);
            }
            catch (Exception e)
            {
                Console.Error.WriteLine("Exception in Updating Result Comments - " + e.Message);
                frameworkLibrary.UpdateTestLog("Error", "Exception in Updating Result Comments - " + e.Message, Status.WARNING);
            }
        }

        /// <summary>
        /// Delete Test Step Details By Test_RunID.
        /// </summary>      

        public void DeleteTestStepDetailsByTest_RunID()
        {
            FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
            try
            {
                string deleteQuery = "DELETE FROM " + TESTSTEPDETAILS + " WHERE " + CTestStepDetails.TESTRUN_ID + " = " + currentRunID;
                frameworkLibrary.ExecuteSQLWriteCommand(deleteQuery, codedUIDbConn);
            }
            catch (Exception e)
            {
                Console.Error.WriteLine("Exception in deleting step details - " + e.Message);
                frameworkLibrary.UpdateTestLog("Error", "Exception in deleting step details - " + e.Message, Status.WARNING);
            }
        }

        /// <summary>
        /// Update Iteration Group ID
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void UpdateIterationGroupID()
        {
            int probableNewGroupingID = iterationGroupingID;
            bool retryWithNewRunID = true;

            FrameworkLibrary frameworkLibrary = new FrameworkLibrary();

            while (retryWithNewRunID)
            {
                try
                {
                    if (iterationGroupingID == 0)
                    {
                        probableNewGroupingID = GetNewIDFromTable(TESTRESULTS, CTestResults.ITERATIONGROUPING_ID);
                    }

                    string updateQuery = "UPDATE " + TESTRESULTS + " SET " + CTestResults.ITERATIONGROUPING_ID
                        + " = " + probableNewGroupingID + " WHERE " + CTestResults.TESTRUN_ID + " = " + currentRunID;

                    frameworkLibrary.ExecuteSQLWriteCommand(updateQuery, codedUIDbConn);

                    if (iterationGroupingID == 0)
                    {
                        // Check for Any Parallel Insertions (Duplicate) 
                        if (!IsDuplicateIterationGrpIdFound(probableNewGroupingID))
                        {
                            ReportFactory.iterationGroupingID = Convert.ToInt32(probableNewGroupingID);
                            retryWithNewRunID = false;
                        }
                    }
                    else
                    {
                        retryWithNewRunID = false;
                    }
                }
                catch (SqlException sqlExcelption)
                {
                    retryWithNewRunID = false;
                    throw new Exception("Issues in Inserting New Run Results to Coded UI - Digital DB. Exception: " + sqlExcelption.Message);
                }
            }
        }

        /// <summary>
        /// Method to get the Maximum  ID from Coded UI DB. Used to generate ID
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        /// <returns name = "ID" > return new id tried to be inserted </returns>
        private static int GetNewIDFromTable(string tableName, string maxIDColumnName)
        {
            if (codedUIDbConn.State != System.Data.ConnectionState.Open)
            {
                codedUIDbConn.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("SELECT ISNULL(MAX(" + maxIDColumnName + "),0) as MAXID from " + tableName, codedUIDbConn);
            sqlDataReader = sqlCommand.ExecuteReader();
            sqlDataReader.Read();
            // Get Max id and Increment by One
            int probablenewID = ((int)sqlDataReader["MAXID"]) + 1;
            codedUIDbConn.Close();
            return probablenewID;
        }

        /// <summary>
        /// Method to Check for Duplicate Iteration Grouping ID in multiple test cases. 
        /// </summary>
        /// <param name="iterationGroupingID"></param>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        /// <returns name="isDuplicateFound"> Will return true if duplicate Iteration Grouping ID found </returns>
        private static bool IsDuplicateIterationGrpIdFound(int iterationGroupingID)
        {
            if (codedUIDbConn.State != System.Data.ConnectionState.Open)
            {
                codedUIDbConn.Open();
            }
            // Get Distinct Test Cases count 
            string checkDuplicateQuery = "SELECT COUNT (DISTINCT " + CTestResults.TESTRUN_ID + ") AS TCCOUNT FROM " + TESTRESULTS
                + " WHERE " + CTestResults.ITERATIONGROUPING_ID + " = " + iterationGroupingID;
            // Execute Query 
            SqlCommand sqlCommand = new SqlCommand(checkDuplicateQuery, codedUIDbConn);
            sqlDataReader = sqlCommand.ExecuteReader();
            sqlDataReader.Read();

            int tcCount = ((int)sqlDataReader["TCCOUNT"]);
            codedUIDbConn.Close();
            // Check and return if distinct test case count is always one 
            return (tcCount != 1);
        }

        /// <summary>
        /// Method to get the Maximum Run ID from DB. Used to generate Uniqiue Test Run ID
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        /// <returns name = "RunId" > return new run id tried to be inserted </returns>
        private static int GenerateARunID()
        {
            if (codedUIDbConn.State != System.Data.ConnectionState.Open)
            {
                codedUIDbConn.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("SELECT ISNULL(MAX(" + CTestResults.TESTRUN_ID + "), 0) as MAXID from " + TESTRESULTS, codedUIDbConn);
            sqlDataReader = sqlCommand.ExecuteReader();
            sqlDataReader.Read();
            // Get Max id and Increment by One
            int probablenewID = ((int)sqlDataReader["MAXID"]) + 1;
            codedUIDbConn.Close();
            return probablenewID;
        }


        /// <summary>
        /// Method to Insert BINARY Data into Database 
        /// </summary>
        /// <param name="imageByteData"> Byte Data of Image to be saved in DB </param>
        /// <returns name="IMAGEID"> Image Id of the Inserted Image From ScreenShot table </returns>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        public int InsertByteDataIntoDB(byte[] imageByteData)
        {
            bool retryWithNewID = true;
            int probableNewRunID, curImageID = 0;
            while (retryWithNewID)
            {
                try
                {
                    probableNewRunID = GenerateAnImageID();
                    string insertQuery = "INSERT INTO " + SCREENSHOTS + "(" + CScreenShots.IMAGE_ID + "," + CScreenShots.IMAGE_DATA
                        + ") VALUES (" + probableNewRunID + ", @ImageData)";

                    SqlCommand sqlCommand = new SqlCommand(insertQuery, ReportFactory.codedUIDbConn);
                    sqlCommand.Parameters.Add(new SqlParameter("@ImageData", (object)imageByteData));

                    codedUIDbConn.Open();
                    sqlCommand.ExecuteNonQuery();
                    codedUIDbConn.Close();

                    curImageID = probableNewRunID;
                    retryWithNewID = false;
                }
                catch (SqlException sqlExcelption)
                {
                    if (sqlExcelption.Message.Contains("Cannot insert duplicate key"))
                    {
                        retryWithNewID = true;
                    }
                    else
                    {
                        retryWithNewID = false;
                        throw new Exception("Issues in Inserting New Run Results to Coded UI - Digital DB. Exception: " + sqlExcelption.Message);
                    }
                }
            }
            return curImageID;
        }

        /// <summary>
        /// Method to get the Maximum Image ID from DB. Used to generate Uniqiue Image ID
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        /// <returns></returns>
        private static int GenerateAnImageID()
        {
            if (codedUIDbConn.State != System.Data.ConnectionState.Open)
            {
                codedUIDbConn.Open();
            }
            SqlCommand sqlCommand = new SqlCommand("SELECT ISNULL(MAX(" + CScreenShots.IMAGE_ID + "),0) as MAXID from " + SCREENSHOTS, codedUIDbConn);
            sqlDataReader = sqlCommand.ExecuteReader();
            sqlDataReader.Read();

            // Get Max id and Increment by One
            int probablenewID = ((int)sqlDataReader["MAXID"]) + 1;
            codedUIDbConn.Close();
            return probablenewID;
        }

        /// <summary>
        /// Sample Method to Read Content
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public static void DoASampleRead()
        {
            codedUIDbConn.Open();
            string sqlCommandString = "SELECT * FROM TEST_RESULTS";

            sqlCommand = new SqlCommand(sqlCommandString, codedUIDbConn);

            // For Reading 
            sqlDataReader = sqlCommand.ExecuteReader();
            //Loog through Rows
            while (sqlDataReader.Read())
            {
                Console.WriteLine(sqlDataReader["TESTRUN_ID"].ToString());
                int id = (int)sqlDataReader["TESTRUN_ID"];
                Console.WriteLine(id - 1);
            }
            Console.ReadLine();
            codedUIDbConn.Close();
        }
    }

}
