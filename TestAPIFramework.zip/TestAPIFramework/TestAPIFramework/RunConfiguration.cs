﻿using System.Collections.Generic;
using System.IO;
using Framework_Reporting;
using System.Diagnostics;
using OpenQA.Selenium;
using System;
using OpenQA.Selenium.Remote;

namespace TestAPIFramework
{
    /// <summary>
    /// Class file Created to Hold Run Configuration Values 
    /// Contents of this class should be Static and can referred Globally
    /// </summary>
    /// <author>GXP4288 - Gowrisankar Palanisamy, GXS8571 Gnaneswar Sodini</author>
    public class RunConfiguration
    {
        //  SELENIUM - DEVOPS AUTOMATION FRAMEWORK SETTINGS
        public static IWebDriver driver;
        public static bool reuseWebDriver = false;
        public static RemoteWebDriver perfectoDriver;
        public static DriverAppUtilLibrary appUtilLibrary;
        public static DriverBusinessLibrary driverBusinessLibrary;
        //public static string projectSolutionPath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;

        //public static string driverServersPath = Directory.GetDirectories(projectSolutionPath, "DriverServers", SearchOption.AllDirectories)[0];
        public static string driverServersPath = @"C:\\Users\\GXS8571\\source\\repos\\Tools_DVPSAutomation\\Tools_Automated\\FrameworkLibrary\\DriverServers";
        ////DRIVER SERVERS PATH
        public static string chromeDriverPath = driverServersPath + @"\chromedriver_2.38";
        public static string alternativeChromeDriverPath = driverServersPath + @"\chromedriver_2.37";
        public static string ieDriverPath = driverServersPath + @"\internetexplorer";
        public static string firefoxDriverPath = driverServersPath + @"\firefox";

        //  DEVOPS AUTOMATION FRAMEWORK SETTINGS
        public static int stepNumber = 1;
        public const string projectName = "Humana Connection Hub";
        public static FrameworkLibrary frameworkLibrary = new FrameworkLibrary();

        // GLOBAL SETTINGS
        public static int pageLoadTimeOut = 100;
        public static int loginTimeOut = 150;
        public static int objectSearchTimeout = 15;

        // ENVIRONMENT CONFIGURATIONS
        public static string envToken = "INT";
        public static string envURL = "NOTINITIALIZEDYET";
        public static bool enabledNewDashboard = true;

        // WEB EMULATION SETTINGS
        public static bool useWebEmulationLogin = false;
        public static string webEmulationStartUrl = "https://hi.humana.com/hss/landing";

        // Browser Reuse Settings
        public static Boolean reUseBrowserInstance = false;
        public static Boolean navigateToBaseIfBrwrReUsed = false;

        //PERFECTO SETTINGS
        public static bool UsePerfecto = false;

        //GRID SETTINGS
        public static bool UserGrid = false;


        //API SETTINGS
        public static bool UseApi = false;

        // REPORT LOGS
        public static bool logAssertFailAtEnd = false;
        public static string testFailMessageInInitialize = "";
        public static string failureLog = "Fail Summary : ";
        public static string currentBrowser = "IE";
        public static bool enableExcelLog = false;
        public static bool enableHtmlLog = true;
        public static bool sendMail = false;
        public static bool useApi = false;
        public static string _baseUrl = "";
        public static bool enableOverrideInHtml = true;
        public static bool enableDynamicBatchRunId = true;
        public static Report htmlReport;
        public static ReportSettings reportSettings;
        public const string excelLogBaseFolder = @"\\RSC.HUMAD.COM\QDRIVE\D937\F11701\SHARED\CompanyRead\IDE SIT Automation\CodedUITests";
        public static string htmlReportPath = @"Q:\D937\F11701\SHARED\CompanyRead\IDE SIT Automation\CodedUITests\HtmlResults\";
        public static string batchRunId = "";
        public static string authorName = "";
        public static string htmlTestStatus = "Passed";
        public static IssueType issueType = IssueType.AutomationScript;
        public static string issueDetails = "";
        public static Stopwatch stopwatch;
        public static string htmlLogCurrentTestCaseName = "";
        public static int iterationPassCount = 0;
        public static int iterationFailCount = 0;
        public static int testsPlannedCount = 0;
        public static string dbName = "";
        

        // HTML REPORTS
        public static bool useHtmlReport = false;
        public static string basePath = @"\\RSC.HUMAD.COM\QDRIVE\D937\F11701\SHARED\CompanyRead\IDE SIT Automation\CodedUITests\Results\";
        public static string sFileName;
        public static Dictionary<string, string> ResultsKey = new Dictionary<string, string>();

        // DB REPORTS 
        public static bool logTestReportToDB = false;
        public static bool getTestDataFromDB = false;
        public static bool isProdDatabase = false;
        public static bool storeScreenShotInDB = false;
        public static string[] TESTDATA_TABLE_DETAILS = new string[] { "TESTDATA_GENERAL", "TESTDATA_ENVSPECIFIC", "TESTDATA_MEGANAVIGATION", "TESTDATA_CONTROLS", "TESTDATA_LINKSNAVIGATION" };
        public static string[] TESTDATA_TABLE_API = new string[] { "WebService_TestData" };

        // SCREENSHOTS CONFIGURATION 
        public static string screenShotFolder = string.Empty; // Initialized from App.Config File Specific to Workstream 
        public static dynamic targetScreenShotObject;

        //X509 Certificates
        public static bool certExists = false;
        public static string certFilePath = string.Empty;
        public static string certFileName = string.Empty;
        public static string certPassword = string.Empty;

        // DATA DRIVEN
        public static TestDataFactory testDataFactory = new TestDataFactory();
        public static TestDBDataFactory testDBDataFactory = new TestDBDataFactory();
        public static TestCaseContext testCaseContext = new TestCaseContext();
        public static string testCaseSummaryDescription = "";

        // Directory Seperater : to be used as local (\) and webserver (/) appropriately
        public static string dirSep = Path.DirectorySeparatorChar.ToString();
    }

    public class TestCaseContext
    {
        public string testDataFolder = "|DataDirectory|";
        public string testDataFileName = "";
        public string testIterationFilePath = "|DataDirectory|" + RunConfiguration.dirSep + "TestIteration.xml";
        public string testGeneralDataSheet = "General_DataSheet";
        public string apiControlsTable = "WebService_TestData";
        public string testDataControlsTable = "Controls_Data";
        public string testDataEnvSpecificDataSheet = "EnvSpecific_DataSheet";
        public string testDataMegaNPromoDataSheet = "MegaNPromo_Data";
        public string testDataLinksNavigationTable = "LinksNav_Data";
        public string testProjectName = "";
        // Level 1 & 2 Namespace Names of the Test Method
        public string[] namespaceOfTestMethod = new string[2];
        public string testCaseName = "";
        public string testDataID = "";
        public string fullyQualifiedTestName = "";
        public string functionalTestName = "";
        public string testCaseDescription = "";
        public string functionalityImpacted = "";
        public string testDataType = "";
        public string testDataCategory = "";
        public string testCategory = "";
        public int currentIteration = 0;
        public int totalIteration = 0;
        public int testStepNumber = 0;
        public bool skipCurrentIteration = false;
        public int iterationGroupID = 0;
    }

    public class AttributeReferences
    {
        #region Constant Decleration
        /// =====================================
        /// Constants - Data Source Providers
        /// =====================================
        public const string PROVIDERNAME_XML = "Microsoft.VisualStudio.TestTools.DataSource.XML";
        public const string PROVIDERNAME_OLEDB = "System.Data.OleDB";

        /// =====================================
        /// Constants - Deployment Items & Iteration Settings
        /// =====================================
        public const string DeployItemIterationFile = "TestData\\TestIteration.xml";
        public const string DataSourceIterationFile = "|DataDirectory|\\TestIteration.xml";

        /// =====================================
        /// Constants - Tests Category
        /// =====================================
        public const string ENVHEALTHCHECKUP = "ENV_HEALTHCHECKUP";

        // Finders
        public const string FINDER_CI = "FINDER_CI";
        public const string FINDER_BVT = "FINDER_BVT";
        public const string FINDER_SMOKE = "FINDER_SMOKE";
        public const string FINDER_REGRESSION = "FINDER_REGRESSION";
        public const string FINDER_READONLY_PROD = "FINDER_READONLY_PROD";

        // Tools CarePlus
        public const string TOOLS_CAREPLUS_BVT = "TOOLS_CAREPLUS_BVT";
        public const string TOOLS_CAREPLUS_SMOKE = "TOOLS_CAREPLUS_SMOKE";
        public const string TOOLS_CAREPLUS_REGRESSION = "TOOLS_CAREPLUS_REGRESSION";

        // Save and Resume
        public const string SAVEANDRESUME_BVT = "SAVEANDRESUME_BVT";
        public const string SAVEANDRESUME_SMOKE = "SAVEANDRESUME_SMOKE";
        public const string SAVEANDRESUME_REGRESSION = "SAVEANDRESUME_REGRESSION";

        // Pharmacy Finder
        public const string PHARMACY_CI = "PHARMACY_CI";
        public const string PHARMACY_BVT = "PHARMACY_BVT";
        public const string PHARMACY_SMOKE = "PHARMACY_SMOKE";
        public const string PHARMACY_REGRESSION = "PHARMACY_REGRESSION";
        // Members
        public const string MEMBERS_CI = "MEMBERS_CI";
        public const string MEMBERS_BVT = "MEMBERS_BVT";
        public const string MEMBERS_BVT2 = "MEMBERS_BVT2";
        public const string MEMBERS_SMOKE = "MEMBERS_SMOKE";
        public const string MEMBER_SMOKE2 = "MEMBER_SMOKE2";
        public const string MEMBERS_REGRESSION = "MEMBERS_REGRESSION";
        public const string MEMBERS_READONLY = "MEMBERS_READONLY";
        public const string MEMBERS_CAREPLUSREADONLY = "MEMBERS_CAREPLUSREADONLY";
        public const string MEMBERS_INSPRINT = "MEMBERS_INSPRINT";
        public const string MEMBER_CAREPLUS_BVT = "MEMBERS_CAREPLUS_BVT";
        public const string MEMBER_CAREPLUS_SMOKE = "MEMBERS_CAREPLUS_SMOKE";


        //MEMBERS INSPRINT
        public const string MEMBERS_INSPRINT1802 = "MEMBERS_INSPRINT1802";

        //Members WorkStream
        public const string MEMBERS_CLAIMS = "MEMBERS_CLAIMS";

        // Go365
        public const string GO365_CI = "GO365_CI";
        public const string GO365_BVT = "GO365_BVT";
        public const string GO365_SMOKE = "GO365_SMOKE";
        public const string GO365_REGRESSION = "GO365_REGRESSION";

        // Caregiver
        public const string CAREGIVER_CI = "CAREGIVER_CI";
        public const string CAREGIVER_BVT = "CAREGIVER_BVT";
        public const string CAREGIVER_SMOKE = "CAREGIVER_SMOKE";
        public const string CAREGIVER_REGRESSION = "CAREGIVER_REGRESSION";
        public const string CAREGIVER_READONLY_PROD = "CAREGIVER_READONLY_PROD";

        // Tools
        public const string TOOLS_CI = "TOOLS_CI";
        public const string TOOLS_BVT = "TOOLS_BVT";
        public const string TOOLS_SMOKE = "TOOLS_SMOKE";
        public const string TOOLS_REGRESSION = "TOOLS_REGRESSION";
        public const string TOOLS_READONLY_PROD = "TOOLS_READONLY_PROD";
        public const string TOOLS_INSPRINT = "TOOLS_INSPRINT";
        public const string TOOLS_INSPRINT_1808 = "TOOLS_INSPRINT_1808";
        
        // IDCC
        public const string IDCC_CI = "IDCC_CI";
        public const string IDCC_BVT = "IDCC_BVT";
        public const string IDCC_SMOKE = "IDCC_SMOKE";
        public const string IDCC_REGRESSION = "IDCC_REGRESSION";

        // HCOM
        public const string HCOM_CI = "HCOM_CI";
        public const string HCOM_BVT = "HCOM_BVT";
        public const string HCOM_SMOKE = "HCOM_SMOKE";
        public const string HCOM_REGRESSION = "HCOM_REGRESSION";
        public const string HCOM_READONLY_PROD = "HCOM_READONLY_PROD";
        public const string HCOM_CAREPLUS = "HCOM_CAREPLUS";
        public const string HCOM_CAREPLUS_BVT = "HCOM_CAREPLUS_BVT";
        public const string HCOM_CAREPLUS_SMOKE = "HCOM_CAREPLUS_SMOKE";
        public const string HCOM_CAREPLUS_REGRESSION = "HCOM_CAREPLUS_REGRESSION";

        // HPOC
        public const string HPOC_BVT = "HPOC_BVT";
        public const string HPOC_SMOKE = "HPOC_SMOKE";
        public const string HPOC_REGRESSION = "HPOC_REGRESSION";
        public const string HPOC_READONLY_PROD = "HPOC_READONLY_PROD";

        // Employer
        public const string EMPLOYER_CI = "EMPLOYER_CI";
        public const string EMPLOYER_BVT = "EMPLOYERS_BVT";
        public const string EMPLOYER_SMOKE = "EMPLOYER_SMOKE";
        public const string EMPLOYER_REGRESSION = "EMPLOYER_REGRESSION";

        /// Constants - Work Streams 
        /// =====================================
        public const string HUMANACOM = "HCOM";
        public const string MEMBER = "MEMBERS";
        public const string CAREGIVER = "CAREGIVER";
        public const string HPOC = "HPOC";
        public const string TOOLS = "TOOLS";
        public const string FINDERS = "FINDERS";
        public const string EMPLOYER = "EMPLOYER";
        public const string GO365 = "GO365";
        public const string IDCC = "IDCC";
        public const string TOOLS_CAREPLUS = "TOOLS_CAREPLUS";
        public const string PHARMACY = "PHARMACY";

        /// =====================================
        /// Constants - Iterations
        /// =====================================
        public const string ONE = "One";
        public const string TWO = "Two";
        public const string THREE = "Three";
        public const string FOUR = "Four";
        public const string FIVE = "Five";
        public const string SIX = "Six";
        public const string SEVEN = "Seven";
        public const string EIGHT = "Eight";
        public const string NINE = "Nine";
        public const string TEN = "Ten";
        public const string ELEVEN = "Eleven";
        public const string TWELVE = "Twelve";
        public const string FOURTEEN = "Fourteen";
        public const string FIFTEEN = "Fifteen";
        public const string THIRTEEN = "Thirteen";
        public const string TWENTY = "Twenty";
        public const string TWENTYFIVE = "TwentyFive";
        public const string TWENTYONE = "TwentyOne";
        public const string TWENTYTWO = "TwentyTwo";
        public const string TWENTYNINE = "TwentyNine";
        public const string TWENTYSEVEN = "TwentySeven";
        public const string FIFTY = "Fifty";
        public const string FIFTYSIX = "FiftySix";
        public const string THIRTY = "Thirty";
        public const string SEVENTEEN = "Seventeen";

        /// =====================================
        /// Constants - Majorly used DT Columns
        /// =====================================
        public const string FUNCTCNAME = "FunctionalTCID";
        public const string FUNCTIONALITYIMPACTED = "FunctionalityImpacted";
        public const string TEST_DATA_TYPE = "TestDataType";
        public const string TEST_DATA_CATEGORY = "TestDataCategory";
        public const string TESTCASEDESCRIPTION = "TestValidationDescription";
        public const string TESTCASESUMMARYDESC = "TestSummaryDescription";
        public const string TESTCATEGORY = "TestCategory";
        public const string AUTHORNAME = "Developer";
        public const string SKIPROW = "SkipRow";
        public const string REMARKS = "Remarks";
        public const string TESTDESC = "TestCaseDescription";
        /// =====================================

        // Common
        public const string OUTOFSCOPE = "OUTOFSCOPE";
        /// =====================================
        #endregion
    }

    // Test Execution Status 
    public enum Status
    {
        PASS,
        FAIL,
        WARNING,
        DONE,
        SCREENSHOT,
        INCONCLUSIVE,
        DEBUG,
        COOKIE
    };

    // Failure Issue Type
    public enum IssueType
    {
        ApplicationDefect,
        AutomationScript,
        Environmental,
        Data
    };
}
