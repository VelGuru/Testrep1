﻿using OpenQA.Selenium;

namespace TestAPIFramework.UIMap
{
    /// <summary>
    /// Generic UI Test Controls - Property Collection/Page Object Model
    /// </summary>
    public partial class GenericLocators
    {
        #region PropertyCollection

        // Links Name
        public Links LinksList { get { return linksList; } }

        // Page Header
        public static PageHeader PageHeaders { get { return pageHeaders; }  }

        // Header Sections
        public static UIParentSection UIParentSections { get { return uIParentSections; } }

        public static GlobalErrorsCollection GlobalErrorControls {  get { return globalErrorsCollection; } }

        private Links linksList = new Links();
        private static PageHeader pageHeaders = new PageHeader();
        private static UIParentSection uIParentSections = new UIParentSection();
        private static GlobalErrorsCollection globalErrorsCollection = new GlobalErrorsCollection();
        #endregion

        // Links Collection Class
        public class Links
        {
        }

        // Page Header Collection Class
        public class PageHeader
        {
        }

        public class UIParentSection
        {
            public By UIFooterSection
            {
                get { return By.TagName("footer"); }
            }

            public By UIHeaderSection
            {
                get { return By.TagName("header"); }
            }

            public By UIMegaNavigationSection
            {
                get { return By.CssSelector("nav[class*='primary-navigation-container']"); }
            }
        }

        public class GlobalErrorsCollection
        {
            string errorMessage = "We're sorry some of the information you requested is unavailable. We're working to resolve the issue. Please try again later.";

            string errorMessage2 = "Due to technical issues, we cannot display all of your information. Please try again later.";
            public By UIWeAreSorrySomeOfInfo
            {
                get { return By.XPath(".//span[.='" + errorMessage + "']"); }
            }

            public By UITechnicalError
            {
                get { return By.XPath(".//span[.='" + errorMessage2 + "']"); }
            }

            public By UIWeAreSorryThePageIsNotHere
            {
                get { return By.XPath(".//p[.='We’re sorry. The page you requested isn’t here anymore.']"); }
            }
        }

    }
}