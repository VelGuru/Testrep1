﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Data;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Data.SqlClient;
using System.Threading;
using Framework_Reporting;
using Framework_Utilities;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;


namespace TestAPIFramework
{
    /// <summary>
    /// Class file used to store Application related Utilities.
    /// </summary>
    /// <author>GXP4288 - Gowrisankar Palanisamy </author>
    /// <comments>This Library should not process Business Logic
    /// Should not invoke Function outside of Framework Library 
    /// </comments>
    public class FrameworkLibrary
    {
        public RemoteWebDriver perfectoDriver;
        /// <summary>
        /// To Initialize Run Configuration, Framework Settings, Browser [Called form TestInitialize Method]
        /// </summary>          
        /// <param name="tContext">TestContext instance for the current Test Case</param>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void InitializeRunConfigurations(TestContext tContext)
        {
            #region Initialize Iteration Number, Data Table and TestContext Values
            // Initialize Current Iteration Number, Step Number
            RunConfiguration.testCaseContext.currentIteration = tContext.DataRow.Table.Rows.IndexOf(tContext.DataRow);
            RunConfiguration.stepNumber = 1;
            if (RunConfiguration.testCaseContext.currentIteration == 0)
            {
                // Initialize Test Case Name and Total Iterations from TestContext
                RunConfiguration.testCaseContext.testCaseName = tContext.TestName.ToString();
                RunConfiguration.testCaseContext.totalIteration = tContext.DataRow.Table.Rows.Count;
                RunConfiguration.testCaseContext.fullyQualifiedTestName = tContext.FullyQualifiedTestClassName + "." + RunConfiguration.testCaseContext.testCaseName;
                RunConfiguration.testCaseContext.testProjectName = tContext.FullyQualifiedTestClassName.Split('.')[0];
                // Fetch Namespace of test method - Used for Identify Test Data sheet and Excel Logs
                var fullyQualifiedNameInArray = tContext.FullyQualifiedTestClassName.Split('.');
                RunConfiguration.testCaseContext.namespaceOfTestMethod[0] = fullyQualifiedNameInArray[fullyQualifiedNameInArray.Length - 2];
                RunConfiguration.testCaseContext.namespaceOfTestMethod[1] = fullyQualifiedNameInArray[fullyQualifiedNameInArray.Length - 3];
                // Initialize from App Config Values 
                DetermineValuesFromAppConfig();

                // Initialize Data Table
                if (RunConfiguration.getTestDataFromDB && !RunConfiguration.useApi)
                {
                    InitializeDBDataTable();
                }
                else if (RunConfiguration.useApi && RunConfiguration.getTestDataFromDB)
                {
                    InitializeDBDataTable_API();
                }
                else if (RunConfiguration.useApi && !RunConfiguration.getTestDataFromDB)
                {
                    InitializeTestData_API_Excel();
                }
                else
                {
                    InitializeTestData();
                }



                // Initialize Test Category
                //RunConfiguration.testCaseContext.testCategory = GetCurrentTestCaseCategory();

                if (!RunConfiguration.getTestDataFromDB && !RunConfiguration.useApi)
                {
                    RunConfiguration.reuseWebDriver = GetBooleanFromFlag(GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "ReuseBrowser"));
                    //RunConfiguration.reuseWebDriver = GetBooleanFromFlag(GetTestData(RunConfiguration.testCaseContext.apiControlsTable, "ReuseBrowser"));
                }
            }
            #endregion

            #region Row Skip - Skip the Current Iteration if applicable
            if (!RunConfiguration.getTestDataFromDB & !RunConfiguration.useApi)
            {
                RunConfiguration.testCaseContext.skipCurrentIteration = GetBooleanFromFlag(GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.SKIPROW));
                if (RunConfiguration.testCaseContext.skipCurrentIteration)
                {
                    Console.WriteLine("Assert In Conclusive - Skipped ROW: " + (RunConfiguration.testCaseContext.currentIteration + 1));
                    Assert.Inconclusive("Row : " + (RunConfiguration.testCaseContext.currentIteration + 1) + " Skipped based on Data table Configuration");
                }
            }
            #endregion Row Skip - If Applicable

            #region HTML & EXCEL REPORTS
            // Initialize Html Reports
            InitializeHtmlReports();

            // Initialize Excel Settings
            RunConfiguration.testDataFactory.InitializeExcelLogSettigs();
            #endregion HTML & EXCEL REPORTS

            try
            {
                #region INITIALIZE TEST CASE PARAMETERS
                // Initilaize Test Case Parameters
                if (RunConfiguration.useApi)
                {
                    InitializeTestCaseParameters_API();
                }
                else
                {
                    InitializeTestCaseParameters();
                }
                #endregion INITIALIZE TEST CASE PARAMETERS

                #region DB REPORT
                if (RunConfiguration.logTestReportToDB)
                {
                    // Insert a New Test Run (Row) for each Iteration 
                    InsertCurrentRunDataBaseEntry();
                }
                #endregion DB REPORT
                if (RunConfiguration.useApi)
                {

                }
                else
                {
                    #region Initialize Environment and Launch Browser
                    // Initialize Env Token
                    InitializeEnvToken();
                }

                if (RunConfiguration.useApi)
                {

                }
                else
                {
                    // Initialize Current Environment details 
                    InitializeCurrentEnvironment();
                }

                //Initialize WebDriver
                if (!RunConfiguration.UserGrid && !RunConfiguration.useApi)
                {
                    InitializeWebDriver();
                }
                else
                {

                }


                //if (RunConfiguration.UsePerfecto)
                //{
                //    LaunchPerfecto();
                //}
                //else if (!RunConfiguration.UserGrid)
                //{
                //    InitializeWebDriver();
                //}

                #endregion Initialize Environment and Launch Browser
            }
            catch (AssertFailedException)
            {
                // Rethrow valid Assertion Exception
                throw;
            }
            catch (Exception e)
            {
                // Log Unhandled/Runtime Exceptions
                Console.Error.WriteLine("Exception: " + e.Message);
                UpdateTestLog("Error", "(Script Initial Error) InitializeRunConfigurations Exception : " + e.Message, Status.FAIL);
            }
        }

        /// <summary>
        /// Initlialize Test Case Parameters
        /// </summary>
        public void InitializeTestCaseParameters_API()
        {
            // Settings need to done for each Test Method [First Iteration]
            if (RunConfiguration.testCaseContext.currentIteration == 0)
            {
                #region TESTCASE DESCRIPTION
                try
                {
                    try
                    {
                        //RunConfiguration.testCaseContext.functionalityImpacted = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.FUNCTIONALITYIMPACTED);
                        RunConfiguration.testCaseContext.functionalityImpacted = "HELATH_CHECK_API";
                    }
                    catch (Exception)
                    {
                        RunConfiguration.testCaseContext.functionalityImpacted = string.Empty;
                    }
                    try
                    {
                        //RunConfiguration.testCaseContext.testDataType = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TEST_DATA_TYPE);
                        RunConfiguration.testCaseContext.testDataType = "TYPE1";
                    }
                    catch (Exception)
                    {
                        RunConfiguration.testCaseContext.testDataType = string.Empty;
                    }
                    try
                    {
                        //RunConfiguration.testCaseContext.testDataCategory = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TEST_DATA_CATEGORY);
                        RunConfiguration.testCaseContext.testDataCategory = "API";
                    }
                    catch (Exception)
                    {
                        RunConfiguration.testCaseContext.testDataCategory = string.Empty;
                    }
                    //RunConfiguration.testCaseSummaryDescription = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TESTCASESUMMARYDESC);
                    RunConfiguration.testCaseSummaryDescription = GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, AttributeReferences.REMARKS);
                }
                catch (Exception)
                {
                    RunConfiguration.testCaseSummaryDescription = "";
                }
                finally
                {
                    if (string.IsNullOrEmpty(RunConfiguration.testCaseSummaryDescription))
                    {
                        RunConfiguration.testCaseSummaryDescription = GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, AttributeReferences.REMARKS);
                    }
                }
                #endregion TESTCASE DESCRIPTION
            }
            #region Initialize Test Parameters
            RunConfiguration.testCaseContext.functionalTestName = GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, AttributeReferences.TESTDESC);


            RunConfiguration.testCaseContext.testCaseDescription = GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, AttributeReferences.REMARKS);
            if (RunConfiguration.enableHtmlLog)
            {
                RunConfiguration.htmlReport.UpdateTestLog("Description", RunConfiguration.testCaseContext.apiControlsTable, Framework_Reporting.Status.DONE);
            }
            try
            {
                //RunConfiguration.authorName = GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, AttributeReferences.AUTHORNAME);
            }
            catch (Exception)
            {
                // Column Name is not available - Optional
                RunConfiguration.authorName = "";
            }
            #endregion

        }

        /// <summary>
        /// Initlialize Test Case Parameters
        /// </summary>
        public void InitializeTestCaseParameters()
        {
            // Settings need to done for each Test Method [First Iteration]
            if (RunConfiguration.testCaseContext.currentIteration == 0)
            {
                #region TESTCASE DESCRIPTION
                try
                {
                    try
                    {
                        RunConfiguration.testCaseContext.functionalityImpacted = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.FUNCTIONALITYIMPACTED);
                    }
                    catch (Exception)
                    {
                        RunConfiguration.testCaseContext.functionalityImpacted = string.Empty;
                    }
                    try
                    {
                        RunConfiguration.testCaseContext.testDataType = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TEST_DATA_TYPE);
                    }
                    catch (Exception)
                    {
                        RunConfiguration.testCaseContext.testDataType = string.Empty;
                    }
                    try
                    {
                        RunConfiguration.testCaseContext.testDataCategory = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TEST_DATA_CATEGORY);
                    }
                    catch (Exception)
                    {
                        RunConfiguration.testCaseContext.testDataCategory = string.Empty;
                    }
                    RunConfiguration.testCaseSummaryDescription = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TESTCASESUMMARYDESC);
                }
                catch (Exception)
                {
                    RunConfiguration.testCaseSummaryDescription = "";
                }
                finally
                {
                    if (string.IsNullOrEmpty(RunConfiguration.testCaseSummaryDescription))
                    {
                        RunConfiguration.testCaseSummaryDescription = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TESTCASEDESCRIPTION);
                    }
                }
                #endregion TESTCASE DESCRIPTION
            }
            #region Initialize Test Parameters
            RunConfiguration.testCaseContext.functionalTestName = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.FUNCTCNAME);


            RunConfiguration.testCaseContext.testCaseDescription = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TESTCASEDESCRIPTION);
            if (RunConfiguration.enableHtmlLog)
            {
                RunConfiguration.htmlReport.UpdateTestLog("Description", RunConfiguration.testCaseContext.testCaseDescription, Framework_Reporting.Status.DONE);
            }
            try
            {
                RunConfiguration.authorName = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.AUTHORNAME);
            }
            catch (Exception)
            {
                // Column Name is not available - Optional
                RunConfiguration.authorName = "";
            }
            #endregion

        }

        /// <summary>
        /// Initialize Web Emulation
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void InitializeWebEmulation()
        {
            // WRITE LOGIC USING WEBDRIVER
            if (RunConfiguration.useWebEmulationLogin)
            {
                Assert.Fail("Web Emulation is not implemented in Selenium. Automation Team is working on this...");
            }
        }

        /// <summary>
        /// Initialize HTML REPORT & HTML Dashboard
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void InitializeHtmlReports()
        {
            if (RunConfiguration.enableHtmlLog)
            {
                if (RunConfiguration.testCaseContext.currentIteration == 0)
                {
                    // Update Pass & Fail Count
                    RunConfiguration.iterationPassCount = 0;
                    RunConfiguration.iterationFailCount = 0;
                    // Update BatchRunId Path
                    string htmlPath = RunConfiguration.htmlReportPath + RunConfiguration.batchRunId;
                    string runConfiguration = RunConfiguration.batchRunId;
                    if (RunConfiguration.enableDynamicBatchRunId)
                    {
                        string todayDate = Regex.Replace(GetTodayDateInISTFormat.ToString(), "/|:", "_").Split(' ')[0];
                        htmlPath = RunConfiguration.htmlReportPath + RunConfiguration.testCaseContext.testProjectName + todayDate;
                        runConfiguration = ReportFactory.currentRunCategory;
                    }

                    if (!Directory.Exists(htmlPath))
                    {
                        Directory.CreateDirectory(htmlPath);
                    }

                    // Start Timer
                    RunConfiguration.stopwatch = Stopwatch.StartNew();

                    string htmlSummaryPath = htmlPath + Util.GetFileSeparator() + "HTML Results" + Util.GetFileSeparator() + "Summary" + ".html";


                    RunConfiguration.htmlLogCurrentTestCaseName = RunConfiguration.testCaseContext.testCaseName;
                    string htmlLogPath = htmlPath + Util.GetFileSeparator() + "HTML Results" + Util.GetFileSeparator() + RunConfiguration.htmlLogCurrentTestCaseName + ".html";

                    if (File.Exists(htmlLogPath))
                    {
                        if (RunConfiguration.enableOverrideInHtml)
                        {
                            // Delete Existing Result Log
                            File.Delete(htmlLogPath);
                        }
                        else
                        {
                            int runId = 2;
                            do
                            {
                                RunConfiguration.htmlLogCurrentTestCaseName = RunConfiguration.testCaseContext.testCaseName + "_Run" + runId;
                                runId++;
                                htmlLogPath = htmlPath + Util.GetFileSeparator() + "HTML Results" + Util.GetFileSeparator() + RunConfiguration.htmlLogCurrentTestCaseName + ".html";
                            } while (File.Exists(htmlLogPath));
                        }
                    }

                    ReportSettings reportSettings = new ReportSettings(htmlPath, RunConfiguration.htmlLogCurrentTestCaseName);
                    reportSettings.ProjectName = RunConfiguration.projectName;
                    reportSettings.GenerateExcelReports = false;
                    reportSettings.GenerateHtmlReports = true;
                    reportSettings.GenerateHtmlDevOpsReports = RunConfiguration.enableOverrideInHtml;
                    reportSettings.IncludeTestDataInReport = false;
                    reportSettings.TakeScreenshotFailedStep = GetBooleanFromFlag(ReadFromConfigFile("TakeScreenshotFailedStep"));
                    reportSettings.TakeScreenshotPassedStep = GetBooleanFromFlag(ReadFromConfigFile("TakeScreenshotPassedStep"));
                    ReportTheme reportTheme = ReportThemeFactory.GetReportsTheme(ReportThemeFactory.Theme.HUMANA);

                    RunConfiguration.htmlReport = new Report(reportSettings, reportTheme);
                    RunConfiguration.htmlReport.InitializeReportTypes();
                    if (!File.Exists(htmlSummaryPath))
                    {
                        RunConfiguration.htmlReport.InitializeResultSummary();
                        RunConfiguration.htmlReport.AddResultSummaryHeading("Humana ConnectionHub API Automation - Execution Summary");
                        RunConfiguration.htmlReport.AddResultSummarySubHeading("Date & Time   ", ": " + Util.GetCurrentFormattedTime(reportSettings.DateFormatString), "Run Configuration   ", ": " + runConfiguration);
                        RunConfiguration.htmlReport.AddResultSummaryTableHeadings();
                        RunConfiguration.htmlReport.AddResultSummaryFooter(RunConfiguration.testCaseContext.fullyQualifiedTestName);
                    }

                    // Add Test Log
                    RunConfiguration.htmlReport.UpdateRunConfigurationInDashboard(runConfiguration, RunConfiguration.testCaseContext.testProjectName, RunConfiguration.testsPlannedCount, RunConfiguration.testCaseContext.fullyQualifiedTestName);
                    RunConfiguration.htmlReport.InitializeTestLog();
                    RunConfiguration.htmlReport.AddTestLogHeading(RunConfiguration.htmlLogCurrentTestCaseName);
                    RunConfiguration.htmlReport.AddTestLogSubHeading("Date & Time   ", ": " + Util.GetCurrentFormattedTime(reportSettings.DateFormatString), "Workstream ", ": " + RunConfiguration.testCaseContext.testProjectName);
                    RunConfiguration.htmlReport.AddTestLogSubHeading("Executed On   ", ": " + Environment.MachineName, "Total Iterations ", ": " + RunConfiguration.testCaseContext.totalIteration);
                    RunConfiguration.htmlReport.AddTestLogSubHeading("Environment   ", ": " + RunConfiguration.envToken, "Test Category ", ": " + RunConfiguration.testCaseContext.testCategory);
                    RunConfiguration.htmlReport.AddTestLogTableHeadings();
                }
                // Add Iteration
                RunConfiguration.htmlReport.AddTestLogSection("Iteration : " + (RunConfiguration.testCaseContext.currentIteration + 1));
            }
        }

        /// <summary>
        /// Initialize Digital DevOps BDD Framework
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void InitializeBDDFramework(String applicationUrl)
        {
            #region Initial Settings for Performance improvement, Close Browsers, ReuseBrowserFlag
            Assert.Fail("Not Yet Implemented using Selenium");
            #endregion
        }

        /// <summary>
        /// Finalize Html Reports and Html Dashboard
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void FinalizeHtmlReports()
        {
            if (RunConfiguration.enableHtmlLog)
            {
                // Stop Timer
                RunConfiguration.stopwatch.Stop();
                TimeSpan timeSpan = RunConfiguration.stopwatch.Elapsed;
                int totalTime = (int)timeSpan.TotalSeconds;
                string timeTaken = timeSpan.Minutes + " minute(s), " + timeSpan.Seconds + " seconds(s)";
                RunConfiguration.htmlReport.AddTestLogFooter(timeTaken);

                RunConfiguration.htmlReport.UpdateResultSummary(RunConfiguration.testCaseContext.testCategory,
                                    RunConfiguration.htmlLogCurrentTestCaseName, RunConfiguration.testCaseContext.functionalTestName,
                                    timeTaken, RunConfiguration.htmlTestStatus);

                RunConfiguration.htmlReport.AddTestLogToDashboardCalcSheet(RunConfiguration.htmlLogCurrentTestCaseName,
                                    RunConfiguration.testCaseContext.functionalTestName, RunConfiguration.testCaseContext.testProjectName,
                                    RunConfiguration.testCaseContext.testCategory, RunConfiguration.testCaseContext.namespaceOfTestMethod[0],
                                    totalTime, RunConfiguration.iterationPassCount, RunConfiguration.iterationFailCount,
                                    RunConfiguration.testCaseContext.fullyQualifiedTestName);

            }
        }

        /// <summary>
        /// Method to determined the Category of Current Test Case : BVT, SMOKE or REGRESSION. 
        /// </summary>
        /// <returns>  String current Test Case Category</returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        public string GetCurrentTestCaseCategory()
        {
            // INCOMPLETE LOGIC - LOGIC to be added to get Test Category defined for Test Method 
            string categoryToReturn = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TESTCATEGORY).Trim();
            if (categoryToReturn.Equals(string.Empty))
            {
                categoryToReturn = "REGRESSION";
            }
            return categoryToReturn;
        }

        /// <summary>
        /// Method to Initialize values from App Config File
        /// Any Logic to Override App.Config values should be written here
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        public void DetermineValuesFromAppConfig()
        {
            RunConfiguration.envToken = ReadFromConfigFile("EnvironmentToken").ToUpper();
            RunConfiguration.currentBrowser = ReadFromConfigFile("CurrentBrowser");
            RunConfiguration.batchRunId = ReadFromConfigFile("BatchRunID");
            ReportFactory.currentRunCategory = ReadFromConfigFile("CurrentRunCategory").ToUpper();
            RunConfiguration.logTestReportToDB = GetBooleanFromFlag(ReadFromConfigFile("LogTestReportToDB"));
            RunConfiguration.isProdDatabase = GetBooleanFromFlag(ReadFromConfigFile("IsProdDatabase"));
            RunConfiguration.getTestDataFromDB = GetBooleanFromFlag(ReadFromConfigFile("GetTestDataFromDB"));
            RunConfiguration.certExists = GetBooleanFromFlag(ReadFromConfigFile("CertExists"));
            RunConfiguration.certFileName = ReadFromConfigFile("certFileName");
            RunConfiguration.certFilePath = ReadFromConfigFile("CertFilePath");
            RunConfiguration.certPassword = ReadFromConfigFile("CertPassword");
            RunConfiguration.enableHtmlLog = GetBooleanFromFlag(ReadFromConfigFile("HtmlReport"));
            RunConfiguration.enableDynamicBatchRunId = GetBooleanFromFlag(ReadFromConfigFile("DynamicBatchRunIdForHtmlReport"));
            RunConfiguration.storeScreenShotInDB = GetBooleanFromFlag(ReadFromConfigFile("StoreScreenShotInDB"));
            RunConfiguration.enableExcelLog = GetBooleanFromFlag(ReadFromConfigFile("LogTestLogToExcel"));
            RunConfiguration.sendMail = GetBooleanFromFlag(ReadFromConfigFile("SendMail"));
            RunConfiguration.useApi = GetBooleanFromFlag(ReadFromConfigFile("UseApi"));
            RunConfiguration._baseUrl = ReadFromConfigFile("BaseUrl");

            if (RunConfiguration.getTestDataFromDB)
            {
                RunConfiguration.testCaseContext.testGeneralDataSheet = "TESTDATA_GENERAL";
                RunConfiguration.testCaseContext.testDataControlsTable = "TESTDATA_CONTROLS";
                RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet = "TESTDATA_ENVSPECIFIC";
                RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet = "TESTDATA_MEGANAVIGATION";
                RunConfiguration.testCaseContext.testDataLinksNavigationTable = "TESTDATA_LINKSNAVIGATION";
                //RunConfiguration.testCaseContext.apiControlsTable = "WEBSERVICE_TESTDATA";
            }
            if (RunConfiguration.useApi)
            {

                RunConfiguration.testCaseContext.apiControlsTable = "WebService_TestData";

            }

            if (RunConfiguration.isProdDatabase)
            {
                RunConfiguration.dbName = "DevOps_Automation";
            }
            else
            {
                RunConfiguration.dbName = "CodedUI";
            }

            // Web Emulation Details
            RunConfiguration.useWebEmulationLogin = GetBooleanFromFlag(ReadFromConfigFile("UseWebEmulationLogin"));
            RunConfiguration.UserGrid = GetBooleanFromFlag(ReadFromConfigFile("UserGrid"));
            RunConfiguration.UsePerfecto = GetBooleanFromFlag(ReadFromConfigFile("UsePerfecto"));

            // Html Report & Screenshot Path
            RunConfiguration.screenShotFolder = ReadFromConfigFile("ScreenShotFolder");
            RunConfiguration.htmlReportPath = ReadFromConfigFile("HtmlReportPath");
            if (!RunConfiguration.htmlReportPath.EndsWith("\\"))
            {
                RunConfiguration.htmlReportPath = RunConfiguration.htmlReportPath + "\\";
            }
            RunConfiguration.screenShotFolder = RunConfiguration.screenShotFolder + "\\" + RunConfiguration.testCaseContext.testProjectName;
            RunConfiguration.screenShotFolder = RunConfiguration.screenShotFolder + "\\" + (Regex.Split(DateTime.Now.ToString(), " ")[0]).Replace("/", "-");

            //Create WorkStream Specific Folder (for Current Day) if not Exist 
            if (!Directory.Exists(RunConfiguration.screenShotFolder))
            {
                Directory.CreateDirectory(RunConfiguration.screenShotFolder);
            }
            // Identify Planned Tests Count
            try
            {
                RunConfiguration.testsPlannedCount = Int32.Parse(ReadFromConfigFile("TestsPlanned"));
            }
            catch (Exception)
            {
                RunConfiguration.testsPlannedCount = 0;
            }
        }

        /// <summary>
        /// Method to Insert a New Status Row in Test Results table for Each Iteration Run 
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        private void InsertCurrentRunDataBaseEntry()
        {
            //string recordID = "11";
            TestResults testResults = new TestResults();

            //Get Batch Run Id 
            testResults.BATCHRUN_ID = ReadFromConfigFile("BatchRunID");
            testResults.RELEASE_NAME = ReadFromConfigFile("ReleaseName");
            if (ReportFactory.currentRunCategory.Equals("BVT"))
            {
                // Logic to be Added to Generate Batch Run ID Dynamically for BVT Execution 
            }

            testResults.FUNCTIONAL_TC_NAME = RunConfiguration.testCaseContext.functionalTestName;
            testResults.WORKSTREAM = GetWorkStreamName;
            testResults.RUN_CATEGORY = ReportFactory.currentRunCategory;
            testResults.TESTCASE_CATEGORY = RunConfiguration.testCaseContext.testCategory;
            testResults.CODEDUI_TEST_NAME = RunConfiguration.testCaseContext.testCaseName;
            testResults.CODEDUI_TEST_DESCRIPTIPON = RunConfiguration.testCaseContext.testCaseDescription;
            testResults.TEST_RESULT = Status.INCONCLUSIVE.ToString();
            testResults.ISSUE_TYPE = IssueType.AutomationScript.ToString().ToUpper();
            testResults.TEST_ITERATION = RunConfiguration.testCaseContext.currentIteration + 1;
            testResults.TEST_STARTTIME = ReportFactory.curTimeStamp;
            testResults.LASTUPDATE_TIMESTAMP = ReportFactory.curTimeStamp;
            testResults.ENVIRONMENT = RunConfiguration.envToken.ToUpper();
            testResults.FUNCTIONAL_DESC = RunConfiguration.testCaseContext.namespaceOfTestMethod[0];
            testResults.FUNCTIONALITY_IMPACTED = RunConfiguration.testCaseContext.functionalityImpacted;
            testResults.TEST_DATA_TYPE = RunConfiguration.testCaseContext.testDataType;
            testResults.TEST_DATA_CATEGORY = RunConfiguration.testCaseContext.testDataCategory;

            ReportFactory reportFactory = new ReportFactory();
            reportFactory.InsertStartTestRunRecord(testResults);

            #region Update Iteration Grouping ID
            reportFactory.UpdateIterationGroupID();
            #endregion Update Iteration Grouping ID
        }

        /// <summary>
        /// Method to Launch Grid
        /// </summary>
        /// <author> Gnaneswar Sodini</author>
        public void LaunchGrid()
        {
            Uri appURI = GetURIFromURL(RunConfiguration.envURL);
            string gridUrl = ReadFromConfigFile("GridURLValue");
            //string gridUrl = "http://10.225.10.222:5555/wd/hub";
            DesiredCapabilities capabilities = new DesiredCapabilities();
            if (RunConfiguration.UserGrid)
            {
                if (RunConfiguration.testCaseContext.currentIteration == 0 || !RunConfiguration.reuseWebDriver)
                {
                    if (RunConfiguration.currentBrowser.Contains("chrome"))
                    {
                        var chromeOptions = new ChromeOptions();
                        chromeOptions.Proxy = null;
                        chromeOptions.SetLoggingPreference(LogType.Driver, LogLevel.All);
                        chromeOptions.AddAdditionalCapability("useAutomationExtension", false);
                        //RunConfiguration.driver = new ChromeDriver(RunConfiguration.chromeDriverPath, chromeOptions);
                        RunConfiguration.driver = new RemoteWebDriver(new Uri(gridUrl), chromeOptions);
                    }
                    else
                    {
                        var options = new InternetExplorerOptions
                        {
                            EnableNativeEvents = true, // just as an example, you don't need this
                            IgnoreZoomLevel = true
                        };
                        // capabilities = DesiredCapabilities.InternetExplorer();
                        options.AddAdditionalCapability(CapabilityType.BrowserName, "internet explorer");
                        options.AddAdditionalCapability(CapabilityType.Platform, new Platform(PlatformType.Windows));
                        RunConfiguration.driver = new RemoteWebDriver(new Uri(gridUrl), options);
                    }
                }

                RunConfiguration.driver.Url = appURI.AbsoluteUri;
                UpdateTestLog("LaunchUrl", "Invoke Application - " + RunConfiguration.envURL, Status.DONE);
                //((IJavaScriptExecutor)RunConfiguration.driver).ExecuteScript("window.resizeTo(1024, 768);");
                RunConfiguration.appUtilLibrary = new DriverAppUtilLibrary(RunConfiguration.driver);
                RunConfiguration.driverBusinessLibrary = new DriverBusinessLibrary(RunConfiguration.driver);
                RunConfiguration.driver.Manage().Window.Maximize();
                var switches = new List<string>
                       {
                           "--start-maximized"
                       };



                capabilities.SetCapability("chrome.switches", switches);
            }
            RunConfiguration.driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
            RunConfiguration.driver.Manage().Window.Maximize();
        }

        /// <summary>
        /// Method to Map Q Drive if not Mapped for Screenshot Saving
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        public void MapQDrive()
        {
            System.Diagnostics.Process.Start("net.exe", @"use Q: ""\\RSC.HUMAD.COM\QDRIVE""");
        }

        /// <summary>
        /// Used for Results Generation
        /// </summary>
        /// <author>GXS8571 - Gnaneswar Sodini</author>
        public static void ResultsGen(string SourceFilePath, string DestinationFilePath, string FileName)
        {
            if (FileName != null)
            {
                SourceFilePath = Regex.Split(SourceFilePath, "Out")[0] + "In";
                DirectoryInfo DirInfo = new DirectoryInfo(SourceFilePath);
                string finam = "";
                foreach (var fi in DirInfo.EnumerateFiles("*.html", SearchOption.AllDirectories))
                {
                    finam = finam + fi.Directory + '\\' + fi.Name;
                }
                File.Copy(finam, DestinationFilePath + '\\' + FileName + ".html");
                File.Delete(finam);
            }
        }

        /// <summary>
        /// Return an equivalent boolean value for the argument passed. Return false by default if passed value if blank or not boolean convertable
        /// </summary>
        /// <param name="flag">can be "true", "Y", "N", "false" case insensitive</param>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        /// <returns>boolean equivalent for the passed value</returns>
        public Boolean GetBooleanFromFlag(string flag)
        {
            Boolean booleanToReturn = false;
            flag = flag.ToUpper();
            if ((flag == "TRUE") || (flag == "Y") || (flag == "YES"))
            {
                booleanToReturn = true;
            }
            return booleanToReturn;
        }

        /// <summary>
        /// Method to Initialize WebDriver
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>    
        public void InitializeWebDriver()
        {
            Uri appURI = GetURIFromURL(RunConfiguration.envURL);

            if (RunConfiguration.testCaseContext.currentIteration == 0 || !RunConfiguration.reuseWebDriver)
            {
                if (RunConfiguration.testCaseContext.currentIteration == 0 || !RunConfiguration.reuseWebDriver)
                {

                    if (RunConfiguration.currentBrowser.Equals("Chrome", StringComparison.OrdinalIgnoreCase))
                    {
                        try
                        {
                            var chromeOptions = new ChromeOptions();
                            chromeOptions.Proxy = null;
                            chromeOptions.SetLoggingPreference(LogType.Driver, LogLevel.All);
                            chromeOptions.AddAdditionalCapability("useAutomationExtension", false);
                            //RunConfiguration.driver = new ChromeDriver(RunConfiguration.chromeDriverPath, chromeOptions);
                            RunConfiguration.driver = new ChromeDriver(RunConfiguration.chromeDriverPath, chromeOptions);
                        }
                        catch (Exception)
                        {
                            var chromeOptions = new ChromeOptions();
                            chromeOptions.Proxy = null;
                            RunConfiguration.driver = new ChromeDriver(RunConfiguration.chromeDriverPath);
                        }
                    }
                    else if (RunConfiguration.currentBrowser.Equals("Firefox", StringComparison.OrdinalIgnoreCase))
                    {
                        FirefoxOptions options = new FirefoxOptions()
                        {
                            BrowserExecutableLocation = @"C:\Program Files (x86)\Mozilla Firefox\firefox.exe"
                        };
                        RunConfiguration.driver = new FirefoxDriver(options);
                    }
                    else
                    {
                        var internetExplorerOptions = new InternetExplorerOptions();
                        internetExplorerOptions.Proxy = null;
                        RunConfiguration.driver = new InternetExplorerDriver(RunConfiguration.ieDriverPath);
                    }
                }
                RunConfiguration.driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
                RunConfiguration.driver.Manage().Window.Maximize();
            }
            RunConfiguration.driver.Url = appURI.AbsoluteUri;
            UpdateTestLog("LaunchUrl", "Invoke Application - " + RunConfiguration.envURL, Status.DONE);
            //RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors();
            RunConfiguration.appUtilLibrary = new DriverAppUtilLibrary(RunConfiguration.driver);
            RunConfiguration.driverBusinessLibrary = new DriverBusinessLibrary(RunConfiguration.driver);
            WaitTillPageLoaded();
        }

        /// <summary>
        /// Method to Launch Perfecto
        /// </summary>
        /// <author> Deepika Shanmugam</author>
        public void LaunchPerfecto()
        {
            Uri appURI = GetURIFromURL(RunConfiguration.envURL);
            var host = "humana.perfectomobile.com";
            var url = new Uri(string.Format("https://{0}/nexperience/perfectomobile/wd/hub", host));
            DesiredCapabilities dc = new DesiredCapabilities();
            ChromeOptions co = new ChromeOptions();
            if (RunConfiguration.UsePerfecto)
            {
                dc.SetCapability("securityToken", "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5dlNCbWpycFNXYzB4MER6dHNOcUF0UUdHMmlLMzFuM3prMlY5bEJtU0hjIn0.eyJqdGkiOiIxMmI0MjIzMy03ZTM1LTQ5NTUtYWUxYS05MTIyNDk3ZjhhNWMiLCJleHAiOjAsIm5iZiI6MCwiaWF0IjoxNTQzNDE3ODM0LCJpc3MiOiJodHRwczovL2F1dGgucGVyZmVjdG9tb2JpbGUuY29tL2F1dGgvcmVhbG1zL2h1bWFuYS1wZXJmZWN0b21vYmlsZS1jb20iLCJhdWQiOiJvZmZsaW5lLXRva2VuLWdlbmVyYXRvciIsInN1YiI6IjdkOTJmZjZlLTQxNTItNDY4MC1hNDNkLTlhNGI3MWQxZGQ1ZSIsInR5cCI6Ik9mZmxpbmUiLCJhenAiOiJvZmZsaW5lLXRva2VuLWdlbmVyYXRvciIsIm5vbmNlIjoiOGVlZGE5YTctZGUzMi00OGM5LTgzMTQtYmVkMjliYjkxNTk5IiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiNWQ2ZDUzOGMtMzVkNC00YzgxLTg3Y2QtZGRkMGNlMTBmMjkxIiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbIm9mZmxpbmVfYWNjZXNzIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fX0.f6I27Jjylnr4rhk5QEftC9kt6e_sDcwjFOK_5ugSF9Xy0rmhnR7X-SzjqKcz5OZm6Vy_ALfOEftpwA-fMXT9i1AuzeSrKjN69FCh6g-FZ6Dk2DBi8wLir74_iR50PUqPEF4XMtpi256c2SiQszXXhEasx5a42dLkfkrnbvzSyDzYINMVUeXDjdkvjzP9UzKuQu9c5jbNNaxKL-2-88hI_OKMLPu1zb3qFGeVEw7w_RX9TDYEWd5o_SpSEPXfJFULGx4Cx7xgjO4F1jqG0bmUcggBNjnWfiSJl-fa9KaI0H5nYwBTjuJvhg5-8nN_GTp05lrFDkrn8VkSUznW0i88bA");
                if (RunConfiguration.currentBrowser == "Chrome" || RunConfiguration.currentBrowser == "ie")
                {
                    //dc.SetCapability("deviceName", "304352434D303098");
                    dc.SetCapability("BrowserName", RunConfiguration.currentBrowser);
                    dc.SetCapability("platformName", "Android");
                    dc.SetCapability("manufacturer", "Samsung");
                    dc.AcceptInsecureCerts = true;
                }
                else
                {
                    //dc.SetCapability("deviceName", "CA8E839332AB155E832B76392A3ABD203B1BB8C5");
                    dc.SetCapability("BrowserName", "Safari");
                    dc.SetCapability("platformName", "iOS");
                    dc.SetCapability("manufacturer", "Apple");
                    dc.AcceptInsecureCerts = true;
                }
                dc.SetCapability("openDeviceTimeout", 5);
                perfectoDriver = new RemoteWebDriver(url, dc, TimeSpan.FromMinutes(5));
                //DesiredCapabilities.Android.MapQDrive();
                UpdateTestLog("LaunchUrl", "Invoke Application - " + RunConfiguration.envURL, Status.DONE);
            }
            RunConfiguration.perfectoDriver = perfectoDriver;
            RunConfiguration.perfectoDriver.Url = appURI.AbsoluteUri;

        }

        /// <summary>
        /// Method to get URL object from String. Http Will be added to URL if not available in passed String my 
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author> 
        /// <param name="url">A String to be Converted as URL. String can have http/https tag optional</param>
        /// <returns>URL of equivaluent url String </returns>
        public Uri GetURIFromURL(string url)
        {
            if (!url.Contains("http"))
            {
                url = "http://" + url;
            }
            return new System.Uri(url);
        }

        /// <summary>
        /// Method to Initialize Test Data - Will read current TC data rows from data source
        /// and store in temporary data table    
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        private void InitializeTestData()
        {
            RunConfiguration.testDataFactory.InitializeDataTable();
        }

        /// <summary>
        /// Method to Initialize Test Data - Will read current TC data rows from data source
        /// and store in temporary data table    
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        private void InitializeTestData_API_Excel()
        {
            RunConfiguration.testDataFactory.InitializeDataTable_API_Excel();
            //RunConfiguration.testDataFactory.InitializeDataTable();
        }

        /// <summary>
        /// Method to Initialize Test Data - Will read current TC data rows from data source
        /// and store in temporary data table    
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        private void InitializeDBDataTable()
        {
            RunConfiguration.testDataFactory.InitializeDBDataTable();
        }

        /// <summary>
        /// Method to Initialize Test Data - Will read current TC data rows from data source
        /// and store in temporary data table    
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        private void InitializeDBDataTable_API()
        {
            RunConfiguration.testDataFactory.InitializeDataTable_API();
        }

        /// <summary>
        /// Method to Initialize Environment Token from App.config File 
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        public void InitializeEnvToken()
        {
            //To be read from config Variable Name, Environment Token, not Environment ID. EnvironmentID to be removed
            string envToken = "";
            try
            {
                envToken = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "EnvToken").ToUpper();
            }
            catch (Exception)
            {
                // Env Token is not found in Sheet - Optional
            }
            if (!string.IsNullOrEmpty(envToken))
            {
                RunConfiguration.envToken = envToken;
            }
        }

        /// <summary>
        /// Method to Initialize Currently executed Environemnt. Will be generated from Environment Token 
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        private void InitializeCurrentEnvironment()
        {
            RunConfiguration.envURL = GetEnvPrefixedURL(GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "ApplicationUrl"));
        }

        /// <summary>
        /// Method to Generate and Get Appropriate URL based on Environment Token 
        /// </summary>
        /// <param name="bURL"></param>
        /// <returns>return URL with environment Prefix </returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        public string GetEnvPrefixedURL(string bURL)
        {
            // Not required to add Token if already complete URL is provided
            if (bURL.StartsWith("http"))
            {
                return bURL;
            }
            if (RunConfiguration.enabledNewDashboard)
            {
                if (RunConfiguration.envToken.Equals("PROD"))
                {
                    bURL = bURL.Replace("www.humana.com/members", "myhumana2.humana.com");
                }
                else
                {
                    bURL = bURL.Replace("www.humana.com/members", "myhumana2.humana.com");
                }
            }
            string envPrefix = null;
            //For Production
            if (RunConfiguration.envToken.Equals("PROD"))
            {
                envPrefix = "https://";
            }
            else if (RunConfiguration.envToken.Contains("QA"))
            {
                envPrefix = "https://" + RunConfiguration.envToken.ToLower() + "-";
            }
            // For Careplus
            else if (RunConfiguration.envToken.Contains("TEST"))
            {
                envPrefix = "http://" + RunConfiguration.envToken.ToLower() + "-";
            }
            else
            {
                envPrefix = "https://" + RunConfiguration.envToken.ToLower() + "-";
            }

            return envPrefix + bURL;
        }

        /// <summary>
        /// Method to Read Value from Configuraiton File. Retrun Blank if Config Key Value is not Found  
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author> 
        public string ReadFromConfigFile(string keyName)
        {
            string configValueRead = "";
            try
            {
                configValueRead = ConfigurationManager.AppSettings[keyName].ToString().Trim();
            }
            catch (Exception)
            {
                Console.Error.WriteLine("Configuraiton Key: " + keyName + " Not found in both Workstream & Reusable App.Config file. Returning Blank Value");
            }
            return configValueRead;
        }

        /// <summary>
        /// Get the test data from Environment sheet, if data not available it will refer INT Env data
        /// </summary>
        /// <param name="columnName">Column Name</param>
        /// <param name="useIntEnvAsDefault">Refer INT Data, if data not available</param>
        /// <returns></returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public string GetTestDataFromEnvSheet(string columnName, bool useIntEnvAsDefault = true)
        {
            string returnData = "";
            Exception exception = null;
            string envPrefix = RunConfiguration.envToken.ToUpper();
            envPrefix = Regex.Replace(envPrefix, "SC8", "").Trim();
            envPrefix = Regex.Replace(envPrefix, "[0-9]", "");
            envPrefix = Regex.Replace(envPrefix, "SUPPORT", "");
            envPrefix = Regex.Replace(envPrefix, "IDE", "");

            try
            { // Get the Test data for the Current Env
                returnData = GetTestData(RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet, columnName + "_" + envPrefix);
            }
            catch (Exception e)
            {
                exception = e;
            }
            if (useIntEnvAsDefault && string.IsNullOrEmpty(returnData))
            { // Get Test Data from INT Env, if no data available for Current Env
                returnData = GetTestData(RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet, columnName + "_INT");
            }
            else if (exception != null)
            {
                throw exception;
            }
            return returnData;
        }

        /// <summary>
        /// Get the test data from Environment sheet, if data not available it will refer INT Env data
        /// </summary>
        /// <param name="columnName">Column Name</param>
        /// <param name="useIntEnvAsDefault">Refer INT Data, if data not available</param>
        /// <returns></returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public string GetTestDataFromEnvSheetAndSubIteration(string columnName, int subIterationNo, bool useIntEnvAsDefault = true)
        {
            string returnData = "";
            Exception exception = null;
            string envPrefix = RunConfiguration.envToken.ToUpper();
            envPrefix = Regex.Replace(envPrefix, "SC8", "").Trim();
            envPrefix = Regex.Replace(envPrefix, "[0-9]", "");
            envPrefix = Regex.Replace(envPrefix, "SUPPORT", "");
            envPrefix = Regex.Replace(envPrefix, "IDE", "");

            try
            { // Get the Test data for the Current Env
                returnData = GetTestDataByAdditionalIndex(RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet, columnName + "_" + envPrefix, subIterationNo);
            }
            catch (Exception e)
            {
                exception = e;
            }
            if (useIntEnvAsDefault && string.IsNullOrEmpty(returnData))
            { // Get Test Data from INT Env, if no data available for Current Env
                returnData = GetTestDataByAdditionalIndex(RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet, columnName + "_INT", subIterationNo);
            }
            else if (exception != null)
            {
                throw exception;
            }
            return returnData;
        }

        /// <summary>
        /// Method to Read Test Data from Data Table. The Data table will have data specic to current Test Case and will be initialized from Initialize Method
        /// </summary>
        /// <param name="columnName">Column to read the test data from</param>
        /// <param name="sheetToRead">Sheet from which the Column to be searched for </param>
        /// <returns>test data read. If Column value is null, will return an empty String</returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        public string GetTestData(string sheetToRead, string columnName)
        {
            string returnData = "", oleDBSheetName = sheetToRead + "$";

            if (RunConfiguration.getTestDataFromDB)
            {
                oleDBSheetName = sheetToRead;
            }
            if (RunConfiguration.testDataFactory.testDataTable.ContainsKey(oleDBSheetName))
            {
                bool iterationFound = false;
                try
                {
                    //DataRow curSheetDTRow = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows[RunConfiguration.testCaseContext.currentIteration];
                    DataRowCollection dataRowCollection = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows;

                    foreach (DataRow eachData in dataRowCollection)
                    {
                        if (eachData["Iteration"].ToString().Trim().Equals((RunConfiguration.testCaseContext.currentIteration + 1).ToString()))
                        {
                            returnData = eachData[columnName].ToString();
                            iterationFound = true;
                            break;
                        }
                    }
                }
                catch (Exception noColumn)
                {
                    noColumn.ToString();
                    throw new Exception("Column: " + columnName + " is not found in Sheet - " + sheetToRead);
                }
                if (!iterationFound)
                {
                    throw new Exception("Iteration (" + (RunConfiguration.testCaseContext.currentIteration + 1).ToString() + ") is not found in for the provided test");
                }
            }
            else
            {
                throw new Exception("Sheet: " + sheetToRead + " not found in Data Table, or the sheet does not have data for this test case's current Iteration");
            }
            // Return Trimmed Test Data 
            return returnData.Trim();
        }

        /// <summary>
        /// Method to Read Test Data from Data Table. The Data table will have data specic to current Test Case and will be initialized from Initialize Method
        /// </summary>
        /// <param name="columnName">Column to read the test data from</param>
        /// <param name="sheetToRead">Sheet from which the Column to be searched for </param>
        /// <returns>test data read. If Column value is null, will return an empty String</returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author> 
        public string GetTestData_API(string sheetToRead, string columnName)
        {
            string returnData = "", oleDBSheetName = sheetToRead + "$";

            if (RunConfiguration.getTestDataFromDB)
            {
                oleDBSheetName = sheetToRead;
            }
            // if (RunConfiguration.testDataFactory.testDataTable.ContainsKey(oleDBSheetName))
            // {
            bool iterationFound = false;
            try
            {
                DataRow curSheetDTRow = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows[RunConfiguration.testCaseContext.currentIteration];
                DataRowCollection dataRowCollection = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows;

                foreach (DataRow eachData in dataRowCollection)
                {
                    if (eachData["Iteration"].ToString().Trim().Equals((RunConfiguration.testCaseContext.currentIteration + 1).ToString()))
                    {
                        returnData = eachData[columnName].ToString();
                        iterationFound = true;
                        break;
                    }
                }
            }
            catch (Exception noColumn)
            {
                noColumn.ToString();
                throw new Exception("Column: " + columnName + " is not found in Sheet - " + sheetToRead);
            }
            if (!iterationFound)
            {
                throw new Exception("Iteration (" + (RunConfiguration.testCaseContext.currentIteration + 1).ToString() + ") is not found in for the provided test");
            }
            //}
            //else
            //{
            //   throw new Exception("Sheet: " + sheetToRead + " not found in Data Table, or the sheet does not have data for this test case's current Iteration");
            // }
            // Return Trimmed Test Data 
            return returnData.Trim();
        }

        /// <summary>
        /// Get Custom Test Data specfic Requirements
        /// </summary>
        /// <param name="sheetToRead"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public string GetCustomTestData(string sheetToRead, string columnName, string whereCondition = "")
        {
            string returnData = "", oleDBSheetName = sheetToRead + "$";
            if (RunConfiguration.testDataFactory.customTestDataTable.ContainsKey(oleDBSheetName))
            {
                bool dataFound = false;
                try
                {
                    //DataRowCollection dataRowCollection = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows;
                    DataRow[] dataRowCollection = RunConfiguration.testDataFactory.customTestDataTable[oleDBSheetName].Select(whereCondition);
                    foreach (DataRow eachData in dataRowCollection)
                    {
                        returnData = eachData[columnName].ToString();
                        dataFound = true;
                        break;
                    }
                }
                catch (Exception noColumn)
                {
                    noColumn.ToString();
                    throw new Exception("Column: " + columnName + " is not found in Sheet - " + sheetToRead);
                }
                if (!dataFound)
                {
                    UpdateTestLog(sheetToRead, whereCondition + " is not found in for the provided Custom Test Data", Status.FAIL);
                }
            }
            else
            {
                throw new Exception("Sheet: " + sheetToRead + " not found in Data Table, or the sheet does not have data for this test case's current Iteration");
            }
            // Return Trimmed Test Data 
            return returnData.Trim();
        }

        /// <summary>
        /// Get Test Data by additional index/sub iteration
        /// </summary>
        /// <param name="sheetToRead">Sheet Name</param>
        /// <param name="columnName">Column Name</param>
        /// <param name="additionalIndexValue">SubIteration Number</param>
        /// <returns>Data Value</returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public string GetTestDataByAdditionalIndex(string sheetToRead, string columnName, int additionalIndexValue)
        {
            if (additionalIndexValue == 1)
            {
                return GetTestData(sheetToRead, columnName);
            }
            string returnData = "", oleDBSheetName = sheetToRead + "$";
            if (RunConfiguration.testDataFactory.testDataTable.ContainsKey(oleDBSheetName))
            {
                bool iterationFound = false, subIterationFound = false;
                try
                {
                    //DataRow curSheetDTRow = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows[RunConfiguration.testCaseContext.currentIteration];
                    DataRowCollection dataRowCollection = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows;

                    foreach (DataRow eachData in dataRowCollection)
                    {
                        if (eachData["Iteration"].ToString().Trim().Equals((RunConfiguration.testCaseContext.currentIteration + 1).ToString()))
                        {
                            iterationFound = true;
                            if (eachData["SubIteration"].ToString().Trim().Equals((additionalIndexValue).ToString()))
                            {
                                returnData = eachData[columnName].ToString();
                                subIterationFound = true;
                                break;
                            }
                        }
                    }
                }
                catch (Exception noColumn)
                {
                    noColumn.ToString();
                    throw new Exception("Column: " + columnName + " is not found in Sheet - " + sheetToRead);
                }
                if (!iterationFound)
                {
                    throw new Exception("Iteration (" + (RunConfiguration.testCaseContext.currentIteration + 1).ToString() + ") is not found in for the provided test");
                }
                if (!subIterationFound)
                {
                    throw new Exception("Sub-Iteration (" + additionalIndexValue + ") is not found in for the provided test");
                }
            }
            else
            {
                throw new Exception("Sheet: " + sheetToRead + " not found in Data Table, or the sheet does not have data for this test case's current Iteration");
            }
            // Return Trimmed Test Data 
            return returnData.Trim();
        }

        /// <summary>
        /// Complete test execution, calculate execution time, export reports if applicable
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy </author>
        public void WrapUpTestExecution(UnitTestOutcome unitTestOutCome = UnitTestOutcome.Passed)
        {
            #region SET OVERALL ITERATIONS RESULT
            if (RunConfiguration.logAssertFailAtEnd)
            {
                unitTestOutCome = UnitTestOutcome.Failed;
            }
            #endregion

            #region IDENTIFY NO OF ITERATIONS PASSED/FAILED
            if (unitTestOutCome == UnitTestOutcome.Passed)
            {
                RunConfiguration.iterationPassCount += 1;
                RunConfiguration.testDataFactory.UpdateExcelLogFile();
            }
            else
            {
                //RunConfiguration.iterationFailCount += 1;
                RunConfiguration.htmlTestStatus = "Failed";
                RunConfiguration.testDataFactory.UpdateExceptionMessage();
            }
            // Update FAIL Count
            RunConfiguration.iterationFailCount = RunConfiguration.testCaseContext.totalIteration - RunConfiguration.iterationPassCount;
            #endregion

            #region DB REPORTS
            if (RunConfiguration.logTestReportToDB)
            {
                FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
                TestResults testResults = new TestResults();
                testResults.TEST_RESULT = unitTestOutCome.ToString().ToUpper();

                if (unitTestOutCome == UnitTestOutcome.Failed)
                {
                    testResults.ISSUE_TYPE = RunConfiguration.issueType.ToString().ToUpper();
                }
                else
                {
                    testResults.ISSUE_TYPE = "";
                }
                testResults.TESTRUN_ID = ReportFactory.currentRunID;

                ReportFactory reportFactory = new ReportFactory();
                reportFactory.UpdateTestRunCompletion(testResults);

                //if (RunConfiguration.sendMail)
                //{
                //    DataTable resultSet = reportFactory.GetTestResultDetailsByTestRunId(ReportFactory.currentRunID);
                //    SendMail objSendMail = new SendMail();
                //    objSendMail.SendEmail(resultSet);
                //}
            }
            #endregion DB REPORTS

            #region CLOSE WEBDRIVER
            // Close the Multiple/Created Window/Tabs
            try
            {
                if (!RunConfiguration.reuseWebDriver || IsLastIteration)
                {
                    RunConfiguration.driver.Quit();
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine("Wrap up Test Execution - " + e.Message);
            }
            #endregion

            #region LOG REPORT & FINALIZE FAIL MESSAGE IF APPLICABLE
            // Error Details
            bool logAssertFailAtEnd = RunConfiguration.logAssertFailAtEnd;
            string logErrorMessage = RunConfiguration.failureLog;

            // Reset Run Configuration 
            if (IsLastIteration)
            {
                // Finalize Html Reports
                FinalizeHtmlReports();
                //TestResults testResults = new TestResults();
                ReportFactory reportFactory = new ReportFactory();
                //reportFactory.UpdateTestRunCompletion(testResults);
                if (RunConfiguration.sendMail)
                {
                    DataTable resultSet = reportFactory.GetTestResultDetailsByTestRunId(ReportFactory.currentRunID);
                    SendMail objSendMail = new SendMail();
                    objSendMail.SendEmail(resultSet);
                }

                // Reset Run Configuration
                ResetRunConfiguration();
            }
            else
            {
                RunConfiguration.logAssertFailAtEnd = false;
                RunConfiguration.failureLog = "Fail Summary : ";
            }

            // Assert Fail
            if (logAssertFailAtEnd)
            {
                Assert.Fail(logErrorMessage);
            }
            #endregion
        }

        /// <summary>
        /// Reset the Static variables for each Test Method
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void ResetRunConfiguration()
        {
            // TODO - Gowri - Find alternative approach to Reset static variables in the Playback settings level
            RunConfiguration.testDataFactory = new TestDataFactory();
            RunConfiguration.testCaseContext = new TestCaseContext();
            RunConfiguration.driver = null;
            RunConfiguration.htmlTestStatus = "Passed";
            RunConfiguration.failureLog = "Fail Summary : ";
            RunConfiguration.logAssertFailAtEnd = false;
            ReportFactory.iterationGroupingID = 0;
            RunConfiguration.iterationPassCount = 0;
            RunConfiguration.iterationFailCount = 0;
        }

        /// <summary>
        /// Kills all IE Explore
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void CloseAllBrowserWindows()
        {
            //Closing IE browser
            System.Diagnostics.Process[] procs = System.Diagnostics.Process.GetProcessesByName("IEXPLORE");
            foreach (System.Diagnostics.Process proc in procs)
            {
                proc.Kill();
            }
            //Closing Chrome browser
            var chromeDriverProcesses = System.Diagnostics.Process.GetProcessesByName("WerFault");
            foreach (var process in chromeDriverProcesses)
            {
                process.Kill();
            }
        }

        /// <summary>
        /// Method to Wait till Parameterized Seconds
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        public void StaticWaitForSeconds(int secondsToWait)
        {
            System.Threading.Thread.Sleep(1000 * secondsToWait);
        }

        /// <summary>
        /// Wait Till Browser window is loaded
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        /// <param name="browserOrParentControl"></param>
        public void WaitTillPageLoaded(int timeOut = 0)
        {
            if (timeOut == 0)
            {
                timeOut = RunConfiguration.pageLoadTimeOut;
            }
            IJavaScriptExecutor js = (IJavaScriptExecutor)RunConfiguration.driver;
            for (int i = 0; i < timeOut; i++)
            {
                if (js.ExecuteScript("return document.readyState").ToString().Equals("complete", StringComparison.OrdinalIgnoreCase))
                {
                    break;
                }
                else
                {
                    Thread.Sleep(2000);
                }
            }
        }

        /// <summary>
        /// Return Current System - To BE updated to handle both time zones IST & EST
        /// </summary>
        /// <returns>Current Date of the System </returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public string GetCurrentDateString()
        {
            return DateTime.Today.ToString("MM/dd/yyyy");
        }

        /// <summary>
        /// This Method is used to log the Test Results to Standard ouput and HTML Reporting as well if not BVT
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        /// <param name="stepName">Step Name</param>
        /// <param name="stepDetails">Step Details</param>
        /// <param name="stepStatus">Step Status</param>
        public void UpdateTestLog(string stepName, string stepDetails, Status stepStatus, bool continueOnFail = false)
        {
            #region CONSOLEREPORTING
            // Console Reporting
            Console.WriteLine("Step " + (RunConfiguration.stepNumber++) + ": " + stepDetails);
            #endregion

            #region HTMLREPORTING
            Framework_Reporting.Status reportStatus;
            if (RunConfiguration.enableHtmlLog)
            {
                switch (stepStatus)
                {
                    case Status.PASS:
                        reportStatus = Framework_Reporting.Status.PASS;
                        break;
                    case Status.SCREENSHOT:
                        reportStatus = Framework_Reporting.Status.SCREENSHOT;
                        break;
                    case Status.DONE:
                        reportStatus = Framework_Reporting.Status.DONE;
                        break;
                    case Status.FAIL:
                        reportStatus = Framework_Reporting.Status.FAIL;
                        break;
                    case Status.WARNING:
                        reportStatus = Framework_Reporting.Status.WARNING;
                        break;
                    default:
                        reportStatus = Framework_Reporting.Status.DEBUG;
                        break;
                }
                RunConfiguration.htmlReport.UpdateTestLog(stepName, stepDetails, reportStatus);
            }
            #endregion HTMLREPORTING

            #region SCREENSHOTS, EXCEL & DB REPORTING
            string screenShotPath = "NA";
            // Screenshots
            if (RunConfiguration.enableExcelLog || RunConfiguration.logTestReportToDB)
            {
                if ((stepStatus == Status.PASS) || (stepStatus == Status.FAIL) || (stepStatus == Status.SCREENSHOT) || (stepStatus == Status.WARNING))
                {
                    try
                    {
                        screenShotPath = SaveScreenCapture(RunConfiguration.targetScreenShotObject);
                    }
                    catch (Exception e)
                    {
                        Console.Error.WriteLine("Exception in Capture Screenshot \n" + e.ToString());
                    }
                }
            }


            // Report Logging in Database if applicable 
            if (RunConfiguration.logTestReportToDB)
            {
                TestStepDetails testStepDetails = new TestStepDetails();
                ReportFactory reportFactory = new ReportFactory();

                if (!string.IsNullOrEmpty(ReportFactory.currentRunID))
                {
                    testStepDetails.TESTRUN_ID = ReportFactory.currentRunID;
                    testStepDetails.STEP_NAME = stepName;
                    testStepDetails.STEP_DESCRIPTION = stepDetails;
                    testStepDetails.STEP_STATUS = stepStatus.ToString();
                    if (!screenShotPath.Equals("NA"))
                    {
                        testStepDetails.SCREENSHOT_PATH = screenShotPath;
                    }
                    //Update Current Status 
                    reportFactory.InsertStepStatus(testStepDetails);
                }
            }
            #endregion ScreenShotCapture

            #region TESTCASE FAIL UPDATE
            if (stepStatus.Equals(Status.FAIL))
            {
                // Update Failure to Excel Reports if Applicable 
                //RunConfiguration.testDataFactory.UpdateErrorMessage(stepDetails, screenShotPath);
                // Log a Fail Statement to denote Current Test Run is Failed, to update overall execution result 
                if (!continueOnFail)
                {
                    Assert.Fail(stepDetails);
                }
                else
                {
                    RunConfiguration.failureLog = RunConfiguration.failureLog + stepDetails;
                    RunConfiguration.logAssertFailAtEnd = true;
                }
            }
            #endregion Update UnitTest Execution Status
        }

        /// <summary>
        /// The Method is used to Take Screenshot af passed control and store either in Configured Location or in Database 
        /// Static Variable 'RunConfiguration.targetScreenShotObject' should be Overriden from test method, 
        /// if screenshot to be Captured for New tab or Any other UI Contorl 
        /// </summary>
        /// <param name="anyCodedUIControlType"></param>
        /// <returns name="screenShotFullPath"> Retrun the location where Screenshot is Saved </returns>
        /// <author> PXS2800 - Prageeth Saravanan </author>
        //public string SaveScreenCapture(dynamic anyCodedUIControlType)
        //{
        //    string scrnShotFileName;
        //    if (string.IsNullOrEmpty(ReportFactory.currentRunID))
        //    {
        //        string screenshotPrefixName = RunConfiguration.testDataFactory.testLogScreenshotsPath;
        //        scrnShotFileName = screenshotPrefixName + "\\" + Regex.Replace(RunConfiguration.testDataFactory.GetTodayDateInISTFormat.ToString(), "/|:| ", "_") + ".jpg";
        //    }
        //    else
        //    {
        //        scrnShotFileName = RunConfiguration.screenShotFolder + "\\" + ReportFactory.currentRunID + "_" + RunConfiguration.stepNumber + ".jpg";
        //    }
        //    string updateQuery = string.Empty, screenShotFullPath = string.Empty;
        //    ReportFactory reportFactory = new ReportFactory();
        //    FrameworkLibrary frameworkLibrary = new FrameworkLibrary();


        //    if (anyCodedUIControlType.GetType().ToString().Contains("Microsoft.VisualStudio.TestTools.UITesting"))
        //    {
        //        //anyCodedUIControlType.DrawHighlight();
        //        //Image screenCaptureImage = anyCodedUIControlType.CaptureImage();
        //        Screenshot screenCaptureImage = ((ITakesScreenshot)RunConfiguration.driver).GetScreenshot();
        //        //If Saving to DB Enabled 
        //        if (RunConfiguration.storeScreenShotInDB)
        //        {
        //            ImageConverter imageConverter = new ImageConverter();
        //            byte[] imageByteData = (byte[])imageConverter.ConvertTo(screenCaptureImage, typeof(byte[]));
        //            int insertedImageID = reportFactory.InsertByteDataIntoDB(imageByteData);
        //            // Write Image ID to Current Run Row 
        //            updateQuery = "UPDATE " + ReportFactory.TESTSTEPDETAILS + " SET " + CTestStepDetails.SCREENSHOT_PATH
        //                + " = '[" + insertedImageID + "]' WHERE " + CTestResults.TESTRUN_ID + " = " + ReportFactory.currentRunID;
        //            screenShotFullPath = "@SCREENSHOT_TABLE:ID = " + insertedImageID;
        //        }
        //        else //If not Save on Configured Network Drive 
        //        {
        //            try
        //            {
        //                screenCaptureImage.SaveAsFile(scrnShotFileName, ScreenshotImageFormat.Jpeg);
        //                //Screenshot screenCaptureImage = ((ITakesScreenshot)RunConfiguration.driver).GetScreenshot();
        //                updateQuery = "UPDATE " + ReportFactory.TESTSTEPDETAILS + " SET " + CTestStepDetails.SCREENSHOT_PATH
        //                    + " = " + scrnShotFileName + " WHERE " + CTestResults.TESTRUN_ID + " = " + ReportFactory.currentRunID;
        //                screenShotFullPath = scrnShotFileName;
        //            }
        //            catch (Exception e)
        //            {
        //                Console.Error.WriteLine("Exception in Save Screenshot - " + e.Message);
        //            }
        //        }
        //    }
        //    else
        //    {
        //        throw new Exception("The Object Passed is Not Appear to be a Coded UI Type.. Please Verify!");
        //    }
        //    return screenShotFullPath;
        //}


        /// <summary>
        /// The Method is used to Take Screenshot af passed control and store either in Configured Location or in Database 
        /// Static Variable 'RunConfiguration.targetScreenShotObject' should be Overriden from test method, 
        /// if screenshot to be Captured for New tab or Any other UI Contorl 
        /// </summary>
        /// <param name="anyControlType"></param>
        /// <returns name="screenShotFullPath"> Retrun the location where Screenshot is Saved </returns>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        public string SaveScreenCapture(dynamic anyControlType)
        {
            string scrnShotFileName;
            if (string.IsNullOrEmpty(ReportFactory.currentRunID))
            {
                string screenshotPrefixName = RunConfiguration.testDataFactory.testLogScreenshotsPath;
                scrnShotFileName = screenshotPrefixName + "\\" + Regex.Replace(RunConfiguration.testDataFactory.GetTodayDateInISTFormat.ToString(), "/|:| ", "_") + ".jpg";
            }
            else
            {
                scrnShotFileName = RunConfiguration.screenShotFolder + "\\" + ReportFactory.currentRunID + "_" + RunConfiguration.stepNumber + ".jpg";
            }
            string updateQuery = string.Empty, screenShotFullPath = string.Empty;
            ReportFactory reportFactory = new ReportFactory();
            FrameworkLibrary frameworkLibrary = new FrameworkLibrary();

            //Image screenCaptureImage = anyControlType.CaptureImage();
            //If Saving to DB Enabled 
            if (RunConfiguration.storeScreenShotInDB)
            {
                Screenshot screenCaptureImage = ((ITakesScreenshot)RunConfiguration.driver).GetScreenshot();
                screenCaptureImage.SaveAsFile(scrnShotFileName, ScreenshotImageFormat.Jpeg);


                //ImageConverter imageConverter = new ImageConverter();
                //byte[] imageByteData = (byte[])imageConverter.ConvertTo(screenCaptureImage, typeof(byte[]));
                byte[] imageByteData = screenCaptureImage.AsByteArray;
                int insertedImageID = reportFactory.InsertByteDataIntoDB(imageByteData);
                // Write Image ID to Current Run Row 
                updateQuery = "UPDATE " + ReportFactory.TESTSTEPDETAILS + " SET " + CTestStepDetails.SCREENSHOT_PATH
                    + " = '[" + insertedImageID + "]' WHERE " + CTestResults.TESTRUN_ID + " = " + ReportFactory.currentRunID;
                screenShotFullPath = "@SCREENSHOT_TABLE:ID = " + insertedImageID;
            }
            else //If not Save on Configured Network Drive 
            {
                try
                {
                    Screenshot screenCaptureImage = ((ITakesScreenshot)RunConfiguration.driver).GetScreenshot();
                    screenCaptureImage.SaveAsFile(scrnShotFileName, ScreenshotImageFormat.Jpeg);
                    //screenCaptureImage.Save(scrnShotFileName, ImageFormat.Jpeg);
                    updateQuery = "UPDATE " + ReportFactory.TESTSTEPDETAILS + " SET " + CTestStepDetails.SCREENSHOT_PATH
                        + " = " + scrnShotFileName + " WHERE " + CTestResults.TESTRUN_ID + " = " + ReportFactory.currentRunID;
                    screenShotFullPath = scrnShotFileName;
                }
                catch (Exception e)
                {
                    Console.Error.WriteLine("Exception in Save Screenshot - " + e.Message);
                }
            }
            return screenShotFullPath;
        }

        /// <summary>
        /// Get the environment token added URL List/Collection
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        /// <param name="urlCollection">URL Collection</param>
        /// <returns></returns>
        public string GetEnvTokenAddedUrlCollection(string urlCollection)
        {
            string envTokenAddedUrlCollection = urlCollection;

            // For humana.com implemented [Need to add our.humana.com, etc once started to using or once got list]
            string baseUrl = "www.humana.com";
            string envSpecifiedBaseUrl = GetEnvPrefixedURL(baseUrl);
            if (urlCollection.Contains(baseUrl) && !urlCollection.Contains("-" + baseUrl))
            {
                envTokenAddedUrlCollection = urlCollection.Replace(baseUrl, envSpecifiedBaseUrl);
            }

            baseUrl = "www.careplushealthplans.com";
            envSpecifiedBaseUrl = GetEnvPrefixedURL(baseUrl);
            if (urlCollection.Contains(baseUrl) && !urlCollection.Contains("-" + baseUrl))
            {
                envTokenAddedUrlCollection = urlCollection.Replace(baseUrl, envSpecifiedBaseUrl);
            }

            // For humana.com implemented [Need to add our.humana.com, etc once started to using or once got list]
            baseUrl = "www.go365.com";
            envSpecifiedBaseUrl = GetEnvPrefixedURL(baseUrl);
            if (urlCollection.Contains(baseUrl) && !urlCollection.Contains("-" + baseUrl))
            {
                envTokenAddedUrlCollection = urlCollection.Replace(baseUrl, envSpecifiedBaseUrl);
            }

            if (RunConfiguration.enabledNewDashboard)
            {
                if (RunConfiguration.envToken.Equals("PROD"))
                {
                    envTokenAddedUrlCollection = envTokenAddedUrlCollection.Replace("www.humana.com/members", "myhumana2.humana.com");
                }
                else
                {
                    envTokenAddedUrlCollection = envTokenAddedUrlCollection.Replace("www.humana.com/members", "myhumana2.humana.com");
                }
            }

            return envTokenAddedUrlCollection;
        }

        /// <summary>
        /// Get the String value from Array
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        /// <param name="arrayList">Array List</param>
        /// <param name="indexNumber">Index Value</param>
        public static string GetArrayIndexValue(string[] arrayList, int indexNumber)
        {
            string arrayValue = "";
            try
            {
                arrayValue = arrayList[indexNumber];
            }
            catch (Exception)
            {
                // Index is not found 
            }
            return arrayValue;
        }

        /// <summary>
        /// Check the List is sorted or not
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        /// <param name="sequence">List</param>
        /// <returns></returns>
        public bool IsSorted(IEnumerable sequence)
        {
            // Now assuming that list
            IEnumerator iterator = sequence.GetEnumerator();
            if (!iterator.MoveNext())
            {
                // An empty sequence is always sorted
                return true;
            }
            IComparable previous = (IComparable)iterator.Current;
            while (iterator.MoveNext())
            {
                IComparable next = (IComparable)iterator.Current;
                if (next.CompareTo(previous) < 0)
                {
                    return false;
                }
                previous = next;
            }
            return true;
        }

        /// <summary>
        /// Compare Array Lists
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        /// <param name="left">First Array</param>
        /// <param name="right">Second Array</param>
        /// <returns></returns>
        public bool CompareArrayList(ArrayList left, ArrayList right)
        {
            if (left == null && right == null)
            {
                return true;
            }
            if (left == null || right == null)
            {
                return false;
            }
            if (left.Count != right.Count)
            {
                return false;
            }

            for (int i = 0; i < left.Count; i++)
            {
                if (!left[i].Equals(right[i]))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Method to Execute, Insert, Update Query in SQL Connection 
        /// </summary>
        /// <author> GXP4288 - Gowrisankar Palanisamy </author>
        /// <param name="query"></param>
        /// <param name="sqlConnection"></param>
        public void ExecuteSQLWriteCommand(string query, SqlConnection sqlConnection)
        {
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }

        /// <summary>
        /// Get the Property to check whether initialize / prerequiste steps need be executed
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public bool InitializeStepsRequired
        {
            get
            {
                if (RunConfiguration.testCaseContext.currentIteration == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Check Current iteration is last or not
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public bool IsLastIteration
        {
            get
            {
                return RunConfiguration.testCaseContext.currentIteration == (RunConfiguration.testCaseContext.totalIteration - 1);
            }
        }

        /// <summary>
        /// Convert String value to Integer
        /// </summary>
        /// <param name="valueToConvert"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public static int ConvertStringToInt(string valueToConvert, int defaultValue = 0)
        {
            try
            {
                defaultValue = Int32.Parse(Regex.Replace(valueToConvert, "[^0-9]", ""));
            }
            catch (Exception)
            {
                // Invalid Number format
            }
            return defaultValue;
        }

        /// <summary>
        /// Get Specific String Value from Source using splitter/pattern
        /// </summary>
        /// <param name="sourceString">Source Content</param>
        /// <param name="splitBy">Split By</param>
        /// <param name="expectedIndex">Expected Index</param>
        /// <param name="defaultValue">Default Value</param>
        /// <returns>Target String</returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public string GetStringBySplittingFromSource(string sourceString, string splitBy, int expectedIndex, string defaultValue = "")
        {
            try
            {
                defaultValue = Regex.Split(sourceString, splitBy)[expectedIndex].Trim();
            }
            catch (Exception)
            {
                // Invalid Split Condition
            }
            return defaultValue;
        }

        /// <summary>
        /// Log any Initialize/Prerequisite error is occurred if any
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public void LogInitializeFailure()
        {
            if (!string.IsNullOrEmpty(ErrorMessageInInitializeTest))
            {
                Assert.Fail(ErrorMessageInInitializeTest);
            }
        }

        /// <summary>
        /// Fetch App Config value using Namespace and Exteneded Text
        /// </summary>
        /// <param name="propNameExtendedText">Prop Name</param>
        /// <returns>App.Config Prop Value</returns>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public string FetchConfigValueByTestMethodNamespace(string propNameExtendedText)
        {
            string actConfigValue = "";
            foreach (string eachNamespace in RunConfiguration.testCaseContext.namespaceOfTestMethod)
            {
                actConfigValue = ReadFromConfigFile(eachNamespace + "_" + propNameExtendedText);
                if (!string.IsNullOrEmpty(actConfigValue))
                {
                    break;
                }
            }
            if (string.IsNullOrEmpty(actConfigValue))
            {
                actConfigValue = ReadFromConfigFile(propNameExtendedText);
            }
            return actConfigValue;
        }

        /// <summary>
        /// Method to Read Test Data from Data Table. The Data table will have data specic to current Test Case and will be initialized from Initialize Method
        /// </summary>
        /// <param name="sheetToRead">Sheet to read the test data from</param>       
        /// <author>RXK4098 - Ramesh Kandasamy </author> 
        public List<SearchDetails> GetTestDataFromControlsSheet(string sheetToRead)
        {
            List<SearchDetails> SearchDetailsCollection = new List<SearchDetails>();

            string oleDBSheetName = sheetToRead + "$";
            if (RunConfiguration.testDataFactory.testDataTable.ContainsKey(oleDBSheetName))
            {
                try
                {
                    DataRowCollection dataRowCollection = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows;

                    foreach (DataRow eachData in dataRowCollection)
                    {
                        SearchDetails searchDetails = new SearchDetails();
                        searchDetails.SearchText = eachData["SearchText"].ToString();
                        searchDetails.ResponseText = eachData["ResponseText"].ToString();
                        searchDetails.LinkList = eachData["LinkList"].ToString();
                        SearchDetailsCollection.Add(searchDetails);
                    }
                }
                catch (Exception noColumn)
                {
                    noColumn.ToString();
                    throw new Exception("Data is not found in Sheet - " + sheetToRead);
                }
            }
            else
            {
                throw new Exception("Sheet: " + sheetToRead + " not found in Data Table, or the sheet does not have data for this test case's current Iteration");
            }
            return SearchDetailsCollection;
        }

        /// <summary>
        /// Class to Hold Column names for Search Details 
        /// </summary>
        /// <author>RXK4098- Ramesh Kandasamy </author>
        public class SearchDetails
        {
            public string SearchText
            {
                get;
                set;
            }

            public string ResponseText
            {
                get;
                set;
            }

            public string LinkList
            {
                get;
                set;
            }

            public string linkListUrl
            {
                get;
                set;
            }
        }

        /// <summary>
        /// Get/Set the Error Message in Initialize tests
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public string ErrorMessageInInitializeTest
        {
            get
            {
                return RunConfiguration.testFailMessageInInitialize;
            }
            set
            {
                RunConfiguration.testFailMessageInInitialize = value;
            }
        }

        /// <summary>
        /// Get the System Date in IST Format
        /// </summary>
        /// <author>GXP4288 - Gowrisankar Palanisamy</author>
        public DateTime GetTodayDateInISTFormat
        {
            get
            {
                TimeZoneInfo tzi = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                DateTime todayDate = DateTime.Now.ToUniversalTime();
                return TimeZoneInfo.ConvertTimeFromUtc(todayDate, tzi);
            }
        }

        /// <summary>
        /// Get the workstream name Format
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetWorkStreamName
        {
            get
            {
                string workstream = RunConfiguration.testCaseContext.testProjectName;

                if (workstream == "Go365Portal")
                {
                    workstream = "Go365";
                }
                else if (workstream == "HumanaCom")
                {
                    workstream = "HCom";
                }
                else if (workstream == "MemberPortal")
                {
                    workstream = "Members";
                }
                return workstream;
            }
        }



    }
}

