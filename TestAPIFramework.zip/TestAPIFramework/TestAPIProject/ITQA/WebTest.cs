﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestAPIFramework;

namespace ITQAAPIProject.ITQA
{
    [TestClass]
    public class WebTest : AttributeReferences
    {
        #region Reusable Library Instantiation
        DriverAppUtilLibrary appUtilLibrary;
        DriverBusinessLibrary driverBusinessLibrary;
        FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
        #endregion
        [TestInitialize]
        public void InitializeMethod()
        {
            // Initialize Run Settings
            //toolsBusinessLibraryGrid1 = new ToolsBusinessComponentsGrid1(RunConfiguration.driver);

            frameworkLibrary.InitializeRunConfigurations(TestContext);
            if (RunConfiguration.UseApi)
            {
                //frameworkLibrary.LaunchGrid();
            }

        }

        [TestMethod]
        [DeploymentItem(WorkstreamConfig.TestIterationDeploymentPath), DeploymentItem(WorkstreamConfig.RegDataDeploymentPath)]
        [DataSource(PROVIDERNAME_XML, DataSourceIterationFile, ONE, DataAccessMethod.Sequential)]
        public void TestMethod1()
        {
            driverBusinessLibrary.NavigateToTargetURL();
        }

        [TestCleanup]
        public void WrapUpTestRun()
        {

            frameworkLibrary.WrapUpTestExecution(TestContext.CurrentTestOutcome);
        }
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;
    }
}
