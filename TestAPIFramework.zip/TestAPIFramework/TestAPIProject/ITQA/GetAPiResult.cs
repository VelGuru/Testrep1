﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using TestAPIFramework;
//using RestSharp_API_TestFramework.Model;

namespace ITQAAPIProject.ITQA
{
    [TestClass]
    public class GetAPiResult : AttributeReferences
    {
        #region Reusable Library Instantiation
        DriverAppUtilLibrary appUtilLibrary;
        //ToolsBusinessComponentsGrid1 toolsBusinessLibraryGrid1;
        API_Helper apiHelper = new API_Helper();
        FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
        #endregion
        static string _baseUrl = ConfigurationManager.AppSettings.Get("BaseUrl");
        //StudentDbContext _studentDbContext = new StudentDbContext();
        Dictionary<string, string> headers = new Dictionary<string, string>();
        string endPoint = "";
        string paraMeters = "";

        [TestInitialize]
        public void InitializeMethod()
        {
            // Initialize Run Settings
            //toolsBusinessLibraryGrid1 = new ToolsBusinessComponentsGrid1(RunConfiguration.driver);

            frameworkLibrary.InitializeRunConfigurations(TestContext);
            if (RunConfiguration.UseApi)
            {
                //frameworkLibrary.LaunchGrid();
            }
           
        }

        [TestCategory("GET")]
        [TestMethod]
        [DeploymentItem(WorkstreamConfig.TestIterationDeploymentPath), DeploymentItem(WorkstreamConfig.RegDataDeploymentPath)]
        [DataSource(PROVIDERNAME_XML, DataSourceIterationFile, ONE, DataAccessMethod.Sequential)]
        public void Can_Check_API_Health_Alive()
        {

            paraMeters = "/health-check/isAlive";
            endPoint = _baseUrl + paraMeters;
            endPoint = "http://dummy.restapiexample.com/api/v1/employees";
            headers.Add("content-type", "application/json");
            var result = API_Helper.GetRequest(endPoint, headers);
            
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
            if (HttpStatusCode.OK.Equals(result.StatusCode))
            {
                frameworkLibrary.UpdateTestLog("Actual Status Code matching with Expected Status Code", "Expected StatusCode: " + result.StatusCode, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Actual Status Code not matching with Expected Status Code", "Expected Response: " + result.StatusCode, Status.FAIL);
            }
            
            var actual = result.Content;
            var actualRespone = actual.Replace("\"", "");
            var expectedResponse = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "ContainsAssertion");
            if(actualRespone.Equals(expectedResponse))
            {
                frameworkLibrary.UpdateTestLog("Actual Response matching with Expected Response", "Expected Response: "+expectedResponse, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Actual Response not matching with Expected Response", "Expected Response: " + expectedResponse, Status.FAIL);
            }
            //var fromAPI = JsonConvert.DeserializeObject<List<Student>>(result.Content).ToList();
            //var fromDB = _studentDbContext.Students.ToList();

            //Assert.IsTrue(API_Helper.Check3Spots(fromAPI, fromDB));
        }

       // [TestCategory("GET")]
       // [TestMethod]
       //// public void Can_Retrieve_Specific_Student()
       //// {
       //    // int studentPicked;
       //     //var ids = _studentDbContext.Students.Select(s => s.StudentId).ToArray();
       //     //int randomID = ids.OrderBy(x => Guid.NewGuid()).FirstOrDefault();

       //     //if (ids.Count() >= 1)
       //     //    studentPicked = randomID;
       //     //else
       //      //   throw new Exception("There is no data to test in DB");

       //    // endPoint = _baseUrl + "/" + studentPicked;
       //     headers.Add("content-type", "application/json");
       //     var result = API_Helper.GetRequest(endPoint, headers);
       //      Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
            
       //     //var fromAPI = JsonConvert.DeserializeObject<Student>(result.Content);
       //     //var fromDB = _studentDbContext.Students.Where(s => s.StudentId == randomID).ToList().FirstOrDefault();

       //     //Assert.IsTrue(fromAPI.stEquals(fromDB));
       // }

        //[TestCleanup]
        //public void TestClean()
        //{
        //    headers.Clear();
        //    endPoint = string.Empty;
        //    //clean up the test data
        //   // _studentDbContext.Students.RemoveRange(_studentDbContext.Students.Where(s => s.Email.Contains("@test.com")));
        //   // _studentDbContext.SaveChanges();
        //}

        [TestCleanup]
        public void WrapUpTestRun()
        {
            headers.Clear();
            endPoint = string.Empty;
            frameworkLibrary.WrapUpTestExecution(TestContext.CurrentTestOutcome);
        }

        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;
    }
}