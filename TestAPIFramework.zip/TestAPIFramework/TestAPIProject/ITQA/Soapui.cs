﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using RestSharp.Serialization.Json;
using TestAPIFramework;
using FluentAssertions.Json;
using System.Text;

namespace ITQAAPIProject.ITQA
{
    [TestClass]
    public class Soapui : AttributeReferences
    {
        #region Reusable Library Instantiation
        DriverAppUtilLibrary appUtilLibrary;
        DriverBusinessLibrary driverBusinessLibrary;
        FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
        static string _baseUrl = ConfigurationManager.AppSettings.Get("BaseUrl");
         Dictionary<string, string> headers = new Dictionary<string, string>();
        string endPoint = "";
        #endregion
        [TestInitialize]
        public void InitializeMethod()
        {
            // Initialize Run Settings
            //toolsBusinessLibraryGrid1 = new ToolsBusinessComponentsGrid1(RunConfiguration.driver);

            frameworkLibrary.InitializeRunConfigurations(TestContext);
            if (RunConfiguration.UseApi)
            {
                //frameworkLibrary.LaunchGrid();
            }
        }

            [TestCategory("POST")]
        [TestMethod]
        [DeploymentItem(WorkstreamConfig.TestIterationDeploymentPath), DeploymentItem(WorkstreamConfig.RegDataDeploymentPath)]
        [DataSource(PROVIDERNAME_XML, DataSourceIterationFile, ONE, DataAccessMethod.Sequential)]
        public void ValidateAcceptAgreementsMethod()
            {
            
            endPoint = _baseUrl;
           // headers.Add("content-type", " text/xml;charset=UTF-8");

            var xmlData = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "RequestXML");

            WebRequest webRequest = WebRequest.Create(_baseUrl);
            HttpWebRequest httpRequest = (HttpWebRequest)webRequest;
            httpRequest.Method = "POST";
            httpRequest.ContentType = "text/xml; charset=utf-8";
            //httpRequest.Headers.Add("SOAPAction: http://tempuri.org/" + methodName);
            httpRequest.ProtocolVersion = HttpVersion.Version11;
            httpRequest.Credentials = CredentialCache.DefaultCredentials;
            Stream requestStream = httpRequest.GetRequestStream();
            //Create Stream and Complete Request             
            StreamWriter streamWriter = new StreamWriter(requestStream, Encoding.ASCII);

            StringBuilder soapRequest = new StringBuilder(xmlData);

            streamWriter.Write(soapRequest.ToString());
            streamWriter.Close();
            //Get the Response    
            HttpWebResponse wr = (HttpWebResponse)httpRequest.GetResponse();
            StreamReader srd = new StreamReader(wr.GetResponseStream());
            string resulXmlFromWebService = srd.ReadToEnd();

            //if (HttpStatusCode.OK.Equals(result.StatusCode))
            //{
            //    frameworkLibrary.UpdateTestLog("Actual Status Code matching with Expected Status Code", "Actual StatusCode: " + HttpStatusCode.OK, Status.PASS);
            //}
            //else
            //{
            //    frameworkLibrary.UpdateTestLog("Actual Status Code not matching with Expected Status Code", "Actual Response: " + HttpStatusCode.OK, Status.FAIL);
            //}
        }


            //var actual = result.Content;
            //JToken actualJSON = JToken.Parse(@"" + actual);
            ////var actualRespone = actual.Replace("\"", "");

            //var expectedResponse = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "ResponseXML");
            //JToken expectedJSON = JToken.Parse(@"" + expectedResponse);
            //actualJSON.Should().BeEquivalentTo(expectedJSON);

            //if (JToken.DeepEquals(actualJSON, expectedJSON))
            //{
            //    frameworkLibrary.UpdateTestLog("Actual Response matching with Expected Response", "Actual Response: " + actualJSON, Status.PASS);
            //}
            //else
            //{
            //    frameworkLibrary.UpdateTestLog("Actual Response not matching with Expected Response", "Actual Response: " + actualJSON, Status.FAIL);
            //}
            public TestContext TestContext
        {
                get
            {
                    return testContextInstance;
                }
                set
            {
                    testContextInstance = value;
                }
            }
        private TestContext testContextInstance;
    }

    }

        