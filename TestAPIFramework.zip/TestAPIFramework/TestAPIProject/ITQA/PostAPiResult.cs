﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using RestSharp.Serialization.Json;
using TestAPIFramework;
using FluentAssertions.Json;
//using RestSharp_API_TestFramework.Model;

namespace ITQAAPIProject.ITQA
{
    [TestClass]
    public class PostAPiResult : AttributeReferences
    {
        #region Reusable Library Instantiation
        DriverAppUtilLibrary appUtilLibrary;
        //ToolsBusinessComponentsGrid1 toolsBusinessLibraryGrid1;
        API_Helper apiHelper = new API_Helper();
        FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
        #endregion
        static string _baseUrl = ConfigurationManager.AppSettings.Get("BaseUrl");
        //StudentDbContext _studentDbContext = new StudentDbContext();
        Dictionary<string, string> headers = new Dictionary<string, string>();
        string endPoint = "";
        string paraMeters = "";

        [TestInitialize]
        public void InitializeMethod()
        {
            // Initialize Run Settings
            //toolsBusinessLibraryGrid1 = new ToolsBusinessComponentsGrid1(RunConfiguration.driver);

            frameworkLibrary.InitializeRunConfigurations(TestContext);
            if (RunConfiguration.UseApi)
            {
                //frameworkLibrary.LaunchGrid();
            }
           
        }

        [TestCategory("POST")]
        [TestMethod]
        [DeploymentItem(WorkstreamConfig.TestIterationDeploymentPath), DeploymentItem(WorkstreamConfig.RegDataDeploymentPath)]
        [DataSource(PROVIDERNAME_XML, DataSourceIterationFile, ONE, DataAccessMethod.Sequential)]
        public void Can_Check_Validate_Address()
        {

            paraMeters = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "ApiParameters");
            endPoint = _baseUrl + paraMeters;
            headers.Add("content-type", "application/json");

            //Student postData = new Student()
            //{
            //    zipCode = "40220",
            //    LastName = "testLastName",
            //    Email = "test@test.com",
            //    Phone = "3939992222",
            //    isActive = true
            //};

            //var jsonData = JsonConvert.SerializeObject(postData);
            //string jsonData = "{'zipCode': '40220'}";
            var jsonData = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "RequestXML");
            
            var result = API_Helper.PostRequest(endPoint, headers, jsonData);

            if (HttpStatusCode.OK.Equals(result.StatusCode))
            {
                frameworkLibrary.UpdateTestLog("Actual Status Code matching with Expected Status Code", "Actual StatusCode: " + HttpStatusCode.OK, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Actual Status Code not matching with Expected Status Code", "Actual Response: " + HttpStatusCode.OK, Status.FAIL);
            }


            var actual = result.Content;
            JToken actualJSON = JToken.Parse(@"" + actual);
            //var actualRespone = actual.Replace("\"", "");
            
            var expectedResponse = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "ResponseXML");
            JToken expectedJSON = JToken.Parse(@""+expectedResponse);
            actualJSON.Should().BeEquivalentTo(expectedJSON);

            if (JToken.DeepEquals(actualJSON, expectedJSON))
            {
                frameworkLibrary.UpdateTestLog("Actual Response matching with Expected Response", "Actual Response: " + actualJSON, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Actual Response not matching with Expected Response", "Actual Response: " + actualJSON, Status.FAIL);
            }
            

            
            
            //var fromAPI = JsonConvert.DeserializeObject<List<Student>>(result.Content).ToList();
            //var fromDB = _studentDbContext.Students.ToList();

            //Assert.IsTrue(API_Helper.Check3Spots(fromAPI, fromDB));
        }
        [TestCategory("X509_POST")]
        [TestMethod]
        [DeploymentItem(WorkstreamConfig.TestIterationDeploymentPath), DeploymentItem(WorkstreamConfig.RegDataDeploymentPath)]
        [DataSource(PROVIDERNAME_XML, DataSourceIterationFile, ONE, DataAccessMethod.Sequential)]
        public void Can_Check_Claims()
        {
            paraMeters = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "ApiParameters");
            endPoint = "https://dev-claimssvcs.humana.com:48022" + paraMeters;
            headers.Add("content-type", "application/json");
            headers.Add("calling_source", "thor");

            var jsonData = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "RequestXML");

            var result = API_Helper.PostRequest(endPoint, headers, jsonData);
            var value = result.StatusCode;
            Console.WriteLine(result.Content);
            string actual1 = result.Content;
            JToken actualJSON1 = JToken.Parse(@"" + actual1);
            var response2 = actualJSON1.First;
            var response3 = actualJSON1.Last;

            var actual = result.Content;
            JToken actualJSON = JToken.Parse(@"" + actual);

            

            if (HttpStatusCode.OK.Equals(result.StatusCode))
            {
                frameworkLibrary.UpdateTestLog("Actual Status Code matching with Expected Status Code", "Expected JSON: " + actualJSON, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Actual Status Code not matching with Expected Status Code", "Expected JSON Response: " + actualJSON, Status.FAIL);
            }


          
            //var actualRespone = actual.Replace("\"", "");

            var expectedResponse = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "ResponseXML");


            string[] splitString = expectedResponse.Split(':');

            string Key = '"'+splitString[0].Trim()+'"'+':';

            string Pair = '"'+splitString[1].Trim() + '"';

            string actualVal = String.Concat(Key, Pair);


            if (actual.Contains(actualVal))
            {
                frameworkLibrary.UpdateTestLog("MemberID Present in Expected Response", "Actual Response: " + actualJSON, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("MemberID Not Present in Expected Response", "Actual Response: " + actualJSON, Status.FAIL);
            }        

        }
        [TestCategory("X509_POST")]
        [TestMethod]
        [DeploymentItem(WorkstreamConfig.TestIterationDeploymentPath), DeploymentItem(WorkstreamConfig.RegDataDeploymentPath)]
        [DataSource(PROVIDERNAME_XML, DataSourceIterationFile, ONE, DataAccessMethod.Sequential)]
        public void Can_Check_Multiple_Claims()
        {
            paraMeters = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "ApiParameters");
            endPoint = paraMeters;
            headers.Add("content-type", "application/json");
            headers.Add("calling_source", "thor");

            string[] jsonData1 = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.apiControlsTable, "RequestXML").Split(';');
            string[] expectedResponse = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.apiControlsTable, "ResponseXML").Split(';');
            var jsonData = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "RequestXML");
            for (int j = 0; j < jsonData1.Length; j++)
            {


                var result = API_Helper.PostRequest(endPoint, headers, jsonData1[j]);
                var value = result.StatusCode;
                Console.WriteLine(result.Content);
                string actual1 = result.Content;

                JToken actualJSON1 = JToken.Parse(@"" + actual1);
                var response2 = actualJSON1.First;
                var response3 = actualJSON1.Last;

                var actual = result.Content;
                JToken actualJSON = JToken.Parse(@"" + actual);



                if (HttpStatusCode.OK.Equals(result.StatusCode))
                {
                    frameworkLibrary.UpdateTestLog("Actual Status Code matching with Expected Status Code", "Expected JSON: " + actualJSON, Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Actual Status Code not matching with Expected Status Code", "Expected JSON Response: " + actualJSON, Status.FAIL);
                }



                //var actualRespone = actual.Replace("\"", "");


                for (int i = 0; i < expectedResponse.Length; i++)
                {

                    string[] splitString = expectedResponse[i].Split(':');

                    string Key = '"' + splitString[0].Trim() + '"' + ':';

                    string Pair = '"' + splitString[1].Trim() + '"';

                    string actualVal = String.Concat(Key, Pair);


                    if (actual.Contains(actualVal))
                    {

                        frameworkLibrary.UpdateTestLog("MemberID Present in Expected Response", "Actual Response: " + actualJSON, Status.PASS);
                    }
                    else
                    {
                        frameworkLibrary.UpdateTestLog("MemberID Not Present in Expected Response", "Actual Response: " + actualJSON, Status.FAIL);
                    }

                }
                //Check if sourcefile is not null and has values 
            }
        }
        [TestCategory("X509_POST")]
        [TestMethod]
        [DeploymentItem(WorkstreamConfig.TestIterationDeploymentPath), DeploymentItem(WorkstreamConfig.RegDataDeploymentPath)]
        [DataSource(PROVIDERNAME_XML, DataSourceIterationFile, TWO, DataAccessMethod.Sequential)]
        public void Can_Check_Send_Claims()
        {
            paraMeters = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "ApiParameters");
            endPoint = paraMeters;
            headers.Add("content-type", "application/json");
            headers.Add("calling_source", "thor");

            var jsonData = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "RequestXML");

            var result = API_Helper.PostRequest(endPoint, headers, jsonData);
            var value = result.StatusCode;
            Console.WriteLine(result.Content);
            string actual1 = result.Content;

            JToken actualJSON1 = JToken.Parse(@"" + actual1);
            var response2 = actualJSON1.First;
            var response3 = actualJSON1.Last;

            var actual = result.Content;
            JToken actualJSON = JToken.Parse(@"" + actual);



            if (HttpStatusCode.OK.Equals(result.StatusCode))
            {
                frameworkLibrary.UpdateTestLog("Actual Status Code matching with Expected Status Code", "Expected JSON: " + actualJSON, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Actual Status Code not matching with Expected Status Code", "Expected JSON Response: " + actualJSON, Status.FAIL);
            }



            //var actualRespone = actual.Replace("\"", "");

            var expectedResponse = frameworkLibrary.GetTestData_API(RunConfiguration.testCaseContext.apiControlsTable, "ResponseXML");


            string[] splitString = expectedResponse.Split(':');

            string Key = '"' + splitString[0].Trim() + '"' + ':';

            string Pair = '"' + splitString[1].Trim() + '"';

            string actualVal = String.Concat(Key, Pair);


            if (actual.Contains(actualVal))
            {

                frameworkLibrary.UpdateTestLog("MemberID Present in Expected Response", "Actual Response: " + actualJSON, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("MemberID Not Present in Expected Response", "Actual Response: " + actualJSON, Status.FAIL);
            }

            //Check if sourcefile is not null and has values 
        }
        [TestCleanup]
        public void WrapUpTestRun()
        {
            headers.Clear();
            endPoint = string.Empty;
            frameworkLibrary.WrapUpTestExecution(TestContext.CurrentTestOutcome);
        }

        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;
    }
}