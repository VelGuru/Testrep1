﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAPIFramework
{
    public class WorkstreamConfig
    {
        // Deployment Parameters
        public const string RegDataDeploymentPath = "TestAPIData\\";
        public const string TestIterationDeploymentPath = "TestAPIData\\TestIteration.xml";

    }
}
