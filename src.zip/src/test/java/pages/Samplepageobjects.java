package pages;

import org.openqa.selenium.By;

import frameworkcore.ScriptHelper;


public class Samplepageobjects {

	public static String ele_Register = "ico-register";
	public static String ele_Male = "//input[@id='gender-male']";
	public static String ele_FirstName = "//input[@id='FirstName']";
	public static String ele_LastName = "//input[@id='LastName']";
	public static String ele_Email = "//input[@id='Email']";
	public static String ele_Password = "//input[@id='Password']";
	public static String ele_cnfPassword = "//input[@id='ConfirmPassword']";

	public static String btn_Register = "register-button";

	public static String obj_Email = "//a[@class='account']";
	public static String obj_Result = "//div[@class='result']";

	public static String ele_Books = "//ul[@class='list']/li/a[@href='/books']";

	public static String ele_Computing = "//h2//a[@href='/computing-and-internet']";
	public static String ele_Quantity = "//input[@id='addtocart_13_EnteredQuantity']";

	public static String btn_AddtoCart = "//input[@id='add-to-cart-button-13']";

	public static String obj_email = "//div[@class='header-links']/ul/li/a[@href='/customer/info']";
	
	public static String obj_shoppingCart = "//li[@id='topcartlink']/a";

	public static String dd_Country = "CountryId";
	public static String dd_State = "StateProvinceId";

	public static String dd_BillingCountry = "BillingNewAddress.CountryId";
	public static String dd_BillingState = "BillingNewAddress.StateProvinceId";

	public static String ele_zipCode = "//input[@id='ZipPostalCode']";

	public static String ele_Estiamte = "//input[@name='estimateshipping']";

	public static String ele_termsChkBox = "//input[@id='termsofservice']";
	public static String btn_Chkout = "//button[@id='checkout']";

	public static String ele_city = "//input[@id='BillingNewAddress_City']";
	public static String ele_Address1 = "//input[@id='BillingNewAddress_Address1']";
	public static String ele_Code = "//input[@id='BillingNewAddress_ZipPostalCode']";
	public static String ele_phNum = "//input[@id='BillingNewAddress_PhoneNumber']";
	public static String btn_Continue = "//div[@id='billing-buttons-container']//input";
	public static String btn_Continue1 = "//div[@id='shipping-buttons-container']//input";
	public static String btn_Continue2 = "//div[@id='shipping-method-buttons-container']//input";
	public static String btn_Continue3= "//div[@id='payment-method-buttons-container']//input";
	public static String btn_Continue4 = "//div[@id='payment-info-buttons-container']//input";
	
	public static String ele_shippingMethod = "//input[@id='shippingoption_1']";
	public static String ele_creditChkBox = "//input[@id='paymentmethod_2']";
	public static String ele_CardHolder = "//input[@id='CardholderName']";
	public static String ele_CardNum = "//input[@id='CardNumber']";
	public static String ele_CardCode = "//input[@id='CardCode']";

	public static String dd_CardType = "CreditCardType";
	// SampletestCase
	public static String dd_Month = "ExpireMonth";

	public static String dd_year = "ExpireYear";

	public static String btn_confirm = "//div[@id='confirm-order-buttons-container']//input";

	//public static String ele_OrderNum = "*//li[starts-with(normalize-space(),'Order number:')]";

	public Samplepageobjects(ScriptHelper scriptHelper) {
		super();
		// TODO Auto-generated constructor stub
	}

	// public static final By imgFlights = By.xpath("//a/img");s
}