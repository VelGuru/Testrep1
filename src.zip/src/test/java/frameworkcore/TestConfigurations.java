package frameworkcore;

import java.lang.reflect.Method;
import java.util.Properties;

import org.testng.annotations.DataProvider;
import java.util.Properties;
import frameworkselenium.Browser;
import frameworkselenium.ExecutionMode;
import frameworkselenium.MobileExecutionPlatform;
import frameworkselenium.SeleniumParametersBuilders;
import frameworkselenium.ToolName;
import frameworkseleniumcore.Settings;
import frameworkseleniumcore.*;

public class TestConfigurations extends CRAFTTestCase {
	private Properties properties;
	
	@DataProvider(name = "DesktopBrowsers")
	public Object[][] desktopBrowsers(Method currentMethod) {
		currentScenario = currentMethod.getDeclaringClass().getSimpleName();
		currentTestcase = currentMethod.getName();
		
		//Object properties;
		//currentTestcase = currentTestcase.substring(0, 1).toUpperCase().concat(currentTestcase.substring(1));
		
		return new Object[][] {
			
				{ new SeleniumParametersBuilders(currentScenario, currentTestcase).extentReport(extentReport)
						.extentTest(extentTest).testInstance("Instance1").executionMode(ExecutionMode.LOCAL)
						//This particular line of code will fetch the browser value from Global Properties file
						.browser(Browser.valueOf(Settings.getInstance().getProperty("DefaultBrowser"))).build() }};
						
	}

	@DataProvider(name = "MobileDevice")
	public Object[][] mobileDevice(Method currentMethod) {
		currentScenario = currentMethod.getDeclaringClass().getSimpleName();
		currentTestcase = currentMethod.getName();
		//currentTestcase = currentTestcase.substring(0, 1).toUpperCase().concat(currentTestcase.substring(1));

		return new Object[][] { { new SeleniumParametersBuilders(currentScenario, currentTestcase)
				.testInstance("Instance1").extentReport(extentReport).extentTest(extentTest)
				.executionMode(ExecutionMode.MOBILE).mobileExecutionPlatform(MobileExecutionPlatform.WEB_ANDROID)
				.toolName(ToolName.APPIUM).deviceName("1215fc22b4101e04").build() } };
	}

	@DataProvider(name = "API")
	public Object[][] api(Method currentMethod) {
		currentScenario = currentMethod.getDeclaringClass().getSimpleName();
		currentTestcase = currentMethod.getName();
		//currentTestcase = currentTestcase.substring(0, 1).toUpperCase().concat(currentTestcase.substring(1));

		return new Object[][] {
				{ new SeleniumParametersBuilders(currentScenario, currentTestcase).testInstance("Instance1")
						.extentReport(extentReport).extentTest(extentTest).executionMode(ExecutionMode.API).build() } };
	}

	@DataProvider(name = "DesktopBrowsersParallel", parallel = true)
	public Object[][] desktopBrowsersParallel(Method currentMethod) {
		currentScenario = currentMethod.getDeclaringClass().getSimpleName();
		currentTestcase = currentMethod.getName();
		//currentTestcase = currentTestcase.substring(0, 1).toUpperCase().concat(currentTestcase.substring(1));

		return new Object[][] {
				{ new SeleniumParametersBuilders(currentScenario, currentTestcase).extentReport(extentReport)
						.extentTest(extentTest).testInstance("Instance1").executionMode(ExecutionMode.LOCAL)
						//.browser(Browser.CHROME).build() },
						//This particular line of code will fetch the browser value from Global Properties file
						.browser(Browser.valueOf(Settings.getInstance().getProperty("DefaultBrowser"))).build() },
				{ new SeleniumParametersBuilders(currentScenario, currentTestcase).extentReport(extentReport)
						.extentTest(extentTest).testInstance("Instance2").executionMode(ExecutionMode.LOCAL)
						//.browser(Browser.CHROME).build() },
						//This particular line of code will fetch the browser value from Global Properties file
						.browser(Browser.valueOf(Settings.getInstance().getProperty("DefaultBrowser"))).build() },
				{ new SeleniumParametersBuilders(currentScenario, currentTestcase).extentReport(extentReport)
						.extentTest(extentTest).testInstance("Instance3").executionMode(ExecutionMode.LOCAL)
						//.browser(Browser.CHROME).build() } };
						//This particular line of code will fetch the browser value from Global Properties file
						.browser(Browser.valueOf(Settings.getInstance().getProperty("DefaultBrowser"))).build() }};
	}

}