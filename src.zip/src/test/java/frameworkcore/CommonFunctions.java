package frameworkcore;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.internal.Dynamic;

import frameworkseleniumcore.Status;
import io.appium.java_client.functions.ExpectedCondition;

public class CommonFunctions extends ReusableLibrary {

	// In this class file we written some methods to perform some actions

	public CommonFunctions(ScriptHelper scriptHelper) {
		super(scriptHelper);
		// TODO Auto-generated constructor stub
	}

	/// <summary>
	/// Click button Control by using the button id as input parameter
	/// </summary>
	/// <param id="buttonID">Button ID</param>
	public static void ClickButtonById(String id, String ButtonDesc) {

		WebElement Button = driver.findElement(By.id(id));

		if (Button != null) {
			Button.click();
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is clicked successfully", Status.PASS);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else {
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is not available in the page",
					Status.FAIL);
		}
	}

	/// <summary>
	/// Click button Control by using the button name as input parameter
	/// </summary>
	/// <param name="buttonName">Button Name</param>
	public static void ClickButtonByClassName(String name, String ButtonDesc) {

		WebElement Button = driver.findElement(By.className(name));

		if (Button != null) {
			Button.click();
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is clicked successfully", Status.PASS);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else {
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is not available in the page",
					Status.FAIL);
		}
	}

	/// <summary>
	/// Click button by xpath using the button xpath as input parameter
	/// </summary>
	/// <param xpath="xpath">Button Name</param>

	public static void ClickButtonByXPath(String xpath, String ButtonDesc) {

		WebElement Button = driver.findElement(By.xpath(xpath));

		if (Button != null) {
			Button.click();
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is clicked successfully", Status.PASS);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else {
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is not available in the page",
					Status.FAIL);
		}
	}

	/// <summary>
	/// Check WebElement is displayed
	/// </summary>
	/// <param name="element">Element to identify</param>
	/// <param name="elementDesc">Element Description</param>
	/// <param name="objectSearchTimeout">Object Search Timeout</param>
	/// <param name="continueOnFail">Continue on Fail</param>

	public static Boolean IsWebElementDisplayed(String Element, String elementDesc, int timeoutInSeconds,
			Boolean continueOnFail) {
		@SuppressWarnings("unused")
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		Boolean elementDisplayed = false;
		try {
			if (timeoutInSeconds != 0) {
				driver.manage().timeouts().implicitlyWait(timeoutInSeconds, TimeUnit.SECONDS);
			}
			if (Element == null) {

				report.updateTestLog("IsWebElementDisplayed", elementDesc + " is not available in the page",
						Status.FAIL);
			} else {
				report.updateTestLog("IsWebElementDisplayed", elementDesc + " is available in the page", Status.PASS);
				elementDisplayed = true;
			}
		} catch (Exception e) {
			report.updateTestLog("Error", e.getMessage(), "", Status.FAIL);

		} finally {
			if (timeoutInSeconds != 0) {
				driver.manage().timeouts().implicitlyWait(timeoutInSeconds, TimeUnit.SECONDS);
			}
		}
		return elementDisplayed;
	}

	/// <summary>
	/// Check WebElement is not available
	/// </summary>
	/// <param name="locator">Locator Type</param>
	/// <param name="elementDesc"></param>
	/// <param name="parentElement"></param>
	/// <param name="objectSearchTimeout"></param>
	/// <param name="continueOnFail"></param>
	/// <returns></returns>
	public static Boolean IsWebElementNotAvailable(By locator, String elementDesc, WebElement parentElement,
			int objectSearchTimeout, Boolean continueOnFail) {
		Boolean elementNotDisplayed = false;
		WebDriverWait wait = new WebDriverWait(driver, objectSearchTimeout);
		try {
			elementNotDisplayed = wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));

			if (Boolean.FALSE) {
				report.updateTestLog("Exception", elementDesc + " Element is not available", Status.PASS);
			}
		} catch (TimeoutException t) {
			report.updateTestLog("TimeoutException", "Timed out waiting for element " + elementDesc, Status.FAIL);
		} catch (Exception e) {
			report.updateTestLog("Exception", elementDesc + " Element is available", Status.FAIL);
		}
		return elementNotDisplayed;
	}

	/// <summary>
	/// Validate element by an attribute
	/// <param name="tagname">Locator Type</param>
	/// <param name="attribute_value"></param>
	/// <param name="value"></param>
	/// <param name="Element"></param>
	/// <param name="parentElement"></param>
	/// </summary>

	public static void ValidateWebElementByAttribute(String tagname, String attribute_value, String value,
			WebElement Element, WebElement parentElement) {
		if (Element == null) {
			try {
				WebElement element = driver
						.findElement(By.xpath(".//" + tagname + "[" + attribute_value + "='" + value + "']"));
				if (element.isDisplayed()) {
					report.updateTestLog("Element with the " + value + " is available",
							"Element with the " + value + " is available", Status.PASS);
				}
			} catch (Exception e) {
				report.updateTestLog("Element with the " + value + " is not available",
						"Element with the " + value + " is not available", Status.FAIL);
			}
		} else {
			try {
				if (Element.isDisplayed()) {
					report.updateTestLog("Element with the " + value + " is available",
							"Element with the " + value + " is available", Status.PASS);
				}
			} catch (Exception e) {
				report.updateTestLog("Element with the " + value + " is not available",
						"Element with the " + value + " is not available", Status.FAIL);
			}
		}
	}

	/// <summary>
	/// Is element present using innertext
	/// <param name="attributeName">Locator Type</param>
	/// <param name="text"></param>
	/// <param name="tagName"></param>
	/// <param name="parentElement"></param>

	/// </summary>

	public static void ValidateElementIsPresent(String attributeName, String[] text, String[] tagName,
			WebElement parentElement) {
		for (int i = 0; i < text.length; i++) {
			WebElement locator = driver
					.findElement(By.xpath("//" + tagName[i] + "[" + attributeName + "='" + text[i] + "']"));
			if (locator.isEnabled()) {
				report.updateTestLog(text[i] + " is present", text[i] + " is present", Status.PASS);
			} else {
				report.updateTestLog(text[i] + " is  not found", text[i] + " is not found", Status.FAIL);
			}
		}
	}

	/// <summary>
	/// Validate expected and actual value matches
	/// </summary>
	/// <param name="expectedValue">ExpectedValue</param>
	/// <param name="actualValue">ActualValue</param>
	/// <param name="controlType">ControlType</param>

	public static void AssertEquals(String expectedValue, String actualValue, String controlType) {
		if (expectedValue.equals(actualValue)) {
			report.updateTestLog("Equals",
					controlType + " - ExpectedValue(" + expectedValue + ") is matched with actual", Status.PASS);
		} else {
			report.updateTestLog("Equals", controlType + " - ExpectedValue(" + expectedValue
					+ ") is not matched with actualvalue(" + actualValue + ")", Status.FAIL);
		}
	}

	/// <summary>
	/// Click Link Control
	/// </summary>
	/// <param name="linkControl">Link Control</param>
	/// <param name="linkDesc">ExpectedValue</param>

	public static Boolean ClickLink(WebElement linkControl, String linkDesc, Boolean addLinkDescToLog) {
		// Check for Link Control Exist in the Page
		if (linkControl.isEnabled() || linkControl.isDisplayed()) {
			String linkName = linkControl.getText();
			report.updateTestLog("Page Navigation", linkDesc + " Link(" + linkName + ") is displayed successfully",
					Status.PASS);
			linkControl.click();
			if (addLinkDescToLog) {
				report.updateTestLog("Page Navigation", linkDesc + " Link(" + linkName + ") is clicked successfully",
						Status.PASS);
			} else {
				report.updateTestLog("Page Navigation", "Link(" + linkName + ") is not clicked successfully",
						Status.FAIL);
			}

			return true;
		} else {
			report.updateTestLog("Page Navigation", "Link(" + linkDesc + ") is not displayed in the page", Status.FAIL);
			return false;
		}
	}

	/// <summary>
	/// Click button Control by JavaScript Executor using the button Name as input
	/// <param name="xpath">ExpectedValue</param>
	/// <param name="ButtonDesc">ActualValue</param>
	/// </summary>

	public static void ClickByXpathUsingJS(String xpath, String ButtonDesc) {

		WebElement Button = driver.findElement(By.xpath(xpath));

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		if (Button != null) {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			executor.executeScript("arguments[0].click();", Button);
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is clicked successfully", Status.PASS);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else {
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is not available in the page",
					Status.FAIL);
		}
	}

	/// <summary>
	/// Click button Control by JavaScript Executor using the button Name as input
	/// parameter
	/// </summary>
	/// <param id="buttonName">Button id</param>

	public static void ClickByIDUsingJS(String id, String ButtonDesc) {

		WebElement Button = driver.findElement(By.id(id));

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		if (Button != null) {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			executor.executeScript("arguments[0].click();", Button);
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is clicked successfully", Status.PASS);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else {
			report.updateTestLog("Click Button", "Button(" + ButtonDesc + ") is not available in the page",
					Status.FAIL);
		}
	}

	/// Validate Paragraph text using contains
	/// </summary>
	/// <param name="parentControl">Parent UI Control</param>
	/// <param name="content">content</param>
	/// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>

	public static void ValidateTextParagraph(String content, String tagName, WebElement parentElement) {
		WebElement paragraph = driver.findElement(By.xpath("//" + tagName + "[contains(.,'" + content + "')]"));

		// Check for Link Control Exist in the Page //p[contains(.,'Get')]
		if (paragraph.isEnabled() || paragraph.isDisplayed()) {
			String linkName = paragraph.getText();
			report.updateTestLog("Page Navigation", " Element(" + linkName + ") is present in the web page",
					Status.PASS);
		} else {
			report.updateTestLog("Page Navigation", "Element(" + content + ") is not displayed in the page",
					Status.FAIL);
		}
	}

	/// <summary>
	/// Validate the display of element using the following tag and
	/// parentControl
	/// <summary>
	/// <param name="parentControl">Parent UI Control</param>

	public void ValidateDisplayOfElementWithTag(String tagName, WebElement parentElement) {
		String elementControl = parentElement.findElement(By.tagName(tagName)).toString();

		// Check for Link Control Exist in the Page
		if (IsWebElementDisplayed(elementControl, "", 5, false)) {
			report.updateTestLog("Element", "Element is displayed in the Page", Status.PASS);
		} else {
			report.updateTestLog("Element", "Element is not displayed in the Page", Status.FAIL);
		}
	}

	/// Clicking the Link by id
	/// </summary>
	/// <param name="idName">idName</param>
	/// <param name="idDesc">id description</param>

	public static void ClickLinkByID(String idName, String idDesc) {
		try {
			WebElement LinkByID = driver.findElement(By.id(idName));
			if (LinkByID != null) {
				LinkByID.click();
				report.updateTestLog("Page Navigation", "Link(" + idDesc + ") is clicked successfully", Status.PASS);
			} else {
				report.updateTestLog("Page Navigation", idDesc + " - Link(" + idDesc + ") is not available in the page",
						Status.FAIL);
			}
		} catch (NoSuchElementException e) {
			report.updateTestLog("Element" + idDesc + "is not found", "Element" + idDesc + "is not found", Status.FAIL);
		}

	}

	/// </summary>
	/// <param name="SectionName">Parent UI Control</param>
	/// <param name="Tag">Header Name</param>
	/// <param name="parentElement"></param>

	public static void ClickSectionByNameandTag(String SectionName, String Tag, WebElement parentElement) {
		String SectionControl = driver.findElement(By.xpath(".//" + Tag + "[.='" + SectionName + "']")).toString();

		// Check for Link Control Exist in the Page
		if (IsWebElementDisplayed(SectionControl, "", 5, false)) {
			WebElement sectionClick = driver.findElement(By.xpath(SectionControl));
			if (sectionClick.isDisplayed()) {
				report.updateTestLog("Section", "Section - " + SectionName + " is displayed in the Page", Status.PASS);
			} else {
				report.updateTestLog("Section", "Section - " + SectionName + " is not displayed in the Page",
						Status.FAIL);
			}
			sectionClick.click();
		}
	}

	/// Clicking the Link by classname
	/// </summary>
	/// <param name="idName">idName</param>
	/// <param name="idDesc">id description</param>>

	public static void ClickLinkByClassName(String className, String idDesc) {
		try {
			WebElement LinkByID = driver.findElement(By.className(className));
			if (LinkByID != null) {
				LinkByID.click();
				report.updateTestLog("Page Navigation", "Link(" + idDesc + ") is clicked successfully", Status.PASS);
			} else {
				report.updateTestLog("Page Navigation", idDesc + " - Link(" + idDesc + ") is not available in the page",
						Status.FAIL);
			}
		} catch (NoSuchElementException e) {
			report.updateTestLog("Element" + idDesc + "is not found", "Element" + idDesc + "is not found", Status.FAIL);
		}

	}

	/// <summary>
	/// Validate Page by the section
	/// </summary>
	/// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>
	/// <param name="attributeName">attributeName</param>
	/// <param name="usePageLoadTimeOut">Wait For Page load if it's true [Default
	/// True]</param>

	public static void ValidatePageSection(String headerTag,String attributeValue ) {
		WebElement section = null;

		if (!headerTag.isEmpty()) {
			section = driver
					.findElement(By.xpath("//" + headerTag + ""));
		} else {
			
		}
		if (section.isEnabled()) {
			report.updateTestLog(  " Section is present", attributeValue + " Section is present",
					Status.PASS);
		} else {
			report.updateTestLog( " Section is  not present", attributeValue + " Section is not present",
					Status.FAIL);
		}
	}

	/// <summary>
	/// Click Link Control by using the Link Name as input parameter
	/// </summary>
	/// <param name="linkName">Link Name</param>
	/// <param name="parentControl">Parent Section</param>
	/// <param name="indexValue">Index Value - If more links available in the same
	/// Name</param>

	public static Boolean ValidateLinkByName(String linkName, Dynamic parentControl, String linkDesc,
			String childTagIfPresent) {
		WebElement linkElement = null;
		// Check for Link Control Exist in the Page
		try {
			linkElement = driver.findElement(By.linkText(linkName));
			report.updateTestLog(linkName + " web element is found", linkName + " web element is found", Status.PASS);
		} catch (Exception e) {

			report.updateTestLog(linkName + " web element is not found", linkName + " web element is not found",
					Status.FAIL);
		}
		if (linkElement != null) {
			linkElement.click();
			report.updateTestLog("Page Navigation", "Link(" + linkName + ") is present", Status.PASS);
			return true;
		} else {
			if (linkDesc.isEmpty()) {
				report.updateTestLog("Page Navigation", "Link(" + linkName + ") is not available in the page",
						Status.FAIL);
			} else {
				report.updateTestLog("Page Navigation",
						linkDesc + " - Link(" + linkName + ") is not available in the page", Status.FAIL);
			}
			return false;
		}
	}
	/// <summary>
	/// Explicit Wait statement for a web element
	/// </summary>

	public static void ExplicitWaitForElement(By byElement, int secwait, String desc) {
		try {
			@SuppressWarnings("unused")
			WebElement expWait = (new WebDriverWait(driver, secwait)
					.until(ExpectedConditions.presenceOfElementLocated(byElement)));
		} catch (Exception e) {
			if (!desc.isEmpty()) {
				report.updateTestLog("Explicit wait", "Explicit wait for finding " + desc + " has failed", Status.FAIL);
			}
		}
	}

	/// Get WebElement
	/// </summary>
	/// <param name="locator"></param>
	/// <param name="elementDesc"></param>
	/// <param name="parentElement"></param>
	/// <param name="objectSearchTimeout"></param>
	/// <param name="returnNullIfNot"></param>
	/// <param name="continueOnFail"></param>
	/// <returns></returns>

	public static WebElement FindElement(By locator, String elementDesc, WebElement parentElement,
			int objectSearchTimeout, Boolean returnNullIfNot, Boolean continueOnFail) {
		WebElement element = null;
		try {
			if (objectSearchTimeout != 0) {
				driver.manage().timeouts().implicitlyWait(objectSearchTimeout, TimeUnit.SECONDS);
			}
			if (parentElement == null) {
				element = driver.findElement(locator);
				String elementValue = element.getText().toString();
			} else {
				element = parentElement.findElement(locator);
				String elementValue = element.getText().toString();
			}
		} catch (NoSuchElementException e) {
			if (!elementDesc.isEmpty()) {
				// Log Report
				report.updateTestLog("Element", "Element-" + elementDesc + " is not available in the page",
						Status.FAIL);
			}

			if (!returnNullIfNot) {
				throw e;
			}
		} finally {
			if (objectSearchTimeout != 0) {
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			}
		}
		return element;
	}

	/// <summary>
	/// Click Link Control by using the Link Name as input parameter
	/// </summary>
	/// <param name="linkName">Link Name</param>
	/// <param name="parentControl">Parent Section</param>
	/// <param name="indexValue">Index Value - If more links available in the same
	/// Name</param>

	public static Boolean ClickLinkByPartialName(String linkName, WebElement parentControl, String linkDesc,
			String childTagIfPresent) {
		By linkControl = By.xpath(".//a[contains(.,'" + linkName + "')]");
		if (!childTagIfPresent.isEmpty()) {
			linkControl = By.xpath(".//a/" + childTagIfPresent + "[contains(.,'" + linkName + "')]/..");
		}

		ExplicitWaitForElement(linkControl, 20, "");
		// Check for Link Control Exist in the Page
		WebElement linkElement = FindElement(linkControl, "", parentControl, 5, true, true);
		if (linkElement != null) {
			linkElement.click();
			report.updateTestLog("Page Navigation", "Link(" + linkName + ") is clicked successfully", Status.PASS);
			return true;
		} else {
			if (linkDesc.isEmpty()) {
				report.updateTestLog("Page Navigation", "Link(" + linkName + ") is not available in the page",
						Status.FAIL);
			} else {
				report.updateTestLog("Page Navigation",
						linkDesc + " - Link(" + linkName + ") is not available in the page", Status.FAIL);
			}
			return false;
		}
	}

	/// <summary>
	/// Validate button is present or not by using the button Name as input
	/// parameter
	/// </summary>
	/// <param name="buttonName">Button Name</param>
	/// <param name="parentControl">Parent Section</param>
	/// <param name="indexValue">Index Value - If more links available in the same
	/// Name</param>

	public static void ValidateButtonByName(String buttonName, Dynamic parentControl, String childTagIfPresent,
			String buttonDesc) {

		WebElement uIButton = null;

		if (!childTagIfPresent.isEmpty()) {
			uIButton = driver.findElement(By.xpath(".//button/" + childTagIfPresent + "[.='" + buttonName + "']/.."));
		} else {
			uIButton = driver.findElement(By.xpath(".//button[.='" + buttonName + "']"));
		}

		if (uIButton != null) {
			report.updateTestLog("Button Validations", "Button(" + buttonName + ") is available in the page",
					Status.PASS);
		} else {
			report.updateTestLog("Button Validations", "Button(" + buttonName + ") is not available in the page",
					Status.FAIL);
		}
	}

	/// <summary>
	/// Validate button is present or not by button partial Name as input parameter
	/// </summary>
	/// <param name="buttonName">Button Name</param>
	/// <param name="parentControl">Parent Section</param>
	/// <param name="indexValue">Index Value - If more links available in the same
	/// Name</param>

	public static void ValidateButtonByPartialName(String buttonName, Dynamic parentControl, String childTagIfPresent,
			String buttonDesc) {

		WebElement uIButton = null;

		if (!childTagIfPresent.isEmpty()) {
			uIButton = driver
					.findElement(By.xpath(".//button/" + childTagIfPresent + "[contains(text(),'" + buttonName + "']"));
		} else {
			uIButton = driver.findElement(By.xpath(".//button[contains(text(),'" + buttonName + "')]"));
		}

		if (uIButton != null) {
			report.updateTestLog("Page Navigation", "Button(" + buttonName + ") is successfully displayed in the page",
					Status.PASS);
		} else {
			report.updateTestLog("Page Navigation", "Button(" + buttonName + ") is not available in the page",
					Status.FAIL);
		}
	}

	/// <summary>
	/// Click button Control by using the button by partial Name as input parameter
	/// </summary>
	/// <param name="buttonName">Button Name</param>
	/// <param name="parentControl">Parent Section</param>
	/// <param name="indexValue">Index Value - If more links available in the same
	/// Name</param>

	public static void ClickButtonByPartialName(String buttonName, Dynamic parentControl, String childTagIfPresent,
			String buttonDesc) {

		WebElement uIButton = null;

		if (!childTagIfPresent.isEmpty()) {
			uIButton = driver.findElement(By.xpath(".//button/" + childTagIfPresent + "[.='" + buttonName + "']"));
		} else {
			uIButton = driver.findElement(By.xpath(".//button[contains(text(),'" + buttonName + "')]"));
		}

		if (uIButton != null) {
			uIButton.click();
			report.updateTestLog("Page Navigation", "Button(" + buttonName + ") is clicked successfully", Status.PASS);
		} else {
			report.updateTestLog("Page Navigation", "Button(" + buttonName + ") is not available in the page",
					Status.FAIL);
		}
	}

	/// <summary>
	/// Click button Control by using the class as input parameter
	/// </summary>
	/// <param name="className">class Name</param>
	/// <param name="parentControl">Parent Section</param>

	public static void ClickButtonByAttribute(String attributeName, String attributeValue, String childTag,
			Dynamic parentControl) {
		// #region Variable Declarations
		try {
			WebElement uIButton;
			if (childTag != null) {
				uIButton = driver.findElement(
						By.xpath("//button/" + childTag + "[" + attributeName + "='" + attributeValue + "']"));
			} else {
				uIButton = driver.findElement(By.xpath("//button[" + attributeName + "='" + attributeValue + "']"));
			}
			if (uIButton != null) {
				uIButton.click();
				report.updateTestLog("Page Navigation", "Button is clicked successfully", Status.PASS);

			} else {
				report.updateTestLog("Page Navigation", "Button is not available in the page", Status.FAIL);
			}
		} catch (Exception e) {
			report.updateTestLog("WebElement " + attributeValue + " is not found",
					"WebElement " + attributeValue + " is not found", Status.FAIL);
		}
	}

	/// <summary>
	/// Click Radio Button by using inner text
	/// </summary>
	/// <param name="className">class Name</param>
	/// <param name="parentControl">Parent Section</param>

	public static void ClickRadioButtonByName(String radioButtonName) {

		WebElement radioButton = driver.findElement(By.name(radioButtonName));

		if (radioButton != null) {
			radioButton.click();
			report.updateTestLog("ClickRadioButton", "Radio Button is clicked successfully", Status.PASS);

		} else {
			report.updateTestLog("ClickRadioButton", "Radio Button is not available in the page", Status.FAIL);
		}
	}

	/// <summary>
	/// Validate Page Header by using href and class
	/// </summary>
	/// <param name="parentControl">Parent Control</param>
	/// <param name="headerName">Header Name - Inner Text</param>

	public static void ValidateHeaderLinkByHrefandClass(String hrefName, String className, WebElement parentElement) {
		try {
			WebElement header = driver
					.findElement(By.xpath(".//a[@href='" + hrefName + "' and @class='" + className + "']"));
			if (header.isDisplayed()) {
				report.updateTestLog("Header is present", "Header is present", Status.PASS);
			}
		} catch (Exception e) {
			report.updateTestLog("Header is not present", "Header is not present", Status.FAIL);
		}
	}

	/// <summary>
	/// Click button Control by using the button Name as input parameter
	/// </summary>
	/// <param id="buttonId">Button Name</param>

	public static void ClickRadioButtonById(String id, String radioButtonDesc, WebElement parentElement) {
		WebElement radioButton = null;
		try {
			radioButton = driver.findElement(By.id(id));
			report.updateTestLog("Radio button", "Radio button (" + radioButtonDesc + ") is present", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog("Radio button", "Radio button (" + radioButtonDesc + ") is not present", Status.FAIL);
		}

		if (radioButton != null) {
			radioButton.click();
			report.updateTestLog("ClickRadioButton", "Radio button (" + radioButtonDesc + ") is clicked successfully",
					Status.PASS);

		} else {
			report.updateTestLog("ClickRadioButton",
					"Radio button (" + radioButtonDesc + ") is not available in the page", Status.FAIL);
		}
	}

	/// <summary>
	/// Select Item from dropdown
	/// </summary>

	public static void SelectDropDownItemByInnerText(WebElement dropDownControl, String itemToSelect,
			String dropDownDesc) {

		if (dropDownControl.isEnabled()) {

			Select select = new Select(dropDownControl);
			try {
				select.selectByVisibleText(itemToSelect);
				report.updateTestLog("ItemToSelect", "Item (" + itemToSelect + ") is selected successfully",
						Status.PASS);
			} catch (Exception e) {
				report.updateTestLog("ItemToSelect", "Item(" + itemToSelect + ") is not available", Status.FAIL);
			}
		} else {
			report.updateTestLog("DropDown", "DropDown(" + dropDownControl + ") is not enabled", Status.FAIL);
		}
	}

	/// <summary>
	/// Select Item from dropdown
	/// </summary>

	public static void SelectDropDownItemByName(String name, String itemToSelect, String dropDownDesc) {
		WebElement dropDownControl = driver.findElement(By.name(name));
		Select select = new Select(dropDownControl);
		if (dropDownControl.isEnabled()) {
			select.selectByVisibleText(itemToSelect);
			try {
				report.updateTestLog("ItemToSelect", "Item (" + itemToSelect + ") is selected successfully",
						Status.PASS);
			} catch (Exception e) {
				report.updateTestLog("ItemToSelect", "Item(" + itemToSelect + ") is not available", Status.FAIL);
			}
		}
	}

	/// <summary>
	/// Select Item from dropdown using dropdown id
	/// </summary>

	public void SelectDropDownItemByID(String id, String itemToSelect, String dropDownDesc) {
		WebElement dropDownControl = driver.findElement(By.id(id));
		Select select = new Select(dropDownControl);
		if (dropDownControl.isEnabled()) {
			select.selectByVisibleText(itemToSelect);
			try {
				report.updateTestLog("ItemToSelect", "Item (" + itemToSelect + ") is selected successfully",
						Status.PASS);
			} catch (Exception e) {
				report.updateTestLog("ItemToSelect", "Item(" + itemToSelect + ") is not available", Status.FAIL);
			}
		}
	}

	/// <summary>
	/// Select Item from dropdown by using inner text
	/// </summary>

	public static void SelectDropDownItemByIDByPartialText(String id, String itemToSelect, String dropDownDesc) {
		WebElement dropDownControl = driver.findElement(By.id(id));
		Select select = new Select(dropDownControl);
		if (dropDownControl.isEnabled()) {
			select.selectByVisibleText(itemToSelect);
			try {
				report.updateTestLog("ItemToSelect", "Item (" + itemToSelect + ") is selected successfully",
						Status.PASS);
			} catch (Exception e) {
				report.updateTestLog("ItemToSelect", "Item(" + itemToSelect + ") is not available", Status.FAIL);
			}
		}
	}

	/// <summary>
	/// Select Item from dropdown
	/// </summary>
	/// <param name="index">Index Starts from 0</param>

	public static void SelectDropDownItemByIndex(WebElement dropDownControl, int index, String dropDownDesc) {
		if (dropDownControl.isEnabled()) {
			Select select = new Select(dropDownControl);
			try {
				if (select.getOptions().size() > index) {
					select.selectByIndex(index);
					report.updateTestLog("ItemToSelect", " Item's (" + index + ") is in the range", Status.PASS);
				} else {
					// Index is not available.Select.Options.Count is the maximum range.
					report.updateTestLog("ItemToSelect", "Item's(" + index + ") is out of range", Status.FAIL);
				}
			} catch (Exception e) {
				// Item is not available log/Failed to Select
				report.updateTestLog("ItemToSelect", "Item's(" + index + ") is not available or failed to select",
						Status.FAIL);
			}
		} else {
			report.updateTestLog("DropDown", "DropDown is not available", Status.FAIL);
		}
	}

	/// <summary>
	/// Enter Input to TextBox by name
	/// </summary>
	/// <param name="textboxElement"></param>
	/// <param name="inputToType"></param>
	/// <param name="textBoxDesc"></param>
	/// <param name="clearBeforeType"></param>

	public static void EnterInputToTextBoxByName(String name, String inputToType, String textBoxDesc,
			Boolean clearBeforeType) {
		WebElement textboxElement = driver.findElement(By.name(name));

		if (textboxElement.isDisplayed() || textboxElement.isEnabled()) {
			textboxElement.click();
			if (clearBeforeType) {
				textboxElement.clear();
			}
			textboxElement.sendKeys(inputToType);
			report.updateTestLog(name + " TextBox", textBoxDesc + "(" + inputToType + ") is entered in the text box",
					Status.PASS);
		} else {
			report.updateTestLog(name + " TextBox", "Textbox(" + textBoxDesc + ") is not available", Status.FAIL);
		}
	}

	/// <summary>
	/// Enter Input to TextBox by id
	/// </summary>
	/// <param name="textboxElement"></param>
	/// <param name="inputToType"></param>
	/// <param name="textBoxDesc"></param>
	/// <param name="clearBeforeType"></param>

	public static void EnterInputToTextBoxByID(String id, String inputToType, String textBoxDesc,
			Boolean clearBeforeType) {
		WebElement textboxElement = driver.findElement(By.id(id));

		if (textboxElement.isDisplayed() || textboxElement.isEnabled()) {
			textboxElement.click();
			if (clearBeforeType) {
				textboxElement.clear();
			}
			textboxElement.sendKeys(inputToType);
			report.updateTestLog(id + " TextBox", textBoxDesc + "(" + inputToType + ") is entered in the text box",
					Status.PASS);
		} else {
			report.updateTestLog(id + " TextBox", "Textbox(" + textBoxDesc + ") is not available", Status.FAIL);
		}
	}

	public static void EnterInputToTextBoxByXpath(String xpathExpression, String inputToType, String textBoxDesc,
			Boolean clearBeforeType) {
		WebElement textboxElement = driver.findElement(By.xpath(xpathExpression));

		if (textboxElement.isDisplayed() || textboxElement.isEnabled()) {
			textboxElement.click();
			if (clearBeforeType) {
				textboxElement.clear();
			}
			textboxElement.sendKeys(inputToType);
			report.updateTestLog(" TextBox", textBoxDesc + "(" + inputToType + ") is entered in the text box",
					Status.PASS);
		} else {
			report.updateTestLog(" TextBox", "Textbox(" + textBoxDesc + ") is not available", Status.FAIL);
		}
	}
	/// <summary>
	/// Scroll up the webpage
	/// </summary>
	/// <param input="xpathelement"></param>
	/// <param name="inpuelementDesctToType"></param>

	public static void ScrollUp(String element, String elementDesc) {
		WebElement ele = driver.findElement(By.xpath(element));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].scrollIntoView(false);", ele);
		report.updateTestLog("ScrollUp", "  " + elementDesc + " is Scrolled up", Status.PASS);

	}

	/// <summary>
	/// Scroll down the webpage
	/// </summary>
	/// <param input="xpathelement"></param>
	/// <param name="inpuelementDesctToType"></param>

	public static void ScrollDown(String element, String elementDesc) {
		WebElement ele = driver.findElement(By.xpath(element));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].scrollIntoView(true);", ele);
		report.updateTestLog("ScrollUp", "  " + elementDesc + " is Scrolled Down", Status.PASS);

	}

	/// <summary>
	/// Click Link in MegaNavigation
	/// </summary>
	/// <param name="parentLink"></param>
	/// <param name="childLink"></param>

	public static void ClickLinkInMegaNavigation(String parentLink, String childLink) {
		WebElement parentLinkElement = driver.findElement(By.linkText(parentLink));

		// Mouse Hover to Parent Element
		Actions actions = new Actions(driver);
		actions.moveToElement(parentLinkElement);

		// Find Child Link
		WebElement childLinkElement = driver.findElement(By.linkText(childLink));
		ClickLink(childLinkElement, "Child Link(" + childLink + ")", true);
	}

	/// <summary>
	/// Enter the text into the text box
	/// </summary>
	/// <param name="attributeName"></param>
	/// <param name="value"></param>
	/// <param name="inputToType"></param>
	/// <param name="textBoxDesc"></param>
	/// <param name="tagName"></param>
	/// <param name="parentElement"></param>
	/// <param name="clearBeforeType"></param>

	public static void EnterTextInTextBoxUsingAttribute(String attributeName, String value, String inputToType,
			String textBoxDesc, String tagName, WebElement parentElement, Boolean clearBeforeType) {
		WebElement textboxElement = null;
		try {
			if (tagName == null) {
				textboxElement = driver.findElement(By.xpath("//*[" + attributeName + "='" + value + "']"));
				report.updateTestLog(textBoxDesc + " is present", textBoxDesc + " is present", Status.PASS);

			} else {
				// *[@id="start-date"]
				textboxElement = driver
						.findElement(By.xpath("//" + tagName + "[" + attributeName + "='" + value + "']"));
				report.updateTestLog(textBoxDesc + " is present", textBoxDesc + " is present", Status.PASS);
			}
		}

		catch (Exception e) {
			report.updateTestLog(textBoxDesc + " is not present", textBoxDesc + " is not present", Status.FAIL);
		}

		if (clearBeforeType) {
			textboxElement.clear();
		}
		textboxElement.sendKeys(inputToType);
		report.updateTestLog(textBoxDesc + " TextBox",
				textBoxDesc + " - (" + inputToType + ") is entered in the text box", Status.PASS);
	}

	/// <summary>
	/// Select Checkbox by ID
	/// </summary>
	/// <param name="checkBoxIdAttribute"></param>
	/// <param name="toBeSelected"></param>
	/// <param name="checkBoxDesc"></param>

	public static void SelectCheckBoxById(String checkBoxIdAttribute, String selectedAttribute, Boolean toBeSelected,
			String checkBoxDesc) {
		WebElement checkBoxElement = driver.findElement(By.id(checkBoxIdAttribute));

		if (checkBoxElement.isDisplayed() || checkBoxElement.isEnabled()) {
			Boolean actualState = checkBoxElement.isSelected();
			if (toBeSelected) {
				if (actualState) {
					report.updateTestLog("CheckBox", "Log is already selected by the checkbox", Status.PASS);
				} else {
					checkBoxElement.click();
					WebElement selectedvalueAttribute = driver.findElement(By.id(selectedAttribute));
					if (selectedvalueAttribute.isSelected()) {
						report.updateTestLog("CheckBox", "CheckBox(" + checkBoxDesc + ") is selected", Status.PASS);
					} else {
						report.updateTestLog("CheckBox", "CheckBox(" + checkBoxDesc + ") is not selected", Status.FAIL);
					}
				}
			} else {
				if (actualState) {
					// UnSelect
					checkBoxElement.click();
					WebElement selectedvalueAttribute = driver.findElement(By.id(selectedAttribute));
					if (selectedvalueAttribute.isSelected()) {
						report.updateTestLog("CheckBox", "Checkbox is not unselected", Status.FAIL);
					} else {
						report.updateTestLog("CheckBox", "Checkbox is unselected", Status.PASS);
					}
				} else {
					report.updateTestLog("CheckBox", "CheckBox(" + checkBoxDesc + ") is unselected by default",
							Status.WARNING);
				}
			}
		} else {
			report.updateTestLog("CheckBox", "CheckBox(" + checkBoxDesc + ") is not available/enabled", Status.FAIL);
		}
	}

	/// <summary>
	/// Select Checkbox by Name
	/// </summary>
	/// <param name="checkBoxIdAttribute"></param>
	/// <param name="toBeSelected"></param>
	/// <param name="checkBoxDesc"></param>
	public static void SelectCheckBoxByName(String checkBoxNameAttribute, Boolean toBeSelected, String Value,
			String checkBoxDesc) {
		WebElement checkBoxElement = driver.findElement(By.name(checkBoxNameAttribute));

		if (checkBoxElement.isDisplayed() && checkBoxElement.isEnabled()) {
			Boolean actualState = checkBoxElement.isSelected();
			if (toBeSelected) {
				if (actualState) {
					report.updateTestLog("CheckBox", "Log is already selected by the checkbox", Status.PASS);
				} else {
					checkBoxElement.click();

					if (checkBoxElement.isSelected()) {
						report.updateTestLog("CheckBox", "CheckBox is selected", Status.PASS);
					} else {
						report.updateTestLog("CheckBox is not selected", "CheckBox is not selected", Status.FAIL);
					}
				}
			} else {
				if (actualState) {
					// UnSelect
					checkBoxElement.click();
					// IWebElement selectedvalueAttribute = FindElement(By.Id(selectedAttribute),
					// "CheckBox(" + checkBoxDesc + ")");
					if (checkBoxElement.isSelected()) {
						report.updateTestLog("Checkbox is not unselected", "Checkbox is not unselected", Status.FAIL);
					} else {
						report.updateTestLog("Checkbox is unselected", "Checkbox is unselected", Status.PASS);
					}
				} else {
					// Add Message - By default it's unselected
				}
			}
		} else {
			// Add Fail Log - Not displayed/enabled
		}
	}

	/// <summary>
	/// Validate Label By InnerText
	/// </summary>
	/// <param name="labelInnerText"></param>
	/// <param name="labelTagName"></param>
	/// <param name="parentElement"></param>
	/// <param name="labelDesc">Label Desc</param>

	public static void ValidateLabelByInnerText(String labelInnerText, String labelTagName, WebElement parentElement,
			String labelDesc) {
		WebElement labelElement = driver
				.findElement(By.xpath(".//" + labelTagName + "[text()='" + labelInnerText + "']"));
		if (labelElement != null) {
			labelElement.click();
			report.updateTestLog("LabelAvailable", "Label (" + labelInnerText + ") is available", Status.PASS);
		} else {
			report.updateTestLog("LabelNotAvailable", "Label(" + labelInnerText + ") is not available", Status.FAIL);
		}
	}

	/// <summary>
	/// Validate Label By Partial InnerText
	/// </summary>
	/// <param name="labelInnerText"></param>
	/// <param name="labelTagName"></param>
	/// <param name="parentElement"></param>
	/// <param name="labelDesc">Label Desc</param>

	public static void ValidateLabelByPartialInnerText(String labelInnerText, String labelTagName,
			WebElement parentElement, String labelDesc) {
		WebElement labelElement = driver
				.findElement(By.xpath(".//" + labelTagName + "[contains(., '" + labelInnerText + "')]"));
		if (labelElement != null) {
			// Successfull Log - labelDesc
			report.updateTestLog("Label", "Label (" + labelElement.getText() + ") is available", Status.PASS);
		} else {
			report.updateTestLog("Label", "Label (" + labelInnerText + ") is not available", Status.FAIL);
		}
	}

	/// <summary>
	/// Get Boolean value from Flag - If String is null or empty, return the default
	/// result expected
	/// </summary>
	/// <param name="flag">Flag</param>
	/// <returns></returns>

	public static Boolean GetBooleanFromFlag(String flag, Boolean defaultResult) {
		Boolean booleanToReturn = defaultResult;
		flag = flag.toUpperCase();
		if ((flag == "TRUE") || (flag == "Y") || (flag == "YES")) {
			booleanToReturn = true;
		} else if (!flag.isEmpty()) {
			booleanToReturn = false;
		}
		return booleanToReturn;
	}

	/// <summary>
	/// Click UI Control by using Mouse Operations
	/// </summary>
	/// <param name="uIControl">UI Control</param>
	/// <param name="controlDesc">Control Description</param>

	public static void MouseClick(WebElement uIControl, String controlDesc, Boolean continueOnError,
			Boolean enableWait) {
		try {
			WebElement webElement = uIControl;
			Actions action = new Actions(driver);
			action.click(webElement).perform();
			if (enableWait) {
				driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			}
		} catch (NoSuchElementException e) {
			if (controlDesc.isEmpty()) {
				throw e;
			}
			report.updateTestLog("MouseClick", controlDesc + " is not available in the page", Status.FAIL);
		} catch (Exception e) {
			report.updateTestLog("Error", "Exception in MouseClick - " + e.getMessage(), Status.FAIL);

			throw e;
		}
	}

	/// <summary>
	/// Validate Link Href Url Value
	/// </summary>
	/// <author>RXK4098 - Ramesh Kandasamy</author>
	/// <param name="linkControl">Link Control</param>
	/// <param name="expectedUrlValue">Expected Url Value</param>
	/// <param name="performCompleteMatch">Compare Method</param>
	public static void ValidateHrefAttribute(WebElement linkControl, String expectedUrlValue,
			Boolean performCompleteMatch) {
		String linkText = linkControl.getText();
		if (expectedUrlValue.isEmpty()) {
			return;
		}
		Boolean urlMatched = false;
		// Get the Href Property for the provided Link
		String actualUrlValue = linkControl.getAttribute("Href").toString();
		actualUrlValue = actualUrlValue.trim().replace("http://", "").replace("https://", "");
		expectedUrlValue = expectedUrlValue.trim().replace("http://", "").replace("https://", "");
		if (performCompleteMatch) {
			if (expectedUrlValue.equals(actualUrlValue)) {
				urlMatched = true;
			}
		} else {
			if (actualUrlValue.contains(expectedUrlValue) || expectedUrlValue.contains(actualUrlValue)) {
				urlMatched = true;
			}
		}
		if (urlMatched) {
			report.updateTestLog("HrefURL",
					"Link(" + linkText + ") URL is matched with Expected Url, Page Url: " + actualUrlValue,
					Status.PASS);
		} else {
			report.updateTestLog("HrefURL", "Link(" + linkText + ") URL is not matched with Expected Url, Page Url: "
					+ actualUrlValue + " Expected URL: " + expectedUrlValue, Status.FAIL);
		}
	}

	/// <summary>
	/// Check New window is opened or not
	/// </summary>
	/// <param name="noOfWindowsBeforeClickingLink">No of Windows before clicking
	/// Link</param>
	/// <returns>Boolean</returns>

	public static Boolean CheckNewTabOpened(int noOfWindowsBeforeClickingLink) {
		Set<String> childWindows = driver.getWindowHandles();
		int noOfWindowsAfterClickingLink = childWindows.size();
		if (noOfWindowsAfterClickingLink - noOfWindowsBeforeClickingLink == 1) {
			report.updateTestLog("LinkNavigation", "Link is opened in new window successfully", Status.PASS);
			return true;
		} else {
			return false;
		}
	}
	/// <summary>
	/// Click Link Control by using the Locators as input parameter
	/// </summary>

	public static Boolean ClickByXPath(String webElement, Dynamic parentControl, String elementDesc,
			String typeOfLocator, String childTagIfPresent) {
		By linkControl = null;
		WebElement linkElement = null;
		if (typeOfLocator.equals("id")) {
			linkControl = By.xpath(".//*[@" + typeOfLocator + "='" + webElement + "']");
		}
		if (typeOfLocator.equals("name")) {
			linkControl = By.xpath(".//*[@" + typeOfLocator + "='" + webElement + "']");
		}

		if (typeOfLocator.equals("class")) {
			linkControl = By.xpath(".//*[@" + typeOfLocator + "='" + webElement + "']");
		}

		if (typeOfLocator.equals("href")) {
			linkControl = By.xpath(".//*[@" + typeOfLocator + "='" + webElement + "']");
		}

		if (!childTagIfPresent.isEmpty()) {
			linkElement = driver.findElement(By.xpath(".//" + childTagIfPresent + "[.='" + webElement + "']/.."));
		} else {
			linkElement = driver.findElement(linkControl, elementDesc, parentControl);
		}

		if (linkElement != null) {
			linkElement.click();
			report.updateTestLog("Page Navigation", "WebElement(" + webElement + ") is clicked successfully",
					Status.PASS);
			return true;
		} else {
			if (elementDesc.isEmpty()) {
				report.updateTestLog("Page Navigation", "WebElement(" + webElement + ") is not available in the page",
						Status.FAIL);
			} else {
				report.updateTestLog("Page Navigation",
						elementDesc + " - WebElement(" + webElement + ") is not available in the page", Status.FAIL);
			}
			return false;
		}

	}

	/// <summary>
	/// Click Link/Button using partial text
	/// </summary>

	/// <param name="Parent Tagname">TagName</param>
	/// <param name="Child TagName"ChildTagname ></param>
	public static void ClickLinkandButtonUsingContains(String parentTag, String containsText, String header,
			String childTag, Boolean headerContains, WebElement parentElement, String headerTag) {
		if (childTag == null) {
			try {
				WebElement element = driver
						.findElement(By.xpath("//" + parentTag + "[contains(.,'" + containsText + "')]"));
				ClickLink(element, containsText + " is present", true);

			} catch (Exception e) {
				report.updateTestLog("WebElement", "WebElement" + header + " is not present", Status.FAIL);
			}
		} else {
			try {
				WebElement registerElement = driver.findElement(
						By.xpath("//" + parentTag + "/" + childTag + "[contains(.,'" + containsText + "')]"));
				ClickLink(registerElement, registerElement + "is present", true);

			} catch (Exception e) {
				report.updateTestLog("Element", "WebElement" + header + " is not present", Status.FAIL);
			}
		}
	}

	/// <summary>
	/// Click Link using contains method
	/// </summary>
	/// <param name="Parent Tagname">TagName</param>
	/// <param name="Child TagName"ChildTagname ></param>
	public static void ClickLinkUsingInnerText(String parentTag, String containsText, String header, String childTag,
			Boolean headerContains, WebElement parentElement, String headerTag) {
		if (childTag == null) {
			try {
				WebElement element = driver
						.findElement(By.xpath("//" + parentTag + "[contains(text(),'" + containsText + "')]"));
				ClickLink(element, containsText, true);

			} catch (Exception e) {
				report.updateTestLog("Link", "Link " + containsText + " is not present", Status.FAIL);
			}
		} else {
			try {
				WebElement element = driver.findElement(
						By.xpath("//" + parentTag + "/" + childTag + "[contains(text(),'" + containsText + "')]"));
				ClickLink(element, element.getText(), true);

			} catch (Exception e) {
				report.updateTestLog("Link", "Link is not present", Status.FAIL);
			}
		}
	}

	/// <summary>
	/// Check element is present in drop down
	/// </summary>
	/// <param name="tagName">Tag Name</param>
	/// <param name="parentControl">Parent Section</param>
	public static void ValidateElementIsPresentInDropdown(WebElement parentElement, String tagName,
			String[] containsElement) {
		List<WebElement> allItems = parentElement.findElements(By.tagName(tagName));
		int i = 0;

		for (WebElement eachItem : allItems) {

			String itemValue = eachItem.getText();
			if (itemValue.contains(containsElement[i])) {
				report.updateTestLog("DropDownList", containsElement[i] + " option is available in the drop down list",
						Status.PASS);
			} else {
				report.updateTestLog("DropDownList",
						containsElement[i] + " option is not available in the drop down list", Status.FAIL);
			}
			i++;
		}
	}

	/// <summary>
	/// Press Tab Key
	/// </summary>
	/// <param name="name"></param>

	public static void EnterTabName(String name) {
		WebElement textboxElement = driver.findElement(By.name(name));

		if (textboxElement.isDisplayed() || textboxElement.isEnabled()) {
			textboxElement.sendKeys(Keys.TAB);
		}
	}

}
