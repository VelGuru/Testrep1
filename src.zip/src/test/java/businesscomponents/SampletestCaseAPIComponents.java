package businesscomponents;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;
import com.mongodb.MongoCredential;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import frameworkcore.ReusableLibrary;
import frameworkcore.ScriptHelper;
import frameworkseleniumcore.Status;
import frameworkseleniumcore.Util;
import frameworkseleniumcore.APIReusuableLibrary.ASSERT_RESPONSE;
import frameworkseleniumcore.APIReusuableLibrary.COMPARISON;
import frameworkseleniumcore.APIReusuableLibrary.SERVICEFORMAT;
import frameworkseleniumcore.APIReusuableLibrary.SERVICEMETHOD;

import java.util.Arrays;
import java.util.Date;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.restassured.response.ValidatableResponse;

import org.bson.Document;

public class SampletestCaseAPIComponents extends ReusableLibrary {

	HeadersForAPI headers = new HeadersForAPI();
	
	String restHealthCondition = "",soapHealthCondition="";
	String restIsAccessible="", soapIsAccessible= "";
	String restAdditionalInfo = "", soapAdditionalInfo = "";
	String restPersonId = "", dbPersonId = "";
	String restFirstName = "", dbFirstName = "";
	String restMiddleName = "", dbMiddleName = "";
	String restMiddleInitial = "", dbMiddleInitial = "";
	String restLastName = "", dbLastName = "";
	String restDOB = "", dbDOB = "";
	String restGender = "", dbGender = "";
    String dbPersonGenKey = "",dbmasterPersonId = "",dbfirstName = "",dbmiddleName="",dblastName="",dbmiddleInitial="",dbgender="";
    Date dbdateOfBirth = null ;
		
	public SampletestCaseAPIComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}

	public void validateUser() {

		Map<String, String> headersMap = headers.getHeaders3();
		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1");
		String postBodyContent = dataTable.getData("General_Data", "InputJsonTemplate");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_name", "murug");
		String expectedResponse = dataTable.getData("General_Data", "OutputJsonTemplate");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.POST, SERVICEFORMAT.JSON, postBodyContent, headersMap,
				201);

		apiDriver.assertIt(url, response, ASSERT_RESPONSE.BODY, "", expectedResponse, COMPARISON.IS_EQUALS);
		apiDriver.assertIt(url, response, ASSERT_RESPONSE.TAG, "name", "murug", COMPARISON.IS_EQUALS);
		apiDriver.assertIt(url, response, ASSERT_RESPONSE.HEADER, "", "application/json;", COMPARISON.IS_EXISTS);

	}
	
	public void restCall() {
		Map<String, String> headersMap = headers.getHeaders3();
		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1");
		String ParameterKeylist = 	dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "ParameterKey");
		String ParameterValuelist = 	dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "ParameterValue");
		String[] keyList = ParameterKeylist.split("#");
		String[] ValueList = ParameterValuelist.split("#");
		String parameterlist="?";
		for (int i=0; i<keyList.length; i++) {
			
			parameterlist=parameterlist+keyList[i]+"="+ValueList[i];
			
		}
		String FinalURL=url+parameterlist;

		response = apiDriver.sendNReceive(FinalURL, SERVICEMETHOD.GET,  headersMap,	200);
		
		restHealthCondition = extractTagValue(response,"healthCondition",SERVICEFORMAT.JSON);
		restIsAccessible = extractTagValue(response,"isAccessible",SERVICEFORMAT.JSON);
		restAdditionalInfo = extractTagValue(response,"additionalInfo",SERVICEFORMAT.JSON);
		
		dataTable.putData("INT_DataSheet", "RESTHealthCondition", restHealthCondition);
		dataTable.putData("INT_DataSheet", "RESTIsAccessible", restIsAccessible);
		dataTable.putData("INT_DataSheet", "RESTAdditionalInfo", restAdditionalInfo);
		
	}


	public void restMemberCall() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		
		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1") + dataTable.getData("INT_DataSheet", "MemberGenKey") ;		

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET,  headersMap,	200);
		
		//Retrieving the value from response
		restPersonId = extractTagValue(response,"personId",SERVICEFORMAT.JSON);		
		restFirstName = extractTagValue(response,"firstName",SERVICEFORMAT.JSON);
		restMiddleName = extractTagValue(response,"middleName",SERVICEFORMAT.JSON);
		restMiddleInitial = extractTagValue(response,"middleInitial",SERVICEFORMAT.JSON);
		restLastName = extractTagValue(response,"lastName",SERVICEFORMAT.JSON);
		restDOB = extractTagValue(response,"dateOfBirth",SERVICEFORMAT.JSON);
		restGender = extractTagValue(response,"gender",SERVICEFORMAT.JSON);
		
		//Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestPersonId", restPersonId);
		dataTable.putData("INT_DataSheet", "RestFirstName", restFirstName);
		dataTable.putData("INT_DataSheet", "RestMiddleName", restMiddleName);
		dataTable.putData("INT_DataSheet", "RestMiddleInitial", restMiddleInitial);
		dataTable.putData("INT_DataSheet", "RestLastName", restLastName);
		dataTable.putData("INT_DataSheet", "RestDOB", restDOB);
		dataTable.putData("INT_DataSheet", "RestGender", restGender);
	}
	
	public void mangoDBDataRetreive()
	{
		
		String DatabaseName = dataTable.getData("General_Data", "DatabaseName");
		String UserName = dataTable.getData("General_Data", "UserName");
		char[] password = (dataTable.getData("General_Data", "Password")).toCharArray();
		
		String ReplicaSet1 = dataTable.getData("General_Data", "ReplicaSet1");
		String ReplicaSet2 = dataTable.getData("General_Data", "ReplicaSet2");
		String ReplicaSet3 = dataTable.getData("General_Data", "ReplicaSet3");
			
		String CollectionName = dataTable.getData("INT_DataSheet", "CollectionName");
		String QueryKey = dataTable.getData("INT_DataSheet", "QueryKey");
		String QueryValue = dataTable.getData("INT_DataSheet", "MemberGenKey");
		
		MongoCredential credential = MongoCredential.createCredential(UserName, DatabaseName, password);
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(true).build();
		MongoClient mongoClient = new MongoClient(Arrays.asList(new ServerAddress(ReplicaSet1),
				new ServerAddress(ReplicaSet2),
				new ServerAddress(ReplicaSet3)),Arrays.asList(credential),options);

	    MongoDatabase database = mongoClient.getDatabase(DatabaseName);
	    MongoCollection<Document> table = database.getCollection(CollectionName);
	    
	    FindIterable<Document> iterDocs = table.find(Filters.eq(QueryKey, QueryValue));
	    

	      for (Document iterdoc:iterDocs) {
	    	 // System.out.println("Key-"+iterdoc.getString("key")+"- firstName -"+iterdoc.getString("personGenKey"));

	    	  	dbPersonGenKey = iterdoc.getString("personGenKey");
	    	  	dbmasterPersonId = iterdoc.getString("masterPersonId");
	    	  	dbfirstName = iterdoc.getString("firstName");
	    	  	dbmiddleName = iterdoc.getString("middleName");
	    	  	dbmiddleInitial = iterdoc.getString("middleInitial");
	    	  	dblastName = iterdoc.getString("lastName");
	    	  	dbdateOfBirth = iterdoc.getDate("dateOfBirth");
	    	  	dbgender = iterdoc.getString("gender");
	    	  	
	    	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
	    	    String strDate = dateFormat.format(dbdateOfBirth);  
	    	    
	    	    
	    	  	//write it in the excel
	    	  	dataTable.putData("INT_DataSheet", "DBPersonId", dbmasterPersonId);
	    		dataTable.putData("INT_DataSheet", "DBFirstName", dbfirstName);
	    		dataTable.putData("INT_DataSheet", "DBMiddleName", dbmiddleName);
	    		dataTable.putData("INT_DataSheet", "DBMiddleInitial", dbmiddleInitial);
	    		dataTable.putData("INT_DataSheet", "DBLastName", dblastName);
	    		dataTable.putData("INT_DataSheet", "DBDOB", strDate);
	    		dataTable.putData("INT_DataSheet", "DBGender", dbgender);
	    	  
	      }
	      
	    mongoClient.close();
	}

	public void validateDetailsAsList() {

		Object expectedList = new ArrayList<String>();
		expectedList = getList();
		ValidatableResponse response;
		Map<String, String> headersMap = null;
		String uri = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.GET, headersMap, 200);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.LIST, "MRData.CircuitTable.Circuits.circuitId", expectedList,
				COMPARISON.IS_EQUALS);

	}

	public void convertFToC() {

		Map<String, String> headersMap = headers.getHeaders2();
		ValidatableResponse response;
		String uri = "https://www.w3schools.com/xml/tempconvert.asmx";

		String postBodyContent = apiDriver.readInput(getTemplatePath() + "FtoC_Input.xml");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_fahrenheit",
				dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "Fahrenheit"));
		String expectedCelcius = dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "Celsius");
		String expectedResponse = apiDriver.readInput(getTemplatePath() + "FtoC_Output.xml");
		expectedResponse = apiDriver.updateContent(expectedResponse, "update_celsius", expectedCelcius);

		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent, headersMap, 200);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.BODY, "", expectedResponse, COMPARISON.IS_EQUALS);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.TAG, "//FahrenheitToCelsiusResult/text()", expectedCelcius,
				COMPARISON.IS_EQUALS);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.HEADER, "", "text/xml;", COMPARISON.IS_EXISTS);
	}
	
	public void soapCall() {

		Map<String, String> headersMap = headers.getHeaders5();
		ValidatableResponse response;
		
		String uri = dataTable.getData("General_Data", "URL2");

		String postBodyContent = apiDriver.readInput(getTemplatePath() + "CheckHealthProgramPageView_Input.xml");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_ApplicationKey",
				dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "ApplicationKey"));
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_MemberGenKey",
				dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "MemberGenKey"));
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_PageRequestCriteria",
				dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "PageRequestCriteria"));			

		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent, headersMap, 200);
		
		soapHealthCondition = extractTagValue(response,"a:PageRequestCriteria",SERVICEFORMAT.XML);
		soapIsAccessible = extractTagValue(response,"a:IsAccessible",SERVICEFORMAT.XML);
		soapAdditionalInfo = extractTagValue(response,"a:AdditionalInfo",SERVICEFORMAT.XML);;
		
		dataTable.putData("INT_DataSheet", "SOAPHealthCondition", soapHealthCondition);
		dataTable.putData("INT_DataSheet", "SOAPIsAccessible", soapIsAccessible);
		dataTable.putData("INT_DataSheet", "SOAPAdditionalInfo", soapAdditionalInfo);				

	}

	public String extractTagValue(ValidatableResponse response, String tagToValidate,SERVICEFORMAT format) {
		
		if(format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString();			
			String retreiveBody	= (((responseBody.replace("\"", "")).replace("]", "")).replace("}", ""));
			
			String subStringOpen = tagToValidate + ":";
			String subStringClose = ",";			
			value = ((retreiveBody.split(subStringOpen))[1].split(subStringClose))[0];		
			value = value.trim();
			return value;
		} else {
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";			
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];			
			return value;
		}
	}

	
	public void validateHealthProgramPage() {	
		

		restHealthCondition = dataTable.getData("INT_DataSheet", "RESTHealthCondition");
		restIsAccessible = dataTable.getData("INT_DataSheet", "RESTIsAccessible");
		restAdditionalInfo = dataTable.getData("INT_DataSheet", "RESTAdditionalInfo");
		

		soapHealthCondition = dataTable.getData("INT_DataSheet", "SOAPHealthCondition");
		soapIsAccessible = dataTable.getData("INT_DataSheet", "SOAPIsAccessible");
		soapAdditionalInfo = dataTable.getData("INT_DataSheet", "SOAPAdditionalInfo");
		
		if(restHealthCondition.equals(soapHealthCondition))
		{
			report.updateTestLog("validateHealthProgramPage","REST HealthCondition => " + restHealthCondition + ". SOAP HealthCondition => " + soapHealthCondition,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validateHealthProgramPage","REST HealthCondition => " + restHealthCondition + ". SOAP HealthCondition => " + soapHealthCondition,Status.FAIL);
		}
		if(restIsAccessible.equals(soapIsAccessible))
		{
			report.updateTestLog("validateHealthProgramPage","REST IsAccessible => " + restIsAccessible + ". SOAP IsAccessible => " + soapIsAccessible,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validateHealthProgramPage","REST IsAccessible => " + restIsAccessible + ". SOAP IsAccessible => " + soapIsAccessible,Status.FAIL);
		}
		if(restAdditionalInfo.equals(soapAdditionalInfo))
		{
			report.updateTestLog("validateHealthProgramPage","REST AdditionalInfo => " + restAdditionalInfo + ". SOAP AdditionalInfo => " + soapAdditionalInfo,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validateHealthProgramPage","REST AdditionalInfo => " + restAdditionalInfo + ". SOAP AdditionalInfo => " + soapAdditionalInfo,Status.FAIL);
		}
	}
	
public void validatePersonDetails() {	
		
	
		restPersonId = dataTable.getData("INT_DataSheet", "RestPersonId");
		restFirstName = dataTable.getData("INT_DataSheet", "RestFirstName");
		restMiddleName = dataTable.getData("INT_DataSheet", "RestMiddleName");
		restMiddleInitial = dataTable.getData("INT_DataSheet", "RestMiddleInitial");
		restLastName = dataTable.getData("INT_DataSheet", "RestLastName");
		restDOB = dataTable.getData("INT_DataSheet", "RestDOB");
		restGender = dataTable.getData("INT_DataSheet", "RestGender");

		dbmasterPersonId = dataTable.getData("INT_DataSheet", "DBPersonId");
		dbfirstName = dataTable.getData("INT_DataSheet", "DBFirstName");
		dbmiddleName = dataTable.getData("INT_DataSheet", "DBMiddleName");
		dbmiddleInitial = dataTable.getData("INT_DataSheet", "DBMiddleInitial");
		dblastName = dataTable.getData("INT_DataSheet", "DBLastName");
		dbDOB = dataTable.getData("INT_DataSheet", "DBDOB");
		dbgender = dataTable.getData("INT_DataSheet", "DBGender");		
		
		if(restPersonId.equals(dbmasterPersonId))
		{
			report.updateTestLog("validatePersonDetails","REST PersonId => " + restPersonId + ". DB PersonId => " + dbmasterPersonId,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validatePersonDetails","REST PersonId => " + restPersonId + ". DB PersonId => " + dbmasterPersonId,Status.FAIL);			
		}
		if(restFirstName.equals(dbfirstName))
		{
			report.updateTestLog("validatePersonDetails","REST FirstName => " + restFirstName + ". DB FirstName => " + dbfirstName,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validatePersonDetails","REST FirstName => " + restFirstName + ". DB FirstName => " + dbfirstName,Status.FAIL);			
		}
		if(restMiddleName.equals(dbmiddleName))
		{
			report.updateTestLog("validatePersonDetails","REST MiddleName => " + restMiddleName + " DB MiddleName => " + dbmiddleName,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validatePersonDetails","REST MiddleName => " + restMiddleName + " DB MiddleName => " + dbmiddleName,Status.FAIL);			
		}
		if(restMiddleInitial.equals(dbmiddleInitial))
		{
			report.updateTestLog("validatePersonDetails","REST MiddleInitial => " + restMiddleInitial + " DB MiddleInitial => " + dbmiddleInitial,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validatePersonDetails","REST MiddleInitial => " + restMiddleInitial + " DB MiddleInitial => " + dbmiddleInitial,Status.FAIL);			
		}
		if(restLastName.equals(dblastName))
		{
			report.updateTestLog("validatePersonDetails","REST LastName => " + restLastName + ". DB LastName => " + dblastName,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validatePersonDetails","REST LastName => " + restLastName + ". DB LastName => " + dblastName,Status.FAIL);			
		}
		if(restDOB.equals(dbDOB))
		{
			report.updateTestLog("validatePersonDetails","REST DOB => " + restDOB + ". DB DOB => " + dbDOB,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validatePersonDetails","REST DOB => " + restDOB + ". DB DOB => " + dbDOB,Status.FAIL);			
		}
		if(restGender.equals(dbgender))
		{
			report.updateTestLog("validatePersonDetails","REST Gender => " + restGender + ". DB Gender => " + dbgender,Status.PASS);			
		}
		else
		{
			report.updateTestLog("validatePersonDetails","REST Gender => " + restGender + ". DB Gender => " + dbgender,Status.FAIL);			
		}

	}

	public void convertTemparatureInSequence() {
		Map<String, String> headersMap = headers.getHeaders2();
		Map<String, String> headersMap1 = headers.getHeaders4();
		ValidatableResponse response;
		String uri = "https://www.w3schools.com/xml/tempconvert.asmx";

		String postBodyContent = apiDriver.readInput(getTemplatePath() + "FtoC_Input.xml");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_fahrenheit", "50");
		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent, headersMap, 200);
		String celciusFromResponse = apiDriver.extractValue(response, "//FahrenheitToCelsiusResult/text()");
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.TAG, "//FahrenheitToCelsiusResult/text()", "10",
				COMPARISON.IS_EQUALS);

		String postBodyContent1 = apiDriver.readInput(getTemplatePath() + "CtoF_Input.xml");
		postBodyContent1 = apiDriver.updateContent(postBodyContent1, "update_celsius", celciusFromResponse);
		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent1, headersMap1,
				200);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.TAG, "//CelsiusToFahrenheitResult/text()", "50",
				COMPARISON.IS_EQUALS);

	}

	private List<String> getList() {
		List<String> sampleList = new ArrayList<String>();
		sampleList.add("albert_park");
		sampleList.add("americas");
		sampleList.add("bahrain");
		sampleList.add("BAK");
		sampleList.add("catalunya");
		sampleList.add("hungaroring");
		sampleList.add("interlagos");
		sampleList.add("marina_bay");
		sampleList.add("monaco");
		sampleList.add("monza");
		sampleList.add("red_bull_ring");
		sampleList.add("rodriguez");
		sampleList.add("sepang");
		sampleList.add("shanghai");
		sampleList.add("silverstone");
		sampleList.add("sochi");
		sampleList.add("spa");
		sampleList.add("suzuka");
		sampleList.add("villeneuve");
		sampleList.add("yas_marina");

		return sampleList;
	}

	private String getTemplatePath() {
		File frameworkPath = new File(frameworkParameters.getRelativePath());

		String parentPath = frameworkPath.getParent();

		String templatePath = parentPath + Util.getFileSeparator() + "Miscellaneous_Maven" + Util.getFileSeparator()
				+ "EndPointInputs" + Util.getFileSeparator();

		return templatePath;
	}

}
