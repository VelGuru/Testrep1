package businesscomponents;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;

import frameworkcore.CommonFunctions;
import frameworkcore.ReusableLibrary;
import frameworkcore.ScriptHelper;
import frameworkseleniumcore.Status;
import pages.Samplepageobjects;

public class ShoppingCaseComponents extends ReusableLibrary {

	private static final String REGISTER_DATA = "Register_Data";
	private static final String PRODUCT_DATA = "Product_Data";
	private static final String PAYMENT_DATA = "Payment_Data";

	public ShoppingCaseComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}

	public void launchapplication() throws InterruptedException {

		//Launching Application URL
		String url = dataTable.getData("General_Data", "Applicationurl").toString();
		driver.navigate().to(url);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		report.updateTestLog("Login", "DemoWebShopping", Status.PASS);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Verifying the page title
		String expectedTitle = "Demo Web Shop";
		String actualTitle = driver.getTitle();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(2000);
		Assert.assertEquals(actualTitle, expectedTitle);
		report.updateTestLog("Page title", "“Demo Web Shop” is Verified", Status.PASS);
		Thread.sleep(5000);

	}

	public void registerUser() throws InterruptedException {

		//Clicking the register link
		Thread.sleep(2000);
		//driver.findElement(By.className(Samplepageobjects.ele_Register)).click();
		CommonFunctions.ClickButtonByClassName(Samplepageobjects.ele_Register, "Register Link");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//verifying the register page
		CommonFunctions.ValidatePageSection("h1", "Register");
		report.updateTestLog("Page", "“Register Page” is Verified", Status.PASS);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the gender check box
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.ele_Male, "Male");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		String str_firstName = dataTable.getData("Register_Data", "First_Name").toString();
		
		//Entering input in firstname textbox field
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_FirstName, str_firstName, "FirstName", true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String str_lastName = dataTable.getData("Register_Data", "Last_Name").toString();
		
		//Entering input in lastname textbox field
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_LastName, str_lastName, "LastName", true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Entering input in email textbox field
		String str_eMail = dataTable.getData("Register_Data", "Email").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_Email, str_eMail, "Email", true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Entering input in password textbox field
		String str_passWord = dataTable.getData("Register_Data", "Password").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_Password, str_passWord, "Password", true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Entering input in password textbox field
		String str_cnfpassWord = dataTable.getData("Register_Data", "Password").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_cnfPassword, str_cnfpassWord,
				"Confirm Password", true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Clicking the Register Button
		CommonFunctions.ClickButtonById(Samplepageobjects.btn_Register, "Register");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Verifying the email 
		String txt_email = driver.findElement(By.xpath(Samplepageobjects.obj_Email)).getText();
		CommonFunctions.IsWebElementDisplayed(Samplepageobjects.obj_Email, "Email: " + txt_email, 5, true);

		//Verifying the Result
		String txt_result = driver.findElement(By.xpath(Samplepageobjects.obj_Result)).getText();
		CommonFunctions.IsWebElementDisplayed(Samplepageobjects.obj_Result, "Result: " + txt_result, 5, true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	public void navigateToProducts() throws InterruptedException {

		Thread.sleep(2000);
		
		//Clicking the Book link
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.ele_Books, "Books");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the Computer And interneting  link
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.ele_Computing, "Computing And Internet");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void addToCart() throws InterruptedException {

		Thread.sleep(2000);
		
		String str_Quantity = dataTable.getData("Product_Data", "Quantity").toString();
		
		//Entering quantity in  the  field
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_Quantity, str_Quantity, "Quantity", true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the ADD to Cart Button 
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.btn_AddtoCart, "Add To Cart");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		String txt_email = driver.findElement(By.xpath(Samplepageobjects.obj_email)).getText();
		
		//Verify the Email is present
		CommonFunctions.IsWebElementDisplayed(Samplepageobjects.obj_email, "Email: "  + txt_email , 5, true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Verify the Shopping Cart is present
		String txt_shopCart = driver.findElement(By.xpath(Samplepageobjects.obj_shoppingCart)).getText();
		
		CommonFunctions.IsWebElementDisplayed(Samplepageobjects.obj_shoppingCart, "Shopping Cart: "  + txt_shopCart, 5,
				true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the Shopping Cart Buuton
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.obj_shoppingCart, "Shopping Cart");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Verifying the Shopping cart page 
		CommonFunctions.ValidatePageSection("h1", "Shopping Cart");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void checkOut() throws InterruptedException {

		Thread.sleep(2000);
		String str_Country = dataTable.getData("Payment_Data", "Country").toString();
		
		//Selecting the Country form Dropdown list
		CommonFunctions.SelectDropDownItemByName(Samplepageobjects.dd_Country, str_Country, str_Country);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String str_state = dataTable.getData("Payment_Data", "State").toString();
		
		//Selecting the State form Dropdown list
		CommonFunctions.SelectDropDownItemByName(Samplepageobjects.dd_State, str_state, str_state);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Entering the zipcode in a filed
		String str_zipcode = dataTable.getData("Payment_Data", "Zip_Code").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_zipCode, str_zipcode, "Zip Code", true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the Estimate Shipping Button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.ele_Estiamte, "Estimate Shipping");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the Agree Check Box
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.ele_termsChkBox, "Agree Check Box");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the Checkout  Button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.btn_Chkout, "Check Out");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Verifying  the Checkout page is displayed
		CommonFunctions.ValidatePageSection("h1", "Checkout");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	public void confirmOrder() throws InterruptedException {

		Thread.sleep(2000);
		//Selecting the Country in dropdown list
		String str_Country = dataTable.getData("Payment_Data", "Country").toString();
		CommonFunctions.SelectDropDownItemByName(Samplepageobjects.dd_BillingCountry, str_Country, str_Country);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Selecting the State in dropdown list
		String str_state = dataTable.getData("Payment_Data", "State").toString();
		CommonFunctions.SelectDropDownItemByName(Samplepageobjects.dd_BillingState, str_state, str_state);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Entering the city name in textbox field
		String str_city = dataTable.getData("Payment_Data", "City").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_city, str_city, "City", true);

		//Entering the Address_1 name in textbox field
		String strAddress_1 = dataTable.getData("Payment_Data", "Address_1").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_Address1, strAddress_1, "Address 1", true);

		//Entering the Zip_Code name in textbox field
		String str_zipcode = dataTable.getData("Payment_Data", "Zip_Code").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_Code, str_zipcode, "Zip code", true);

		//Entering the Phone_number name in textbox field
		String str_phNum = dataTable.getData("Payment_Data", "Phone_number").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_phNum, str_phNum, "Phone Number", true);

		//Clicking the Continue button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.btn_Continue, "Continue");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		
		//Clicking the Continue button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.btn_Continue1, "Continue");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Clicking the Shipping Method button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.ele_shippingMethod, "Shipping Method");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the Continue button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.btn_Continue2, "Continue");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the Credit Card button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.ele_creditChkBox, "Credit Card");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Clicking the Continue button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.btn_Continue3, "Continue");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Selecting the Card_Type in Dropdown List
		String str_CardType = dataTable.getData("Payment_Data", "Card_Type").toString();
		CommonFunctions.SelectDropDownItemByName(Samplepageobjects.dd_CardType, str_CardType, str_CardType);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Entering the cardholder name in textbox field
		String str_holdername = dataTable.getData("Payment_Data", "Cardholder_Name").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_CardHolder, str_holdername, "Card holder name",
				true);
		//Entering the cardnumber name in textbox field
		String st_cardnum = dataTable.getData("Payment_Data", "Card_Number").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_CardNum, st_cardnum, "Card number", true);

		//Selecting the Month in Dropdown List
		String str_expMonth = dataTable.getData("Payment_Data", "Exp_Month").toString();
		CommonFunctions.SelectDropDownItemByName(Samplepageobjects.dd_Month, str_expMonth, str_expMonth);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Selecting the Year in Dropdown List
		String str_expYear = dataTable.getData("Payment_Data", "Exp_Year").toString();
		CommonFunctions.SelectDropDownItemByName(Samplepageobjects.dd_year, str_expYear, str_expYear);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Entering the cardcode name in textbox field
		String st_cardcode = dataTable.getData("Payment_Data", "Card_Code").toString();
		CommonFunctions.EnterInputToTextBoxByXpath(Samplepageobjects.ele_CardCode, st_cardcode, "Card code", true);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//clicking the continue button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.btn_Continue4, "Continue");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		//Clicking the Confirm Button
		CommonFunctions.ClickButtonByXPath(Samplepageobjects.btn_confirm, "Confirm");

	}

	public void retrieve_Order_details() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Verifyin the thankyou is displayed
		CommonFunctions.ValidatePageSection("h1", "Thankyou");
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//String orderNum = driver.findElement(By.xpath(Samplepageobjects.ele_OrderNum)).getText().trim();
		
		//putting the order number in general data 
		//dataTable.putData("General_Data", "Order_Number", orderNum);
		//report.updateTestLog("Data", orderNum + " is written in the General_Data sheet sucessfully", Status.PASS);

	}

	public void logoutToApplication() {

		driver.quit();
		report.updateTestLog("Logout", "Logout from application ", Status.DONE);
	}
}
