/**
 * Package containing core libraries of Framework Request you to
 * keep these unchanged In future, we may provide support for any bugs fixes or
 * feature addition via these files. 
 * 
 * 
 */
package frameworkseleniumcore;