package testscripts;

import org.testng.annotations.Test;

import frameworkcore.DriverScript;
import frameworkcore.TestConfigurations;
import frameworkselenium.SeleniumTestParameters;

public class SampletestCaseAPI extends TestConfigurations {

	/*@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void validateUserData_REST(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription("Test API for User data");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void temparatureConvertion_SOAP(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription("Test API for Temparture Convertions");
		
		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}*/
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void ExternalSystem_REST_SOAP(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription("Test to validate Additional Info in External service using REST and SOAP Service");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void MembersAPI_DirectMongo(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription("Test to validate details of Response API against the details of Mongo DB");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

}
