package testscripts;

import org.testng.annotations.Test;

import frameworkcore.DriverScript;
import frameworkcore.TestConfigurations;
import frameworkhealing.GetClassNMethodNames;
import frameworkselenium.SeleniumTestParameters;

public class Shopping extends TestConfigurations {
	

	@Test(dataProvider = "DesktopBrowsers", dataProviderClass = TestConfigurations.class)
	public void ValidateShopping(SeleniumTestParameters testParameters) {
		
		testParameters.setCurrentTestDescription("Validating Shopping");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);

}
}
