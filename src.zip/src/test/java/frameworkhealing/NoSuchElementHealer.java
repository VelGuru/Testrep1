package frameworkhealing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import frameworkselenium.SeleniumTestParameters;
import frameworkseleniumcore.FrameworkParameters;
import frameworkseleniumcore.Report;



public class NoSuchElementHealer extends ObjectFortify {

	public NoSuchElementHealer(Exception e, By userDefinedLocator, String className, String methodName, int lineNumber,
			String packageName, WebDriver driver, FrameworkParameters frameworkParameters,
			SeleniumTestParameters testParameters, Report report,int objectlineNumber) {
		super(e, userDefinedLocator, className, methodName, lineNumber, packageName, driver, frameworkParameters,
				testParameters, report,objectlineNumber);
	}

	@Override
	public WebElement heal() {

		return invokeHealingProcess();
	}

}
