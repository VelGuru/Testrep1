package frameworkhealing;

public class Params {
	
	private LocatorType locatorType;

	public LocatorType getLocatorType() {
		return locatorType;
	}

	public void setLocatorType(LocatorType locatorType) {
		this.locatorType = locatorType;
	}
	
	

}
