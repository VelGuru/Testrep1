package frameworkhealing;


public enum LocatorType {

	ID, NAME, LINK_TEXT, PARTIAL_LINKTEXT, TAG_NAME, CLASS_NAME, CSS_SELECTOR, XPATH

}
