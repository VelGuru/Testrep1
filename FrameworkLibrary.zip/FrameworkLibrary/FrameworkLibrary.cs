﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Data;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Data.SqlClient;
using System.Threading;
using Framework_Reporting;
using Framework_Utilities;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support;


namespace ReusableLibrary
{
    /// <summary>
    /// Class file used to store Application related Utilities.
    /// </summary>
    /// <author>RXK4098 - Ramesh Kandasamy</author>
    /// <comments>This Library should not process Business Logic
    /// Should not invoke Function outside of Framework Library 
    /// </comments>
    public class FrameworkLibrary
    {

        /// <summary>
        /// To Initialize Run Configuration, Framework Settings, Browser [Called form TestInitialize Method]
        /// </summary>          
        /// <param name="tContext">TestContext instance for the current Test Case</param>
        /// <author>RXK4098 - Ramesh Kandasamy </author>
        public void InitializeRunConfigurations(TestContext tContext)
        {
            // CloseAllBrowserWindows();
            #region Initialize Iteration Number, Data Table and TestContext Values
            // Initialize Current Iteration Number, Step Number
            RunConfiguration.testCaseContext.currentIteration = tContext.DataRow.Table.Rows.IndexOf(tContext.DataRow);
            RunConfiguration.stepNumber = 1;
            if (RunConfiguration.testCaseContext.currentIteration == 0)
            {
                // Initialize Test Case Name and Total Iterations from TestContext
                RunConfiguration.testCaseContext.testCaseName = tContext.TestName.ToString();
                RunConfiguration.testCaseContext.totalIteration = tContext.DataRow.Table.Rows.Count;
                RunConfiguration.testCaseContext.fullyQualifiedTestName = tContext.FullyQualifiedTestClassName + "." + RunConfiguration.testCaseContext.testCaseName;
                RunConfiguration.testCaseContext.testProjectName = tContext.FullyQualifiedTestClassName.Split('.')[0];
                // Fetch Namespace of test method - Used for Identify Test Data sheet and Excel Logs
                var fullyQualifiedNameInArray = tContext.FullyQualifiedTestClassName.Split('.');
                RunConfiguration.testCaseContext.namespaceOfTestMethod[0] = fullyQualifiedNameInArray[fullyQualifiedNameInArray.Length - 2];
                RunConfiguration.testCaseContext.namespaceOfTestMethod[1] = fullyQualifiedNameInArray[fullyQualifiedNameInArray.Length - 3];
                // Initialize from App Config Values 
                DetermineValuesFromAppConfig();

                // Initialize Data Table
                if (RunConfiguration.getTestDataFromDB)
                {
                    InitializeDBDataTable();
                }
                else
                {
                    InitializeTestData();
                }

                // Initialize Test Category
                RunConfiguration.testCaseContext.testCategory = GetCurrentTestCaseCategory();

                if (!RunConfiguration.getTestDataFromDB)
                {
                    RunConfiguration.reuseWebDriver = GetBooleanFromFlag(GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "ReuseBrowser"));
                }
            }
            #endregion

            #region Row Skip - Skip the Current Iteration if applicable
            if (!RunConfiguration.getTestDataFromDB)
            {
                RunConfiguration.testCaseContext.skipCurrentIteration = GetBooleanFromFlag(GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.SKIPROW));
                if (RunConfiguration.testCaseContext.skipCurrentIteration)
                {
                    Console.WriteLine("Assert In Conclusive - Skipped ROW: " + (RunConfiguration.testCaseContext.currentIteration + 1));
                    Assert.Inconclusive("Row : " + (RunConfiguration.testCaseContext.currentIteration + 1) + " Skipped based on Data table Configuration");
                }
            }
            #endregion Row Skip - If Applicable

            #region HTML & EXCEL REPORTS
            // Initialize Html Reports
            InitializeHtmlReports();

            // Initialize Excel Settings
            RunConfiguration.testDataFactory.InitializeExcelLogSettigs();
            #endregion HTML & EXCEL REPORTS

            try
            {
                #region INITIALIZE TEST CASE PARAMETERS
                // Initilaize Test Case Parameters
                InitializeTestCaseParameters();
                #endregion INITIALIZE TEST CASE PARAMETERS

                #region DB REPORT
                if (RunConfiguration.logTestReportToDB)
                {
                    // Insert a New Test Run (Row) for each Iteration 
                    InsertCurrentRunDataBaseEntry();
                }
                #endregion DB REPORT

                #region Initialize Environment and Launch Browser
                // Initialize Env Token
                InitializeEnvToken();

                // Initialize Current Environment details 
                InitializeCurrentEnvironment();

                // Initialize WebDriver
                if (!RunConfiguration.UserGrid)
                {
                    InitializeWebDriver();
                }

                #endregion Initialize Environment and Launch Browser
            }
            catch (AssertFailedException)
            {
                // Rethrow valid Assertion Exception
                throw;
            }
            catch (Exception e)
            {
                // Log Unhandled/Runtime Exceptions
                Console.Error.WriteLine("Exception: " + e.Message);
                UpdateTestLog("Error", "(Script Initial Error) InitializeRunConfigurations Exception : " + e.Message, Status.FAIL);
            }
        }

        /// <summary>
        /// Initlialize Test Case Parameters
        /// </summary>
        public void InitializeTestCaseParameters()
        {
            // Settings need to done for each Test Method [First Iteration]
            if (RunConfiguration.testCaseContext.currentIteration == 0)
            {
                #region TESTCASE DESCRIPTION
                try
                {
                    try
                    {
                        RunConfiguration.testCaseContext.functionalityImpacted = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.FUNCTIONALITYIMPACTED);
                    }
                    catch (Exception)
                    {
                        RunConfiguration.testCaseContext.functionalityImpacted = string.Empty;
                    }
                    try
                    {
                        RunConfiguration.testCaseContext.testDataType = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TEST_DATA_TYPE);
                    }
                    catch (Exception)
                    {
                        RunConfiguration.testCaseContext.testDataType = string.Empty;
                    }
                    try
                    {
                        RunConfiguration.testCaseContext.testDataCategory = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TEST_DATA_CATEGORY);
                    }
                    catch (Exception)
                    {
                        RunConfiguration.testCaseContext.testDataCategory = string.Empty;
                    }
                    RunConfiguration.testCaseSummaryDescription = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TESTCASESUMMARYDESC);
                }
                catch (Exception)
                {
                    RunConfiguration.testCaseSummaryDescription = "";
                }
                finally
                {
                    if (string.IsNullOrEmpty(RunConfiguration.testCaseSummaryDescription))
                    {
                        RunConfiguration.testCaseSummaryDescription = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TESTCASEDESCRIPTION);
                    }
                }
                #endregion TESTCASE DESCRIPTION
            }
            #region Initialize Test Parameters
            RunConfiguration.testCaseContext.functionalTestName = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.FUNCTCNAME);


            RunConfiguration.testCaseContext.testCaseDescription = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TESTCASEDESCRIPTION);
            if (RunConfiguration.enableHtmlLog)
            {
                RunConfiguration.htmlReport.UpdateTestLog("Description", RunConfiguration.testCaseContext.testCaseDescription, Framework_Reporting.Status.DONE);
            }
            try
            {
                RunConfiguration.authorName = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.AUTHORNAME);
            }
            catch (Exception)
            {
                // Column Name is not available - Optional
                RunConfiguration.authorName = "";
            }
            #endregion

        }

        /// <summary>
        /// Initialize Web Emulation
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy </author>
        public void InitializeWebEmulation()
        {
            // WRITE LOGIC USING WEBDRIVER
            if (RunConfiguration.useWebEmulationLogin)
            {
                Assert.Fail("Web Emulation is not implemented in Selenium. Automation Team is working on this...");
            }
        }

        /// <summary>
        /// Initialize HTML REPORT & HTML Dashboard
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void InitializeHtmlReports()
        {
            if (RunConfiguration.enableHtmlLog)
            {
                if (RunConfiguration.testCaseContext.currentIteration == 0)
                {
                    // Update Pass & Fail Count
                    RunConfiguration.iterationPassCount = 0;
                    RunConfiguration.iterationFailCount = 0;
                    // Update BatchRunId Path
                    string htmlPath = RunConfiguration.htmlReportPath + RunConfiguration.batchRunId;
                    string runConfiguration = RunConfiguration.batchRunId;
                    if (RunConfiguration.enableDynamicBatchRunId)
                    {
                        string todayDate = Regex.Replace(GetTodayDateInISTFormat.ToString(), "/|:", "_").Split(' ')[0];
                        htmlPath = RunConfiguration.htmlReportPath + RunConfiguration.testCaseContext.testProjectName + todayDate;
                        runConfiguration = ReportFactory.currentRunCategory;
                    }

                    if (!Directory.Exists(htmlPath))
                    {
                        Directory.CreateDirectory(htmlPath);
                    }

                    // Start Timer
                    RunConfiguration.stopwatch = Stopwatch.StartNew();

                    string htmlSummaryPath = htmlPath + Util.GetFileSeparator() + "HTML Results" + Util.GetFileSeparator() + "Summary" + ".html";


                    RunConfiguration.htmlLogCurrentTestCaseName = RunConfiguration.testCaseContext.testCaseName;
                    string htmlLogPath = htmlPath + Util.GetFileSeparator() + "HTML Results" + Util.GetFileSeparator() + RunConfiguration.htmlLogCurrentTestCaseName + ".html";

                    if (File.Exists(htmlLogPath))
                    {
                        if (RunConfiguration.enableOverrideInHtml)
                        {
                            // Delete Existing Result Log
                            File.Delete(htmlLogPath);
                        }
                        else
                        {
                            int runId = 2;
                            do
                            {
                                RunConfiguration.htmlLogCurrentTestCaseName = RunConfiguration.testCaseContext.testCaseName + "_Run" + runId;
                                runId++;
                                htmlLogPath = htmlPath + Util.GetFileSeparator() + "HTML Results" + Util.GetFileSeparator() + RunConfiguration.htmlLogCurrentTestCaseName + ".html";
                            } while (File.Exists(htmlLogPath));
                        }
                    }

                    ReportSettings reportSettings = new ReportSettings(htmlPath, RunConfiguration.htmlLogCurrentTestCaseName);
                    reportSettings.ProjectName = RunConfiguration.projectName;
                    reportSettings.GenerateExcelReports = true;
                    reportSettings.GenerateHtmlReports = true;
                    reportSettings.GenerateHtmlDevOpsReports = RunConfiguration.enableOverrideInHtml;
                    reportSettings.IncludeTestDataInReport = false;
                    reportSettings.TakeScreenshotFailedStep = GetBooleanFromFlag(ReadFromConfigFile("TakeScreenshotFailedStep"));
                    reportSettings.TakeScreenshotPassedStep = GetBooleanFromFlag(ReadFromConfigFile("TakeScreenshotPassedStep"));
                    ReportTheme reportTheme = ReportThemeFactory.GetReportsTheme(ReportThemeFactory.Theme.HUMANA);

                    RunConfiguration.htmlReport = new Report(reportSettings, reportTheme);
                    RunConfiguration.htmlReport.InitializeReportTypes();
                    if (!File.Exists(htmlSummaryPath))
                    {
                        RunConfiguration.htmlReport.InitializeResultSummary();
                        RunConfiguration.htmlReport.AddResultSummaryHeading("Sample Project - Execution Summary");
                        RunConfiguration.htmlReport.AddResultSummarySubHeading("Date & Time   ", ": " + Util.GetCurrentFormattedTime(reportSettings.DateFormatString), "Run Configuration   ", ": " + runConfiguration);
                        RunConfiguration.htmlReport.AddResultSummaryTableHeadings();
                        RunConfiguration.htmlReport.AddResultSummaryFooter(RunConfiguration.testCaseContext.fullyQualifiedTestName);
                    }

                    // Add Test Log
                    RunConfiguration.htmlReport.UpdateRunConfigurationInDashboard(runConfiguration, RunConfiguration.testCaseContext.testProjectName, RunConfiguration.testsPlannedCount, RunConfiguration.testCaseContext.fullyQualifiedTestName);
                    RunConfiguration.htmlReport.InitializeTestLog();
                    RunConfiguration.htmlReport.AddTestLogHeading(RunConfiguration.htmlLogCurrentTestCaseName);
                    RunConfiguration.htmlReport.AddTestLogSubHeading("Date & Time   ", ": " + Util.GetCurrentFormattedTime(reportSettings.DateFormatString), "Workstream ", ": " + RunConfiguration.testCaseContext.testProjectName);
                    RunConfiguration.htmlReport.AddTestLogSubHeading("Executed On   ", ": " + Environment.MachineName, "Total Iterations ", ": " + RunConfiguration.testCaseContext.totalIteration);
                    RunConfiguration.htmlReport.AddTestLogSubHeading("Environment   ", ": " + RunConfiguration.envToken, "Test Category ", ": " + RunConfiguration.testCaseContext.testCategory);
                    RunConfiguration.htmlReport.AddTestLogTableHeadings();
                }
                // Add Iteration
                RunConfiguration.htmlReport.AddTestLogSection("Iteration : " + (RunConfiguration.testCaseContext.currentIteration + 1));
            }
        }

        /// <summary>
        /// Finalize Html Reports and Html Dashboard
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void FinalizeHtmlReports()
        {
            if (RunConfiguration.enableHtmlLog)
            {
                // Stop Timer
                RunConfiguration.stopwatch.Stop();
                TimeSpan timeSpan = RunConfiguration.stopwatch.Elapsed;
                int totalTime = (int)timeSpan.TotalSeconds;
                string timeTaken = timeSpan.Minutes + " minute(s), " + timeSpan.Seconds + " seconds(s)";
                RunConfiguration.htmlReport.AddTestLogFooter(timeTaken);

                RunConfiguration.htmlReport.UpdateResultSummary(RunConfiguration.testCaseContext.testCategory,
                                    RunConfiguration.htmlLogCurrentTestCaseName, RunConfiguration.testCaseContext.functionalTestName,
                                    timeTaken, RunConfiguration.htmlTestStatus);

                RunConfiguration.htmlReport.AddTestLogToDashboardCalcSheet(RunConfiguration.htmlLogCurrentTestCaseName,
                                    RunConfiguration.testCaseContext.functionalTestName, RunConfiguration.testCaseContext.testProjectName,
                                    RunConfiguration.testCaseContext.testCategory, RunConfiguration.testCaseContext.namespaceOfTestMethod[0],
                                    totalTime, RunConfiguration.iterationPassCount, RunConfiguration.iterationFailCount,
                                    RunConfiguration.testCaseContext.fullyQualifiedTestName);

            }
        }

        /// <summary>
        /// Method to determined the Category of Current Test Case : BVT, SMOKE or REGRESSION. 
        /// </summary>
        /// <returns>  String current Test Case Category</returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetCurrentTestCaseCategory()
        {
            // INCOMPLETE LOGIC - LOGIC to be added to get Test Category defined for Test Method 
            string categoryToReturn = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, AttributeReferences.TESTCATEGORY).Trim();
            if (categoryToReturn.Equals(string.Empty))
            {
                categoryToReturn = "REGRESSION";
            }
            return categoryToReturn;
        }

        /// <summary>
        /// Method to Initialize values from App Config File
        /// Any Logic to Override App.Config values should be written here
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void DetermineValuesFromAppConfig()
        {
            //RunConfiguration.envToken = ReadFromConfigFile("EnvironmentToken").ToUpper();
            RunConfiguration.currentBrowser = ReadFromConfigFile("CurrentBrowser");
            RunConfiguration.batchRunId = ReadFromConfigFile("BatchRunID");
            ReportFactory.currentRunCategory = ReadFromConfigFile("CurrentRunCategory").ToUpper();
            RunConfiguration.logTestReportToDB = GetBooleanFromFlag(ReadFromConfigFile("LogTestReportToDB"));
            RunConfiguration.isProdDatabase = GetBooleanFromFlag(ReadFromConfigFile("IsProdDatabase"));
            RunConfiguration.getTestDataFromDB = GetBooleanFromFlag(ReadFromConfigFile("GetTestDataFromDB"));
            RunConfiguration.enableHtmlLog = GetBooleanFromFlag(ReadFromConfigFile("HtmlReport"));
            RunConfiguration.enableDynamicBatchRunId = GetBooleanFromFlag(ReadFromConfigFile("DynamicBatchRunIdForHtmlReport"));
            RunConfiguration.storeScreenShotInDB = GetBooleanFromFlag(ReadFromConfigFile("StoreScreenShotInDB"));
            RunConfiguration.enableExcelLog = GetBooleanFromFlag(ReadFromConfigFile("LogTestLogToExcel"));
            RunConfiguration.sendMail = GetBooleanFromFlag(ReadFromConfigFile("SendMail"));


            if (RunConfiguration.getTestDataFromDB)
            {
                RunConfiguration.testCaseContext.testGeneralDataSheet = "TESTDATA_GENERAL";
                RunConfiguration.testCaseContext.testDataControlsTable = "TESTDATA_CONTROLS";
                RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet = "TESTDATA_ENVSPECIFIC";
                RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet = "TESTDATA_MEGANAVIGATION";
                RunConfiguration.testCaseContext.testDataLinksNavigationTable = "TESTDATA_LINKSNAVIGATION";
            }

            if (RunConfiguration.isProdDatabase)
            {
                RunConfiguration.dbName = "DevOps_Automation";
            }
            else
            {
                RunConfiguration.dbName = "CodedUI";
            }

            // Web Emulation Details
            RunConfiguration.useWebEmulationLogin = GetBooleanFromFlag(ReadFromConfigFile("UseWebEmulationLogin"));
            RunConfiguration.UserGrid = GetBooleanFromFlag(ReadFromConfigFile("UserGrid"));

            // Html Report & Screenshot Path
            RunConfiguration.screenShotFolder = ReadFromConfigFile("ScreenShotFolder");
            RunConfiguration.htmlReportPath = ReadFromConfigFile("HtmlReportPath");
            if (!RunConfiguration.htmlReportPath.EndsWith("\\"))
            {
                RunConfiguration.htmlReportPath = RunConfiguration.htmlReportPath + "\\";
            }
            RunConfiguration.screenShotFolder = RunConfiguration.screenShotFolder + "\\" + RunConfiguration.testCaseContext.testProjectName;
            RunConfiguration.screenShotFolder = RunConfiguration.screenShotFolder + "\\" + (Regex.Split(DateTime.Now.ToString(), " ")[0]).Replace("/", "-");

            //Create WorkStream Specific Folder (for Current Day) if not Exist 
            if (!Directory.Exists(RunConfiguration.screenShotFolder))
            {
                Directory.CreateDirectory(RunConfiguration.screenShotFolder);
            }
            // Identify Planned Tests Count
            try
            {
                RunConfiguration.testsPlannedCount = Int32.Parse(ReadFromConfigFile("TestsPlanned"));
            }
            catch (Exception)
            {
                RunConfiguration.testsPlannedCount = 0;
            }
        }

        /// <summary>
        /// Method to Insert a New Status Row in Test Results table for Each Iteration Run 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        private void InsertCurrentRunDataBaseEntry()
        {
            //string recordID = "11";
            TestResults testResults = new TestResults();

            //Get Batch Run Id 
            testResults.BATCHRUN_ID = ReadFromConfigFile("BatchRunID");
            testResults.RELEASE_NAME = ReadFromConfigFile("ReleaseName");
            if (ReportFactory.currentRunCategory.Equals("BVT"))
            {
                // Logic to be Added to Generate Batch Run ID Dynamically for BVT Execution 
            }

            testResults.FUNCTIONAL_TC_NAME = RunConfiguration.testCaseContext.functionalTestName;
            testResults.WORKSTREAM = GetWorkStreamName;
            testResults.RUN_CATEGORY = ReportFactory.currentRunCategory;
            testResults.TESTCASE_CATEGORY = RunConfiguration.testCaseContext.testCategory;
            testResults.CODEDUI_TEST_NAME = RunConfiguration.testCaseContext.testCaseName;
            testResults.CODEDUI_TEST_DESCRIPTIPON = RunConfiguration.testCaseContext.testCaseDescription;
            testResults.TEST_RESULT = Status.INCONCLUSIVE.ToString();
            testResults.ISSUE_TYPE = IssueType.AutomationScript.ToString().ToUpper();
            testResults.TEST_ITERATION = RunConfiguration.testCaseContext.currentIteration + 1;
            testResults.TEST_STARTTIME = ReportFactory.curTimeStamp;
            testResults.LASTUPDATE_TIMESTAMP = ReportFactory.curTimeStamp;
            testResults.ENVIRONMENT = RunConfiguration.envToken.ToUpper();
            testResults.FUNCTIONAL_DESC = RunConfiguration.testCaseContext.namespaceOfTestMethod[0];
            testResults.FUNCTIONALITY_IMPACTED = RunConfiguration.testCaseContext.functionalityImpacted;
            testResults.TEST_DATA_TYPE = RunConfiguration.testCaseContext.testDataType;
            testResults.TEST_DATA_CATEGORY = RunConfiguration.testCaseContext.testDataCategory;

            ReportFactory reportFactory = new ReportFactory();
            reportFactory.InsertStartTestRunRecord(testResults);

            #region Update Iteration Grouping ID
            reportFactory.UpdateIterationGroupID();
            #endregion Update Iteration Grouping ID
        }

        /// <summary>
        /// Method to Launch Grid
        /// </summary>
        /// <author> Gnaneswar Sodini</author>
        public void LaunchGrid()
        {
            Uri appURI = GetURIFromURL(RunConfiguration.envURL);
            string gridUrl = ReadFromConfigFile("GridURLValue");
            //string gridUrl = "http://10.225.10.222:5555/wd/hub";
            DesiredCapabilities capabilities = new DesiredCapabilities();
            if (RunConfiguration.UserGrid)
            {
                if (RunConfiguration.testCaseContext.currentIteration == 0 || !RunConfiguration.reuseWebDriver)
                {
                    capabilities = DesiredCapabilities.Chrome();
                    capabilities.SetCapability(CapabilityType.BrowserName, "chrome");
                    capabilities.SetCapability(CapabilityType.Platform, new Platform(PlatformType.Windows));
                    RunConfiguration.driver = new RemoteWebDriver(new Uri(gridUrl), capabilities);
                }
                RunConfiguration.driver.Url = appURI.AbsoluteUri;
                UpdateTestLog("LaunchUrl", "Invoke Application - " + RunConfiguration.envURL, Status.DONE);
                ((IJavaScriptExecutor)RunConfiguration.driver).ExecuteScript("window.resizeTo(1024, 768);");
                RunConfiguration.appUtilLibrary = new DriverAppUtilLibrary(RunConfiguration.driver);
                RunConfiguration.driverBusinessLibrary = new DriverBusinessLibrary(RunConfiguration.driver);
                var switches = new List<string>
                       {
                           "--start-maximized"
                       };

                capabilities.SetCapability("chrome.switches", switches);
            }
            RunConfiguration.driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
            RunConfiguration.driver.Manage().Window.Maximize();
        }


        /// <summary>
        /// Used for Results Generation
        /// </summary>
        /// <author>GXS8571 - Gnaneswar Sodini</author>
        public static void ResultsGen(string SourceFilePath, string DestinationFilePath, string FileName)
        {
            if (FileName != null)
            {
                SourceFilePath = Regex.Split(SourceFilePath, "Out")[0] + "In";
                DirectoryInfo DirInfo = new DirectoryInfo(SourceFilePath);
                string finam = "";
                foreach (var fi in DirInfo.EnumerateFiles("*.html", SearchOption.AllDirectories))
                {
                    finam = finam + fi.Directory + '\\' + fi.Name;
                }
                File.Copy(finam, DestinationFilePath + '\\' + FileName + ".html");
                File.Delete(finam);
            }
        }

        /// <summary>
        /// Return an equivalent boolean value for the argument passed. Return false by default if passed value if blank or not boolean convertable
        /// </summary>
        /// <param name="flag">can be "true", "Y", "N", "false" case insensitive</param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <returns>boolean equivalent for the passed value</returns>
        public Boolean GetBooleanFromFlag(string flag)
        {
            Boolean booleanToReturn = false;
            flag = flag.ToUpper();
            if ((flag == "TRUE") || (flag == "Y") || (flag == "YES"))
            {
                booleanToReturn = true;
            }
            return booleanToReturn;
        }

        /// <summary>
        /// Method to Initialize WebDriver
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>    
        public void InitializeWebDriver()
        {
            Uri appURI = GetURIFromURL(RunConfiguration.envURL);

            if (RunConfiguration.testCaseContext.currentIteration == 0 || !RunConfiguration.reuseWebDriver)
            {
                if (RunConfiguration.testCaseContext.currentIteration == 0 || !RunConfiguration.reuseWebDriver)
                {
                    if (RunConfiguration.currentBrowser.Equals("Chrome", StringComparison.OrdinalIgnoreCase))
                    {
                        try
                        {
                            var chromeOptions = new ChromeOptions();
                            chromeOptions.Proxy = null;
                            chromeOptions.AddArgument("--headless");
                            chromeOptions.AddArgument("disable-extensions");
                            chromeOptions.AddArgument("--no-sandbox");
                            //chromeOptions.AddArguments("--screenshot");
                            chromeOptions.AddAdditionalCapability("useAutomationExtension", false);
                            RunConfiguration.driver = new ChromeDriver(RunConfiguration.chromeDriverPath, chromeOptions);
                            RunConfiguration.driver.Manage().Cookies.DeleteAllCookies();


                            //if (GetBooleanFromFlag(ReadFromConfigFile("IsHeadless")))
                            //{
                            //    chromeOptions.AddArguments("headless");
                            //}
                            //RunConfiguration.driver = new ChromeDriver(RunConfiguration.chromeDriverPath, chromeOptions);
                        }
                        catch (Exception e)
                        {
                            var chromeOptions = new ChromeOptions();
                            chromeOptions.Proxy = null;
                            RunConfiguration.driver = new ChromeDriver(RunConfiguration.chromeDriverPath);
                        }
                    }
                    else if (RunConfiguration.currentBrowser.Equals("Firefox", StringComparison.OrdinalIgnoreCase))
                    {
                        FirefoxOptions options = new FirefoxOptions()
                        {
                            BrowserExecutableLocation = @"C:\Program Files (x86)\Mozilla Firefox\firefox.exe"
                        };
                        RunConfiguration.driver = new FirefoxDriver(options);
                    }
                    else
                    {
                        try
                        {

                            //InternetExplorerOptions optionsie = new InternetExplorerOptions();
                            ////optionsie.EnableNativeEvents = true;
                            //optionsie.IgnoreZoomLevel = true;
                            //optionsie.EnsureCleanSession = true;
                            ////Variable.driverIE = new InternetExplorerDriver(optionsie);



                            ////InternetExplorerOptions iE = new InternetExplorerOptions();
                            var internetExplorerOptions = new InternetExplorerOptions();
                            internetExplorerOptions.Proxy = null;
                            internetExplorerOptions.EnableNativeEvents = false;
                            internetExplorerOptions.IgnoreZoomLevel = true;
                            internetExplorerOptions.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                            internetExplorerOptions.EnablePersistentHover = true;
                            RunConfiguration.driver = new InternetExplorerDriver(RunConfiguration.ieDriverPath);
                            // RunConfiguration.driver = new InternetExplorerDriver();
                        }
                        catch (Exception ex)
                        {
                            Console.Error.WriteLine("Exception: " + ex.Message);
                            UpdateTestLog("Error", "(Script Initial Error) InitializeRunConfigurations Exception - for IE driver initialize: " + ex.Message, Status.FAIL);
                        }
                    }
                }
                RunConfiguration.driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
                RunConfiguration.driver.Manage().Window.Maximize();
            }
            RunConfiguration.driver.Url = appURI.AbsoluteUri;
            UpdateTestLog("LaunchUrl", "Invoke Application - " + RunConfiguration.envURL, Status.DONE);
            //RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors();
            RunConfiguration.appUtilLibrary = new DriverAppUtilLibrary(RunConfiguration.driver);
            RunConfiguration.driverBusinessLibrary = new DriverBusinessLibrary(RunConfiguration.driver);
            WaitTillPageLoaded();
        }

        /// <summary>
        /// Method to get URL object from String. Http Will be added to URL if not available in passed String my 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author> 
        /// <param name="url">A String to be Converted as URL. String can have http/https tag optional</param>
        /// <returns>URL of equivaluent url String </returns>
        public Uri GetURIFromURL(string url)
        {
            if (!url.Contains("http"))
            {
                url = "http://" + url;
            }
            return new System.Uri(url);
        }

        /// <summary>
        /// Method to Initialize Test Data - Will read current TC data rows from data source
        /// and store in temporary data table    
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author> 
        private void InitializeTestData()
        {
            RunConfiguration.testDataFactory.InitializeDataTable();
        }

        /// <summary>
        /// Method to Initialize Test Data - Will read current TC data rows from data source
        /// and store in temporary data table    
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        private void InitializeDBDataTable()
        {
            RunConfiguration.testDataFactory.InitializeDBDataTable();
        }

        /// <summary>
        /// Method to Initialize Environment Token from App.config File 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void InitializeEnvToken()
        {
            //To be read from config Variable Name, Environment Token, not Environment ID. EnvironmentID to be removed
            string envToken = "";
            try
            {
                envToken = GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "EnvToken").ToUpper();
            }
            catch (Exception)
            {
                // Env Token is not found in Sheet - Optional
            }
            if (!string.IsNullOrEmpty(envToken))
            {
                RunConfiguration.envToken = envToken;
            }
        }

        /// <summary>
        /// Method to Initialize Currently executed Environemnt. Will be generated from Environment Token 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author> 
        private void InitializeCurrentEnvironment()
        {
            RunConfiguration.envURL = GetEnvPrefixedURL(GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "ApplicationUrl"));
        }

        /// <summary>
        /// Method to Generate and Get Appropriate URL based on Environment Token 
        /// </summary>
        /// <param name="bURL"></param>
        /// <returns>return URL with environment Prefix </returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetEnvPrefixedURL(string bURL)
        {
            // Not required to add Token if already complete URL is provided
            if (bURL.StartsWith("http"))
            {
                return bURL;
            }
            if (RunConfiguration.enabledNewDashboard)
            {
                if (RunConfiguration.envToken.Equals("PROD"))
                {
                    bURL = bURL.Replace("www.humana.com/members", "myhumana2.humana.com");
                }
                else
                {
                    bURL = bURL.Replace("www.humana.com/members", "myhumana2.humana.com");
                }
            }
            string envPrefix = null;
            //For Production
            if (RunConfiguration.envToken.Equals("PROD"))
            {
                envPrefix = "http://";
            }
            else if (RunConfiguration.envToken.Equals("QA"))
            {
                envPrefix = "https://" + RunConfiguration.envToken.ToLower() + "-";
            }
            else
            {
                envPrefix = "http://" + RunConfiguration.envToken.ToLower() + "-";
            }

            return envPrefix + bURL;
        }

        /// <summary>
        /// Method to Read Value from Configuraiton File. Retrun Blank if Config Key Value is not Found  
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author> 
        public string ReadFromConfigFile(string keyName)
        {
            string configValueRead = "";
            try
            {
                configValueRead = ConfigurationManager.AppSettings[keyName].ToString().Trim();
            }
            catch (Exception)
            {
                Console.Error.WriteLine("Configuraiton Key: " + keyName + " Not found in both Workstream & Reusable App.Config file. Returning Blank Value");
            }
            return configValueRead;
        }

        /// <summary>
        /// Get the test data from Environment sheet, if data not available it will refer INT Env data
        /// </summary>
        /// <param name="columnName">Column Name</param>
        /// <param name="useIntEnvAsDefault">Refer INT Data, if data not available</param>
        /// <returns></returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetTestDataFromEnvSheet(string columnName, bool useIntEnvAsDefault = true)
        {
            string returnData = "";
            Exception exception = null;
            string envPrefix = RunConfiguration.envToken.ToUpper();
            envPrefix = Regex.Replace(envPrefix, "SC8", "").Trim();
            envPrefix = Regex.Replace(envPrefix, "[0-9]", "");
            envPrefix = Regex.Replace(envPrefix, "SUPPORT", "");
            envPrefix = Regex.Replace(envPrefix, "IDE", "");

            try
            { // Get the Test data for the Current Env
                returnData = GetTestData(RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet, columnName + "_" + envPrefix);
            }
            catch (Exception e)
            {
                exception = e;
            }
            if (useIntEnvAsDefault && string.IsNullOrEmpty(returnData))
            { // Get Test Data from INT Env, if no data available for Current Env
                returnData = GetTestData(RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet, columnName + "_INT");
            }
            else if (exception != null)
            {
                throw exception;
            }
            return returnData;
        }

        /// <summary>
        /// Get the test data from Environment sheet, if data not available it will refer INT Env data
        /// </summary>
        /// <param name="columnName">Column Name</param>
        /// <param name="useIntEnvAsDefault">Refer INT Data, if data not available</param>
        /// <returns></returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetTestDataFromEnvSheetAndSubIteration(string columnName, int subIterationNo, bool useIntEnvAsDefault = true)
        {
            string returnData = "";
            Exception exception = null;
            string envPrefix = RunConfiguration.envToken.ToUpper();
            envPrefix = Regex.Replace(envPrefix, "SC8", "").Trim();
            envPrefix = Regex.Replace(envPrefix, "[0-9]", "");
            envPrefix = Regex.Replace(envPrefix, "SUPPORT", "");
            envPrefix = Regex.Replace(envPrefix, "IDE", "");

            try
            { // Get the Test data for the Current Env
                returnData = GetTestDataByAdditionalIndex(RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet, columnName + "_" + envPrefix, subIterationNo);
            }
            catch (Exception e)
            {
                exception = e;
            }
            if (useIntEnvAsDefault && string.IsNullOrEmpty(returnData))
            { // Get Test Data from INT Env, if no data available for Current Env
                returnData = GetTestDataByAdditionalIndex(RunConfiguration.testCaseContext.testDataEnvSpecificDataSheet, columnName + "_INT", subIterationNo);
            }
            else if (exception != null)
            {
                throw exception;
            }
            return returnData;
        }

        /// <summary>
        /// Method to Read Test Data from Data Table. The Data table will have data specic to current Test Case and will be initialized from Initialize Method
        /// </summary>
        /// <param name="columnName">Column to read the test data from</param>
        /// <param name="sheetToRead">Sheet from which the Column to be searched for </param>
        /// <returns>test data read. If Column value is null, will return an empty String</returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetTestData(string sheetToRead, string columnName)
        {
            string returnData = "", oleDBSheetName = sheetToRead + "$";

            if (RunConfiguration.getTestDataFromDB)
            {
                oleDBSheetName = sheetToRead;
            }
            if (RunConfiguration.testDataFactory.testDataTable.ContainsKey(oleDBSheetName))
            {
                bool iterationFound = false;
                try
                {
                    //DataRow curSheetDTRow = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows[RunConfiguration.testCaseContext.currentIteration];
                    DataRowCollection dataRowCollection = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows;

                    foreach (DataRow eachData in dataRowCollection)
                    {
                        if (eachData["Iteration"].ToString().Trim().Equals((RunConfiguration.testCaseContext.currentIteration + 1).ToString()))
                        {
                            returnData = eachData[columnName.Trim()].ToString().Trim();
                            iterationFound = true;
                            break;
                        }
                    }
                }
                catch (Exception noColumn)
                {
                    noColumn.ToString();
                    throw new Exception("Column: " + columnName + " is not found in Sheet - " + sheetToRead);
                }
                if (!iterationFound)
                {
                    throw new Exception("Iteration (" + (RunConfiguration.testCaseContext.currentIteration + 1).ToString() + ") is not found in for the provided test");
                }
            }
            else
            {
                throw new Exception("Sheet: " + sheetToRead + " not found in Data Table, or the sheet does not have data for this test case's current Iteration");
            }
            // Return Trimmed Test Data 
            return returnData.Trim();
        }

        /// <summary>
        /// Get Custom Test Data specfic Requirements
        /// </summary>
        /// <param name="sheetToRead"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public string GetCustomTestData(string sheetToRead, string columnName, string whereCondition = "")
        {
            string returnData = "", oleDBSheetName = sheetToRead + "$";
            if (RunConfiguration.testDataFactory.customTestDataTable.ContainsKey(oleDBSheetName))
            {
                bool dataFound = false;
                try
                {
                    //DataRowCollection dataRowCollection = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows;
                    DataRow[] dataRowCollection = RunConfiguration.testDataFactory.customTestDataTable[oleDBSheetName].Select(whereCondition);
                    foreach (DataRow eachData in dataRowCollection)
                    {
                        returnData = eachData[columnName].ToString();
                        dataFound = true;
                        break;
                    }
                }
                catch (Exception noColumn)
                {
                    noColumn.ToString();
                    throw new Exception("Column: " + columnName + " is not found in Sheet - " + sheetToRead);
                }
                if (!dataFound)
                {
                    UpdateTestLog(sheetToRead, whereCondition + " is not found in for the provided Custom Test Data", Status.FAIL);
                }
            }
            else
            {
                throw new Exception("Sheet: " + sheetToRead + " not found in Data Table, or the sheet does not have data for this test case's current Iteration");
            }
            // Return Trimmed Test Data 
            return returnData.Trim();
        }

        /// <summary>
        /// Get Test Data by additional index/sub iteration
        /// </summary>
        /// <param name="sheetToRead">Sheet Name</param>
        /// <param name="columnName">Column Name</param>
        /// <param name="additionalIndexValue">SubIteration Number</param>
        /// <returns>Data Value</returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetTestDataByAdditionalIndex(string sheetToRead, string columnName, int additionalIndexValue)
        {
            if (additionalIndexValue == 1)
            {
                return GetTestData(sheetToRead, columnName);
            }
            string returnData = "", oleDBSheetName = sheetToRead + "$";
            if (RunConfiguration.testDataFactory.testDataTable.ContainsKey(oleDBSheetName))
            {
                bool iterationFound = false, subIterationFound = false;
                try
                {
                    //DataRow curSheetDTRow = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows[RunConfiguration.testCaseContext.currentIteration];
                    DataRowCollection dataRowCollection = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows;

                    foreach (DataRow eachData in dataRowCollection)
                    {
                        if (eachData["Iteration"].ToString().Trim().Equals((RunConfiguration.testCaseContext.currentIteration + 1).ToString()))
                        {
                            iterationFound = true;
                            if (eachData["SubIteration"].ToString().Trim().Equals((additionalIndexValue).ToString()))
                            {
                                returnData = eachData[columnName].ToString();
                                subIterationFound = true;
                                break;
                            }
                        }
                    }
                }
                catch (Exception noColumn)
                {
                    noColumn.ToString();
                    throw new Exception("Column: " + columnName + " is not found in Sheet - " + sheetToRead);
                }
                if (!iterationFound)
                {
                    throw new Exception("Iteration (" + (RunConfiguration.testCaseContext.currentIteration + 1).ToString() + ") is not found in for the provided test");
                }
                if (!subIterationFound)
                {
                    throw new Exception("Sub-Iteration (" + additionalIndexValue + ") is not found in for the provided test");
                }
            }
            else
            {
                throw new Exception("Sheet: " + sheetToRead + " not found in Data Table, or the sheet does not have data for this test case's current Iteration");
            }
            // Return Trimmed Test Data 
            return returnData.Trim();
        }

        /// <summary>
        /// Complete test execution, calculate execution time, export reports if applicable
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void WrapUpTestExecution(UnitTestOutcome unitTestOutCome = UnitTestOutcome.Passed)
        {
            #region SET OVERALL ITERATIONS RESULT
            if (RunConfiguration.logAssertFailAtEnd)
            {
                unitTestOutCome = UnitTestOutcome.Failed;
            }
            #endregion

            #region IDENTIFY NO OF ITERATIONS PASSED/FAILED
            if (unitTestOutCome == UnitTestOutcome.Passed)
            {
                RunConfiguration.iterationPassCount += 1;
                RunConfiguration.testDataFactory.UpdateExcelLogFile();
            }
            else
            {
                //RunConfiguration.iterationFailCount += 1;
                RunConfiguration.htmlTestStatus = "Failed";
                RunConfiguration.testDataFactory.UpdateExceptionMessage();
            }
            // Update FAIL Count
            RunConfiguration.iterationFailCount = RunConfiguration.testCaseContext.totalIteration - RunConfiguration.iterationPassCount;
            #endregion

            #region DB REPORTS
            if (RunConfiguration.logTestReportToDB)
            {
                FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
                TestResults testResults = new TestResults();
                testResults.TEST_RESULT = unitTestOutCome.ToString().ToUpper();

                if (unitTestOutCome == UnitTestOutcome.Failed)
                {
                    testResults.ISSUE_TYPE = RunConfiguration.issueType.ToString().ToUpper();
                }
                else
                {
                    testResults.ISSUE_TYPE = "";
                }
                testResults.TESTRUN_ID = ReportFactory.currentRunID;

                ReportFactory reportFactory = new ReportFactory();
                reportFactory.UpdateTestRunCompletion(testResults);

                //if (RunConfiguration.sendMail)
                //{
                //    DataTable resultSet = reportFactory.GetTestResultDetailsByTestRunId(ReportFactory.currentRunID);
                //    SendMail objSendMail = new SendMail();
                //    objSendMail.SendEmail(resultSet);
                //}
            }
            #endregion DB REPORTS

            #region CLOSE WEBDRIVER
            // Close the Multiple/Created Window/Tabs
            try
            {
                if (!RunConfiguration.reuseWebDriver || IsLastIteration)
                {
                    RunConfiguration.driver.Quit();
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine("Wrap up Test Execution - " + e.Message);
            }
            #endregion

            #region LOG REPORT & FINALIZE FAIL MESSAGE IF APPLICABLE
            // Error Details
            bool logAssertFailAtEnd = RunConfiguration.logAssertFailAtEnd;
            string logErrorMessage = RunConfiguration.failureLog;

            // Reset Run Configuration 
            if (IsLastIteration)
            {
                // Finalize Html Reports
                FinalizeHtmlReports();
                //TestResults testResults = new TestResults();
                ReportFactory reportFactory = new ReportFactory();
                //reportFactory.UpdateTestRunCompletion(testResults);
                if (RunConfiguration.sendMail)
                {
                    DataTable resultSet = reportFactory.GetTestResultDetailsByTestRunId(ReportFactory.currentRunID);
                    SendMail objSendMail = new SendMail();
                    objSendMail.SendEmail(resultSet);
                }

                // Reset Run Configuration
                ResetRunConfiguration();
            }
            else
            {
                RunConfiguration.logAssertFailAtEnd = false;
                RunConfiguration.failureLog = "Fail Summary : ";
            }

            // Assert Fail
            if (logAssertFailAtEnd)
            {
                Assert.Fail(logErrorMessage);
            }
            #endregion
        }

        /// <summary>
        /// Reset the Static variables for each Test Method
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ResetRunConfiguration()
        {
            // TODO - Gowri - Find alternative approach to Reset static variables in the Playback settings level
            RunConfiguration.testDataFactory = new TestDataFactory();
            RunConfiguration.testCaseContext = new TestCaseContext();
            RunConfiguration.driver = null;
            RunConfiguration.htmlTestStatus = "Passed";
            RunConfiguration.failureLog = "Fail Summary : ";
            RunConfiguration.logAssertFailAtEnd = false;
            ReportFactory.iterationGroupingID = 0;
            RunConfiguration.iterationPassCount = 0;
            RunConfiguration.iterationFailCount = 0;
        }

        /// <summary>
        /// Kills all IE Explore
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void CloseAllBrowserWindows()
        {
            System.Diagnostics.Process[] procs = System.Diagnostics.Process.GetProcessesByName("IEXPLORE");
            System.Diagnostics.Process[] procsdriver = System.Diagnostics.Process.GetProcessesByName("IEXPLORE");
            System.Diagnostics.Process[] procsff = System.Diagnostics.Process.GetProcessesByName("firefox");
            System.Diagnostics.Process[] procsffdriver = System.Diagnostics.Process.GetProcessesByName("geckodriver");
            System.Diagnostics.Process[] excelproc = System.Diagnostics.Process.GetProcessesByName("EXCEL");
            System.Diagnostics.Process[] IEDriverServer = System.Diagnostics.Process.GetProcessesByName("IEDriverServer");
            System.Diagnostics.Process[] procsdriverg = System.Diagnostics.Process.GetProcessesByName("geckodriver");
            System.Diagnostics.Process[] procschrome = System.Diagnostics.Process.GetProcessesByName("chrome");
            System.Diagnostics.Process[] procscdriver = System.Diagnostics.Process.GetProcessesByName("chromedriver");

            if (RunConfiguration.currentBrowser == "InternetExplorer")
            {
                procs = System.Diagnostics.Process.GetProcessesByName("iexplore");
                procsdriver = System.Diagnostics.Process.GetProcessesByName("InternetExplorerDriver");
            }
            else if (RunConfiguration.currentBrowser == "Chrome")
            {
                procs = System.Diagnostics.Process.GetProcessesByName("chrome");
                procsdriver = System.Diagnostics.Process.GetProcessesByName("ChromeDriver");

            }
            else if (RunConfiguration.currentBrowser == "FireFox")
            {
                procs = System.Diagnostics.Process.GetProcessesByName("Firefox");
                procsdriver = System.Diagnostics.Process.GetProcessesByName("FireFoxDriver");

            }

            foreach (System.Diagnostics.Process proc in procsdriverg)
            {
                proc.Kill();
            }
            foreach (System.Diagnostics.Process proc in procsdriver)
            {
                proc.Kill();
            }
            foreach (System.Diagnostics.Process proc in excelproc)
            {
                proc.Kill();
            }

            foreach (System.Diagnostics.Process proc in IEDriverServer)
            {
                proc.Kill();
            }
        }

        /// <summary>
        /// Method to Wait till Parameterized Seconds
        /// </summary>
        /// <author> RXK4098 - Ramesh Kandasamy  </author>
        public void ImplicitWaitBySeconds(int secondsToWait)
        {
            RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(secondsToWait);
        }



        /// <summary>
        /// Wait Till Browser window is loaded
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="browserOrParentControl"></param>
        public void WaitTillPageLoaded(int timeOut = 0)
        {
            if (timeOut == 0)
            {
                timeOut = RunConfiguration.pageLoadTimeOut;
            }
            IJavaScriptExecutor js = (IJavaScriptExecutor)RunConfiguration.driver;
            for (int i = 0; i < timeOut; i++)
            {
                if (js.ExecuteScript("return document.readyState").ToString().Equals("complete", StringComparison.OrdinalIgnoreCase))
                {
                    break;
                }
                else
                {
                    RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1);
                }
            }
        }

        /// <summary>
        /// Return Current System - To BE updated to handle both time zones IST & EST
        /// </summary>
        /// <returns>Current Date of the System </returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetCurrentDateString()
        {
            return DateTime.Today.ToString("MM/dd/yyyy");
        }

        /// <summary>
        /// This Method is used to log the Test Results to Standard ouput and HTML Reporting as well if not BVT
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="stepName">Step Name</param>
        /// <param name="stepDetails">Step Details</param>
        /// <param name="stepStatus">Step Status</param>
        public void UpdateTestLog(string stepName, string stepDetails, Status stepStatus, bool continueOnFail = false)
        {
            #region CONSOLEREPORTING
            // Console Reporting
            Console.WriteLine("Step " + (RunConfiguration.stepNumber++) + ": " + stepDetails);
            #endregion

            #region HTMLREPORTING
            Framework_Reporting.Status reportStatus;
            if (RunConfiguration.enableHtmlLog)
            {
                switch (stepStatus)
                {
                    case Status.PASS:
                        reportStatus = Framework_Reporting.Status.PASS;
                        break;
                    case Status.SCREENSHOT:
                        reportStatus = Framework_Reporting.Status.SCREENSHOT;
                        break;
                    case Status.DONE:
                        reportStatus = Framework_Reporting.Status.DONE;
                        break;
                    case Status.FAIL:
                        reportStatus = Framework_Reporting.Status.FAIL;
                        break;
                    case Status.WARNING:
                        reportStatus = Framework_Reporting.Status.WARNING;
                        break;
                    default:
                        reportStatus = Framework_Reporting.Status.DEBUG;
                        break;
                }
                RunConfiguration.htmlReport.UpdateTestLog(stepName, stepDetails, reportStatus);
            }
            #endregion HTMLREPORTING

            #region SCREENSHOTS, EXCEL & DB REPORTING
            string screenShotPath = "NA";
            // Screenshots
            if (RunConfiguration.enableExcelLog || RunConfiguration.logTestReportToDB)
            {
                if ((stepStatus == Status.PASS) || (stepStatus == Status.FAIL) || (stepStatus == Status.SCREENSHOT) || (stepStatus == Status.WARNING))
                {
                    try
                    {
                        screenShotPath = SaveScreenCapture(RunConfiguration.targetScreenShotObject);
                    }
                    catch (Exception e)
                    {
                        Console.Error.WriteLine("Exception in Capture Screenshot \n" + e.ToString());
                    }
                }
            }


            // Report Logging in Database if applicable 
            if (RunConfiguration.logTestReportToDB)
            {
                TestStepDetails testStepDetails = new TestStepDetails();
                ReportFactory reportFactory = new ReportFactory();

                if (!string.IsNullOrEmpty(ReportFactory.currentRunID))
                {
                    testStepDetails.TESTRUN_ID = ReportFactory.currentRunID;
                    testStepDetails.STEP_NAME = stepName;
                    testStepDetails.STEP_DESCRIPTION = stepDetails;
                    testStepDetails.STEP_STATUS = stepStatus.ToString();
                    if (!screenShotPath.Equals("NA"))
                    {
                        testStepDetails.SCREENSHOT_PATH = screenShotPath;
                    }
                    //Update Current Status 
                    reportFactory.InsertStepStatus(testStepDetails);
                }
            }
            #endregion ScreenShotCapture

            #region TESTCASE FAIL UPDATE
            if (stepStatus.Equals(Status.FAIL))
            {
                // Update Failure to Excel Reports if Applicable 
                //RunConfiguration.testDataFactory.UpdateErrorMessage(stepDetails, screenShotPath);
                // Log a Fail Statement to denote Current Test Run is Failed, to update overall execution result 
                if (!continueOnFail)
                {
                    Assert.Fail(stepDetails);
                }
                else
                {
                    RunConfiguration.failureLog = RunConfiguration.failureLog + stepDetails;
                    RunConfiguration.logAssertFailAtEnd = true;
                }
            }
            #endregion Update UnitTest Execution Status
        }

        /// <summary>
        /// The Method is used to Take Screenshot af passed control and store either in Configured Location or in Database 
        /// Static Variable 'RunConfiguration.targetScreenShotObject' should be Overriden from test method, 
        /// if screenshot to be Captured for New tab or Any other UI Contorl 
        /// </summary>
        /// <param name="anyCodedUIControlType"></param>
        /// <returns name="screenShotFullPath"> Retrun the location where Screenshot is Saved </returns>
        /// <author> PXS2800 - Prageeth Saravanan </author>
        //public string SaveScreenCapture(dynamic anyCodedUIControlType)
        //{
        //    string scrnShotFileName;
        //    if (string.IsNullOrEmpty(ReportFactory.currentRunID))
        //    {
        //        string screenshotPrefixName = RunConfiguration.testDataFactory.testLogScreenshotsPath;
        //        scrnShotFileName = screenshotPrefixName + "\\" + Regex.Replace(RunConfiguration.testDataFactory.GetTodayDateInISTFormat.ToString(), "/|:| ", "_") + ".jpg";
        //    }
        //    else
        //    {
        //        scrnShotFileName = RunConfiguration.screenShotFolder + "\\" + ReportFactory.currentRunID + "_" + RunConfiguration.stepNumber + ".jpg";
        //    }
        //    string updateQuery = string.Empty, screenShotFullPath = string.Empty;
        //    ReportFactory reportFactory = new ReportFactory();
        //    FrameworkLibrary frameworkLibrary = new FrameworkLibrary();


        //    if (anyCodedUIControlType.GetType().ToString().Contains("Microsoft.VisualStudio.TestTools.UITesting"))
        //    {
        //        //anyCodedUIControlType.DrawHighlight();
        //        //Image screenCaptureImage = anyCodedUIControlType.CaptureImage();
        //        Screenshot screenCaptureImage = ((ITakesScreenshot)RunConfiguration.driver).GetScreenshot();
        //        //If Saving to DB Enabled 
        //        if (RunConfiguration.storeScreenShotInDB)
        //        {
        //            ImageConverter imageConverter = new ImageConverter();
        //            byte[] imageByteData = (byte[])imageConverter.ConvertTo(screenCaptureImage, typeof(byte[]));
        //            int insertedImageID = reportFactory.InsertByteDataIntoDB(imageByteData);
        //            // Write Image ID to Current Run Row 
        //            updateQuery = "UPDATE " + ReportFactory.TESTSTEPDETAILS + " SET " + CTestStepDetails.SCREENSHOT_PATH
        //                + " = '[" + insertedImageID + "]' WHERE " + CTestResults.TESTRUN_ID + " = " + ReportFactory.currentRunID;
        //            screenShotFullPath = "@SCREENSHOT_TABLE:ID = " + insertedImageID;
        //        }
        //        else //If not Save on Configured Network Drive 
        //        {
        //            try
        //            {
        //                screenCaptureImage.SaveAsFile(scrnShotFileName, ScreenshotImageFormat.Jpeg);
        //                //Screenshot screenCaptureImage = ((ITakesScreenshot)RunConfiguration.driver).GetScreenshot();
        //                updateQuery = "UPDATE " + ReportFactory.TESTSTEPDETAILS + " SET " + CTestStepDetails.SCREENSHOT_PATH
        //                    + " = " + scrnShotFileName + " WHERE " + CTestResults.TESTRUN_ID + " = " + ReportFactory.currentRunID;
        //                screenShotFullPath = scrnShotFileName;
        //            }
        //            catch (Exception e)
        //            {
        //                Console.Error.WriteLine("Exception in Save Screenshot - " + e.Message);
        //            }
        //        }
        //    }
        //    else
        //    {
        //        throw new Exception("The Object Passed is Not Appear to be a Coded UI Type.. Please Verify!");
        //    }
        //    return screenShotFullPath;
        //}


        /// <summary>
        /// The Method is used to Take Screenshot af passed control and store either in Configured Location or in Database 
        /// Static Variable 'RunConfiguration.targetScreenShotObject' should be Overriden from test method, 
        /// if screenshot to be Captured for New tab or Any other UI Contorl 
        /// </summary>
        /// <param name="anyControlType"></param>
        /// <returns name="screenShotFullPath"> Retrun the location where Screenshot is Saved </returns>
        /// <author> RXK4098 - Ramesh Kandasamy </author>
        public string SaveScreenCapture(dynamic anyControlType)
        {
            string scrnShotFileName;
            if (string.IsNullOrEmpty(ReportFactory.currentRunID))
            {
                string screenshotPrefixName = RunConfiguration.testDataFactory.testLogScreenshotsPath;
                scrnShotFileName = screenshotPrefixName + "\\" + Regex.Replace(RunConfiguration.testDataFactory.GetTodayDateInISTFormat.ToString(), "/|:| ", "_") + ".jpg";
            }
            else
            {
                scrnShotFileName = RunConfiguration.screenShotFolder + "\\" + ReportFactory.currentRunID + "_" + RunConfiguration.stepNumber + ".jpg";
            }
            string updateQuery = string.Empty, screenShotFullPath = string.Empty;
            ReportFactory reportFactory = new ReportFactory();
            FrameworkLibrary frameworkLibrary = new FrameworkLibrary();

            //Image screenCaptureImage = anyControlType.CaptureImage();
            //If Saving to DB Enabled 
            if (RunConfiguration.storeScreenShotInDB)
            {
                Screenshot screenCaptureImage = ((ITakesScreenshot)RunConfiguration.driver).GetScreenshot();
                screenCaptureImage.SaveAsFile(scrnShotFileName, ScreenshotImageFormat.Jpeg);


                //ImageConverter imageConverter = new ImageConverter();
                //byte[] imageByteData = (byte[])imageConverter.ConvertTo(screenCaptureImage, typeof(byte[]));
                byte[] imageByteData = screenCaptureImage.AsByteArray;
                int insertedImageID = reportFactory.InsertByteDataIntoDB(imageByteData);
                // Write Image ID to Current Run Row 
                updateQuery = "UPDATE " + ReportFactory.TESTSTEPDETAILS + " SET " + CTestStepDetails.SCREENSHOT_PATH
                    + " = '[" + insertedImageID + "]' WHERE " + CTestResults.TESTRUN_ID + " = " + ReportFactory.currentRunID;
                screenShotFullPath = "@SCREENSHOT_TABLE:ID = " + insertedImageID;
            }
            else //If not Save on Configured Network Drive 
            {
                try
                {
                    Screenshot screenCaptureImage = ((ITakesScreenshot)RunConfiguration.driver).GetScreenshot();
                    screenCaptureImage.SaveAsFile(scrnShotFileName, ScreenshotImageFormat.Jpeg);
                    //screenCaptureImage.Save(scrnShotFileName, ImageFormat.Jpeg);
                    updateQuery = "UPDATE " + ReportFactory.TESTSTEPDETAILS + " SET " + CTestStepDetails.SCREENSHOT_PATH
                        + " = " + scrnShotFileName + " WHERE " + CTestResults.TESTRUN_ID + " = " + ReportFactory.currentRunID;
                    screenShotFullPath = scrnShotFileName;
                }
                catch (Exception e)
                {
                    Console.Error.WriteLine("Exception in Save Screenshot - " + e.Message);
                }
            }
            return screenShotFullPath;
        }

        /// <summary>
        /// Get the environment token added URL List/Collection
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="urlCollection">URL Collection</param>
        /// <returns></returns>
        public string GetEnvTokenAddedUrlCollection(string urlCollection)
        {
            string envTokenAddedUrlCollection = urlCollection;

            // For humana.com implemented [Need to add our.humana.com, etc once started to using or once got list]
            string baseUrl = "www.humana.com";
            string envSpecifiedBaseUrl = GetEnvPrefixedURL(baseUrl);
            if (urlCollection.Contains(baseUrl) && !urlCollection.Contains("-" + baseUrl))
            {
                envTokenAddedUrlCollection = urlCollection.Replace(baseUrl, envSpecifiedBaseUrl);
            }

            baseUrl = "www.careplushealthplans.com";
            envSpecifiedBaseUrl = GetEnvPrefixedURL(baseUrl);
            if (urlCollection.Contains(baseUrl) && !urlCollection.Contains("-" + baseUrl))
            {
                envTokenAddedUrlCollection = urlCollection.Replace(baseUrl, envSpecifiedBaseUrl);
            }

            // For humana.com implemented [Need to add our.humana.com, etc once started to using or once got list]
            baseUrl = "www.go365.com";
            envSpecifiedBaseUrl = GetEnvPrefixedURL(baseUrl);
            if (urlCollection.Contains(baseUrl) && !urlCollection.Contains("-" + baseUrl))
            {
                envTokenAddedUrlCollection = urlCollection.Replace(baseUrl, envSpecifiedBaseUrl);
            }

            if (RunConfiguration.enabledNewDashboard)
            {
                if (RunConfiguration.envToken.Equals("PROD"))
                {
                    envTokenAddedUrlCollection = envTokenAddedUrlCollection.Replace("www.humana.com/members", "myhumana2.humana.com");
                }
                else
                {
                    envTokenAddedUrlCollection = envTokenAddedUrlCollection.Replace("www.humana.com/members", "myhumana2.humana.com");
                }
            }

            return envTokenAddedUrlCollection;
        }

        /// <summary>
        /// Get the String value from Array
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="arrayList">Array List</param>
        /// <param name="indexNumber">Index Value</param>
        public static string GetArrayIndexValue(string[] arrayList, int indexNumber)
        {
            string arrayValue = "";
            try
            {
                arrayValue = arrayList[indexNumber];
            }
            catch (Exception)
            {
                // Index is not found 
            }
            return arrayValue;
        }

        /// <summary>
        /// Check the List is sorted or not
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="sequence">List</param>
        /// <returns></returns>
        public bool IsSorted(IEnumerable sequence)
        {
            // Now assuming that list
            IEnumerator iterator = sequence.GetEnumerator();
            if (!iterator.MoveNext())
            {
                // An empty sequence is always sorted
                return true;
            }
            IComparable previous = (IComparable)iterator.Current;
            while (iterator.MoveNext())
            {
                IComparable next = (IComparable)iterator.Current;
                if (next.CompareTo(previous) < 0)
                {
                    return false;
                }
                previous = next;
            }
            return true;
        }

        /// <summary>
        /// Compare Array Lists
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="left">First Array</param>
        /// <param name="right">Second Array</param>
        /// <returns></returns>
        public bool CompareArrayList(ArrayList left, ArrayList right)
        {
            if (left == null && right == null)
            {
                return true;
            }
            if (left == null || right == null)
            {
                return false;
            }
            if (left.Count != right.Count)
            {
                return false;
            }

            for (int i = 0; i < left.Count; i++)
            {
                if (!left[i].Equals(right[i]))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Method to Execute, Insert, Update Query in SQL Connection 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="query"></param>
        /// <param name="sqlConnection"></param>
        public void ExecuteSQLWriteCommand(string query, SqlConnection sqlConnection)
        {
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }

        /// <summary>
        /// Get the Property to check whether initialize / prerequiste steps need be executed
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public bool InitializeStepsRequired
        {
            get
            {
                if (RunConfiguration.testCaseContext.currentIteration == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Check Current iteration is last or not
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public bool IsLastIteration
        {
            get
            {
                return RunConfiguration.testCaseContext.currentIteration == (RunConfiguration.testCaseContext.totalIteration - 1);
            }
        }

        /// <summary>
        /// Convert String value to Integer
        /// </summary>
        /// <param name="valueToConvert"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public static int ConvertStringToInt(string valueToConvert, int defaultValue = 0)
        {
            try
            {
                defaultValue = Int32.Parse(Regex.Replace(valueToConvert, "[^0-9]", ""));
            }
            catch (Exception)
            {
                // Invalid Number format
            }
            return defaultValue;
        }

        /// <summary>
        /// Get Specific String Value from Source using splitter/pattern
        /// </summary>
        /// <param name="sourceString">Source Content</param>
        /// <param name="splitBy">Split By</param>
        /// <param name="expectedIndex">Expected Index</param>
        /// <param name="defaultValue">Default Value</param>
        /// <returns>Target String</returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetStringBySplittingFromSource(string sourceString, string splitBy, int expectedIndex, string defaultValue = "")
        {
            try
            {
                defaultValue = Regex.Split(sourceString, splitBy)[expectedIndex].Trim();
            }
            catch (Exception)
            {
                // Invalid Split Condition
            }
            return defaultValue;
        }

        /// <summary>
        /// Log any Initialize/Prerequisite error is occurred if any
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void LogInitializeFailure()
        {
            if (!string.IsNullOrEmpty(ErrorMessageInInitializeTest))
            {
                Assert.Fail(ErrorMessageInInitializeTest);
            }
        }

        /// <summary>
        /// Fetch App Config value using Namespace and Exteneded Text
        /// </summary>
        /// <param name="propNameExtendedText">Prop Name</param>
        /// <returns>App.Config Prop Value</returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string FetchConfigValueByTestMethodNamespace(string propNameExtendedText)
        {
            string actConfigValue = "";
            foreach (string eachNamespace in RunConfiguration.testCaseContext.namespaceOfTestMethod)
            {
                actConfigValue = ReadFromConfigFile(eachNamespace + "_" + propNameExtendedText);
                if (!string.IsNullOrEmpty(actConfigValue))
                {
                    break;
                }
            }
            if (string.IsNullOrEmpty(actConfigValue))
            {
                actConfigValue = ReadFromConfigFile(propNameExtendedText);
            }
            return actConfigValue;
        }

        /// <summary>
        /// Method to Read Test Data from Data Table. The Data table will have data specic to current Test Case and will be initialized from Initialize Method
        /// </summary>
        /// <param name="sheetToRead">Sheet to read the test data from</param>       
        /// <author>RXK4098 - Ramesh Kandasamy </author> 
        public List<SearchDetails> GetTestDataFromControlsSheet(string sheetToRead)
        {
            List<SearchDetails> SearchDetailsCollection = new List<SearchDetails>();

            string oleDBSheetName = sheetToRead + "$";
            if (RunConfiguration.testDataFactory.testDataTable.ContainsKey(oleDBSheetName))
            {
                try
                {
                    DataRowCollection dataRowCollection = RunConfiguration.testDataFactory.testDataTable[oleDBSheetName].Rows;

                    foreach (DataRow eachData in dataRowCollection)
                    {
                        SearchDetails searchDetails = new SearchDetails();
                        searchDetails.SearchText = eachData["SearchText"].ToString();
                        searchDetails.ResponseText = eachData["ResponseText"].ToString();
                        searchDetails.LinkList = eachData["LinkList"].ToString();
                        SearchDetailsCollection.Add(searchDetails);
                    }
                }
                catch (Exception noColumn)
                {
                    noColumn.ToString();
                    throw new Exception("Data is not found in Sheet - " + sheetToRead);
                }
            }
            else
            {
                throw new Exception("Sheet: " + sheetToRead + " not found in Data Table, or the sheet does not have data for this test case's current Iteration");
            }
            return SearchDetailsCollection;
        }

        /// <summary>
        /// Class to Hold Column names for Search Details 
        /// </summary>
        /// <author>RXK4098- Ramesh Kandasamy </author>
        public class SearchDetails
        {
            public string SearchText
            {
                get;
                set;
            }

            public string ResponseText
            {
                get;
                set;
            }

            public string LinkList
            {
                get;
                set;
            }

            public string linkListUrl
            {
                get;
                set;
            }
        }

        /// <summary>
        /// Get/Set the Error Message in Initialize tests
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string ErrorMessageInInitializeTest
        {
            get
            {
                return RunConfiguration.testFailMessageInInitialize;
            }
            set
            {
                RunConfiguration.testFailMessageInInitialize = value;
            }
        }

        /// <summary>
        /// Get the System Date in IST Format
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public DateTime GetTodayDateInISTFormat
        {
            get
            {
                TimeZoneInfo tzi = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                DateTime todayDate = DateTime.Now.ToUniversalTime();
                return TimeZoneInfo.ConvertTimeFromUtc(todayDate, tzi);
            }
        }

        /// <summary>
        /// Get the workstream name Format
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public string GetWorkStreamName
        {
            get
            {
                string workstream = RunConfiguration.testCaseContext.testProjectName;

                if (workstream == "Go365Portal")
                {
                    workstream = "Go365";
                }
                else if (workstream == "HumanaCom")
                {
                    workstream = "HCom";
                }
                else if (workstream == "MemberPortal")
                {
                    workstream = "Members";
                }
                return workstream;
            }
        }



    }
}
