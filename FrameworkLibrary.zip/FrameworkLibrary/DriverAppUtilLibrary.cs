﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace ReusableLibrary
{
    public class DriverAppUtilLibrary
    {
        IWebDriver driver;
        FrameworkLibrary frameworkLibrary;
        DriverBusinessLibrary driverBusinessLibrary;

        public DriverAppUtilLibrary(IWebDriver driver)
        {
            this.driver = driver;
            frameworkLibrary = RunConfiguration.frameworkLibrary;
            driverBusinessLibrary = RunConfiguration.driverBusinessLibrary;
        }

        /// <summary>
        /// Check WebElement is displayed
        /// </summary>
        /// <param name="locator">Locator Type</param>
        /// <param name="elementDesc">Element Description</param>
        /// <param name="parentElement">Parent Element</param>
        /// <param name="objectSearchTimeout">Object Search Timeout</param>
        /// <param name="continueOnFail">Continue on Fail</param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <returns>Returns True if it's displayed</returns>
        public bool IsWebElementDisplayed(By locator, string elementDesc = "", IWebElement parentElement = null, int objectSearchTimeout = 0, bool continueOnFail = false)
        {
            IWebElement element;
            return IsWebElementDisplayed(locator, out element, elementDesc, parentElement, objectSearchTimeout, continueOnFail);
        }

        /// <summary>
        /// Check WebElement is displayed
        /// </summary>
        /// <param name="element">Element to identify</param>
        /// <param name="elementDesc">Element Description</param>
        /// <param name="objectSearchTimeout">Object Search Timeout</param>
        /// <param name="continueOnFail">Continue on Fail</param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <returns>Returns True if it's displayed</returns>
        public bool IsWebElementDisplayed(IWebElement element, string elementDesc, int objectSearchTimeout = 0, bool continueOnFail = false)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(objectSearchTimeout));
            bool elementDisplayed = false;
            try
            {
                if (objectSearchTimeout != 0)
                {
                    driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(objectSearchTimeout);
                }
                if (element == null)
                {
                    frameworkLibrary.UpdateTestLog("IsWebElementDisplayed", elementDesc + " is not available in the page", Status.FAIL);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("IsWebElementDisplayed", elementDesc + " is available in the page", Status.PASS);
                    elementDisplayed = true;
                }
            }
            catch (Exception e)
            {
                frameworkLibrary.UpdateTestLog("Error", e.Message, Status.FAIL, true);
                frameworkLibrary.WrapUpTestExecution(UnitTestOutcome.Failed);
                throw;
            }
            finally
            {
                if (objectSearchTimeout != 0)
                {
                    driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(0);
                }
            }
            return elementDisplayed;
        }

        /// <summary>
        /// Keep mouse position in one particular place
        /// </summary>
        /// <author>KXS9441 - Kalaiyarasan Sivaprakasam</author>
        public void KeepMouseDown(By locator)
        {
            Actions action = new Actions(RunConfiguration.driver);
            IWebElement elementName = FindElement(locator);
            action.MoveToElement(elementName).Build().Perform();
        }

        /// <summary>
        ///  Validate element by an attribute
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateWebElementByAttribute(string tagname, string attribute_value, string value, IWebElement Element = null, IWebElement parentElement = null)
        {
            if (Element == null)
            {
                try
                {
                    IWebElement element = FindElement(By.XPath(".//" + tagname + "[" + attribute_value + "='" + value + "']"));
                    if (element.Displayed)
                    {
                        frameworkLibrary.UpdateTestLog("Element with the " + value + " is available", "Element with the " + value + " is available", Status.PASS);
                    }
                }
                catch
                {
                    frameworkLibrary.UpdateTestLog("Element with the " + value + " is not available", "Element with the " + value + " is not available", Status.FAIL);
                }
            }
            else
            {
                try
                {
                    if (Element.Displayed)
                    {
                        frameworkLibrary.UpdateTestLog("Element with the " + value + " is available", "Element with the " + value + " is available", Status.PASS);
                    }
                }
                catch
                {
                    frameworkLibrary.UpdateTestLog("Element with the " + value + " is not available", "Element with the " + value + " is not available", Status.FAIL);
                }
            }
        }

        /// <summary>
        ///Is element present using innertext 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateElementIsPresent(string attributeName, string[] text, string[] tagName, IWebElement parentElement = null)
        {
            for (int i = 0; i < text.Length; i++)
            {
                By locator = By.XPath("//" + tagName[i] + "[" + attributeName + "='" + text[i] + "']");
                if (IsElementVisible(locator))
                {
                    frameworkLibrary.UpdateTestLog(text[i] + " is present", text[i] + " is present", Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog(text[i] + " is  not found", text[i] + " is not found", Status.FAIL);
                }
            }
        }

        /// <summary>
        /// Check WebElement is displayed
        /// </summary>
        /// <param name="locator"></param>
        /// <param name="element"></param>
        /// <param name="elementDesc"></param>
        /// <param name="parentElement"></param>
        /// <param name="objectSearchTimeout"></param>
        /// <param name="continueOnFail"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <returns></returns>
        public bool IsWebElementDisplayed(By locator, out IWebElement element, string elementDesc = "", IWebElement parentElement = null, int objectSearchTimeout = 0, bool continueOnFail = false)
        {
            bool elementDisplayed = false;
            element = null;
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(objectSearchTimeout));
            try
            {
                if (objectSearchTimeout != 0)
                {
                    driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(objectSearchTimeout);
                }
                if (parentElement == null)
                {
                    element = driver.FindElement(locator);
                }
                else
                {
                    element = parentElement.FindElement(locator);
                }
                elementDisplayed = element.Displayed;
                if (!string.IsNullOrEmpty(elementDesc))
                {
                    DynamicResultLog(elementDisplayed, true, elementDesc, continueOnFail);
                }
            }
            catch (NoSuchElementException)
            {
                elementDisplayed = false;
            }
            finally
            {
                if (objectSearchTimeout != 0)
                {
                    driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(0);
                }
            }
            return elementDisplayed;
        }

        /// <summary>
        /// Check WebElement is not available
        /// </summary>
        /// <param name="locator">Locator Type</param>
        /// <param name="elementDesc"></param>
        /// <param name="parentElement"></param>
        /// <param name="objectSearchTimeout"></param>
        /// <param name="continueOnFail"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <returns></returns>
        public bool IsWebElementNotAvailable(By locator, string elementDesc = "", IWebElement parentElement = null, int objectSearchTimeout = 3, bool continueOnFail = false)
        {
            bool elementNotDisplayed = false;
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(objectSearchTimeout));
            try
            {
                elementNotDisplayed = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(locator));
                if (!string.IsNullOrEmpty(elementDesc))
                {
                    DynamicResultLog(!elementNotDisplayed, false, elementDesc, continueOnFail);
                }
            }
            catch (TimeoutException)
            {
                frameworkLibrary.UpdateTestLog("TimeoutException", "Timed out waiting for element " + elementDesc, Status.FAIL);
            }
            catch (Exception)
            {
                frameworkLibrary.UpdateTestLog("Exception", elementDesc + " Element is available", Status.FAIL);
            }
            return elementNotDisplayed;
        }

        public void ValidateElementIsSuprressed(string tagName, string attributeName, string attributeValue, string elementdesc, IWebElement parentElement = null)
        {
            By locatorName = By.XPath("//" + tagName + "[" + attributeName + "='" + attributeValue + "']");
            IList<IWebElement> element = driver.FindElements(locatorName);
            if (element.Count == 0)
            {
                frameworkLibrary.UpdateTestLog(elementdesc + " is suppressed", elementdesc + " is suppressed", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog(elementdesc + " is not suppressed", elementdesc + " is not suppressed", Status.FAIL);
            }
        }

        /// <summary>
        /// Find Matching WebElement from Collection
        /// </summary>
        /// <param name="locator"></param>
        /// <param name="elementDesc"></param>
        /// <param name="parentElement"></param>
        /// <param name="checkDisplayed"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <returns></returns>
        public IWebElement FindDisplayedElementFromCollection(By locator, string elementDesc = "", IWebElement parentElement = null)
        {
            IWebElement targetElement = null;

            ReadOnlyCollection<IWebElement> allElements;
            if (parentElement == null)
            {
                allElements = driver.FindElements(locator);
            }
            else
            {
                allElements = parentElement.FindElements(locator);
            }

            foreach (IWebElement eachElement in allElements)
            {
                if (eachElement.Displayed)
                {
                    targetElement = eachElement;
                    break;
                }
            }

            return targetElement;
        }

        /// <summary>
        /// Validate Link Navigation to Same Window
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent Control</param>
        /// <param name="linkName">Link Name</param>
        /// <param name="pageUrl">Page URL</param>
        /// <param name="navigateToBack">Navigate to Parent Page - bool</param>
        public void ValidateLinkNavigationToSameWindow(IWebElement parentControl, string linkName, string pageUrl = "", bool navigateToBack = true, string pageHeader = "")
        {
            LinksValidation linksValidation = new LinksValidation(parentControl);
            linksValidation.navigateBackIfSameWindow = navigateToBack;
            linksValidation.InitializeIndividualLinkProperties(linkName, "Same", pageUrl, pageHeader);
            linksValidation.ValidateLinkNavigationToSameWindow();
        }

        /// <summary>
        /// Validate Link Navigation to New Window
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent Control</param>
        /// <param name="linkName">Link Name</param>
        /// <param name="closeTheNavigatedPage">Close the Navigated Page - bool</param>
        /// <param name="clickParentTabPage">Click Parent Tab Page - bool</param>
        /// <param name="pageUrl">Page URL</param>
        public void ValidateLinkNavigationToNewWindow(IWebElement parentControl, string linkName, bool closeTheNavigatedPage = true, bool clickParentTabPage = false, string pageUrl = "", string pageHeader = "")
        {
            LinksValidation linksValidation = new LinksValidation(parentControl);
            linksValidation.closeWindowIfNewWindow = closeTheNavigatedPage;
            linksValidation.clickFirstTabIfNewWindow = clickParentTabPage;
            linksValidation.InitializeIndividualLinkProperties(linkName, "New", pageUrl, pageHeader);
            linksValidation.ValidateLinkNavigationToNewWindow();
        }

        /// <summary>
        /// Get WebElement
        /// </summary>
        /// <param name="locator"></param>
        /// <param name="elementDesc"></param>
        /// <param name="parentElement"></param>
        /// <param name="objectSearchTimeout"></param>
        /// <param name="returnNullIfNot"></param>
        /// <param name="continueOnFail"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <returns></returns>
        public IWebElement FindElement(By locator, string elementDesc = "", IWebElement parentElement = null, int objectSearchTimeout = 0, bool returnNullIfNot = true, bool continueOnFail = false)
        {
            IWebElement element = null;
            try
            {
                if (objectSearchTimeout != 0)
                {
                    driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(objectSearchTimeout);
                }
                if (parentElement == null)
                {
                    element = driver.FindElement(locator);
                    string elementValue = element.Text.ToString();
                }
                else
                {
                    element = parentElement.FindElement(locator);
                    string elementValue = element.Text.ToString();
                }
            }
            catch (NoSuchElementException)
            {
                if (!string.IsNullOrEmpty(elementDesc))
                {
                    // Log Report
                    frameworkLibrary.UpdateTestLog("Element", "Element-" + elementDesc + " is not available in the page", Status.FAIL, continueOnFail);
                }

                if (!returnNullIfNot)
                {
                    throw;
                }
            }
            finally
            {
                if (objectSearchTimeout != 0)
                {
                    RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(0);
                }
            }
            return element;
        }




        /// <summary>
        /// Find Matching web element
        /// </summary>
        public IWebElement FindMatchingWebElement(By locator, string elementDesc = "", IWebElement parentElement = null, bool checkDisplayed = true)
        {
            IWebElement targetElement = null;

            ReadOnlyCollection<IWebElement> allElements;
            if (parentElement == null)
            {
                allElements = RunConfiguration.driver.FindElements(locator);
            }
            else
            {
                allElements = parentElement.FindElements(locator);
            }

            foreach (IWebElement eachElement in allElements)
            {
                if (eachElement.Displayed)
                {
                    targetElement = eachElement;
                    break;
                }
            }

            return targetElement;
        }

        /// <summary>
        /// Get WebElement
        /// </summary>
        /// <param name="locator"></param>
        /// <param name="elementDesc"></param>
        /// <param name="parentElement"></param>
        /// <param name="objectSearchTimeout"></param>
        /// <param name="returnNullIfNot"></param>
        /// <param name="continueOnFail"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <returns></returns>
        public By SetLocatorUsingAncestor(string elementAttribute, string elementValue, string ancestorTag, string headerTag = null)
        {
            By element = null;

            if (headerTag == null)
            {
                element = By.XPath("//*[" + elementAttribute + "='" + elementValue + "']//ancestor::" + ancestorTag);
            }
            else
            {
                element = By.XPath("//" + headerTag + "[" + elementAttribute + "='" + elementValue + "']//ancestor::" + ancestorTag);
            }
            return element;
        }

        public By SetTheLocatorUsingXpath(string elementAttribute, string elementValue, string headerTag = null)
        {
            By element = null;

            if (headerTag == null)
            {
                element = By.XPath("//*[" + elementAttribute + "='" + elementValue + "']");
            }
            else
            {
                element = By.XPath("//" + headerTag + "[" + elementAttribute + "='" + elementValue + "']");
            }
            return element;
        }

        /// <summary>
        /// Validate Page Header by header name/inner text
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent UI Control</param>
        /// <param name="headerName">Header Name</param>
        /// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>
        /// <param name="usePageLoadTimeOut">Wait For Page load if it's true [Default True]</param>
        public void ValidatePageHeaderByName(string headerName, IWebElement parentElement = null, string headerTag = "H1", bool contains = false, bool usePageLoadTimeOut = true, bool continueOnFail = false)
        {
            int pageLoadTimeOut = 1;
            By headerControl = null;
            if (usePageLoadTimeOut)
            {
                pageLoadTimeOut = RunConfiguration.pageLoadTimeOut;
            }

            if (string.IsNullOrEmpty(headerTag))
            {
                headerTag = "H1";
            }

            if (contains != true)
            {
                headerControl = By.XPath(".//" + headerTag + "[.='" + headerName + "']");
            }
            else
            {
                headerControl = By.XPath("//" + headerTag + "[contains(.,'" + headerName + "')]");
                //ExplicitWaitForElement(headerControl);
                IWebElement headerElement = FindElement(By.TagName(headerTag));
                string headerValue = headerElement.Text;
                headerName = headerValue;
                try
                {
                    // Check 500 Server Error
                    IWebElement pageErrorControl = FindElement(By.XPath("//h1[contains(text(),'server error')]"));
                    if (pageErrorControl != null)
                    {
                        frameworkLibrary.UpdateTestLog("Error", "Server error is displayed on the page", Status.FAIL);
                    }
                }
                catch { }
            }

            //ExplicitWaitForElement(headerControl);
            // Check for Link Control Exist in the Page
            if (IsWebElementDisplayed(headerControl, "", parentElement, pageLoadTimeOut))
            {
                frameworkLibrary.UpdateTestLog(headerName, "Page/Section - " + headerName + " is displayed in the Page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog(headerName, "Page/Section  - " + headerName + " is not displayed in the Page", Status.FAIL, continueOnFail);
            }
        }

        /// <summary>
        /// Validate Paragraph text using contains
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent UI Control</param>
        /// <param name="content">content</param>
        /// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>
        public void ValidateTextParagraph(string content, string tagName = "p", IWebElement parentElement = null)
        {
            IWebElement paragraph = FindElement(By.XPath("//" + tagName + "[contains(.,'" + content + "')]"));

            // Check for Link Control Exist in the Page //p[contains(.,'Get')]
            if (paragraph.Enabled || paragraph.Displayed)
            {
                string linkName = paragraph.Text;
                frameworkLibrary.UpdateTestLog("Page Navigation", " Element(" + linkName + ") is present in the web page", Status.PASS);
                frameworkLibrary.WaitTillPageLoaded();
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Page Navigation", "Element(" + content + ") is not displayed in the page", Status.FAIL);
            }
        }


        /// <summary>
        /// Validate Page Header by partial header name/inner text
        /// <summary>
        /// <param name="parentControl">Parent UI Control</param>
        /// <param name="headerName">Header Name</param>
        /// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>
        /// <param name="usePageLoadTimeOut">Wait For Page load if it's true [Default True]</param>
        public void ValidatePageHeaderByPartialName(string headerName, IWebElement parentElement = null, string headerTag = "H1", bool usePageLoadTimeOut = true, bool continueOnFail = false)
        {
            int pageLoadTimeOut = 1;
            if (usePageLoadTimeOut)
            {
                pageLoadTimeOut = RunConfiguration.pageLoadTimeOut;
            }

            if (string.IsNullOrEmpty(headerTag))
            {
                headerTag = "H1";
            }

            By headerControl = By.XPath(".//" + headerTag + "['" + headerName + "']");

            // Check for Link Control Exist in the Page
            if (IsWebElementDisplayed(headerControl, "", parentElement, pageLoadTimeOut))
            {
                frameworkLibrary.UpdateTestLog("Header", "Page/Section Header - " + headerName + " is displayed in the Page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Header", "Page/Section Header - " + headerName + " is not displayed in the Page", Status.FAIL, continueOnFail);
            }
        }

        /// <summary>
        /// Validate Validate the display of element using the following tag and parentControl
        /// <summary>
        /// <param name="parentControl">Parent UI Control</param>
        public void ValidateDisplayOfElementWithTag(string tagName, IWebElement parentElement = null)
        {
            IWebElement elementControl = parentElement.FindElement(By.TagName(tagName));

            // Check for Link Control Exist in the Page
            if (IsWebElementDisplayed(elementControl, ""))
            {
                frameworkLibrary.UpdateTestLog("Element", "Element is displayed in the Page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Element", "Element is not displayed in the Page", Status.FAIL);
            }
        }


        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent UI Control</param>
        /// <param name="headerName">Header Name</param>
        /// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>
        /// <param name="usePageLoadTimeOut">Wait For Page load if it's true [Default True]</param>
        public void ClickLinkByID(string idName, string idDesc)
        {
            try
            {
                IWebElement LinkByID = FindElement(By.Id(idName));
                if (LinkByID != null)
                {
                    LinkByID.Click();
                    frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + idDesc + ") is clicked successfully", Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", idDesc + " - Link(" + idDesc + ") is not available in the page", Status.FAIL);
                }
            }
            catch (NoSuchElementException)
            {
                frameworkLibrary.UpdateTestLog("Element" + idDesc + "is not found", "Element" + idDesc + "is not found", Status.FAIL);
            }

        }

        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent UI Control</param>
        /// <param name="headerName">Header Name</param>
        /// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>
        /// <param name="usePageLoadTimeOut">Wait For Page load if it's true [Default True]</param>
        public void ClickSectionByNameandTag(string SectionName, string Tag, IWebElement parentElement = null)
        {
            By SectionControl = By.XPath(".//" + Tag + "[.='" + SectionName + "']");

            // Check for Link Control Exist in the Page
            if (IsWebElementDisplayed(SectionControl, "", parentElement))
            {
                IWebElement sectionClick = FindElement(SectionControl);
                if (sectionClick.Displayed)
                {
                    frameworkLibrary.UpdateTestLog("Section", "Section - " + SectionName + " is displayed in the Page", Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Section", "Section - " + SectionName + " is not displayed in the Page", Status.FAIL);
                }
                sectionClick.Click();
            }
        }

        /// <summary>
        /// Validate Page Header by header name/inner text
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent UI Control</param>
        /// <param name="headerName">Header Name</param>
        /// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>
        /// <param name="usePageLoadTimeOut">Wait For Page load if it's true [Default True]</param>
        public void ValidatePageHeaderByNameIsNotPresent(string headerName, IWebElement parentElement = null, string headerTag = "H1", bool usePageLoadTimeOut = true, bool continueOnFail = false)
        {
            int pageLoadTimeOut = 1;
            if (usePageLoadTimeOut)
            {
                pageLoadTimeOut = RunConfiguration.pageLoadTimeOut;
            }

            if (string.IsNullOrEmpty(headerTag))
            {
                headerTag = "H1";
            }

            By headerControl = By.XPath(".//" + headerTag + "[.='" + headerName + "']");

            // Check for Link Control Exist in the Page
            if (IsWebElementNotAvailable(headerControl, "", parentElement, pageLoadTimeOut))
            {
                frameworkLibrary.UpdateTestLog("Header", "Page/Section Header - " + headerName + " is  not displayed in the Page", Status.PASS);
            }
            else
            {
                // Check for page Load error if any
                frameworkLibrary.UpdateTestLog("Header", "Page/Section Header - " + headerName + " is displayed in the Page", Status.FAIL, continueOnFail);
            }
        }

        /// <summary>
        /// Validate Page by the section
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="">Parent UI Control</param>
        /// <param name="class">Header Name</param>
        /// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>
        /// <param name="usePageLoadTimeOut">Wait For Page load if it's true [Default True]</param>
        public void ValidatePageSection(string headerTag, string attributeName, string attributeValue, IWebElement parentElement = null, bool usePageLoadTimeOut = true, bool continueOnFail = false)
        {
            By section = null;

            if (!string.IsNullOrEmpty(attributeName))
            {
                section = By.XPath("//" + headerTag + "[" + attributeName + "='" + attributeValue + "']");
            }
            else
            {
                section = By.XPath("//" + headerTag + "[contains(.,'" + attributeValue + "')]");
            }
            if (IsElementVisible(section, "Enabled"))
            {
                frameworkLibrary.UpdateTestLog(attributeName + " Section is present", attributeValue + " Section is present", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog(attributeName + " Section is  not present", attributeValue + " Section is not present", Status.FAIL);
            }
        }



        /// <summary>
        /// Perform is element present in the comboBox
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void IsElementPresentInComboBox(By comboElement, string elementPresent)
        {

            IWebElement comboBoxWebElement = FindElement(comboElement);
            SelectElement element = new SelectElement(comboBoxWebElement);
            element.SelectByText(elementPresent);
            if (elementPresent == element.SelectedOption.Text)
            {
                frameworkLibrary.UpdateTestLog(elementPresent + " is present in the dropdown", elementPresent + " is present in the dropdown", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog(elementPresent + " is  not present in the dropdown", elementPresent + " is not present in the dropdown", Status.FAIL);
            }

        }


        /// <summary>
        /// Validate Page Name by Partial/inner text
        /// </summary>
        /// <author>KXS9441 - Kalaiyarasan Sivaprakasam</author>
        /// <param name="parentControl">Parent UI Control</param>
        /// <param name="headerName">Header Name</param>
        /// <param name="headerTag">Header Tag [Default Tag is "H1"]</param>
        /// <param name="usePageLoadTimeOut">Wait For Page load if it's true [Default True]</param>
        public void ValidateNameByPartialText(string partialName, IWebElement parentControl = null, string headerTag = "a", bool usePageLoadTimeOut = true, bool continueOnFail = false)
        {
            int pageLoadTimeOut = 1;
            if (usePageLoadTimeOut)
            {
                pageLoadTimeOut = RunConfiguration.pageLoadTimeOut;
            }

            if (string.IsNullOrEmpty(headerTag))
            {
                headerTag = "a";
            }

            By headerControl = By.XPath(".//" + headerTag + "[contains(.,'" + partialName + "')]");

            // Check for Link Control Exist in the Page
            if (IsWebElementDisplayed(headerControl, "", parentControl, pageLoadTimeOut))
            {
                frameworkLibrary.UpdateTestLog("Name", "Page/Section  - " + partialName + " Message is displayed in the Page", Status.PASS);
            }
            else
            {
                // Check for page Load error if any
                RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors(partialName);
                frameworkLibrary.UpdateTestLog("Name", "Page/Section  - " + partialName + " Message is not displayed in the Page", Status.FAIL, continueOnFail);
            }
        }

        /// <summary>
        /// Log result dynamically
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="actualResult">Actual Result</param>
        /// <param name="expectedResult">Expected Result</param>
        /// <param name="controlType">Control Type</param>
        public void DynamicResultLog(bool actualResult, bool expectedResult, string controlType, bool continueOnError = false)
        {
            string actControlType = controlType;
            if (controlType.Length > 45)
            {
                controlType = controlType.Trim().Substring(0, 46);
            }
            Status status = Status.PASS;
            if (actualResult != expectedResult)
            {
                status = Status.FAIL;
            }
            if (actualResult)
            {
                frameworkLibrary.UpdateTestLog(controlType, actControlType + " is displayed/available in the Page", status, continueOnError);
            }
            else
            {
                frameworkLibrary.UpdateTestLog(controlType, actControlType + " is not available in the Page", status, continueOnError);
            }
        }

        /// <summary>
        /// Click Link Control by using the Link Name as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="linkName">Link Name</param>
        /// <param name="parentControl">Parent Section</param>
        /// <param name="indexValue">Index Value - If more links available in the same Name</param>
        public bool ClickLinkByName(string linkName, IWebElement parentControl = null, string linkDesc = "", string childTagIfPresent = "")
        {
            IWebElement linkElement = null;
            By linkControl = By.XPath("//a[contains(text(), '" + linkName + "')]");
            if (!string.IsNullOrEmpty(childTagIfPresent))
            {
                linkControl = By.XPath("//a/" + childTagIfPresent + "[text()='" + linkName + "']");
            }

            try
            {

                linkElement = FindElement(linkControl, "", parentControl);
            }
            catch
            {
                frameworkLibrary.UpdateTestLog("WebElement Link " + linkName + " is present", "WebElement Link " + linkName + " is present", Status.FAIL);
            }
            // Check for Link Control Exist in the Page

            if (linkElement != null)
            {
                linkElement.Click();
                frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + linkName + ") is clicked successfully", Status.PASS);
                return true;
            }
            else
            {
                if (string.IsNullOrEmpty(linkDesc))
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + linkName + ") is not available in the page", Status.FAIL);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", linkDesc + " - Link(" + linkName + ") is not available in the page", Status.FAIL);
                }
                return false;
            }
        }

        /// <summary>
        /// Click Link which is invisible
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="linkName">Link Name</param>
        /// <param name="parentControl">Parent Section</param>
        /// <param name="indexValue">Index Value - If more links available in the same Name</param>
        public bool ClickLinkByNameForInvisibleElement(string linkName, IWebElement parentControl = null, string linkDesc = "", string childTagIfPresent = "")
        {
            IWebElement linkElement = null;
            By linkControl = By.XPath("//a[contains(text(), '" + linkName + "')]");
            if (!string.IsNullOrEmpty(childTagIfPresent))
            {
                linkControl = By.XPath("//a/" + childTagIfPresent + "[text()='" + linkName + "']");
            }


            try
            {
                linkElement = FindElement(linkControl, "", parentControl);

            }
            catch
            {
                frameworkLibrary.UpdateTestLog("WebElement Link " + linkName + " is present", "WebElement Link " + linkName + " is present", Status.FAIL);
            }
            // Check for Link Control Exist in the Page

            if (linkElement != null)
            {
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                js.ExecuteScript("arguments[0].click();", linkElement);
                return true;
            }
            else
            {
                if (string.IsNullOrEmpty(linkDesc))
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + linkName + ") is not available in the page", Status.FAIL);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", linkDesc + " - Link(" + linkName + ") is not available in the page", Status.FAIL);
                }
                return false;
            }
        }


        /// <summary>
        /// Click Link Control by using the Link Name as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="linkName">Link Name</param>
        /// <param name="parentControl">Parent Section</param>
        /// <param name="indexValue">Index Value - If more links available in the same Name</param>
        public bool ValidateLinkByName(string linkName, dynamic parentControl = null, string linkDesc = "", string childTagIfPresent = "")
        {
            IWebElement linkElement = null;
            // Check for Link Control Exist in the Page
            try
            {
                linkElement = FindElement(By.LinkText(linkName), "", parentControl);
                frameworkLibrary.UpdateTestLog(linkName + " web element is found", linkName + " web element is found", Status.PASS);
            }
            catch
            {

                frameworkLibrary.UpdateTestLog(linkName + " web element is not found", linkName + " web element is not found", Status.FAIL);
            }
            if (linkElement != null)
            {
                linkElement.Click();
                frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + linkName + ") is present", Status.PASS);
                return true;
            }
            else
            {
                if (string.IsNullOrEmpty(linkDesc))
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + linkName + ") is not available in the page", Status.FAIL);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", linkDesc + " - Link(" + linkName + ") is not available in the page", Status.FAIL);
                }
                return false;
            }
        }


        /// <summary>
        /// Click Link Control by using the Link Name as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="linkName">Link Name</param>
        /// <param name="parentControl">Parent Section</param>
        /// <param name="indexValue">Index Value - If more links available in the same Name</param>
        public bool ClickLinkByPartialName(string linkName, dynamic parentControl = null, string linkDesc = "", string childTagIfPresent = "")
        {
            By linkControl = By.XPath(".//a[contains(.,'" + linkName + "')]");
            if (!string.IsNullOrEmpty(childTagIfPresent))
            {
                linkControl = By.XPath(".//a/" + childTagIfPresent + "[contains(.,'" + linkName + "')]/..");
            }

            ExplicitWaitForElement(linkControl, 20);
            // Check for Link Control Exist in the Page
            IWebElement linkElement = FindElement(linkControl, "", parentControl);
            if (linkElement != null)
            {
                linkElement.Click();
                frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + linkName + ") is clicked successfully", Status.PASS);
                return true;
            }
            else
            {
                if (string.IsNullOrEmpty(linkDesc))
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + linkName + ") is not available in the page", Status.FAIL);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", linkDesc + " - Link(" + linkName + ") is not available in the page", Status.FAIL);
                }
                return false;
            }
        }

        /// <summary>
        /// Click button Control by using the button Name as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="buttonName">Button Name</param>
        /// <param name="parentControl">Parent Section</param>
        /// <param name="indexValue">Index Value - If more links available in the same Name</param>
        public void ClickButtonByName(string buttonName, dynamic parentControl = null, string childTagIfPresent = "", string buttonDesc = "")
        {
            #region Variable Declarations   
            IWebElement uIButton = null;
            #endregion

            if (!string.IsNullOrEmpty(childTagIfPresent))
            {
                // uIButton = FindElement(By.XPath(".//*[@id=core-tab-pxk745-1-lg"));
                //  uIButton = FindElement(By.XPath("//div[1]/button[ends-with(@id,'-1-lg')]"));

                uIButton = FindElement(By.XPath(".//button/" + childTagIfPresent + "[.='" + buttonName + "']/.."), " Button", parentControl);
            }
            else
            {
                uIButton = FindElement(By.XPath(".//button[.='" + buttonName + "']/.."), buttonDesc, parentControl);
            }

            if (uIButton != null)
            {
                uIButton.Click();
                frameworkLibrary.UpdateTestLog("Page Navigation", "Button(" + buttonName + ") is clicked successfully", Status.PASS);
                //frameworkLibrary.WaitTillPageLoaded();
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Page Navigation", "Button(" + buttonName + ") is not available in the page", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate button is present or not by using the button Name as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="buttonName">Button Name</param>
        /// <param name="parentControl">Parent Section</param>
        /// <param name="indexValue">Index Value - If more links available in the same Name</param>
        public void ValidateButtonByName(string buttonName, dynamic parentControl = null, string childTagIfPresent = "", string buttonDesc = "")
        {
            #region Variable Declarations   
            IWebElement uIButton = null;
            #endregion

            if (!string.IsNullOrEmpty(childTagIfPresent))
            {
                uIButton = FindElement(By.XPath(".//button/" + childTagIfPresent + "[.='" + buttonName + "']/.."), " Button", parentControl);
            }
            else
            {
                uIButton = FindElement(By.XPath(".//button[.='" + buttonName + "']"), buttonDesc, parentControl);
            }

            if (uIButton != null)
            {
                frameworkLibrary.UpdateTestLog("Button Validations", "Button(" + buttonName + ") is available in the page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Button Validations", "Button(" + buttonName + ") is not available in the page", Status.FAIL);
            }
        }


        /// <summary>
        /// Validate button is present or not by button partial Name as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="buttonName">Button Name</param>
        /// <param name="parentControl">Parent Section</param>
        /// <param name="indexValue">Index Value - If more links available in the same Name</param>
        public void ValidateButtonByPartialName(string buttonName, dynamic parentControl = null, string childTagIfPresent = "", string buttonDesc = "")
        {
            #region Variable Declarations   
            IWebElement uIButton = null;
            #endregion

            if (!string.IsNullOrEmpty(childTagIfPresent))
            {
                uIButton = FindElement(By.XPath(".//button/" + childTagIfPresent + "[contains(text(),'" + buttonName + "']"), " Button", parentControl, 2);
            }
            else
            {
                uIButton = FindElement(By.XPath(".//button[contains(text(),'" + buttonName + "')]"), buttonDesc, parentControl, 2);
            }

            if (uIButton != null)
            {
                frameworkLibrary.UpdateTestLog("Page Navigation", "Button(" + buttonName + ") is successfully displayed in the page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Page Navigation", "Button(" + buttonName + ") is not available in the page", Status.FAIL);
            }
        }


        /// <summary>
        /// Click button Control by using the button by partial Name as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="buttonName">Button Name</param>
        /// <param name="parentControl">Parent Section</param>
        /// <param name="indexValue">Index Value - If more links available in the same Name</param>
        public void ClickButtonByPartialName(string buttonName, dynamic parentControl = null, string childTagIfPresent = "", string buttonDesc = "")
        {
            #region Variable Declarations   
            IWebElement uIButton = null;
            #endregion

            if (!string.IsNullOrEmpty(childTagIfPresent))
            {
                uIButton = FindElement(By.XPath(".//button/" + childTagIfPresent + "[.='" + buttonName + "']"), " Button", parentControl);
            }
            else
            {
                uIButton = FindElement(By.XPath(".//button[contains(text(),'" + buttonName + "')]"), buttonDesc, parentControl);
            }

            if (uIButton != null)
            {
                uIButton.Click();
                frameworkLibrary.UpdateTestLog("Page Navigation", "Button(" + buttonName + ") is clicked successfully", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Page Navigation", "Button(" + buttonName + ") is not available in the page", Status.FAIL);
            }
        }



        /// <summary>
        /// Click button Control by using the class as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="className">class Name</param>
        /// <param name="parentControl">Parent Section</param>
        public void ClickButtonByAttribute(string attributeName, string attributeValue, string childTag = null, dynamic parentControl = null)
        {
            //#region Variable Declarations 
            try
            {
                IWebElement uIButton;
                if (childTag != null)
                {
                    uIButton = FindElement(By.XPath("//button/" + childTag + "[" + attributeName + "='" + attributeValue + "']"), parentControl);
                }
                else
                {
                    uIButton = FindElement(By.XPath("//button[" + attributeName + "='" + attributeValue + "']"), parentControl);
                }
                if (uIButton != null)
                {
                    uIButton.Click();
                    frameworkLibrary.UpdateTestLog("Page Navigation", "Button is clicked successfully", Status.PASS);
                    frameworkLibrary.WaitTillPageLoaded();
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", "Button is not available in the page", Status.FAIL);
                }
            }
            catch
            {
                frameworkLibrary.UpdateTestLog("WebElement " + attributeValue + " is not found", "WebElement " + attributeValue + " is not found", Status.FAIL);
            }
        }

        /// <summary>
        /// Click Radio Button by using inner text
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="className">class Name</param>
        /// <param name="parentControl">Parent Section</param>
        public void ClickRadioButtonByName(string radioButtonName, string Value, dynamic parentControl = null)
        {
            //string Xpath = ".//label[contains(.,'" + radioButtonName + "')]/..";
            IWebElement radioButton = FindElement(By.Name(radioButtonName), "Value(" + Value + ")");
            //IWebElement radioButton = driver.FindElement(By.Name(radioButtonName),Value(" + Value + "));         

            if (radioButton != null)
            {
                radioButton.Click();
                frameworkLibrary.UpdateTestLog("ClickRadioButton", "Radio Button is clicked successfully", Status.PASS);
                frameworkLibrary.WaitTillPageLoaded();
            }
            else
            {
                frameworkLibrary.UpdateTestLog("ClickRadioButton", "Radio Button is not available in the page", Status.FAIL);
            }
        }

        /// <summary>
        /// Click Radio Button by using inner text
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="tagName">Tag Name</param>
        /// <param name="parentControl">Parent Section</param>
        public void ValidateElementIsNotPresentInDropdown(IWebElement parentElement, string tagName, string containsElement, dynamic parentControl = null)
        {
            IList<IWebElement> allItems = parentElement.FindElements(By.TagName(tagName));
            foreach (IWebElement eachItem in allItems)
            {
                string itemValue = eachItem.Text;
                if (itemValue.Contains(containsElement))
                {
                    frameworkLibrary.UpdateTestLog("Current plan log", "Current Plan is available for the provided member, Please check provide Termed Member/validate Member", Status.FAIL);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Current plan log", itemValue + " Plan is available Coverage Selector drop down for the Termed Member", Status.PASS);
                }
            }
        }

        /// <summary>
        /// Validate Link Navigation - Single Link
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateLinkNavigation(IWebElement parentSection, string linkName, string linkNavWindowType = "Same", string pageUrl = "", string pageHeader = "")
        {
            LinksValidation linksValidation = new LinksValidation(parentSection);
            if (linkName.Contains("\r\n("))
            {
                linkNavWindowType = "New";
                string[] linkNameArray = linkName.Split('\r');
                linkName = linkNameArray[0];

            }
            linksValidation.InitializeIndividualLinkProperties(linkName, linkNavWindowType, pageUrl, pageHeader);
            linksValidation.ValidateLinkNavigation();
        }

        /// <summary>
        /// Validate Page Header by using dynamic Header Tag
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent Control</param>
        /// <param name="headerName">Header Name - Inner Text</param>
        public void ValidatePageHeaderByDynamicHeaderTag(IWebElement parentControl, string headerName)
        {
            if (string.IsNullOrEmpty(headerName))
            {
                return;
            }
            bool headerFound = false;
            string[] tagNameCollection = "H1;H2;H3;H4".Split(';');
            foreach (string tagName in tagNameCollection)
            {
                IWebElement promoHeaderUI = FindElement(By.XPath("//" + tagName + "[contains(text(), '" + headerName + "')]"));
                if (promoHeaderUI.Displayed)
                {
                    frameworkLibrary.UpdateTestLog("Header", "Page Header (" + promoHeaderUI.Text + ") is available", Status.PASS);
                    headerFound = true;
                    break;
                }
            }
            if (!headerFound)
            {
                RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors(headerName);
                frameworkLibrary.UpdateTestLog("Header", "Page Header (" + headerName + ") is not available", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate Page Header by using href and class
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent Control</param>
        /// <param name="headerName">Header Name - Inner Text</param>
        public void ValidateHeaderLinkByHrefandClass(string hrefName, string className, IWebElement parentElement = null)
        {
            try
            {
                IWebElement header = FindElement(By.XPath(".//a[@href='" + hrefName + "' and @class='" + className + "']"));
                if (header.Displayed)
                {
                    frameworkLibrary.UpdateTestLog("Header is present", "Header is present", Status.PASS);
                }
            }
            catch
            {
                frameworkLibrary.UpdateTestLog("Header is not present", "Header is not present", Status.FAIL);
            }
        }


        /// <summary>
        /// Click Radio Button by using Web Element
        /// </summary>
        /// <author>KXS9441 -Kalaiyarasan Sivaprakasam</author>
        public void ClickRadioButtonByWebElement(IWebElement webElement, string descRadio)
        {
            if (null != webElement && webElement.Selected)
            {
                frameworkLibrary.UpdateTestLog(descRadio, "Radio Button is Already selected specified option", Status.PASS);
                frameworkLibrary.WaitTillPageLoaded();
            }
            else if (null != webElement && !webElement.Selected)
            {
                webElement.Click();
                frameworkLibrary.UpdateTestLog(descRadio, "Radio Button is clicked successfully", Status.PASS);
                frameworkLibrary.WaitTillPageLoaded();
            }
            else
            {
                frameworkLibrary.UpdateTestLog(descRadio, "Radio Button is not available/already selected in the page", Status.FAIL);
            }
        }


        /// <summary>
        /// Click button Control by using the button Name as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="buttonName">Button Name</param>       
        public void ClickRadioButtonById(string id, string radioButtonDesc = "", IWebElement parentElement = null)
        {
            IWebElement radioButton = null;

            #region Variable Declarations 
            try
            {
                radioButton = FindElement(By.Id(id), "", parentElement);
                frameworkLibrary.UpdateTestLog("Radio button", "Radio button (" + radioButtonDesc + ") is present", Status.PASS);
            }
            catch
            {
                frameworkLibrary.UpdateTestLog("Radio button", "Radio button (" + radioButtonDesc + ") is not present", Status.FAIL);
            }
            #endregion

            if (radioButton != null)
            {
                radioButton.Click();
                frameworkLibrary.UpdateTestLog("ClickRadioButton", "Radio button (" + radioButtonDesc + ") is clicked successfully", Status.PASS);
                frameworkLibrary.WaitTillPageLoaded();
            }
            else
            {
                frameworkLibrary.UpdateTestLog("ClickRadioButton", "Radio button (" + radioButtonDesc + ") is not available in the page", Status.FAIL);
            }
        }
        /// <summary>
        /// Click button Control by using the button Name as input parameter
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="buttonName">Button Name</param>       
        public void ClickButtonById(string id, string ButtonDesc, IWebElement parentElement = null)
        {
            #region Variable Declarations        
            IWebElement Button = FindElement(By.Id(id), "", null);
            #endregion

            if (Button != null)
            {
                Button.Click();
                frameworkLibrary.UpdateTestLog("Click Button", "Button(" + ButtonDesc + ") is clicked successfully", Status.PASS);
                frameworkLibrary.WaitTillPageLoaded();
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Click Button", "Button(" + ButtonDesc + ") is not available in the page", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate expected and actual value matches
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="expectedValue">ExpectedValue</param>
        /// <param name="actualValue">ActualValue</param>
        /// <param name="controlType">ControlType</param>
        public void AssertEquals(string expectedValue, string actualValue, string controlType, bool continueOnError = false)
        {
            if (string.IsNullOrEmpty(expectedValue) && string.IsNullOrEmpty(actualValue))
            {
                frameworkLibrary.UpdateTestLog("Equals", controlType + " - Value is Empty as Expected", Status.PASS);
            }
            else if (expectedValue.Equals(actualValue))
            {
                frameworkLibrary.UpdateTestLog("Equals", controlType + " - ExpectedValue(" + expectedValue + ") is matched with actual", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Equals", controlType + " - ExpectedValue(" + expectedValue + ") is not matched with actualvalue(" + actualValue + ")", Status.FAIL, continueOnError);
            }
        }

        /// <summary>
        /// Click Link Control
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="linkControl">Link Control</param>
        public bool ClickLink(IWebElement linkControl, string linkDesc, bool addLinkDescToLog = true)
        {
            // Check for Link Control Exist in the Page
            if (linkControl.Enabled || linkControl.Displayed)
            {
                string linkName = linkControl.Text;
                frameworkLibrary.UpdateTestLog("Page Navigation", linkDesc + " Link(" + linkName + ") is displayed successfully", Status.PASS);
                linkControl.Click();
                if (addLinkDescToLog)
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", linkDesc + " Link(" + linkName + ") is clicked successfully", Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + linkName + ") is not clicked successfully", Status.FAIL);
                }
                frameworkLibrary.WaitTillPageLoaded();
                return true;
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Page Navigation", "Link(" + linkDesc + ") is not displayed in the page", Status.FAIL);
                return false;
            }
        }


        /// <summary>
        /// Select Item from dropdown
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void SelectDropDownItemByInnerText(IWebElement dropDownControl, string itemToSelect, string dropDownDesc)
        {
            if (dropDownControl.Enabled)
            {
                SelectElement select = new SelectElement(dropDownControl);
                try
                {
                    select.SelectByText(itemToSelect);
                    frameworkLibrary.UpdateTestLog("ItemToSelect", "Item (" + itemToSelect + ") is selected successfully", Status.PASS);
                }
                catch (Exception)
                {
                    frameworkLibrary.UpdateTestLog("ItemToSelect", "Item(" + itemToSelect + ") is not available", Status.FAIL);
                }
            }
            else
            {
                frameworkLibrary.UpdateTestLog("DropDown", "DropDown(" + dropDownControl + ") is not enabled", Status.FAIL);
            }
        }

        /// <summary>
        /// Select Item from dropdown
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void SelectDropDownItemByName(string name, string itemToSelect, string dropDownDesc)
        {
            IWebElement dropDownControl = FindElement(By.Name(name), "");
            SelectElement select = new SelectElement(dropDownControl);
            if (dropDownControl.Enabled)
            {
                select.SelectByText(itemToSelect);
                try
                {

                    frameworkLibrary.UpdateTestLog("ItemToSelect", "Item (" + itemToSelect + ") is selected successfully", Status.PASS);
                }
                catch (Exception)
                {
                    frameworkLibrary.UpdateTestLog("ItemToSelect", "Item(" + itemToSelect + ") is not available", Status.FAIL);
                }
            }
        }


        /// <summary>
        /// Select Item from dropdown using dropdown id 
        /// </summary>
        /// <author>RXK40989 - Ramesh Kandasamy</author>
        public void SelectDropDownItemByID(string id, string itemToSelect, string dropDownDesc)
        {
            IWebElement dropDownControl = FindElement(By.Id(id), dropDownDesc);
            SelectElement select = new SelectElement(dropDownControl);
            if (dropDownControl.Enabled)
            {
                select.SelectByText(itemToSelect);
                try
                {

                    frameworkLibrary.UpdateTestLog("ItemToSelect", "Item (" + itemToSelect + ") is selected successfully", Status.PASS);
                }
                catch (Exception)
                {
                    frameworkLibrary.UpdateTestLog("ItemToSelect", "Item(" + itemToSelect + ") is not available", Status.FAIL);
                }
            }
        }

        /// <summary>
        /// Select Item from dropdown using dropdown id 
        /// </summary>
        /// <author>RXK40989 - Ramesh Kandasamy</author>
        public void SelectDropDownItemByIDByPartialText(string id, string itemToSelect, string dropDownDesc)
        {
            IWebElement dropDownControl = FindElement(By.Id(id), "");
            SelectElement select = new SelectElement(dropDownControl);
            if (dropDownControl.Enabled)
            {
                select.SelectByText(itemToSelect, true);
                try
                {

                    frameworkLibrary.UpdateTestLog("ItemToSelect", "Item (" + itemToSelect + ") is selected successfully", Status.PASS);
                }
                catch (Exception)
                {
                    frameworkLibrary.UpdateTestLog("ItemToSelect", "Item(" + itemToSelect + ") is not available", Status.FAIL);
                }
            }
        }

        /// <summary>
        /// Select Item from dropdown
        /// </summary>
        /// <param name="index">Index Starts from 0</param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void SelectDropDownItemByIndex(IWebElement dropDownControl, int index, string dropDownDesc)
        {
            if (dropDownControl.Enabled)
            {
                SelectElement select = new SelectElement(dropDownControl);
                try
                {
                    if (select.Options.Count > index)
                    {
                        select.SelectByIndex(index);
                        frameworkLibrary.UpdateTestLog("ItemToSelect", " Item's (" + index + ") is in the range", Status.PASS);
                    }
                    else
                    {
                        // Index is not available.Select.Options.Count is the maximum range.
                        frameworkLibrary.UpdateTestLog("ItemToSelect", "Item's(" + index + ") is out of range", Status.FAIL);
                    }
                }
                catch (Exception)
                {
                    //  Item is not available log/Failed to Select
                    frameworkLibrary.UpdateTestLog("ItemToSelect", "Item's(" + index + ") is not available or failed to select", Status.FAIL);
                }
            }
            else
            {
                frameworkLibrary.UpdateTestLog("DropDown", "DropDown is not available", Status.FAIL);
            }
        }

        /// <summary>
        /// Enter Input to TextBox
        /// </summary>
        /// <param name="textboxElement"></param>
        /// <param name="inputToType"></param>
        /// <param name="textBoxDesc"></param>
        /// <param name="clearBeforeType"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void EnterInputToTextBox(string name, string inputToType, string textBoxDesc, bool clearBeforeType = true)
        {
            IWebElement textboxElement = FindElement(By.Name(name));

            if (textboxElement.Displayed || textboxElement.Enabled)
            {
                textboxElement.Click();
                if (clearBeforeType)
                {
                    textboxElement.Clear();
                }
                textboxElement.SendKeys(inputToType);
                frameworkLibrary.UpdateTestLog(name + " TextBox", textBoxDesc + "(" + inputToType + ") is entered in the text box", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog(name + " TextBox", "Textbox(" + textBoxDesc + ") is not available", Status.FAIL);
            }
        }

        /// <summary>
        /// Enter Input to TextBox
        /// </summary>
        /// <param name="textboxElement"></param>
        /// <param name="inputToType"></param>
        /// <param name="textBoxDesc"></param>
        /// <param name="clearBeforeType"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void EnterInputToTextBoxById(string id, string inputToType, string textBoxDesc, bool clearBeforeType = true)
        {
            IWebElement textboxElement = FindElement(By.Id(id));

            if (textboxElement.Displayed || textboxElement.Enabled)
            {
                textboxElement.Click();
                if (clearBeforeType)
                {
                    textboxElement.Clear();
                }
                textboxElement.SendKeys(inputToType);
                frameworkLibrary.UpdateTestLog("Enter value to textBox", textBoxDesc + " (" + inputToType + ") is entered in the text box", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Enter value to textBox", "Textbox (" + textBoxDesc + ") is not available - " + id, Status.FAIL);
            }
        }

        /// <summary>
        /// Click Link in MegaNavigation
        /// </summary>
        /// <param name="parentLink"></param>
        /// <param name="childLink"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ClickLinkInMegaNavigation(string parentLink, string childLink)
        {
            IWebElement parentLinkElement = FindElement(By.LinkText(parentLink), "Parent Link(" + parentLink + ")");

            // Mouse Hover to Parent Element
            Actions actions = new Actions(driver);
            actions.MoveToElement(parentLinkElement);

            // Find Child Link
            IWebElement childLinkElement = FindElement(By.LinkText(childLink), "Child Link(" + childLink + ")");
            ClickLink(childLinkElement, "Child Link(" + childLink + ")", true);
        }


        /// <summary>
        /// The method will return whether the element is present or no
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="by"></param>
        /// <param name="getStatus"></param>
        /// <returns></returns>
        public bool IsElementVisible(By by, string getStatus = "Enabled", IWebElement parentElement = null)
        {
            try
            {
                bool elementSize = (FindElement(by).Size != null);
                if (elementSize)
                {
                    if (getStatus.Equals("Enabled"))
                    {

                        if (FindElement(by).Enabled)
                            return true;
                        return false;

                    }
                    else if (getStatus.Equals("Displayed"))
                    {
                        if (FindElement(by).Displayed)
                            return true;
                        return false;
                    }

                    else if (getStatus.Equals("Both"))
                    {
                        if (FindElement(by).Displayed && FindElement(by).Enabled)
                            return true;
                        return false;
                    }
                    else
                    {
                        Assert.Fail("DEBUG INFO - Provided Status Control Class(" + getStatus + ") is not added, Please add before use the class");
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// Enter the text into the text box
        /// </summary>
        /// <param name="attributeName"></param>
        /// <param name="value"></param>
        /// <param name="inputToType"></param>
        /// <param name="textBoxDesc"></param>
        /// <param name="tagName"></param>
        /// <param name="parentElement"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="clearBeforeType"></param>
        public void EnterTextInTextBoxUsingAttribute(string attributeName, string value, string inputToType, string textBoxDesc, string tagName = null, IWebElement parentElement = null, bool clearBeforeType = true)
        {
            IWebElement textboxElement = null;
            try
            {
                if (tagName == null)
                {
                    textboxElement = FindElement(By.XPath("//*[" + attributeName + "='" + value + "']"));
                    frameworkLibrary.UpdateTestLog(textBoxDesc + " is present", textBoxDesc + " is present", Status.PASS);
                }
                else
                {
                    //*[@id="start-date"]
                    textboxElement = FindElement(By.XPath("//" + tagName + "[" + attributeName + "='" + value + "']"));
                    frameworkLibrary.UpdateTestLog(textBoxDesc + " is present", textBoxDesc + " is present", Status.PASS);
                }
            }

            catch
            {
                frameworkLibrary.UpdateTestLog(textBoxDesc + " is not present", textBoxDesc + " is not present", Status.FAIL);
            }

            if (clearBeforeType)
            {
                textboxElement.Clear();
            }
            textboxElement.SendKeys(inputToType);
            frameworkLibrary.UpdateTestLog(textBoxDesc + " TextBox", textBoxDesc + " - (" + inputToType + ") is entered in the text box", Status.PASS);
        }



        /// <summary>
        /// Validate Link in MegaNavigation
        /// </summary>
        /// <param name="parentLink"></param>
        /// <param name="childLink"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateLinkInMegaNavigation()
        {
            string megaNavParentLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavParentLink");
            string[] header = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "TargetPageHeader").Split(';');
            string[] megaNavChildLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavChildLink").Split(';');
            IWebElement parentLinkElement = FindElement(By.XPath("//*[text()='" + megaNavParentLink + " ']"));
            int i = 0;
            foreach (string childLink in megaNavChildLink)
            {
                frameworkLibrary.WaitTillPageLoaded(9000);
                // Mouse Hover to Parent Element
                Actions actions = new Actions(driver);
                actions.MoveToElement(parentLinkElement).Perform();

                frameworkLibrary.UpdateTestLog("Clicked" + megaNavParentLink + "successfully", "Clicked" + megaNavParentLink + " successfully", Status.PASS);
                try
                {
                    IWebElement childLinkElement = FindElement(By.LinkText(childLink), "Child Link(" + childLink + ")");
                    if (childLinkElement.Displayed)
                    {
                        frameworkLibrary.UpdateTestLog(childLink + " is  present", childLink + " is present", Status.PASS);
                        actions.MoveToElement(childLinkElement);
                        actions.Click().Perform();
                        frameworkLibrary.UpdateTestLog("Clicked" + childLinkElement + "successfully", "Clicked" + childLinkElement + " successfully", Status.PASS);
                        ValidatePageHeaderByName(header[i]);
                        i++;
                    }
                }
                catch
                {
                    frameworkLibrary.UpdateTestLog(childLink + " is not present", childLink + " is not present", Status.FAIL);
                }
            }
        }

        /// <summary>
        /// Select Checkbox by ID
        /// </summary>
        /// <param name="checkBoxIdAttribute"></param>
        /// <param name="toBeSelected"></param>
        /// <param name="checkBoxDesc"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void SelectCheckBoxById(string checkBoxIdAttribute, string selectedAttribute, bool toBeSelected, string checkBoxDesc)
        {
            IWebElement checkBoxElement = FindElement(By.Id(checkBoxIdAttribute));

            if (checkBoxElement.Displayed || checkBoxElement.Enabled)
            {
                bool actualState = checkBoxElement.Selected;
                if (toBeSelected)
                {
                    if (actualState)
                    {
                        frameworkLibrary.UpdateTestLog("CheckBox", "Log is already selected by the checkbox", Status.PASS);
                    }
                    else
                    {
                        checkBoxElement.Click();
                        IWebElement selectedvalueAttribute = FindElement(By.Id(selectedAttribute), "CheckBox(" + checkBoxDesc + ")");
                        if (selectedvalueAttribute.Selected)
                        {
                            frameworkLibrary.UpdateTestLog("CheckBox", "CheckBox(" + checkBoxDesc + ") is selected", Status.PASS);
                        }
                        else
                        {
                            frameworkLibrary.UpdateTestLog("CheckBox", "CheckBox(" + checkBoxDesc + ") is not selected", Status.FAIL);
                        }
                    }
                }
                else
                {
                    if (actualState)
                    {
                        // UnSelect                      
                        checkBoxElement.Click();
                        IWebElement selectedvalueAttribute = FindElement(By.Id(selectedAttribute), "CheckBox(" + checkBoxDesc + ")");
                        if (selectedvalueAttribute.Selected)
                        {
                            frameworkLibrary.UpdateTestLog("CheckBox", "Checkbox is not unselected", Status.FAIL);
                        }
                        else
                        {
                            frameworkLibrary.UpdateTestLog("CheckBox", "Checkbox is unselected", Status.PASS);
                        }
                    }
                    else
                    {
                        frameworkLibrary.UpdateTestLog("CheckBox", "CheckBox(" + checkBoxDesc + ") is unselected by default", Status.WARNING);
                    }
                }
            }
            else
            {
                frameworkLibrary.UpdateTestLog("CheckBox", "CheckBox(" + checkBoxDesc + ") is not available/enabled", Status.FAIL);
            }
        }

        /// <summary>
        /// Select Checkbox by Name
        /// </summary>
        /// <param name="checkBoxIdAttribute"></param>
        /// <param name="toBeSelected"></param>
        /// <param name="checkBoxDesc"></param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void SelectCheckBoxByName(string checkBoxNameAttribute, bool toBeSelected, string Value, string checkBoxDesc)
        {
            IWebElement checkBoxElement = FindElement(By.Name(checkBoxNameAttribute), "Value(" + Value + ")");

            if (checkBoxElement.Displayed && checkBoxElement.Enabled)
            {
                bool actualState = checkBoxElement.Selected;
                if (toBeSelected)
                {
                    if (actualState)
                    {
                        frameworkLibrary.UpdateTestLog("CheckBox", "Log is already selected by the checkbox", Status.PASS);
                    }
                    else
                    {
                        checkBoxElement.Click();
                        //IWebElement selectedvalueAttribute = FindElement(By.Id(selectedAttribute), "CheckBox(" + checkBoxDesc + ")");
                        if (checkBoxElement.Selected)
                        {
                            frameworkLibrary.UpdateTestLog("CheckBox", "CheckBox is selected", Status.PASS);
                        }
                        else
                        {
                            frameworkLibrary.UpdateTestLog("CheckBox is not selected", "CheckBox is not selected", Status.FAIL);
                        }
                    }
                }
                else
                {
                    if (actualState)
                    {
                        // UnSelect
                        checkBoxElement.Click();
                        //IWebElement selectedvalueAttribute = FindElement(By.Id(selectedAttribute), "CheckBox(" + checkBoxDesc + ")");
                        if (checkBoxElement.Selected)
                        {
                            frameworkLibrary.UpdateTestLog("Checkbox is not unselected", "Checkbox is not unselected", Status.FAIL);
                        }
                        else
                        {
                            frameworkLibrary.UpdateTestLog("Checkbox is unselected", "Checkbox is unselected", Status.PASS);
                        }
                    }
                    else
                    {
                        // Add Message - By default it's unselected
                    }
                }
            }
            else
            {
                // Add Fail Log - Not displayed/enabled
            }
        }

        /// <summary>
        /// Validate Page URL
        /// </summary>
        /// <param name="expectedUrl">Expected URL</param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidatePageUrl(string expectedUrl)
        {
            expectedUrl = frameworkLibrary.GetEnvPrefixedURL(expectedUrl);
            String actualUrl = RunConfiguration.driver.Url;
            if (expectedUrl.Equals(actualUrl))
            {
                frameworkLibrary.UpdateTestLog("ValidatePageUrl", "URL (" + expectedUrl + ") matches the expected URL", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("ValidatePageUrl", "Page URL (" + actualUrl + ") does not match the expected URL (" + expectedUrl + ")", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate Label By InnerText
        /// </summary>
        /// <param name="labelInnerText"></param>
        /// <param name="labelTagName"></param>
        /// <param name="parentElement"></param>
        /// <param name="labelDesc">Label Desc</param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateLabelByInnerText(string labelInnerText, string labelTagName = "label", IWebElement parentElement = null, string labelDesc = "")
        {
            IWebElement labelElement = FindElement(By.XPath(".//" + labelTagName + "[text()='" + labelInnerText + "']"), parentElement: parentElement);
            if (labelElement != null)
            {
                labelElement.Click();
                frameworkLibrary.UpdateTestLog("LabelAvailable", "Label (" + labelInnerText + ") is available", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("LabelNotAvailable", "Label(" + labelInnerText + ") is not available", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate Label By InnerText
        /// </summary>
        /// <param name="labelInnerText"></param>
        /// <param name="labelTagName"></param>
        /// <param name="parentElement"></param>
        /// <param name="labelDesc">Label Desc</param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateTextUsingContains(string labelInnerText, string labelTagName = "label", IWebElement parentElement = null, string labelDesc = "")
        {
            if (IsElementVisible(By.XPath(".//" + labelTagName + "[contains(text(),'" + labelInnerText + "')]"), "Displayed"))
            {
                frameworkLibrary.UpdateTestLog("Label", "Label (" + labelInnerText + ") is available", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Label", "Label(" + labelInnerText + ") is not available", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate Label By Partial InnerText
        /// </summary>
        /// <param name="labelInnerText"></param>
        /// <param name="labelTagName"></param>
        /// <param name="parentElement"></param>
        /// <param name="labelDesc">Label Desc</param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateLabelByPartialInnerText(string labelInnerText, string labelTagName, IWebElement parentElement = null, string labelDesc = "")
        {
            IWebElement labelElement = FindElement(By.XPath(".//" + labelTagName + "[contains(., '" + labelInnerText + "')]"), parentElement: parentElement);
            if (labelElement != null)
            {
                //Successfull Log - labelDesc
                frameworkLibrary.UpdateTestLog("Label", "Label (" + labelElement.Text + ") is available", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Label", "Label (" + labelInnerText + ") is not available", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate Radio Button Selection
        /// </summary>
        /// <author>KXS9441 - Kalaiyarasan Sivaprakasam</author>
        /// <param name="radioButton">Radio Button Ui</param>
        /// <param name="controlType">Control Type</param>
        /// <param name="expectedSelection">Expected Selection - True/False</param>
        public void AssertRadioButtonSelection(IWebElement radioButton, string controlType, bool expectedSelection)
        {
            if (radioButton.Displayed || radioButton.Enabled)
            {
                bool actualSelection = radioButton.Selected;
                if (actualSelection)
                {
                    if (expectedSelection)
                    {
                        frameworkLibrary.UpdateTestLog("Equals", "RadioButton(" + controlType + ") is selected as expected", Status.PASS);
                    }
                    else
                    {
                        frameworkLibrary.UpdateTestLog("Equals", "RadioButton(" + controlType + ") is selected, but it should not be selected", Status.FAIL);
                    }
                }
                else
                {
                    if (!expectedSelection)
                    {
                        frameworkLibrary.UpdateTestLog("Equals", "RadioButton(" + controlType + ") is not selected as expected", Status.PASS);
                    }
                    else
                    {
                        frameworkLibrary.UpdateTestLog("Equals", "RadioButton(" + controlType + ") is not selected, but it should be selected", Status.FAIL);
                    }
                }
            }
        }

        /// <summary>
        /// Validate Array is sorted or not
        /// </summary>
        /// <param name="list">List Ui</param>
        /// <returns></returns>
        /// <author>KXS9441 - Kalaiyarasan Sivaprakasam</author>
        public bool ValidateArraySorted(string[] list)
        {
            for (int i = 1; i < list.Length - 1; i++)
            {
                if (String.Compare(list[i], list[i + 1]) > 0)
                {
                    Console.WriteLine("Not in Order - " + list[i] + " - " + list[i + 1]);
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Get Boolean value from Flag - If String is null or empty, return the default result expected
        /// </summary>
        /// <param name="flag">Flag</param>
        /// <returns></returns>
        /// <author>KXS9441 - Kalaiyarasan Sivaprakasam</author>
        public bool GetBooleanFromFlag(string flag, bool defaultResult = false)
        {
            bool booleanToReturn = defaultResult;
            flag = flag.ToUpper();
            if ((flag == "TRUE") || (flag == "Y") || (flag == "YES"))
            {
                booleanToReturn = true;
            }
            else if (!string.IsNullOrEmpty(flag))
            {
                booleanToReturn = false;
            }
            return booleanToReturn;
        }

        /// <summary>
        /// Validate Label Control with expected Inner Text
        /// </summary>
        /// <author>KXS9441 - Kalaiyarasan Sivaprakasam</author>
        /// <param name="labelControl">Label Control</param>
        /// <param name="expectedLabelInnerText">Expected Inner Text</param>
        /// <param name="labelDescription">Label Description</param>
        /// <param name="timeOutInSeconds">Timeout In seconds</param>
        public void ValidateLabelWithExpectedInnerText(dynamic labelControl, string expectedLabelInnerText, string labelDescription, int timeOutInSeconds = 1)
        {
            // Check for Link Control Exist in the Page
            if (labelControl.WaitForControlExist(1000 * timeOutInSeconds))
            {
                string actualInnerText = labelControl.InnerText.Trim();
                if (actualInnerText.Equals(expectedLabelInnerText))
                {
                    frameworkLibrary.UpdateTestLog("LabelAvailable", "Actual " + labelDescription + "(" + actualInnerText + ") matches with the expected " + labelDescription + " (" + expectedLabelInnerText + ")", Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Label is not Available", "Actual " + labelDescription + "(" + actualInnerText + ") not matches with the expected " + labelDescription + " (" + expectedLabelInnerText + ")", Status.FAIL);
                }
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Label not Available", labelDescription + " Control is not available", Status.FAIL);
            }
        }

        /// <summary>
        /// Explicit Wait statement for a web element
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ExplicitWaitForElement(By byElement, int secwait = 5, string desc = "")
        {
            try
            {
                IWebElement expWait = (new WebDriverWait(RunConfiguration.driver, TimeSpan.FromSeconds(secwait))).Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(byElement));
            }
            catch
            {
                if (!string.IsNullOrEmpty(desc))
                {
                    frameworkLibrary.UpdateTestLog("Explicit wait", "Explicit wait for finding " + desc + " has failed", Status.FAIL);
                }
            }
        }

        /// <summary>
        /// Get the Parent Control from Section Header and by level
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public IWebElement GetParentControlFromSectionHeader(string sectionHeader, string sectionHeaderTag, int parentLevel = 1, string parentOrder = null, dynamic parentControl = null)
        {
            if (!string.IsNullOrEmpty(parentOrder))
            {
                parentLevel = FrameworkLibrary.ConvertStringToInt(parentOrder, parentLevel);
            }
            IWebElement parentSection = null;
            IWebElement sectionHeaderUi = FindElement(By.XPath("//" + sectionHeaderTag + "[text()='" + sectionHeader + "']"), "", parentControl);
            if (sectionHeaderUi.Displayed)
            {
                parentSection = (IWebElement)sectionHeaderUi.FindElement(By.XPath(".."));
                for (int i = 1; i < parentLevel; i++)
                {
                    parentSection = (IWebElement)parentSection.FindElement(By.XPath(".."));
                }
            }
            return parentSection;
        }

        /// <summary>
        /// Validate Link is displayed, and it's url value
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentUIControl">Parent Section</param>
        /// <param name="linkNameCollection">Link List [Format:- separated by comma(;)]</param>
        /// <param name="linkUrlsCollection">URLs Collection [Format:- separated by comma(;)]</param>
        /// <param name="sectionOrPageName">Section Name</param>
        public void ValidateLinksAvailablity(IWebElement parentUIControl, string linkNameCollection, string linkUrlsCollection, string sectionOrPageName, bool logWarningIfFail = false, bool continueOnFail = false)
        {
            // Validate Links Collection in the Section
            if (!string.IsNullOrEmpty(linkNameCollection))
            {
                string[] linksList = linkNameCollection.Split(';');
                string[] linkUrlsList = linkUrlsCollection.Split(';');
                ValidateLinksAvailablity(parentUIControl, linksList, linkUrlsList, sectionOrPageName, logWarningIfFail, continueOnFail);
            }
        }

        /// <summary>
        /// Validate all the links within a section
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateLinkCollectionNavigation(By locator)
        {
            IWebElement parentSection = FindElement(locator);
            if (IsWebElementDisplayed(parentSection, "Links List"))
            {
                IReadOnlyList<IWebElement> linksList = parentSection.FindElements(By.TagName("A"));
                if (linksList.Count != 0)
                {
                    for (int i = 0; i < linksList.Count; i++)
                    {
                        try
                        {
                            parentSection = FindElement(locator);
                            linksList = parentSection.FindElements(By.TagName("A"));
                            if (!linksList[i].Text.Equals(""))
                            {
                                ValidateLinkNavigation(parentSection, linksList[i].Text, "Dynamic");
                            }
                        }
                        catch (Exception e)
                        {
                            frameworkLibrary.UpdateTestLog("Error", "Exception in ValidateLinkCollectionNavigation - " + e.Message, Status.FAIL);
                            throw;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Validate Link is displayed, and it's url value
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentUIControl">Parent Section</param>
        /// <param name="linksList">Link List</param>
        /// <param name="linkUrlsList">Link URLs List</param>
        /// <param name="sectionOrPageName">Section Name</param>
        public void ValidateLinksAvailablity(IWebElement parentUIControl, string[] linksList, string[] linkUrlsList, string sectionOrPageName, bool logWarningIfFail = false, bool continueOnFail = false)
        {
            Status failStatus = Status.FAIL;
            if (logWarningIfFail)
            {
                failStatus = Status.WARNING;
            }

            // Iterate Link Validation for the provided links collection
            for (int i = 0; i < linksList.Length; i++)
            {
                string currentLinkName = linksList[i];
                string currentLinkUrl = FrameworkLibrary.GetArrayIndexValue(linkUrlsList, i);
                IWebElement linkUIControl = parentUIControl.FindElement(By.LinkText(currentLinkName));
                if (linkUIControl.Displayed)
                {
                    frameworkLibrary.UpdateTestLog("Link", "Link (" + currentLinkName + ") is available", Status.PASS);
                    // Validate Link Url
                    ValidateHrefAttribute(linkUIControl, currentLinkUrl, false);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Link", "Link (" + currentLinkName + ") is not available", failStatus, continueOnFail);
                }
            }
        }

        /// <summary>
        /// Get all Children elements of a specific element as a Collection
        /// </summary>
        /// <param name="uiTestControl"></param>
        /// <returns>UI Test Control as List Collection</returns>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public ReadOnlyCollection<IWebElement> GetAllChildren(IWebElement uiTestControl, By locator)
        {
            ReadOnlyCollection<IWebElement> childElementsList = uiTestControl.FindElements(locator);
            return childElementsList;
        }

        /// <summary>
        /// Validate Links Collection
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateDynamicLinkCollection(IWebElement parentSection, int startLink = 0, int endLink = 0, bool logNotAvailableFail = true)
        {
            LinksValidation linksValidation = new LinksValidation(parentSection);
            linksValidation.startLink = startLink;
            linksValidation.endLink = endLink;
            linksValidation.ValidateAllLinksInParentSection(parentSection, logNotAvailableFail);
        }

        /// <summary>
        /// Click Link Control
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="linkControl">Link Control</param>
        public bool ClickTestControls(IWebElement uiTestControl, string controlType)
        {
            IWebElement testControl = uiTestControl;

            // Check for Link Control Exist in the Page
            if (testControl.Enabled)
            {
                MouseClick(testControl, controlType);
                if (!string.IsNullOrEmpty(controlType))
                {
                    frameworkLibrary.UpdateTestLog("ClickControl", controlType + " is clicked successfully", Status.DONE);
                }
                frameworkLibrary.WaitTillPageLoaded();
                return true;
            }
            else
            {
                if (!string.IsNullOrEmpty(controlType))
                {
                    frameworkLibrary.UpdateTestLog("ClickControl", controlType + " is not available in the page", Status.FAIL);
                }
                return false;
            }
        }

        /// <summary>
        /// Click UI Control by using Mouse Operations
        /// </summary>
        /// <param name="uIControl">UI Control</param>
        /// <param name="controlDesc">Control Description</param>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void MouseClick(dynamic uIControl, string controlDesc, bool continueOnError = false, bool enableWait = true)
        {
            try
            {
                IWebElement webElement = uIControl;
                Actions action = new Actions(driver);
                action.Click(webElement).Perform();
                if (enableWait)
                {
                    frameworkLibrary.WaitTillPageLoaded();
                }
            }
            catch (NoSuchElementException)
            {
                if (string.IsNullOrEmpty(controlDesc))
                { throw; }
                frameworkLibrary.UpdateTestLog("MouseClick", controlDesc + " is not available in the page", Status.FAIL, continueOnError);
            }
            catch (Exception e)
            {
                frameworkLibrary.UpdateTestLog("Error", "Exception in MouseClick - " + e.Message, Status.FAIL);
                frameworkLibrary.WrapUpTestExecution(UnitTestOutcome.Failed);
                throw;
            }
        }

        /// <summary>
        /// Validate Link Href Url Value
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="linkControl">Link Control</param>
        /// <param name="expectedUrlValue">Expected Url Value</param>
        /// <param name="performCompleteMatch">Compare Method</param>
        public void ValidateHrefAttribute(IWebElement linkControl, string expectedUrlValue, bool performCompleteMatch = false)
        {
            string linkText = linkControl.Text;
            if (string.IsNullOrEmpty(expectedUrlValue))
            {
                return;
            }
            bool urlMatched = false;
            // Get the Href Property for the provided Link
            string actualUrlValue = linkControl.GetAttribute("Href").ToString();
            actualUrlValue = actualUrlValue.TrimEnd('/').Replace("http://", "").Replace("https://", "");
            expectedUrlValue = expectedUrlValue.TrimEnd('/').Replace("http://", "").Replace("https://", "");
            if (performCompleteMatch)
            {
                if (expectedUrlValue.Equals(actualUrlValue, StringComparison.CurrentCultureIgnoreCase))
                {
                    urlMatched = true;
                }
            }
            else
            {
                if (actualUrlValue.Contains(expectedUrlValue) || expectedUrlValue.Contains(actualUrlValue))
                {
                    urlMatched = true;
                }
            }
            if (urlMatched)
            {
                frameworkLibrary.UpdateTestLog("HrefURL", "Link(" + linkText + ") URL is matched with Expected Url, Page Url: " + actualUrlValue, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("HrefURL", "Link(" + linkText + ") URL is not matched with Expected Url, Page Url: " + actualUrlValue + " Expected URL: " + expectedUrlValue, Status.FAIL, true);
            }
        }

        #region LinksValidation_Class
        /// <summary>
        /// Validate Links  - Link Navigation, Links Availablity
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public class LinksValidation
        {
            // General Properties
            public IWebElement parentSection;
            IWebElement linkControlUI;
            public static IWebDriver driver = RunConfiguration.driver;
            FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
            DriverAppUtilLibrary applicationUtilLibrary = new DriverAppUtilLibrary(RunConfiguration.driver);
            public int totalLinks = 0;
            public int startLink = 1, endLink = 0;

            // Links List Properties
            string[] linkList, linkNavigationWinTypeList, linkUrlsList, linkUrlsValidationTypeList, pageHeaderList;

            // Individual Link Property For Each Operation
            public string linkName, pageUrl, pageHeader, parentPageUrl, actualLinkHrefUrl;
            public string windowMode;
            bool hrefValidationRequired = true, pageUrlValidationRequired = false;
            public bool navigateBackIfSameWindow = true, closeWindowIfNewWindow = true, clickFirstTabIfNewWindow = false;
            public bool popupIsOpened = false;

            // Constructor
            public LinksValidation(IWebElement parentSection)
            {
                if (parentSection != null)
                {
                    this.parentSection = parentSection;
                }
            }

            /// <summary>
            /// Initialize Links Collection
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public void InitializeLinksCollection(string linkNameCollection, string linkNavWindowTypeCollection, string pageUrlCollection, string pageUrlValTypeCollection, string pageHeaderCollection)
            {
                linkList = linkNameCollection.Split(';');
                totalLinks = linkList.Length;
                linkNavigationWinTypeList = linkNavWindowTypeCollection.Split(';');
                linkUrlsList = pageUrlCollection.Split(';');
                linkUrlsValidationTypeList = pageUrlValTypeCollection.Split(';');
                pageHeaderList = pageHeaderCollection.Split(';');
            }

            /// <summary>
            /// Generate Link Description
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public string GenerateLinkDescription(IWebElement linkControl)
            {
                string linkDesc = linkControl.Text.Trim();
                if (string.IsNullOrEmpty(linkDesc))
                {
                    if (linkControl.GetAttribute("Href").Contains("#"))
                    {
                        linkDesc = linkControl.GetAttribute("Href").Split('#')[1];
                    }
                    else if (!string.IsNullOrEmpty(linkControl.Text))
                    {
                        linkDesc = linkControl.Text.Trim();
                    }
                    else
                    {
                        linkDesc = "Link";
                    }
                }
                return linkDesc;
            }

            /// <summary>
            /// Initialize Link Properties
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            /// <param name="iterationIndex">Iteration Index</param>
            /// <returns></returns>
            public bool InitializeIndividualLinkProperties(int iterationIndex)
            {
                try
                {
                    linkName = linkList[iterationIndex];
                    windowMode = FrameworkLibrary.GetArrayIndexValue(linkNavigationWinTypeList, iterationIndex);
                    pageUrl = FrameworkLibrary.GetArrayIndexValue(linkUrlsList, iterationIndex);
                    pageHeader = FrameworkLibrary.GetArrayIndexValue(pageHeaderList, iterationIndex);
                }
                catch (Exception)
                {
                    linkName = "";
                    return false;
                }
                return true;
            }

            /// <summary>
            /// Initialize Link Property from Other sources
            /// </summary>
            /// <param name="linkName">Link Name</param>
            /// <param name="windowMode">Window Mode</param>
            /// <param name="pageUrl">Page Url</param>
            /// <param name="pageHeader">Page Header</param>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public void InitializeIndividualLinkProperties(string linkName, string windowMode, string pageUrl, string pageHeader)
            {
                this.linkName = linkName;
                this.windowMode = windowMode;
                this.pageUrl = pageUrl;
                this.pageHeader = pageHeader;
                if (!String.IsNullOrEmpty(pageUrl))
                {
                    pageUrlValidationRequired = true;
                }
            }

            /// <summary>
            /// Validate All the visible links in the Section
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public void ValidateAllLinksInParentSection(IWebElement parentSection, bool logNotAvailableFail = true, String test = "")
            {
                Dictionary<int, IWebElement> linksCollection = new Dictionary<int, IWebElement>();
                Dictionary<int, string> linksDescCollection = new Dictionary<int, string>();
                int length = 20;
                foreach (IWebElement eachLink in parentSection.FindElements(By.TagName("A")))
                {
                    if (eachLink != null)
                    {
                        linksCollection.Add(++length, eachLink);
                        linksDescCollection.Add(length, GenerateLinkDescription(eachLink));
                    }
                }

                // Get the parent page URL
                parentPageUrl = RunConfiguration.driver.Url.ToString();
                foreach (int keyValue in linksCollection.Keys)
                {
                    linkName = linksDescCollection[keyValue];
                    linkControlUI = linksCollection[keyValue];
                    frameworkLibrary.WaitTillPageLoaded();
                    if (!logNotAvailableFail)
                    {
                        if (linkControlUI.Displayed)
                        {
                            ValidateDynamicLinkNavigation();
                        }
                    }
                    else
                    {
                        ValidateDynamicLinkNavigation();
                    }
                }
            }

            /// <summary>
            /// Validate All the visible links in the Section
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public void ValidateAllLinksInParentSection(IWebElement parentSection, bool logNotAvailableFail = true)
            {
                Dictionary<int, IWebElement> linksCollection = new Dictionary<int, IWebElement>();
                Dictionary<int, string> linksDescCollection = new Dictionary<int, string>();
                parentPageUrl = RunConfiguration.driver.Url.ToString();
                IReadOnlyList<IWebElement> linksList = parentSection.FindElements(By.TagName("A"));

                // Get all links in the parent section
                try
                {
                    for (int i = 0; i < linksList.Count; i++)
                    {
                        parentSection = this.parentSection;
                        IReadOnlyList<IWebElement> newLinksList = parentSection.FindElements(By.TagName("A"));
                        if (newLinksList != null)
                        {
                            IWebElement currentLink = newLinksList[i];
                            applicationUtilLibrary.ClickLink(currentLink, currentLink.Text);
                            frameworkLibrary.WaitTillPageLoaded(timeOut: 10);
                            if (!IsLinkOpenedInSameWindow(true))
                            {
                                RunConfiguration.driverBusinessLibrary.OpenUrl(parentPageUrl);
                                frameworkLibrary.WaitTillPageLoaded();
                            }
                        }
                    }
                }

                catch (StaleElementReferenceException e)
                {
                    frameworkLibrary.UpdateTestLog("Error", "Exception in ValidateAllLinksInParentSection - " + e.Message, Status.WARNING, true);
                    throw;
                }
            }
            #endregion
            /// <summary>
            /// Validate Dynamic Link Navigation
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            private void ValidateDynamicLinkNavigation()
            {
                bool linkOpenedInNewWin = false;
                bool linkOpenedInSameWin = false;
                bool checkPageLoadError = false;
                popupIsOpened = false;
                string parentWindow = RunConfiguration.driver.CurrentWindowHandle;
                List<string> childWindows = RunConfiguration.driver.WindowHandles.ToList();
                int noOfWindowsBeforeClickingLink = childWindows.Count;
                string navigatedPageUrl = "";

                try
                {
                    // Click the Link
                    linkControlUI = applicationUtilLibrary.FindElement(By.LinkText(linkName), linkName, parentSection);
                    applicationUtilLibrary.ClickLink(linkControlUI, linkName);
                    frameworkLibrary.WaitTillPageLoaded(timeOut: 5);

                    // Check any Leaving Humana Popup is displayed
                    AcceptLeavingHumanaPopup();
                    if (CheckNewTabOpened(noOfWindowsBeforeClickingLink))
                    {
                        linkOpenedInNewWin = true;
                    }
                    else
                    {
                        frameworkLibrary.WaitTillPageLoaded(timeOut: 5);
                        if (CheckNewTabOpened(noOfWindowsBeforeClickingLink))
                        {
                            linkOpenedInNewWin = true;
                        }
                        else
                        {
                            // Validate link navigation in same window
                            linkOpenedInNewWin = false;

                            try
                            {
                                // Get the Navigated Page URL
                                navigatedPageUrl = RunConfiguration.driver.Url.ToString();
                            }
                            catch (Exception)
                            {
                                frameworkLibrary.WaitTillPageLoaded();
                                navigatedPageUrl = RunConfiguration.driver.Url.ToString();
                            }
                            if (!navigatedPageUrl.Equals(parentPageUrl))
                            {
                                frameworkLibrary.UpdateTestLog("LinkNavigation", "Link(" + linkName + ") is navigated to target page in the Same Window", Status.PASS);

                                // Validate Page URL
                                if (pageUrlValidationRequired)
                                {
                                    applicationUtilLibrary.ValidatePageUrl(pageUrl);
                                }
                                frameworkLibrary.WaitTillPageLoaded();
                                if (checkPageLoadError)
                                {
                                    if (!RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors("Link(" + linkName + ") Navigation"))
                                    {
                                        frameworkLibrary.UpdateTestLog("PageError", "No Page Load Error Was Thrown for Link: " + linkName, Status.PASS);
                                    }
                                }
                                // Validate Page Header
                                if (!string.IsNullOrEmpty(pageHeader))
                                {
                                    applicationUtilLibrary.ValidatePageHeaderByDynamicHeaderTag(null, pageHeader);
                                }

                                // Navigate to Parent Page
                                if (navigateBackIfSameWindow)
                                {
                                    RunConfiguration.driverBusinessLibrary.OpenUrl(parentPageUrl);
                                    frameworkLibrary.WaitTillPageLoaded(2);
                                }
                                linkOpenedInSameWin = true;
                            }
                        }
                    }
                    // Get the BrowserWindow of the link navigation Page, and close the browser
                    if (closeWindowIfNewWindow && linkOpenedInNewWin)
                    {
                        bool closedSuccessfully = false;
                        try
                        {
                            //Switch to the desired window first and then execute commands using driver
                            string lastWindowHandle = RunConfiguration.driver.WindowHandles.Last();
                            RunConfiguration.driver.SwitchTo().Window(lastWindowHandle);

                            // Validate Page URL
                            if (pageUrlValidationRequired)
                            {
                                applicationUtilLibrary.ValidatePageUrl(pageUrl);
                            }
                            if (checkPageLoadError)
                            {
                                RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors("Link(" + linkName + ") Navigated", continueOnFail: true);
                            }
                            // Validate Page Header
                            if (!string.IsNullOrEmpty(pageHeader))
                            {
                                frameworkLibrary.WaitTillPageLoaded();
                                applicationUtilLibrary.ValidatePageHeaderByDynamicHeaderTag(null, pageHeader);
                            }
                            // Switch to the parent window
                            RunConfiguration.driver.Close();
                            RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
                            RunConfiguration.driver.SwitchTo().Window(parentWindow);
                            RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
                            closedSuccessfully = true;
                            frameworkLibrary.UpdateTestLog("LinkNavigation", "Link(" + linkName + ") Navigated page is closed successfully", Status.PASS);
                        }
                        catch (Exception e)
                        {
                            frameworkLibrary.UpdateTestLog("Error", "Debug Info - " + e.Message, Status.FAIL);
                        }

                        if (!closedSuccessfully || clickFirstTabIfNewWindow)
                        {
                            //Switch to the parent window
                            RunConfiguration.driver.SwitchTo().Window(parentWindow);
                        }
                        if (!linkOpenedInNewWin)
                        {
                            frameworkLibrary.UpdateTestLog("LinkNavigation", linkName + " is not opened in new window after clicking Continue Popup", Status.FAIL);
                        }
                    }
                }
                catch (Exception e)
                {
                    RunConfiguration.driverBusinessLibrary.OpenUrl(parentPageUrl);
                    throw e;
                }
                frameworkLibrary.WaitTillPageLoaded();
            }

            /// <summary>
            /// Validate Link Collection Navigation
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public void ValidateLinkCollectionNavigation()
            {
                // Validate Link Collections Navigation - New/Same Window
                for (int i = 0; i < linkList.Length; i++)
                {
                    // Initialize Link Properties
                    InitializeIndividualLinkProperties(i);
                    // Validate Individual Link Navigation
                    ValidateLinkNavigation();
                }
            }

            /// <summary>
            /// Validate Link Navigation - Single Link
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public void ValidateLinkNavigation()
            {
                // Wait Till Parent Section is exist in the Page
                popupIsOpened = false;
                parentPageUrl = RunConfiguration.driver.Url.ToString();
                frameworkLibrary.WaitTillPageLoaded();
                if (applicationUtilLibrary.IsWebElementDisplayed(parentSection, "Link Section"))
                {
                    // Validate Links Navigation - New/Same Window
                    if (windowMode.Equals("New", StringComparison.OrdinalIgnoreCase))
                    {
                        ValidateLinkNavigationToNewWindow();
                    }
                    else if (windowMode.Equals("Same", StringComparison.OrdinalIgnoreCase))
                    {
                        navigateBackIfSameWindow = true;
                        ValidateLinkNavigationToSameWindow();
                    }
                    else if (windowMode.Equals("Yes", StringComparison.OrdinalIgnoreCase))
                    {
                        ValidateLinkIsAvailable();
                    }
                    else if (windowMode.Equals("Alert", StringComparison.OrdinalIgnoreCase))
                    {
                        //ValidateLinkNavigationToAlertPopup(); -TODO
                    }
                    else if (windowMode.Equals("Dynamic", StringComparison.OrdinalIgnoreCase))
                    {
                        ValidateDynamicLinkNavigation();
                    }
                    else if (windowMode.Equals("NA", StringComparison.OrdinalIgnoreCase))
                    {
                        applicationUtilLibrary.ClickLinkByName(linkName, parentSection);
                        RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors(linkName + " Link Navigated Page");
                    }
                    else
                    {
                        navigateBackIfSameWindow = false;
                        ValidateLinkNavigationToSameWindow();
                    }
                }
            }

            /// <summary>
            /// Validate Link Navigation to Same Window
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public void ValidateLinkNavigationToSameWindow()
            {
                // Find the Link Control
                linkControlUI = applicationUtilLibrary.FindElement(By.LinkText(linkName), linkName, parentSection);
                // Get the parent page URL
                parentPageUrl = RunConfiguration.driver.Url.ToString();

                // Click the Link
                applicationUtilLibrary.ClickLink(linkControlUI, linkName);
                RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3);

                // Validate Link is opend in Same Window
                if (!IsLinkOpenedInSameWindow(false))
                {
                    if (navigateBackIfSameWindow)
                    {
                        frameworkLibrary.UpdateTestLog("LinkNavigation", "Link(" + linkName + ") is not navigated to target page in the Same Window", Status.FAIL);
                    }
                    else
                    {
                        frameworkLibrary.UpdateTestLog("LinkNavigation", "Link(" + linkName + ") is performed operation in the same page", Status.DONE);
                    }
                }
            }

            /// <summary>
            /// Check the link is opened in Same window
            /// </summary>
            /// <param name="checkPageLoadError">Check for Page Load Error is required</param>
            /// <returns></returns>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public bool IsLinkOpenedInSameWindow(bool checkPageLoadError = false)
            {
                bool linkOpenedInSameWin = false;
                // Generic Leave Humana Popup
                AcceptLeavingHumanaPopup();

                // Leave Humana Medicare Popup         
                AcceptLeavingHumanaMedicarePopup();

                frameworkLibrary.WaitTillPageLoaded();
                string navigatedPageUrl = "";
                try
                {
                    // Get the Navigated Page URL
                    navigatedPageUrl = RunConfiguration.driver.Url.ToString();
                    Uri navigatedPageUri = new Uri(navigatedPageUrl);
                    navigatedPageUrl = navigatedPageUri.ToString();
                }
                catch (Exception)
                {
                    frameworkLibrary.WaitTillPageLoaded();
                    navigatedPageUrl = RunConfiguration.driver.Url.ToString();
                }
                if (!navigatedPageUrl.Equals(parentPageUrl))
                {
                    frameworkLibrary.UpdateTestLog("LinkNavigation", "Link(" + linkName + ") is navigated to target page in the Same Window", Status.PASS);

                    // Validate Page URL
                    if (pageUrlValidationRequired)
                    {
                        applicationUtilLibrary.ValidatePageUrl(pageUrl);
                    }
                    frameworkLibrary.WaitTillPageLoaded();
                    if (checkPageLoadError)
                    {
                        if (!RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors("Link(" + linkName + ") Navigation"))
                        {
                            frameworkLibrary.UpdateTestLog("PageError", "No Page Load Error Was Thrown for Link: " + linkName, Status.PASS);
                        }
                    }
                    // Validate Page Header
                    if (!string.IsNullOrEmpty(pageHeader))
                    {
                        applicationUtilLibrary.ValidatePageHeaderByDynamicHeaderTag(null, pageHeader);
                    }

                    // Navigate to Parent Page
                    if (navigateBackIfSameWindow)
                    {
                        RunConfiguration.driverBusinessLibrary.OpenUrl(parentPageUrl);
                        frameworkLibrary.WaitTillPageLoaded(2);
                    }
                    linkOpenedInSameWin = true;
                }
                return linkOpenedInSameWin;
            }

            /// <summary>
            /// Validate Link Navigation to New Window
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public void ValidateLinkNavigationToNewWindow()
            {
                linkControlUI = applicationUtilLibrary.FindElement(By.PartialLinkText(linkName), linkName, parentSection);
                if (!IsLinkOpenedInNewWindow(false, 500))
                {
                    RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors("Navigated Link - " + linkName);
                    frameworkLibrary.UpdateTestLog("LinkNavigation", "Link(" + linkName + ") is not opened in new window as expected", Status.FAIL);
                    return;
                }
            }

            /// <summary>
            /// Check the link is opend in new window
            /// </summary>
            /// <param name="checkPageLoadError">Check for Page Load Error</param>
            /// <returns></returns>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            private bool IsLinkOpenedInNewWindow(bool checkPageLoadError = false, int retryStaticTimeOut = 100)
            {
                bool linkOpenedInNewWin = false;
                popupIsOpened = false;
                string parentWindow = RunConfiguration.driver.CurrentWindowHandle;
                List<string> childWindows = RunConfiguration.driver.WindowHandles.ToList();
                int noOfWindowsBeforeClickingLink = childWindows.Count;

                // Click the Link
                linkControlUI = applicationUtilLibrary.FindElement(By.PartialLinkText(linkName), linkName, parentSection);
                applicationUtilLibrary.ClickLink(linkControlUI, linkName);
                frameworkLibrary.WaitTillPageLoaded(timeOut: 5);

                // Check any Leaving Humana Popup is displayed
                AcceptLeavingHumanaPopup();
                if (CheckNewTabOpened(noOfWindowsBeforeClickingLink))
                {
                    linkOpenedInNewWin = true;
                }
                else
                {
                    frameworkLibrary.WaitTillPageLoaded(timeOut: 5);
                    if (CheckNewTabOpened(noOfWindowsBeforeClickingLink))
                    {
                        linkOpenedInNewWin = true;
                    }
                    else
                    {
                        linkOpenedInNewWin = false;
                    }
                }
                // Get the BrowserWindow of the link navigation Page, and close the browser
                if (closeWindowIfNewWindow && linkOpenedInNewWin)
                {
                    bool closedSuccessfully = false;
                    try
                    {
                        //Switch to the desired window first and then execute commands using driver
                        string lastWindowHandle = driver.WindowHandles.Last();
                        RunConfiguration.driver.SwitchTo().Window(lastWindowHandle);

                        // Validate Page URL
                        if (pageUrlValidationRequired)
                        {
                            applicationUtilLibrary.ValidatePageUrl(pageUrl);
                        }
                        if (checkPageLoadError)
                        {
                            RunConfiguration.driverBusinessLibrary.CheckForPageLoadErrors("Link(" + linkName + ") Navigated", continueOnFail: true);
                        }
                        // Validate Page Header
                        if (!string.IsNullOrEmpty(pageHeader))
                        {
                            frameworkLibrary.WaitTillPageLoaded();
                            applicationUtilLibrary.ValidatePageHeaderByDynamicHeaderTag(null, pageHeader);
                        }
                        // Switch to the parent window
                        RunConfiguration.driver.Close();
                        driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
                        RunConfiguration.driver.SwitchTo().Window(parentWindow);
                        driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
                        closedSuccessfully = true;
                        frameworkLibrary.UpdateTestLog("LinkNavigation", "Link(" + linkName + ") Navigated page is closed successfully", Status.PASS);
                    }
                    catch (Exception e)
                    {
                        frameworkLibrary.UpdateTestLog("Error", "Debug Info - " + e.Message, Status.FAIL);
                    }

                    if (!closedSuccessfully)
                    {
                        //Switch to the parent window
                        RunConfiguration.driver.SwitchTo().Window(parentWindow);
                    }
                }
                if (clickFirstTabIfNewWindow)
                {
                    //Switch to the parent window
                    RunConfiguration.driver.SwitchTo().Window(parentWindow);
                }
                if (!linkOpenedInNewWin)
                {
                    frameworkLibrary.UpdateTestLog("LinkNavigation", linkName + " is not opened in new window after clicking Continue Popup", Status.FAIL);
                }
                return linkOpenedInNewWin;
            }

            /// <summary>
            /// Accept Leaving Humana Popup
            /// </summary>
            /// <returns></returns>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            private void AcceptLeavingHumanaPopup()
            {
                try
                {
                    IWebElement popupUi = driver.FindElement(By.CssSelector("div#disclaimer.modal"));
                    if (popupUi != null)
                    {
                        RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
                        IWebElement continueLink = popupUi.FindElement(By.LinkText("Continue"));
                        if (continueLink.Displayed)
                        {
                            applicationUtilLibrary.ClickLink(continueLink, "Leaving Humana Popup - Continue");
                        }
                    }
                }
                catch (Exception) { }
            }

            /// <summary>
            /// Accept Leaving Humana Medicare Popup
            /// </summary>
            /// <returns></returns>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            private void AcceptLeavingHumanaMedicarePopup()
            {
                try
                {
                    IWebElement popupUi = driver.FindElement(By.CssSelector("div#medicare-disclaimer-modal"));
                    if (popupUi != null)
                    {
                        RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
                        IWebElement continueLink = popupUi.FindElement(By.LinkText("Continue"));
                        if (continueLink.Displayed)
                        {
                            applicationUtilLibrary.ClickLink(continueLink, "Medicare Disclaimer Modal - Continue");
                        }
                    }
                }
                catch (Exception) { }
            }

            /// <summary>
            /// Check New window is opened or not
            /// </summary>
            /// <param name="noOfWindowsBeforeClickingLink">No of Windows before clicking Link</param>
            /// <returns>Boolean</returns>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            private bool CheckNewTabOpened(int noOfWindowsBeforeClickingLink)
            {
                List<string> childWindows = RunConfiguration.driver.WindowHandles.ToList();
                int noOfWindowsAfterClickingLink = childWindows.Count;
                if (noOfWindowsAfterClickingLink - noOfWindowsBeforeClickingLink == 1)
                {
                    frameworkLibrary.UpdateTestLog("LinkNavigation", "Link(" + linkName + ") is opened in new window successfully", Status.PASS);
                    return true;
                }
                else
                {
                    return false;
                }
            }

            /// <summary>
            /// Validate Href URL
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            private void ValidateHrefUrl()
            {
                if (applicationUtilLibrary.IsWebElementDisplayed(By.LinkText(linkName), linkName))
                {
                    try
                    {
                        actualLinkHrefUrl = linkControlUI.GetAttribute("Href").ToString();
                    }
                    catch (Exception)
                    {
                        actualLinkHrefUrl = "";
                    }
                    // Get the Link Control and Validate Href URL
                    if (hrefValidationRequired)
                    {
                        applicationUtilLibrary.ValidateHrefAttribute(linkControlUI, pageUrl, false);
                    }
                }
            }

            /// <summary>
            /// Validate Link is available
            /// </summary>
            /// <author>RXK4098 - Ramesh Kandasamy</author>
            public void ValidateLinkIsAvailable()
            {
                // Find the Link Control
                By link = By.LinkText(linkName);
                applicationUtilLibrary.IsWebElementDisplayed(link, "Link(" + linkName + ")", parentSection);
            }
        }


        /// <summary>
        /// Validate Link is displayed in the Page
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent Control</param>
        /// <param name="linkName">Link Name</param>
        public void ValidateLinkIsDisplayed(string linkName, dynamic parentControl = null, string childLink = null)
        {
            IWebElement linkControl = null;
            By byLink;
            try
            {
                if (childLink == null)
                {
                    byLink = By.XPath("//a[text()='" + linkName + "']");
                }
                else
                {
                    byLink = By.XPath("//a/" + childLink + "[text()='" + linkName + "']");
                }
                ExplicitWaitForElement(byLink, 6);
                linkControl = FindElement(byLink, "Link Text(" + linkName + ")", parentControl);
                frameworkLibrary.UpdateTestLog(linkName + " element is found", linkName + " element is found", Status.PASS);
            }
            catch
            {
                frameworkLibrary.UpdateTestLog(linkName + " element is not found", linkName + " element is not found", Status.FAIL);
            }


            // Check for Link Control Exist in the Page
            if (linkControl.Displayed || linkControl.Enabled)
            {

                frameworkLibrary.UpdateTestLog("LinkAvailable", "Link(" + linkName + ") is displayed in the Page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("LinkAvailable", "Link(" + linkName + ") is not available in the page", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate Link is displayed in the Page
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent Control</param>
        /// <param name="linkName">Link Name</param>
        public void ValidatePartialLinkIsDisplayed(string linkName, dynamic parentControl = null, string childLink = null)
        {
            IWebElement linkControl = null;
            By byLink;
            try
            {
                if (childLink == null)
                {
                    byLink = By.XPath("//a[contains(.,'" + linkName + "')]");
                }
                else
                {
                    byLink = By.XPath("//a/" + childLink + "[contains(.,'" + linkName + "')]");
                }
                linkControl = FindElement(byLink, "Link Text(" + linkName + ")", parentControl);
                frameworkLibrary.UpdateTestLog("Link Available ", "Element (" + linkName + ") is found", Status.PASS);
            }
            catch
            {
                frameworkLibrary.UpdateTestLog("Link Available", "Element (" + linkName + ") is not found", Status.FAIL);
            }


            // Check for Link Control Exist in the Page
            if (linkControl.Displayed)
            {

                frameworkLibrary.UpdateTestLog("Link Available", "Link(" + linkName + ") is displayed in the Page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Link Available", "Link(" + linkName + ") is not available in the page", Status.FAIL);
            }
        }


        /// <summary>
        /// Validate Link is displayed in the Page
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent Control</param>
        /// <param name="linkName">Link Name</param>
        public void ValidateLinkIsNotDisplayed(dynamic parentControl, string linkName)
        {
            IWebElement linkControl = FindElement(By.LinkText(linkName), "Link Text(" + linkName + ")", parentControl);
            // Check for Link Control doesn't Exist in the Page
            if (!(UIControlIsDisplayed(linkControl)))
            {
                frameworkLibrary.UpdateTestLog("LinkAvailable", "Link(" + linkName + ") is not available in the Page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("LinkAvailable", "Link(" + linkName + ") is available in the page", Status.FAIL);
            }
        }


        /// <summary>
        /// Validate Page Header by header name/ partial inner text
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentControl">Parent UI Control</param>
        /// <param name="headerName">Partial Header Name</param>
        /// <param name="headerTag">Header Tag</param>
        /// <param name="usePageLoadTimeOut">Wait For Page load if it's true</param>
        public void ValidatePageHeaderByPartialName(dynamic parentControl, string headerName, string headerTag = "H1", bool usePageLoadTimeOut = true, bool continueOnFail = false)
        {
            int pageLoadTimeOut = 1;
            if (usePageLoadTimeOut)
            {
                pageLoadTimeOut = RunConfiguration.pageLoadTimeOut;
            }
            // Check for Link Control Exist in the Page
            IWebElement labelElement = FindElement(By.XPath("//" + headerTag + "[contains(., '" + headerName + "')]"), parentElement: parentControl);
            if (null != labelElement)
            {
                frameworkLibrary.UpdateTestLog("Header", labelElement.Text + " is displayed in the Page", Status.PASS);
            }
            else
            {
                // Check for page Load error if any

                driverBusinessLibrary.CheckForPageLoadErrors(headerName);
                frameworkLibrary.UpdateTestLog("Header", "Page Header - " + headerName + " is not displayed in the Page", Status.FAIL, continueOnFail);
            }
        }

        /// <summary>
        /// Click Link Control by using the Locators as input parameter
        /// </summary>
        /// <author>KXS9441 - Kalaiyarasan Sivaprakasam</author>
        public bool ClickByXPath(string webElement, dynamic parentControl = null, string elementDesc = "", string typeOfLocator = "", string childTagIfPresent = "")
        {
            By linkControl = null;
            IWebElement linkElement = null;
            if (typeOfLocator.Equals("id"))
            {
                linkControl = By.XPath(".//*[@" + typeOfLocator + "='" + webElement + "']");
            }
            if (typeOfLocator.Equals("name"))
            {
                linkControl = By.XPath(".//*[@" + typeOfLocator + "='" + webElement + "']");
            }

            if (typeOfLocator.Equals("class"))
            {
                linkControl = By.XPath(".//*[@" + typeOfLocator + "='" + webElement + "']");
            }

            if (typeOfLocator.Equals("href"))
            {
                linkControl = By.XPath(".//*[@" + typeOfLocator + "='" + webElement + "']");
            }
            if (typeOfLocator.Equals("text"))
            {
                linkControl = By.XPath(".//*[" + typeOfLocator + "()='" + webElement + "']");
            }

            if (!string.IsNullOrEmpty(childTagIfPresent))
            {
                linkElement = FindElement(By.XPath(".//" + childTagIfPresent + "[.='" + webElement + "']/.."), " Button", parentControl);
            }
            else
            {
                linkElement = FindElement(linkControl, elementDesc, parentControl);
            }

            if (linkElement != null)
            {
                linkElement.Click();
                frameworkLibrary.UpdateTestLog("Page Navigation", "WebElement(" + webElement + ") is clicked successfully", Status.PASS);
                return true;
            }
            else
            {
                if (string.IsNullOrEmpty(elementDesc))
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", "WebElement(" + webElement + ") is not available in the page", Status.FAIL);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Page Navigation", elementDesc + " - WebElement(" + webElement + ") is not available in the page", Status.FAIL);
                }
                return false;
            }

        }

        /// <summary>
        /// Validate UI Control is displayed in the Page
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="uIControl">UI Control</param>
        /// <returns></returns>
        public bool UIControlIsDisplayed(dynamic uIControl, bool acceptBlockedControl = false)
        {
            bool controlDisplayed = false;
            try
            {
                if (uIControl.WaitForControlExist(300))
                {
                    // Ensure the element is clickable - Scroll to the Element if displayed
                    uIControl.EnsureClickable();
                    controlDisplayed = true;
                }
            }
            catch (Exception)
            {
            }
            return controlDisplayed;
        }


        /// <summary>
        /// Validate UI Control is displayed in the Page
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="uIControl">UI Control</param>
        /// <returns></returns>
        public bool UIControlIsNotDisplayed(dynamic uIControl, bool acceptBlockedControl = false)
        {
            bool controlDisplayed = false;
            try
            {
                {
                    // Ensure the element is clickable - Scroll to the Element if displayed
                    uIControl.EnsureClickable();
                    controlDisplayed = true;
                }
            }
            catch (Exception)
            {
            }
            return controlDisplayed;
        }

        /// <summary>
        /// Validate Link Navigation to New Popup Modal
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateLinkNavigationToPopupModal(dynamic parentControl, string linkName, string cssSelectorToFind, string popupHeader)
        {
            try
            {
                // Click the Link
                IWebElement linkControlUI = FindElement(By.LinkText(linkName), linkName, parentControl);
                ClickLink(linkControlUI, linkName);

                // Wait for popup 
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                IWebElement popup = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(cssSelectorToFind)));


                // Validate the popup
                if (popup != null)
                {
                    IWebElement popuUpHeading = popup.FindElement(By.TagName("H2"));
                    IsWebElementDisplayed(popuUpHeading, popupHeader + " Modal");
                    IWebElement cancelLink = popup.FindElement(By.LinkText("Cancel"));
                    if (IsWebElementDisplayed(cancelLink, "Cancel Link in Modal"))
                    {
                        ClickLink(cancelLink, cancelLink.Text);
                    }
                }
            }
            catch (Exception e)
            {
                frameworkLibrary.UpdateTestLog("Error", "Exception in ValidateLinkNavigationToPopupModal - " + e.Message, Status.FAIL, true);
            }
        }

        /// <summary>
        /// Click Link/Button using partial text
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="Parent Tagname">TagName</param>
        /// <param name="Child TagName"ChildTagname ></param>
        public void ClickLinkandButtonUsingContains(string parentTag, string containsText, string header, string childTag = null, bool headerContains = false, IWebElement parentElement = null, string headerTag = "h1")
        {
            if (childTag == null)
            {
                try
                {
                    IWebElement element = FindElement(By.XPath("//" + parentTag + "[contains(.,'" + containsText + "')]"));
                    ClickLink(element, containsText + " is present");
                    ValidatePageHeaderByName(header, parentElement, headerTag, headerContains);
                }
                catch
                {
                    frameworkLibrary.UpdateTestLog("WebElement", "WebElement" + header + " is not present", Status.FAIL);
                }
            }
            else
            {
                try
                {
                    IWebElement registerElement = FindElement(By.XPath("//" + parentTag + "/" + childTag + "[contains(.,'" + containsText + "')]"));
                    ClickLink(registerElement, registerElement + "is present");
                    ValidatePageHeaderByName(header, parentElement, headerTag, headerContains);
                }
                catch
                {
                    frameworkLibrary.UpdateTestLog("Element", "WebElement" + header + " is not present", Status.FAIL);
                }
            }
        }

        /// <summary>
        /// Click Link using contains method
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="Parent Tagname">TagName</param>
        /// <param name="Child TagName"ChildTagname ></param>
        public void ClickLinkUsingInnerText(string parentTag, string containsText, string header, string childTag = null, bool headerContains = false, IWebElement parentElement = null, string headerTag = "h1")
        {
            if (childTag == null)
            {
                try
                {
                    IWebElement element = FindElement(By.XPath("//" + parentTag + "[contains(text(),'" + containsText + "')]"));
                    ClickLink(element, containsText);
                    ValidatePageHeaderByName(header, parentElement, headerTag, headerContains);
                }
                catch
                {
                    frameworkLibrary.UpdateTestLog("Link", "Link " + containsText + " is not present", Status.FAIL);
                }
            }
            else
            {
                try
                {
                    IWebElement element = FindElement(By.XPath("//" + parentTag + "/" + childTag + "[contains(text(),'" + containsText + "')]"));
                    ClickLink(element, element.Text);
                    ValidatePageHeaderByName(header, parentElement, headerTag, headerContains);
                }
                catch
                {
                    frameworkLibrary.UpdateTestLog("Link", "Link is not present", Status.FAIL);
                }
            }
        }

        /// <summary>
        /// Check element is present in drop down
        /// </summary>
        /// <author>KXK1653 - Karthik Kannathasan</author>
        /// <param name="tagName">Tag Name</param>
        /// <param name="parentControl">Parent Section</param>
        public void ValidateElementIsPresentInDropdown(IWebElement parentElement, string tagName, string[] containsElement)
        {
            IList<IWebElement> allItems = parentElement.FindElements(By.TagName(tagName));
            int i = 0;
            foreach (IWebElement eachItem in allItems)
            {
                string itemValue = eachItem.Text;
                if (itemValue.Contains(containsElement[i]))
                {
                    frameworkLibrary.UpdateTestLog("DropDownList", containsElement[i] + " option is available in the drop down list", Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("DropDownList", containsElement[i] + " option is not available in the drop down list", Status.FAIL);
                }
                i++;
            }
        }

        /// <summary>
        /// Press Tab Key
        /// </summary>
        /// <param name="name"></param>
        /// <author>SXS2929 Selvakumar Srinivasan</author>
        public void EnterTabName(string name)
        {
            IWebElement textboxElement = FindElement(By.Name(name));

            if (textboxElement.Displayed || textboxElement.Enabled)
            {
                textboxElement.SendKeys(Keys.Tab);
            }
        }


        /// <summary>
        /// Validate Link is not displayed in the Page
        /// </summary>
        /// <author>SXS2929 - Selvakumar Srinivasan</author>
        /// <param name="parentControl">Parent Control</param>
        /// <param name="linkName">Link Name</param>
        public void VerifyLinkIsNotDisplayed(string linkName)
        {
            IWebElement linkControl = FindElement(By.XPath("//a[contains(text(), '" + linkName + "')]"));
            // Check for Link Control doesn't Exist in the Page
            if (!(UIControlIsDisplayed(linkControl)))
            {
                frameworkLibrary.UpdateTestLog("LinkAvailable", "Link(" + linkName + ") is not available in the Page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("LinkAvailable", "Link(" + linkName + ") is available in the page", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate Link in MegaNavigation
        /// </summary>
        /// <param name="parentLink"></param>
        /// <param name="childLink"></param>
        /// <author>SXS2929 - SelvaKumar Srinivasan</author>
        public void ValidateLinkInMegaNavigation(string parentLink, string childLinks)
        {
            IWebElement parentLinkElement = FindElement(By.LinkText(parentLink), "Parent Link(" + parentLink + ")");
            ValidatePartialLinkIsDisplayed(parentLink);

            ClickLinkByPartialName(parentLink);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
            string[] ChildLinks = childLinks.Split(':');

            foreach (string ChildLink in ChildLinks)
            {
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
                ValidatePartialLinkIsDisplayed(ChildLink);
            }
        }

        public void scrollUpDown(By locator)
        {
            IWebElement s = driver.FindElement(locator);
            IJavaScriptExecutor je = (IJavaScriptExecutor)driver;
            je.ExecuteScript("arguments[0].scrollIntoView(false);", s);

        }

    }
}
