﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace ReusableLibrary
{   
    /// <summary>
    /// Class to Hold Column Names of TestResults table 
    /// <author>RXK4098 - Ramesh Kandasamy</author>
    /// </summary>
    public class CTestResults
    {
        public const string TESTRUN_ID = "AssetID";
        public const string BATCHRUN_ID = "BATCHRUN_ID";
        public const string ITERATIONGROUPING_ID = "ITERATIONGROUPING_ID";
        public const string FUNCTIONAL_TC_NAME = "FUNCTIONAL_TC_NAME";
        public const string WORKSTREAM = "WORKSTREAM";
        public const string RUN_CATEGORY = "RUN_CATEGORY";
        public const string TESTCASE_CATEGORY = "TESTCASE_CATEGORY";
        public const string CODEDUI_TEST_NAME = "CODEDUI_TEST_NAME";
        public const string CODEDUI_TEST_DESCRIPTIPON = "CODEDUI_TEST_DESCRIPTIPON";
        public const string TEST_RESULT = "TEST_RESULT";
        public const string ISSUE_TYPE = "ISSUE_TYPE";
        public const string TEST_ITERATION = "TEST_ITERATION";
        public const string TEST_STARTTIME = "TEST_STARTTIME";
        public const string TEST_ENDTIME = "TEST_ENDTIME";
        public const string TEST_DURATION = "TEST_DURATION";
        public const string LASTUPDATE_TIMESTAMP = "LASTUPDATE_TIMESTAMP";
        public const string FUNCTIONAL_DESC = "FUNCTIONAL_DESC";
        public const string COMMENTS = "COMMENTS";
        public const string ENVIRONMENT = "ENVIRONMENT";
        public const string FUNCTIONALITY_IMPACTED = "FUNCTIONALITY_IMPACTED";
        public const string RELEASE_NAME = "RELEASE_NAME";
        public const string TEST_DATA_TYPE = "TEST_DATA_TYPE";
        public const string TEST_DATA_CATEGORY = "TEST_DATA_CATEGORY";

    }

    /// <summary>
    /// Class to Hold Values from TestResults table 
    /// </summary>
    public class TestResults
    {
        public string TESTRUN_ID = "";
        public string BATCHRUN_ID = "";
        public string ITERATIONGROUPING_ID = "";
        public string FUNCTIONAL_TC_NAME = "";
        public string WORKSTREAM = "";
        public string RUN_CATEGORY = "REGRESSION"; //Defaulted - will be updated in Run-Time 
        public string TESTCASE_CATEGORY = "REGRESSION";
        public string CODEDUI_TEST_NAME = "";
        public string CODEDUI_TEST_DESCRIPTIPON = "";
        public string TEST_RESULT = "RUNINTERRUPTED";
        public string ISSUE_TYPE = "";
        public int TEST_ITERATION = 0;
        public string TEST_STARTTIME = "CURRENT_TIMESTAMP";
        public string TEST_ENDTIME = "CURRENT_TIMESTAMP";
        public string TEST_DURATION = "DATEDIFF(SS,TEST_STARTTIME, TEST_ENDTIME)";
        public string LASTUPDATE_TIMESTAMP = "CURRENT_TIMESTAMP";
        public string FUNCTIONAL_DESC = RunConfiguration.testCaseContext.namespaceOfTestMethod[0];
        public string COMMENTS = "";
        public string ENVIRONMENT = "";
        public string FUNCTIONALITY_IMPACTED = "";
        public string RELEASE_NAME = "";
        public string TEST_DATA_TYPE = "";
        public string TEST_DATA_CATEGORY = "";

        /// <summary>
        ///  MEthod to replace ' with '' to avoid SQL trunctation 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void FormatValuesForSQL()
        {
            FUNCTIONAL_TC_NAME = FUNCTIONAL_TC_NAME.Replace("'", "''");
            CODEDUI_TEST_NAME = CODEDUI_TEST_NAME.Replace("'", "''");
            CODEDUI_TEST_DESCRIPTIPON = CODEDUI_TEST_DESCRIPTIPON.Replace("'", "''");
            FUNCTIONAL_DESC = FUNCTIONAL_DESC.Replace("'", "''");
            COMMENTS = COMMENTS.Replace("'", "''");
            FUNCTIONALITY_IMPACTED = FUNCTIONALITY_IMPACTED.Replace("'", "''");
            RELEASE_NAME = RELEASE_NAME.Replace("'", "''");
            TEST_DATA_TYPE = TEST_DATA_TYPE.Replace("'", "''");
            TEST_DATA_CATEGORY = TEST_DATA_CATEGORY.Replace("'", "''");
        }
    }


    /// <summary>
    /// Class to Hold Column names for Test Step Details table 
    /// </summary>
    /// <author>RXK4098 - Ramesh Kandasamy</author>
    public class CTestStepDetails
    {
        public const string TESTRUN_ID = "TESTRUN_ID";
        public const string STEP_NAME = "STEP_NAME";
        public const string STEP_DESCRIPTION = "STEP_DESCRIPTION";
        public const string STEP_STATUS = "STEP_STATUS";
        public const string SCREENSHOT_PATH = "SCREENSHOT_PATH";
        public const string LASTUPDATE_TIMESTAMP = "LASTUPDATE_TIMESTAMP";
    }

    /// <summary>
    /// Class to hold data for Test Result Details. 
    /// </summary>
    /// <author> RXK4098 - Ramesh Kandasamy </author>
    public class TestResultInformation
    {
        public string TESTRUN_ID = "";
        public string BATCHRUN_ID = "";
        public string RELEASE_NAME = "";
        public bool IS_RECORD_AVILABLE = false;
        public string CODEDUI_TEST_NAME = ""; 
        public int TEST_ITERATION = 0;
    }

        /// <summary>
        /// Class to hold data for Test Step Details Table 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public class TestStepDetails
    {
        public string TESTRUN_ID = "";
        public string STEP_NAME = "DYNAMIC VALIDATION NAME";
        public string STEP_DESCRIPTION = "DYNAMIC VALIDATION DESCRIPTION";
        public string STEP_STATUS = "FAILED";
        public string SCREENSHOT_PATH = "NOTAVAILABLE";
        public string LASTUPDATE_TIMESTAMP = "CURRENT_TIMESTAMP";
        public string COMMENTS = "";

        /// <summary>
        ///  MEthod to replace ' with '' to avoid SQL trunctation 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void FormatValuesForSQL()
        {
            STEP_NAME = STEP_NAME.Replace("'", "''");
            STEP_DESCRIPTION = STEP_DESCRIPTION.Replace("'", "''");      
        }
    }

    public class CScreenShots
    {
        public const string IMAGE_ID = "IMAGE_ID";
        public const string IMAGE_DATA = "IMAGE_DATA";
    }

    // Class ScreenShots Most Likely be not used, MAY be removed later 
    public class ScreenShots
    {
        public string IMAGE_ID = "";
        public string IMAGE_DATA = "";
    }


}
