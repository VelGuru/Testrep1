﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace ReusableLibrary
{
    /// <summary>
    /// Class to Access & Initialize Test Data. Logic to read data from other sources, XML, DB will be added in future. 
    /// </summary>
    /// <author> RXK4098 - Ramesh Kandasamy</author>
    /// 
    public class TestDataFactory
    {
        FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
        TestDBDataFactory testDBDataFactory = new TestDBDataFactory();
        public Dictionary<string, DataTable> testDataTable = new Dictionary<string, DataTable>();
        public Dictionary<string, DataTable> customTestDataTable = new Dictionary<string, DataTable>();
        public string conStrContainer = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0}; Extended Properties='Excel 8.0;HDR={1}';";
        //public string conStrContainer = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0}; Extended Properties=\"Text;HDR={1};FORMAT=Delimited\"";

        /// <summary>
        /// Method to Read Test Data specific to current test case and assign it to data table 
        /// </summary>
        /// <author> RXK4098 - Ramesh Kandasamy</author>
        public void InitializeDataTable()
        {
            // Initialize Data Table
            testDataTable = new Dictionary<string, DataTable>();

            // Determine the Test Data File Path 
            RunConfiguration.testCaseContext.testDataFileName = frameworkLibrary.FetchConfigValueByTestMethodNamespace("TestDataFileName");
            string dtFilePath = RunConfiguration.testCaseContext.testDataFolder + RunConfiguration.testCaseContext.testDataFileName;

            //Format Connection String with Parameters
            string connectionString = String.Format(conStrContainer, dtFilePath, "YES");

            OleDbConnection excelDbConnection = new OleDbConnection(connectionString);
            Console.WriteLine(excelDbConnection.ConnectionString);
            OleDbCommand dbCommand = new OleDbCommand();
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter();

            dbCommand.Connection = excelDbConnection;
            excelDbConnection.Open();

            DataTable excelSchema = excelDbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string curSheetName = "";

            foreach (DataRow row in excelSchema.Rows)
            {
                curSheetName = row["TABLE_NAME"].ToString();
                if (!testDataTable.ContainsKey(curSheetName))
                {
                    dbCommand.CommandText = "Select * From [" + curSheetName + "] where TestMethodName = '" + RunConfiguration.testCaseContext.testCaseName + "'";
                    dataAdapter.SelectCommand = dbCommand;
                    DataTable curSheetDataTable = new DataTable();
                    dataAdapter.Fill(curSheetDataTable);
                    // Assign Values to Datatable only if current sheet has records for Current Test Case 
                    if (curSheetDataTable.Rows.Count != 0)
                    {
                        testDataTable.Add(curSheetName, curSheetDataTable);
                    }
                }
            }
            // Close Connection
            excelDbConnection.Close();
            excelDbConnection = null;
        }

        /// <summary>
        /// Method to Read Test Data specific to current test case and assign it to data table from Database.
        /// <author> RXK4098 - Ramesh Kandasamy</author>
        /// </summary>
        public void InitializeDBDataTable()
        {
            try
            {
                TestDBDataFactory.codedUIDbConn.Open();
                // Initialize Data Table
                testDataTable = new Dictionary<string, DataTable>();

                string testDataId = testDBDataFactory.GetTestDataIdFromGeneralTable();

                DataTable curSheetDataTable = new DataTable();

                for (int i = 0; i < RunConfiguration.TESTDATA_TABLE_DETAILS.Length; i++)
                {
                    if (!string.IsNullOrEmpty(RunConfiguration.TESTDATA_TABLE_DETAILS[i]))
                    {
                        curSheetDataTable = testDBDataFactory.GetTestDataDetails(RunConfiguration.TESTDATA_TABLE_DETAILS[i], testDataId);
                    }

                    if (curSheetDataTable.Rows.Count != 0)
                    {
                        testDataTable.Add(RunConfiguration.TESTDATA_TABLE_DETAILS[i], curSheetDataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error Getting the Test Data From The DataBase ", ex);
            }
            TestDBDataFactory.codedUIDbConn.Close();
        }

        /// <summary>
        /// Initialize Custom Test Data
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void InitializeCustomDataTable(string testDataFile)
        {
            // Initialize Data Table
            customTestDataTable = new Dictionary<string, DataTable>();

            // Determine the Test Data File Path 
            string dtFilePath = RunConfiguration.testCaseContext.testDataFolder + testDataFile;

            //Format Connection String with Parameters
            string connectionString = String.Format(conStrContainer, dtFilePath, "YES");

            OleDbConnection excelDbConnection = new OleDbConnection(connectionString);
            OleDbCommand dbCommand = new OleDbCommand();
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter();

            dbCommand.Connection = excelDbConnection;
            excelDbConnection.Open();

            DataTable excelSchema = excelDbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string curSheetName = "";

            foreach (DataRow row in excelSchema.Rows)
            {
                curSheetName = row["TABLE_NAME"].ToString();
                if (!customTestDataTable.ContainsKey(curSheetName))
                {
                    dbCommand.CommandText = "Select * From [" + curSheetName + "]";
                    dataAdapter.SelectCommand = dbCommand;
                    DataTable curSheetDataTable = new DataTable();
                    dataAdapter.Fill(curSheetDataTable);
                    // Assign Values to Datatable only if current sheet has records for Current Test Case 
                    if (curSheetDataTable.Rows.Count != 0)
                    {
                        customTestDataTable.Add(curSheetName, curSheetDataTable);
                    }
                }
            }
            // Close Connection
            excelDbConnection.Close();
            excelDbConnection = null;
        }


        // Excel Log Settings
        public bool useTimeStampReporting = true;
        public string editingLogFileLocation = RunConfiguration.excelLogBaseFolder + @"\CodedUI_ExcelLogResults\~$CodedUITests.xlsx";
        public string templateLogFileLocation = RunConfiguration.excelLogBaseFolder + @"\CodedUI_ExcelLogResults\Templates\Template.xlsx";
        public string machineTemplateLocation = RunConfiguration.excelLogBaseFolder + @"\CodedUI_ExcelLogResults\Templates\MachineNameTemplate.xlsx";
        public string excelLogFolder = RunConfiguration.excelLogBaseFolder + @"\ExcelLogs\";
        public string testLogFileLocation = RunConfiguration.excelLogBaseFolder + @"\CodedUI_ExcelLogResults\CodedUITests.xlsx";
        public string testLogScreenshotsPath = RunConfiguration.excelLogBaseFolder + @"\Screenshots";
        public string executionStatus = "PASS";
        public string executionMessage = "";
        public string executionTime = "";
        public string batchRunID = "";
        public String screenshotPath = "";
        public static Stopwatch stopwatch;
        public string cookieName = "";
        Microsoft.Office.Interop.Excel.Application oXL = null;
        Microsoft.Office.Interop.Excel._Workbook oWB = null;
        Microsoft.Office.Interop.Excel._Worksheet oSheet = null;
        string rangeStartValue = "A2";
        string rangeEndValue = "O5000";

        /// <summary>
        /// Write contents to Excel by storing in Array
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void WriteContentByArray()
        {
            // Initialize Excel File
            InitializeExcelFile();
            object misvalue = System.Reflection.Missing.Value;
            try
            {
                // Add table values to Array
                Object[,] excelArray = new Object[9999, 20];
                excelArray = oSheet.get_Range(rangeStartValue, rangeEndValue).Value;
                bool testDataComplete = false;
                int rowNumber = 1;
                while (!testDataComplete)
                {
                    string currentTcName = "", currentIterationNum = "";
                    if (excelArray[rowNumber, 4] != null)
                    {
                        currentTcName = excelArray[rowNumber, 4].ToString();
                    }
                    if (excelArray[rowNumber, 5] != null)
                    {
                        currentIterationNum = excelArray[rowNumber, 5].ToString();
                    }
                    string actualIterationNum = (RunConfiguration.testCaseContext.currentIteration + 1).ToString();

                    if ((RunConfiguration.testCaseContext.testCaseName.Equals(currentTcName) && (actualIterationNum.Equals(currentIterationNum) || string.IsNullOrEmpty(currentIterationNum))) || string.IsNullOrEmpty(currentTcName))
                    {
                        if (ReportFactory.currentRunID != null)
                        {
                            // Test Case Run ID From Database
                            excelArray[rowNumber, 1] = ReportFactory.currentRunID;
                        }
                        else
                        {
                            excelArray[rowNumber, 1] = rowNumber;
                        }
                        // Test Case Description
                        excelArray[rowNumber, 2] = RunConfiguration.testCaseContext.testCaseDescription;
                        // Functional Test Case ID
                        excelArray[rowNumber, 3] = RunConfiguration.testCaseContext.functionalTestName;
                        // CodedUI Test Method Name
                        excelArray[rowNumber, 4] = RunConfiguration.testCaseContext.testCaseName;
                        // Iteration Number
                        excelArray[rowNumber, 5] = actualIterationNum;
                        // Execution Status
                        excelArray[rowNumber, 6] = executionStatus;
                        // Execution Message
                        excelArray[rowNumber, 7] = executionMessage;
                        // Screenshot Path
                        excelArray[rowNumber, 8] = screenshotPath;
                        // Test Category
                        excelArray[rowNumber, 9] = RunConfiguration.testCaseContext.testCategory;
                        // Batch Run ID
                        excelArray[rowNumber, 10] = batchRunID;
                        // Developer Name
                        excelArray[rowNumber, 11] = RunConfiguration.authorName;
                        // TimeStamp
                        excelArray[rowNumber, 12] = GetTodayDateInISTFormat.ToString();
                        // Execution Time
                        excelArray[rowNumber, 13] = executionTime;
                        // Functionality Name
                        excelArray[rowNumber, 14] = RunConfiguration.testCaseContext.namespaceOfTestMethod[0];

                        testDataComplete = true;
                    }
                    rowNumber++;
                    if (rowNumber > 2000)
                    {
                        break;
                    }
                }

                // Assign Array content to Excel Object
                oSheet.get_Range(rangeStartValue, rangeEndValue).Value = excelArray;
                //oSheet.Hyperlinks.Add(oSheet.Range["H" + rowNumber, Type.Missing], screenshotPath, Type.Missing, "Screenshot", "Screenshot Ref");

                // Save and Close Workbook
                oWB.Save();
                oWB.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                try
                {
                    oXL.Quit();
                }
                finally
                {
                    // Manual disposal because of COM
                    while (Marshal.ReleaseComObject(oSheet) != 0) { }
                    while (Marshal.ReleaseComObject(oWB) != 0) { }
                    while (Marshal.ReleaseComObject(oXL) != 0) { }
                    oSheet = null;
                    oWB = null;
                    oXL = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
        }

        bool excelFileOpened = false;
        /// <summary>
        /// Initialize Excel Application, Work book objects
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void InitializeExcelFile()
        {
            // Start Excel and get Application object.
            oXL = new Microsoft.Office.Interop.Excel.Application();
            oXL.Visible = false;
            oXL.DisplayAlerts = false;
            oXL.UserControl = false;
            Random random = new Random();

            for (int i = 0; i < 50; i++)
            {
                if (File.Exists(editingLogFileLocation))
                {
                    Thread.Sleep(random.Next(500));
                }
                else
                {
                    // Open the Excel Log File
                    oWB = (Microsoft.Office.Interop.Excel._Workbook)(oXL.Workbooks.Open(testLogFileLocation));
                    if (!oWB.ReadOnly)
                    {
                        // Gowri - Added a logic to Fetch Dynamic Sheet Name depends to TestsCollection Name
                        string sheetName = frameworkLibrary.FetchConfigValueByTestMethodNamespace("ExcelSheetName");
                        if (string.IsNullOrEmpty(sheetName))
                        {
                            sheetName = RunConfiguration.testCaseContext.testProjectName;
                        }
                        try
                        {
                            oSheet = (Microsoft.Office.Interop.Excel._Worksheet)oWB.Worksheets.get_Item(sheetName);
                        }
                        catch (Exception e)
                        {
                            Console.Error.WriteLine("Error Details - \n" + e.Message);
                            frameworkLibrary.UpdateTestLog("SheetName", "Excel Log Sheet Name is not valid. Please check and update correct Sheet name. Sheet Name - " + sheetName, Status.FAIL);
                        }
                        excelFileOpened = true;
                        break;
                    }
                    else
                    {
                        oWB.Close();
                    }
                }
            }
            if (!excelFileOpened)
            {
                throw new Exception("Failed to Update/Open Excel Log File");
            }
        }

        /// <summary>
        /// Initialize Log Settings
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void InitializeExcelLogSettigs()
        {
            if (RunConfiguration.enableExcelLog)
            {
                if (RunConfiguration.testCaseContext.currentIteration == 0)
                {
                    if (useTimeStampReporting)
                    {
                        InitializeTimeStampFolder();
                    }
                    else
                    {
                        InitializeMachineNameFile();
                    }
                    if (!Directory.Exists(testLogScreenshotsPath))
                    {
                        Directory.CreateDirectory(testLogScreenshotsPath);
                    }
                }
                executionStatus = "PASS";
                executionMessage = "";
                executionTime = "";
                stopwatch = Stopwatch.StartNew();
                batchRunID = frameworkLibrary.ReadFromConfigFile("BatchRunID");
                screenshotPath = "";
            }
        }

        /// <summary>
        /// Initialize Time Stamp Folder and Excel Log File
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void InitializeTimeStampFolder()
        {
            string todayDate = Regex.Replace(GetTodayDateInISTFormat.ToString(), "/|:", "_").Split(' ')[0];
            string folderPath = excelLogFolder + @"Results_" + todayDate;
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }
            string filePath = folderPath + @"\" + Environment.MachineName + "_" + todayDate + ".xlsx";
            if (!File.Exists(filePath))
            {
                File.Copy(templateLogFileLocation, filePath);
            }
            testLogFileLocation = filePath;
            testLogScreenshotsPath = folderPath + "\\Screenshots";
            editingLogFileLocation = folderPath + @"\~$" + Environment.MachineName + "_" + todayDate + ".xlsx";
        }

        /// <summary>
        /// Initialize Time Stamp Folder and Excel Log File
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void InitializeMachineNameFile()
        {
            string folderPath = RunConfiguration.excelLogBaseFolder + @"\CodedUI_ExcelLogResults\";
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }
            string filePath = folderPath + @"\CodedUITests_" + Environment.MachineName + ".xlsx";
            if (!File.Exists(filePath))
            {
                File.Copy(machineTemplateLocation, filePath);
            }
            testLogFileLocation = filePath;
            editingLogFileLocation = folderPath + @"\~$CodedUITests_" + Environment.MachineName + ".xlsx";
        }

        /// <summary>
        /// Update Error Message to Excel Log
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy </author>
        /// <param name="errorMessage">Error Description</param>
        public void UpdateErrorMessage(string errorMessage, string screenshotPath = "")
        {
            executionStatus = "FAIL";
            executionMessage = errorMessage;
            this.screenshotPath = screenshotPath;
            UpdateExcelLogFile();
        }

        /// <summary>
        /// Update Error Message to Excel Log
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="errorMessage">Error Description</param>
        public void UpdateExceptionMessage()
        {
            if (executionStatus.Equals("PASS"))
            {
                executionStatus = "FAIL";
                executionMessage = "Exception is thrown for this TestMethod/Iteration";
                UpdateExcelLogFile();
            }
        }

        /// <summary>
        /// Update Excel Log File
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void UpdateExcelLogFile()
        {
            if (RunConfiguration.enableExcelLog)
            {
                stopwatch.Stop();
                TimeSpan timeSpan = stopwatch.Elapsed;
                executionTime = ((int)timeSpan.TotalSeconds).ToString();
                // Write Content to Excel
                WriteContentByArray();
            }
        }

        /// <summary>
        /// Get the System Date in IST Format
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public DateTime GetTodayDateInISTFormat
        {
            get
            {
                TimeZoneInfo tzi = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                DateTime todayDate = DateTime.Now.ToUniversalTime();
                return TimeZoneInfo.ConvertTimeFromUtc(todayDate, tzi);
            }
        }
    }
}
