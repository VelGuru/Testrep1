﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using ReusableLibrary.UIMap;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using static ReusableLibrary.DriverAppUtilLibrary;

namespace ReusableLibrary
{
    public class DriverBusinessLibrary
    {
        IWebDriver driver;
        DriverAppUtilLibrary appUtilLibrary;
        FrameworkLibrary frameworkLibrary;
        //PageObjects pageObjects;

        public DriverBusinessLibrary(IWebDriver driver)
        {
            this.driver = driver;
            appUtilLibrary = new DriverAppUtilLibrary(driver);
            appUtilLibrary = RunConfiguration.appUtilLibrary;
            frameworkLibrary = RunConfiguration.frameworkLibrary;
            //pageObjects = RunConfiguration.pageObjects;

        }



        /// <summary>
        ///  Check Dashboard has occured or not
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void CheckMembersLoginSuccessful()
        {
            try
            {
                ////*[@class='logo']
                By windowElement = By.XPath("//*[contains(text(),'Welcome')]");
                appUtilLibrary.ExplicitWaitForElement(windowElement);
                IWebElement enterMember = appUtilLibrary.FindElement(windowElement);
                if (enterMember != null)
                {
                    frameworkLibrary.UpdateTestLog("Login to user  is successful", "Login to user is successful", Status.PASS);
                }

                else
                {
                    frameworkLibrary.UpdateTestLog("Login to the dashboard has not been successful ", "Login to the dashboard has not been successful", Status.FAIL);
                }

            }

            catch
            {
                frameworkLibrary.UpdateTestLog("Login is unsuccessful", "Login is unsuccessful", Status.FAIL);
            }

        }


        /// <summary>
        ///  Login to HPAS Applications 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="username">User Name</param>
        /// <param name="password">Password</param>
        public void LoginToHPASPortal(string username, string password)
        {
            try
            {
                CheckForPageLoadErrors("Sign in Page");
                EnterUserNamePassword(username, password);
                appUtilLibrary.ClickButtonById("btnLogin", "Click Login Button");
                Thread.Sleep(5000);
            }
            catch
            {
                frameworkLibrary.UpdateTestLog("Login", "Login page is not loaded", Status.FAIL);
            }
        }


        /// <summary>
        /// Enter Username Password
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="username"></param>
        /// <param name="password"></param>
        public void EnterUserNamePassword(string username, string password)
        {
            #region Variable Declarations  
            IWebElement uIUsernameEdit = appUtilLibrary.FindElement(By.Id("txtUserid"), "User Name TextBox");
            IWebElement uIPasswordEdit = appUtilLibrary.FindElement(By.Id("txtPassword"), "Password TextBox");
            #endregion

            uIUsernameEdit.SendKeys(username);
            uIPasswordEdit.SendKeys(password);
            frameworkLibrary.UpdateTestLog("Login", "UserName(" + username + ") is entered successfully", Status.PASS);
        }



        /// <summary>
        /// Validate Login is successful for Engagement Source Application
        /// </summary>
        /// <author>Ramesh Kandasamy</author>
        public void ValidateRSAPortalLoginSuccessful()
        {
            try
            {

                CheckRSAPortalLoginSuccessful();
            }
            catch (Exception e)
            {
                if (e.Message.Contains("The web page could not be accessed"))
                {
                    CheckRSAPortalLoginSuccessful();
                }
                else
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// Validate Login is successful for PQA Application
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        private void CheckRSAPortalLoginSuccessful(string userName = "")
        {
            try
            {
                //driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(200);
                appUtilLibrary.ExplicitWaitForElement(By.Id("prefmenubutton-1025-btnInnerEl"), 100, "Login user Click");
                //appUtilLibrary.ClickButtonById("prefmenubutton-1025-btnInnerEl", "Login user Click");

                appUtilLibrary.ClickLinkByID("prefmenubutton-1025-btnInnerEl", "Login user Click");
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(200);

                By linkControl = By.XPath("//span[text()='Logout']");
                appUtilLibrary.ExplicitWaitForElement(linkControl, 150, "Logout Link");

                //Thread.Sleep(3000);
                //driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2000);




                if (appUtilLibrary.IsWebElementDisplayed(linkControl, ""))
                {
                    frameworkLibrary.UpdateTestLog("Login", userName + "Login is Successful, The RSA Source page is loaded", Status.PASS);
                    driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(200);

                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Login", userName + "Login is not successful, The RSA Source page is not loaded", Status.FAIL);
                }
            }
            catch
            {
                frameworkLibrary.UpdateTestLog("Login", userName + "Login is not successful, The RSA Source dashboard is not loaded", Status.FAIL);
            }
        }


        /// <summary>
        /// Validate Login is successful for IDE Application
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        private void ValidateLoginSuccessful(string userName = "")
        {
            frameworkLibrary.WaitTillPageLoaded();
            try
            {
                // Validate Mega Navigation is loaded
                IWebElement megaNavigationControl = appUtilLibrary.FindElement(By.CssSelector("nav.primary-navigation-container"), objectSearchTimeout: 60);
                if (megaNavigationControl != null)
                {
                    frameworkLibrary.UpdateTestLog("Login", userName + " Login is Successful, Dashboard Page is loaded", Status.PASS);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Login", userName + " Login is not successful, Dashboard/Mega Navigation is not loaded", Status.FAIL);
                }
                CheckForPageLoadErrors("Dashboard");
            }
            catch (Exception)
            {
                frameworkLibrary.WaitTillPageLoaded();
                CheckForPageLoadErrors("Dashboard");
            }
        }

        /// <summary>
        /// Check For Page Load Errors
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public bool CheckForPageLoadErrors(string pageDesc = "", string pageUrl = "", bool continueOnFail = false)
        {
            bool pageErrorOccurred = false;
            IWebElement pageErrorControl = null;
            string errorMsg = "";
            // Check 404 Server Error
            if (appUtilLibrary.IsWebElementDisplayed(GenericLocators.GlobalErrorControls.UIWeAreSorryThePageIsNotHere))
            {
                errorMsg = "\"We’re sorry. The page you requested isn’t here anymore.\"";
            }

            // Check 500 Server Error
            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//h1[contains(text(),'Server Error')]"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"" + pageErrorControl.Text + "\"";
            }

            // Check Internet Explorer can not display Message
            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//h1[text()='Internet Explorer cannot display the webpage']"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"Internet Explorer cannot display the webpage\"";
            }

            // Check Blank page is displayed
            pageErrorControl = appUtilLibrary.FindElement(By.TagName("body"));
            if (pageErrorControl != null)
            {
                if (string.IsNullOrEmpty(pageErrorControl.Text))
                {
                    errorMsg = "\"Blank Page\"";
                }
            }

            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//div[@id='mainTitle'][text()='This page can’t be displayed']"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"This page can’t be displayed\"";
            }

            // Check "Http/1.1 Service Unavailable" Message
            pageErrorControl = appUtilLibrary.FindElement(By.XPath("//body/b[text()='Http/1.1 Service Unavailable']"));
            if (pageErrorControl != null)
            {
                errorMsg = "\"Http/1.1 Service Unavailable\"";
            }

            if (!string.IsNullOrEmpty(errorMsg))
            {
                pageErrorOccurred = true;
                if (!string.IsNullOrEmpty(pageUrl))
                {
                    frameworkLibrary.UpdateTestLog("PageLoadError", "Error: " + errorMsg + " is displayed for <b> URL: " + pageUrl + " </b> Current Page URL: " + RunConfiguration.driver.Url, Status.FAIL, continueOnFail);
                }
                else if (RunConfiguration.envURL.Trim() != string.Empty && pageDesc.Trim() == string.Empty)
                {
                    frameworkLibrary.UpdateTestLog("PageLoadError", "Error: " + errorMsg + " is displayed for <b> Base URL: " + RunConfiguration.envURL + " </b> Current Page URL: " + RunConfiguration.driver.Url, Status.FAIL, continueOnFail);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("PageLoadError", "Error: " + errorMsg + " is displayed in " + pageDesc + " page", Status.FAIL, continueOnFail);
                }
            }
            else
            {
                frameworkLibrary.UpdateTestLog("PageLoadError", "No page load error was thrown for Current Page URL: " + RunConfiguration.driver.Url, Status.PASS, continueOnFail);
            }

            return pageErrorOccurred;
        }

        /// <summary>
        /// Navigate to target URL, and validate target page header as optional
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void NavigateToTargetURL()
        {
            string targetURL = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "TargetUrl");
            string pageHeader = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "TargetPageHeader");
            string pageHeaderTag = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testGeneralDataSheet, "TargetPageHeaderTag");
            if (!string.IsNullOrEmpty(targetURL))
            {
                OpenUrl(targetURL);
                frameworkLibrary.WaitTillPageLoaded();
                CheckForPageLoadErrors(pageUrl: targetURL);
            }
            if (!string.IsNullOrEmpty(pageHeader))
            {
                if (string.IsNullOrEmpty(pageHeaderTag))
                {
                    pageHeaderTag = "H1";
                }
                appUtilLibrary.ValidatePageHeaderByName(pageHeader, null, pageHeaderTag, true);
            }
        }

        /// <summary>
        /// Open Provided URL in the existing BrowserWindow
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void OpenUrl(string targetUrl)
        {
            targetUrl = frameworkLibrary.GetEnvPrefixedURL(targetUrl);
            driver.Url = targetUrl;
            frameworkLibrary.UpdateTestLog("OpenPage", "Current WebPage is Navigated to URL: " + targetUrl, Status.DONE);
        }

        /// <summary>
        /// Validate Promo contents Like Promo Header, Promo Image, Promo Links and URLs
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="promoHeader">Promo Header Name</param>
        /// <param name="promoImageSrc">Promo Image Source</param>
        /// <param name="promoLinksCollection">Promo Links Collection</param>
        /// <param name="promoLinkUrlsCollection">Promo Link URLs Collection</param>
        public void ValidatePromoContentsAvailability(string promoHeader, string promoImageSrc, string promoLinksCollection, string promoLinkUrlsCollection)
        {
            // Get the Promo Element
            IWebElement promoControl = GetCompletePromoSection();
            if (promoControl.Displayed)
            {
                // Validate Promo Header and Image Source
                ValidatePromoHeaderAndImage(promoControl, promoHeader, promoImageSrc);

                // Validate Promo Links Availablity
                appUtilLibrary.ValidateLinksAvailablity(promoControl, promoLinksCollection, promoLinkUrlsCollection, "Promo Section");
            }
        }

        /// <summary>
        /// Validate Promo Header and Image Source
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="promoControl">Promo Control</param>
        /// <param name="promoHeader">Promo Header</param>
        /// <param name="promoImageSrc">Promo Image Source</param>
        private string ValidatePromoHeaderAndImage(IWebElement promoControl, string promoHeader, string promoImageSrc)
        {
            string promoTag = "";
            // Validate Promo Header
            if (!string.IsNullOrEmpty(promoHeader))
            {
                bool promoHeaderFound = false;
                string[] tagNameCollection = "P;H4;H3;H2;H1".Split(';');
                foreach (string tagName in tagNameCollection)
                {
                    IWebElement promoHeaderUI = appUtilLibrary.FindElement(By.XPath("//" + tagName + "[text()='" + promoHeader + "']"), "Promo Header", promoControl);
                    if (promoHeaderUI.Displayed)
                    {
                        frameworkLibrary.UpdateTestLog("PromoSection", "Promo Header (" + promoHeader + ") is available in the Promo Section", Status.PASS);
                        promoHeaderFound = true;
                        promoTag = tagName;
                        break;
                    }
                }
                if (!promoHeaderFound)
                {
                    frameworkLibrary.UpdateTestLog("PromoSection", "Promo Header (" + promoHeader + ") is not available in the Promo Section", Status.FAIL);
                }
            }

            // Validate Promo Image
            if (!string.IsNullOrEmpty(promoImageSrc))
            {
                IWebElement promoImageHeaderUI = appUtilLibrary.FindElement(By.XPath("//img[@src=" + promoImageSrc + "]"), "PromoImage(ImageSrc :-" + promoImageSrc);
            }
            return promoTag;
        }

        /// <summary>
        /// Promo Control Property
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public IWebElement GetCompletePromoSection()
        {
            IWebElement prevPromo = appUtilLibrary.FindElement(By.XPath("//DIV[contains(@class, 'row solid-background')]"));
            IWebElement updatedPromo = appUtilLibrary.FindElement(By.XPath("//DIV[@id='promos']"));
            try
            {
                if (prevPromo.Displayed)
                {
                    return prevPromo;
                }
                else if (updatedPromo.Displayed)
                {
                    return updatedPromo;
                }
            }
            catch (Exception)
            {
                frameworkLibrary.UpdateTestLog("GetCompletePromoSection", "Promo section is not found", Status.FAIL);
            }
            return prevPromo;
        }

        /// <summary>
        /// Reusable Method to Navigate through Mega Navigation 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentLinkText">Parent Link - Mega Navigation</param>
        /// <param name="childLinkText">Inner Link Name - DropDown</param>
        /// <param name="browser">BrowserWindow Object</param>
        public void NavigateThruMegaNavLink(string parentLinkText, string childLinkText, string windowType = "Same", string useParentContains = "No", string useChildContains = "No")
        {
            IWebElement headerUI = appUtilLibrary.FindElement(By.TagName("HEADER"));
            IWebElement parentLink = appUtilLibrary.FindElement(By.LinkText(parentLinkText), "Parent Link(" + parentLinkText + ")");

            // Mouse Hover to Parent Element
            Actions actions = new Actions(driver);
            actions.MoveToElement(parentLink).Perform();

            // Find Child Link
            IWebElement childLinkElement = appUtilLibrary.FindElement(By.LinkText(childLinkText), "Child Link(" + childLinkText + ")", headerUI);
            appUtilLibrary.ClickLink(childLinkElement, "Child Link(" + childLinkText + ")", true);
        }

        /// <summary>
        /// Reusable Method to Navigate through Mega Navigation 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentLinkText">Parent Link - Mega Navigation</param>
        /// <param name="childLinkText">Inner Link Name - DropDown</param>
        /// <param name="browser">BrowserWindow Object</param>
        public void NavigateThruMegaNavLinks(string parentLinkText, string[] childLinkText, string[] header, bool useParentContains, bool useChildContains)
        {
            By parentsection = null;
            By childsection = null;
            int i = 0;
            foreach (string childLink in childLinkText)
            {
                IWebElement headerUI = appUtilLibrary.FindElement(By.TagName("HEADER"));
                // Mouse Hover to Parent Element
                Actions actions = new Actions(driver);
                if (useParentContains != true && useChildContains != true)
                {
                    parentsection = By.LinkText(parentLinkText);
                    childsection = By.PartialLinkText(childLink);
                }
                else if (useParentContains == true && useChildContains != true)
                {

                    parentsection = By.XPath("//a[contains(text(), '" + parentLinkText + "')]");
                    childsection = By.PartialLinkText(childLink);
                }

                else if (useParentContains != true && useChildContains == true)
                {
                    parentsection = By.LinkText(parentLinkText);
                    childsection = By.XPath("//a[contains(text(), '" + childLink + "')]");
                }

                else
                {
                    parentsection = By.XPath("//a[contains(text(), '" + parentLinkText + "')]");
                    childsection = By.XPath("//a[contains(text(), '" + childLink + "')]");
                }

                IWebElement parentLink = appUtilLibrary.FindElement(parentsection, "Parent Link(" + parentLinkText + ")");
                actions.MoveToElement(parentLink).Perform();
                frameworkLibrary.UpdateTestLog("Clicked " + parentLinkText + "successfully", "Clicked " + parentLinkText + " successfully", Status.PASS);

                IWebElement childLinkElement = appUtilLibrary.FindElement(childsection, "Child Link(" + childLink + ")", headerUI);
                actions.MoveToElement(childLinkElement);
                actions.Click().Perform();
                frameworkLibrary.WaitTillPageLoaded();
                frameworkLibrary.UpdateTestLog("Clicked " + childLink + " successfully", "Clicked " + childLink + " successfully", Status.PASS);
                if (header[i] == null)
                {
                    appUtilLibrary.ValidatePageHeaderByName(childLink);
                }
                else
                {
                    appUtilLibrary.ValidatePageHeaderByName(header[i]);
                }
                i++;
            }
        }

        /// <summary>
        /// Reusable Method to Navigate through Mega Navigation 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="parentLinkText">Parent Link - Mega Navigation</param>
        /// <param name="childLinkText">Child Link - Mega Navigation</param>
        /// <param name="navigatedPageHeader">Navigated Page Header</param>
        public void ValidateThruMegaNavLinks(string parentLinkText, string[] childLinkText, string[] navigatedPageHeaders, bool useParentContains, bool useChildContains)
        {
            By parentsection = null;
            By childsection = null;
            string pageHeader = null;

            for (int i = 0; i < childLinkText.Length; i++)
            {
                string childLink = childLinkText[i];
                if (navigatedPageHeaders != null && navigatedPageHeaders.Length != 0)
                {
                    pageHeader = navigatedPageHeaders[i];
                }
                IWebElement headerUI = appUtilLibrary.FindElement(By.TagName("HEADER"));
                Actions actions = new Actions(driver);

                if (useParentContains != true && useChildContains != true)
                {
                    parentsection = By.LinkText(parentLinkText);
                    childsection = By.PartialLinkText(childLink);
                }
                else if (useParentContains == true && useChildContains != true)
                {
                    parentsection = By.XPath("//a[contains(text(), '" + parentLinkText + "')]");
                    childsection = By.PartialLinkText(childLink);
                }

                else if (useParentContains != true && useChildContains == true)
                {
                    parentsection = By.LinkText(parentLinkText);
                    childsection = By.XPath("//a[contains(text(), '" + childLink + "')]");
                }
                else
                {
                    parentsection = By.XPath("//a[contains(text(), '" + parentLinkText + "')]");
                    childsection = By.XPath("//a[contains(text(), '" + childLink + "')]");
                }

                // Mouse Hover to Parent Element
                IWebElement parentLink = appUtilLibrary.FindElement(parentsection, "Parent Link (" + parentLinkText + ")");
                actions.MoveToElement(parentLink).Perform();
                frameworkLibrary.UpdateTestLog("MegaNavigationParent", "Parent Link (" + parentLinkText + " ) is displayed successfully", Status.PASS);

                appUtilLibrary.ExplicitWaitForElement(childsection, 9);
                // Click Child Link
                IWebElement childLinkElement = appUtilLibrary.FindElement(childsection, "Child Link (" + childLink + ")", headerUI);
                actions.MoveToElement(childLinkElement);
                actions.Click().Perform();
                frameworkLibrary.WaitTillPageLoaded();
                frameworkLibrary.UpdateTestLog("MegaNavigationChild", "Clicked child link (" + childLink + ") under Parent link ( " + parentLinkText + " ) successfully", Status.PASS);
                CheckForPageLoadErrors(childLink + " navigated page");
                if (pageHeader != null)
                {
                    appUtilLibrary.ValidatePageHeaderByName(pageHeader);
                }

                // Navigate to the main page
                driver.Navigate().Back();
                frameworkLibrary.WaitTillPageLoaded();
            }
        }


        /// <summary>
        /// Validate Log out of test case
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateLogoutSuccessful()
        {
            IWebElement Signout = appUtilLibrary.FindElement(By.LinkText("Sign out"));
            Signout.Click();
            frameworkLibrary.UpdateTestLog("Signout", "Sign out button is clicked", Status.PASS);
            frameworkLibrary.WaitTillPageLoaded();

            // validate log out is successfull
            appUtilLibrary.ValidatePageHeaderByName("You have signed out successfully");
        }

        /// <summary>
        /// Validate mega naviagation 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateMegaNavigation(bool useParentContains = false, bool useChildContains = false)
        {
            string megaNavParentLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavParentLink");
            string[] megaNavChildLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavChildLink").Split(';');
            string[] megaNavHeader = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavPageHeader").Split(';');
            frameworkLibrary.WaitTillPageLoaded();

            appUtilLibrary.ExplicitWaitForElement(By.LinkText(megaNavParentLink));
            // Navigate mega navigation
            NavigateThruMegaNavLinks(megaNavParentLink, megaNavChildLink, megaNavHeader, useParentContains, useChildContains);

            frameworkLibrary.WaitTillPageLoaded();
        }

        /// <summary>
        /// Validate mega naviagation links
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateLinksInMegaNavigation(bool useParentContains = false, bool useChildContains = false)
        {
            string megaNavParentLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavParentLink");
            string[] megaNavChildLink = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavChildLink").Split(';');
            string[] megaNavPageHeader = null;
            string pageHeader = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavPageHeader");
            if (!String.IsNullOrEmpty(pageHeader))
            {
                megaNavPageHeader = frameworkLibrary.GetTestData(RunConfiguration.testCaseContext.testDataMegaNPromoDataSheet, "MegaNavPageHeader").Split(';');
            }

            // Navigate mega navigation
            ValidateThruMegaNavLinks(megaNavParentLink, megaNavChildLink, megaNavPageHeader, useParentContains, useChildContains);
            frameworkLibrary.WaitTillPageLoaded();
        }

        /// <summary>
        /// Validate Page URL
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="expectedUrl">Expected URL</param>
        public void ValidatePageUrl(string expectedUrl)
        {
            // Get the Page Url
            expectedUrl = expectedUrl.TrimEnd('/').Replace("http://", "").Replace("https://", "");
            string pageUrl = driver.Url;

            pageUrl = pageUrl.Replace("http://", "").Replace("https://", "");

            if (string.Equals(pageUrl.Trim(), expectedUrl.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                frameworkLibrary.UpdateTestLog("PageURL", "Page Url is matched with Expected Url, Page Url: " + pageUrl, Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("PageURL", "Page Url is not matched with Expected Url, Page Url: " + pageUrl + " Expected URL: " + expectedUrl, Status.FAIL);
            }
        }

        /// <summary>
        /// Validate UI Controls Available
        /// Check and Supperess UI control
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidateUIControlsAvailable(dynamic parentUI = null, int subIterationNo = 1)
        {
            string controlsComment, linkToBePresent, linkToBeSuppress, labelInnerText;
            string controlPropertyCollection = "";
            // Get the Test Data from Data Table
            controlsComment = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "Controls_Comment", subIterationNo);
            linkToBePresent = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LinkToBePresent", subIterationNo);
            linkToBeSuppress = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LinkToBeSuppress", subIterationNo);
            labelInnerText = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LabelInnerText", subIterationNo);
            try
            {
                controlPropertyCollection = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "UIControlProperty", subIterationNo);
            }
            catch (Exception) { }

            // Get Section Header - Parent
            try
            {
                string parentOrder = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "ParentSectionOrder", subIterationNo);
                string parentSectionHeader = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "ParentSectionHeader", subIterationNo);
                string parentSectionHeaderTag = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "ParentSectionHeaderTag", subIterationNo);
                if (!string.IsNullOrEmpty(parentSectionHeader) && !string.IsNullOrEmpty(parentSectionHeaderTag))
                {
                    parentUI = appUtilLibrary.GetParentControlFromSectionHeader(parentSectionHeader, parentSectionHeaderTag, parentOrder: parentOrder, parentControl: parentUI);
                    appUtilLibrary.UIControlIsDisplayed(parentUI);
                }
                else if (!string.IsNullOrEmpty(controlsComment) && parentUI != null)
                {
                    appUtilLibrary.IsWebElementDisplayed(parentUI, "Control" + parentUI + "is present");
                }
            }
            catch (Exception)
            {
                // Parent Section is optional
            }

            try
            {
                // Validate Links Available
                if (!string.IsNullOrEmpty(linkToBePresent))
                {
                    appUtilLibrary.ValidateLinksAvailablity(parentUI, linkToBePresent, "", controlsComment, continueOnFail: true);
                }

                // Validate Links Not available
                if (!string.IsNullOrEmpty(linkToBeSuppress))
                {
                    //appUtilLibrary.ValidateLinksNotAvailable(parentUI, linkToBeSuppress, controlsComment, continueOnFail: true);
                }

                // Validate Label Contents
                if (!string.IsNullOrEmpty(labelInnerText))
                {
                    // Test Data
                    string[] labelPresenceList = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LabelPresence", subIterationNo).Split(';');
                    string[] labelTagNameList = frameworkLibrary.GetTestDataByAdditionalIndex("Controls_Data", "LabelTagName", subIterationNo).Split(';');
                    string[] labelInnerTextList = labelInnerText.Split(';');

                    string eachLabel, eachLabelTag, eachLabelPresence;
                    for (int i = 0; i < labelInnerTextList.Length; i++)
                    {
                        eachLabel = labelInnerTextList[i];
                        eachLabelTag = FrameworkLibrary.GetArrayIndexValue(labelTagNameList, i);
                        eachLabelPresence = FrameworkLibrary.GetArrayIndexValue(labelPresenceList, i).ToUpper();
                        switch (eachLabelPresence)
                        {
                            case "YES":
                                if (Regex.IsMatch(eachLabelTag, "H1|H2|H3|H4"))
                                {
                                    appUtilLibrary.ValidatePageHeaderByName(eachLabel, parentUI, eachLabelTag, false, true);
                                }
                                else
                                {
                                    appUtilLibrary.ValidateLabelByInnerText(eachLabel, eachLabelTag, parentUI);
                                }
                                break;
                            case "NO":
                                appUtilLibrary.IsWebElementNotAvailable(By.TagName(eachLabelTag), "WebElement" + eachLabelTag + "is present", parentUI);
                                break;
                            case "REGEXP":
                                if (Regex.IsMatch(eachLabelTag, "H1|H2|H3|H4"))
                                {
                                    //appUtilLibrary.ValidatePageHeaderByPartialName(parentUI, eachLabel, eachLabelTag, false, true);
                                }
                                else
                                {
                                    appUtilLibrary.ValidateLabelByPartialInnerText(eachLabel, eachLabelTag, parentUI);
                                }
                                break;
                            default:
                                appUtilLibrary.ValidateLabelByInnerText(eachLabel, eachLabelTag, parentUI);
                                break;
                        }
                    }
                }
            }
            catch (AssertFailedException e)
            {
                if (!string.IsNullOrEmpty(controlsComment))
                {
                    frameworkLibrary.UpdateTestLog("UIControl", controlsComment + " - " + e.Message, Status.FAIL);
                }
                else
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// Validate BreadCrumb Section, Links & Active Breadcrumb label
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        /// <param name="activeBreadCrumbPage">Active Breadcrumb Label</param>
        /// <param name="breadcrumbLinksCollection">Breadcrumb Links Collection</param>
        /// <param name="breadcrumbLinkUrlsCollection">Link URLs Collection</param>
        public void ValidateBreadcrumbContents(string activeBreadCrumbPage, string breadcrumbLinksCollection = "", string breadcrumbLinkUrlsCollection = "")
        {
            // Get the Breadcrumb section
            IWebElement breadcrumbSection = driver.FindElement(By.Id("bc"));

            if (breadcrumbSection.Displayed)
            {
                frameworkLibrary.UpdateTestLog("Breadcrumb", "Breadcrumb Section is available in the Page", Status.PASS);

                // Validate Active Breadcrumb Label
                if (!string.IsNullOrEmpty(activeBreadCrumbPage))
                {
                    IWebElement activeBreadcrumbUI = breadcrumbSection.FindElement(By.XPath("//nav/ul/li/span[@itemprop='title']"));
                    if (activeBreadcrumbUI.Displayed)
                    {
                        String actualActiveBreadcrumbText = activeBreadcrumbUI.Text;
                        if (actualActiveBreadcrumbText.Equals(activeBreadCrumbPage))
                        {
                            frameworkLibrary.UpdateTestLog("Breadcrumb", "Active Breadcrumb Page Text (" + actualActiveBreadcrumbText + ") is available in the Breadcrumb Section", Status.PASS);
                        }
                        else
                        {
                            frameworkLibrary.UpdateTestLog("Breadcrumb", "Active Breadcrumb Page Text (" + activeBreadCrumbPage + ") is not available in the Breadcrumb Section, Actual Text - " + actualActiveBreadcrumbText, Status.FAIL);
                        }
                    }
                    else
                    {
                        frameworkLibrary.UpdateTestLog("Breadcrumb", "Active Breadcrumb Page Text (" + activeBreadCrumbPage + ") is not available in the Breadcrumb Section", Status.FAIL);
                    }
                }

                if (!string.IsNullOrEmpty(breadcrumbLinksCollection))
                {
                    // Validate Breadcrumb section Links
                    appUtilLibrary.ValidateLinksAvailablity(breadcrumbSection, breadcrumbLinksCollection, breadcrumbLinkUrlsCollection, "Breadcrumb Section");
                }
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Breadcrumb", "Breadcrumb Section is not available in the Page", Status.FAIL);
            }
        }

        /// <summary>
        /// Validate Promo Contents 
        /// </summary>
        /// <author>RXK4098 - Ramesh Kandasamy</author>
        public void ValidatePromoContents()
        {
            IWebElement promoControl = GetCompletePromoSection();
            By promoLocator = By.XPath("//div[contains(@class, 'six columns')]");
            IReadOnlyList<IWebElement> childCollection = appUtilLibrary.GetAllChildren(promoControl, promoLocator);
            IWebElement eachPromo;
            if (childCollection.Count > 0)
            {
                try
                {
                    for (int j = 0; j < childCollection.Count; j++)
                    {
                        promoControl = GetCompletePromoSection();
                        childCollection = appUtilLibrary.GetAllChildren(promoControl, By.XPath("//div[contains(@class, 'six columns')]"));
                        eachPromo = childCollection[j];
                        LinksValidation linksValidation = new LinksValidation(eachPromo);
                        linksValidation.parentPageUrl = driver.Url.ToString();

                        // Validate Promo Header
                        bool promoHeaderFound = false;
                        string promoHeader = "";
                        string[] tagNameCollection = "H4;P;H3;H2;H1".Split(';');
                        foreach (string tagName in tagNameCollection)
                        {
                            try
                            {
                                IWebElement promoHeaderUI = eachPromo.FindElement(By.TagName(tagName));
                                if (tagName.Equals("P"))
                                {
                                    promoHeaderUI = eachPromo.FindElement(By.XPath("//p[contains(class(), 'headline x1']"));
                                }
                                if (promoHeaderUI != null && promoHeaderUI.Displayed)
                                {
                                    promoHeader = promoHeaderUI.Text;
                                    frameworkLibrary.UpdateTestLog("PromoSection", "Promo Header (" + promoHeader + ") is available in the Promo Section", Status.PASS);
                                    promoHeaderFound = true;
                                }
                            }
                            catch (NoSuchElementException) { }
                        }
                        if (!promoHeaderFound)
                        {
                            frameworkLibrary.UpdateTestLog("PromoSection", "Promo Header is not available in the  promo Section", Status.FAIL);
                        }

                        // Validate Promo Image
                        IWebElement promoImageHeaderUI = appUtilLibrary.FindElement(By.TagName("IMG"), parentElement: eachPromo);
                        if (promoImageHeaderUI != null)
                        {
                            frameworkLibrary.UpdateTestLog("PromoImage", "Promo Image is available for the Promo Header - " + promoHeader, Status.PASS);
                        }
                        else
                        {
                            frameworkLibrary.UpdateTestLog("PromoImage", "Promo Image is not available for the Promo Header - " + promoHeader, Status.DONE);
                        }

                        // Validate Promo Links
                        IReadOnlyList<IWebElement> linksList = eachPromo.FindElements(By.TagName("A"));
                        for (int i = 0; i < linksList.Count; i++)
                        {
                            try
                            {
                                // Get the page elements again
                                promoControl = GetCompletePromoSection();
                                promoLocator = By.XPath("//div[contains(@class, 'six columns')]");
                                childCollection = appUtilLibrary.GetAllChildren(promoControl, promoLocator);
                                eachPromo = childCollection[j];
                                IReadOnlyList<IWebElement> newLinksList = eachPromo.FindElements(By.TagName("A"));
                                if (newLinksList != null)
                                {
                                    IWebElement currentLink = newLinksList[i];
                                    linksValidation.linkName = currentLink.Text;
                                    RunConfiguration.appUtilLibrary.ClickLink(currentLink, currentLink.Text);
                                    frameworkLibrary.WaitTillPageLoaded(timeOut: 10);
                                    if (!linksValidation.IsLinkOpenedInSameWindow(true))
                                    {
                                        OpenUrl(linksValidation.parentPageUrl);
                                        frameworkLibrary.WaitTillPageLoaded();
                                    }
                                }
                            }
                            catch (StaleElementReferenceException)
                            {
                                // Get the page elements again
                                promoControl = GetCompletePromoSection();
                                promoLocator = By.XPath("//div[contains(@class, 'six columns')]");
                                childCollection = appUtilLibrary.GetAllChildren(promoControl, promoLocator);
                                for (j = 0; j < childCollection.Count;)
                                {
                                    eachPromo = childCollection[j];
                                    break;
                                }
                            }
                        }
                    }
                }
                catch (StaleElementReferenceException)
                {
                    // Get the page elements again
                    promoControl = GetCompletePromoSection();
                    promoLocator = By.XPath("//div[contains(@class, 'six columns')]");
                    childCollection = appUtilLibrary.GetAllChildren(promoControl, promoLocator);
                    for (int j = 0; j < childCollection.Count;)
                    {
                        eachPromo = childCollection[j];
                        break;
                    }
                }
            }
        }
    }
}
