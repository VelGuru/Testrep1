﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using ReusableLibrary;
using System;

namespace MRM_Project.Demmo
{
    /// <summary>
    /// Summary description for EngagementSource Tests
    /// </summary>
    [TestClass]
    public class MRMDemo : AttributeReferences
    {
        #region Reusable Library Instantiation

        //Initialize the business library.
        DriverBusinessLibrary driverBusinessLibrary;
        DriverAppUtilLibrary appUtilLibrary;
        FrameworkLibrary frameworkLibrary = new FrameworkLibrary();
        public static IWebDriver driver;
        BusinessLibrary businessLibrary;

        #endregion

        // Initialization will run by default for all the test case. 
        [TestInitialize]
        public void Enterprise_InitializeMethod()
        {
            // Initialize Run Settings
            frameworkLibrary.InitializeRunConfigurations(TestContext);
            if (RunConfiguration.UserGrid)
            {
                //engagementSourceBusinessLibrary.LaunchGrid();
            }
            driverBusinessLibrary = new DriverBusinessLibrary(RunConfiguration.driver);
            appUtilLibrary = new DriverAppUtilLibrary(RunConfiguration.driver);
            frameworkLibrary = RunConfiguration.frameworkLibrary;
            businessLibrary = new BusinessLibrary(RunConfiguration.driver);

        }

        /// <summary>
        /// UAT_Regression_CRMKnowledge_Default Values : Verify if all the default values are being displayed in the form
        ///.///
        /// <author></author> 
        /// </summary>
        [TestMethod, TestCategory(MODULE), TestCategory(SAMPLE)]
        [DeploymentItem(WorkstreamConfig.TestIterationDeploymentPath), DeploymentItem(WorkstreamConfig.RegDataDeploymentPath)]
        [DataSource(PROVIDERNAME_XML, DataSourceIterationFile, ONE, DataAccessMethod.Sequential)]
        public void RequestIDLookup_ReturnsMetadata()
        {
            try
            {
                businessLibrary.verify_MRMerrormessage();
                
            }
            catch (AssertFailedException e)
            {

                throw e;

            }
            catch (Exception e)
            {
                frameworkLibrary.UpdateTestLog("Error", "Debug Info - " + e.Message, Status.FAIL);
            }

        }
        [TestMethod, TestCategory(MODULE), TestCategory(SAMPLE)]
        [DeploymentItem(WorkstreamConfig.TestIterationDeploymentPath), DeploymentItem(WorkstreamConfig.RegDataDeploymentPath)]
        [DataSource(PROVIDERNAME_XML, DataSourceIterationFile, ONE, DataAccessMethod.Sequential)]
        public void Userprofile_Createprofile()
        {
            try
            {
                businessLibrary.verify_AdminTool();

            }
            catch (AssertFailedException e)
            {

                throw e;

            }
            catch (Exception e)
            {
                frameworkLibrary.UpdateTestLog("Error", "Debug Info - " + e.Message, Status.FAIL);
            }

        }




        // /// <summary>
        // /// Method to finize test runs, generate Report if applicable
        // /// </summary>
        [TestCleanup]
        public void WrapUpTestRun()
        {
            try
            {
                RunConfiguration.driver.Quit();
            }
            catch (Exception e)
            {
                frameworkLibrary.UpdateTestLog("Error", "Debug Info - " + e.Message, Status.FAIL);
            }
            frameworkLibrary.WrapUpTestExecution(TestContext.CurrentTestOutcome);
        }
        /// <summary>
        /// Method to finize test runs, generate Report if applicable 
        /// </summary>        
        //[TestCleanup]
        //public void WrapUpTestRun()
        //{
        //    frameworkLibrary.WrapUpTestExecution(TestContext.CurrentTestOutcome);
        //    try
        //    {
        //        RunConfiguration.driver.Close();
        //        RunConfiguration.driver.Quit();
        //    }
        //    catch (Exception e)
        //    {
        //        frameworkLibrary.UpdateTestLog("Error", "Debug Info - " + e.Message, Status.FAIL);
        //    }
        //}

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;
    }
}


