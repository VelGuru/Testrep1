﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using ReusableLibrary;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
//using NsExcel = Microsoft.Office.Interop.Excel;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Globalization;
using Actions = OpenQA.Selenium.Interactions.Actions;
using Keys = OpenQA.Selenium.Keys;

namespace MRM_Project
{
    public partial class BusinessLibrary
    {
        IWebDriver driver;
        DriverAppUtilLibrary appUtilLibrary;
        DriverBusinessLibrary driverBusinessLibrary;
        FrameworkLibrary frameworkLibrary;
        PageObjects pageObjects;
        

        private const string defaultBaseUrl = "http://localhost:5001";
        private const string defaultGridUrl = "http://10.232.3.169:5557/wd/hub";

        public string baseUrl = RunConfiguration.envURL;
        // public string gridUrl = "http://10.232.3.169:5557/wd/hub";
        private StringBuilder verificationErrors;

        string gridUrl = ConfigurationManager.AppSettings["GridURLValue"];
        string currentBrowser = ConfigurationManager.AppSettings["CurrentBrowser"];


        public BusinessLibrary(IWebDriver driver)
        {
            this.driver = driver;
            appUtilLibrary = new DriverAppUtilLibrary(driver);
            frameworkLibrary = RunConfiguration.frameworkLibrary;
            driverBusinessLibrary = new DriverBusinessLibrary(RunConfiguration.driver);
            pageObjects = new PageObjects();
           
        }

        internal void DB2PlanAccess()
        {
            throw new NotImplementedException();
        }

        //public void LaunchGrid()
        //{
        //    Uri appURI = frameworkLibrary.GetURIFromURL(RunConfiguration.envURL);

        //    if (RunConfiguration.UserGrid)
        //    {

        //        if (currentBrowser == "internet explorer")
        //        {
        //            DesiredCapabilities capabilities = new DesiredCapabilities();
        //            capabilities = DesiredCapabilities.InternetExplorer();
        //            capabilities.SetCapability(CapabilityType.BrowserName, currentBrowser);
        //            capabilities.SetCapability(CapabilityType.Platform, new Platform(PlatformType.Windows));
        //            RunConfiguration.driver = new RemoteWebDriver(new Uri(gridUrl), capabilities);
        //            verificationErrors = new StringBuilder();
        //            RunConfiguration.driver.Manage().Window.Maximize();
        //            RunConfiguration.driver.Manage().Cookies.DeleteAllCookies();
        //            frameworkLibrary.UpdateTestLog("GridURL Used", "Grid URL triggered for execution" + gridUrl, Status.DONE);
        //        }
        //        else
        //        {
        //            DesiredCapabilities capabilities = new DesiredCapabilities();
        //            capabilities = DesiredCapabilities.Chrome();
        //            capabilities.SetCapability(CapabilityType.BrowserName, currentBrowser);
        //            capabilities.SetCapability(CapabilityType.Platform, new Platform(PlatformType.Windows));
        //            RunConfiguration.driver = new RemoteWebDriver(new Uri(gridUrl), capabilities);
        //            verificationErrors = new StringBuilder();
        //            RunConfiguration.driver.Manage().Window.Maximize();
        //            RunConfiguration.driver.Manage().Cookies.DeleteAllCookies();
        //            frameworkLibrary.UpdateTestLog("GridURL Used", "Grid URL triggered for execution" + gridUrl, Status.DONE);
        //        }
        //        //RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        //        RunConfiguration.driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
        //        RunConfiguration.driver.Manage().Window.Maximize();

        //    }
        //    RunConfiguration.driver.Url = appURI.AbsoluteUri;
        //    RunConfiguration.appUtilLibrary = new DriverAppUtilLibrary(RunConfiguration.driver);
        //    RunConfiguration.driverBusinessLibrary = new DriverBusinessLibrary(RunConfiguration.driver);
        //    frameworkLibrary.WaitTillPageLoaded();
        //}
        /// <summary>
        /// 
        /// </summary>
        public void LoginToHPASApplication()
        {
            if (frameworkLibrary.InitializeStepsRequired)
            {
                try
                {
                    if (driver.Title.Contains("Sign in"))
                    {
                        WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
                        wait.Until(ExpectedConditions.TitleContains("Sign in"));
                        wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("//input[@name='loginfmt']")));
                        Thread.Sleep(5000);
                        driver.FindElement(By.XPath("//input[@name='loginfmt']")).SendKeys("gm2@humana.com");
                        driver.FindElement(By.XPath("//input[@value='Next']")).Click();
                        Thread.Sleep(5000);
                        driver.FindElement(By.Name("passwd")).SendKeys("panda#94");
                        driver.FindElement(By.XPath("//input[@value='Sign in']")).Click();
                        driver.FindElement(By.XPath("//input[@value='Yes']")).Click();
                    }

                    // Read User ID & Password
                    //string userName = frameworkLibrary.GetTestDataFromEnvSheet("UserName");
                    //string password = frameworkLibrary.GetTestDataFromEnvSheet("Password");

                    // Login to HPASApplication
                    //driverBusinessLibrary.LoginToHPASPortal(userName, password);
                    //driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2000);

                }
                catch (AssertFailedException e)
                {
                    throw e;


                }
                catch (Exception e)
                {
                    frameworkLibrary.UpdateTestLog("Exception", "Exception in RSAPortalApplication - " + e.Message, Status.FAIL);
                }
            }
        }
        
        public void verify_MRMerrormessage()
        {
            string MRMID = frameworkLibrary.GetTestData("General_DataSheet", "ValidMRMID");
            Thread.Sleep(5000);
            appUtilLibrary.ExplicitWaitForVisibilityElement(By.Id(pageObjects.btn_acknowledge), 30, "");
            appUtilLibrary.ClickButtonById(pageObjects.btn_acknowledge, "Acknowledge Button");
            Thread.Sleep(10000);
            appUtilLibrary.ClickLinkusingByElement(By.XPath(pageObjects.wdgt_Updatetool), "Upload Tool widget", true);
            driver.SwitchTo().Frame("contentFrame");
            Thread.Sleep(10000);
            appUtilLibrary.ExplicitWaitForVisibilityElement(By.XPath(pageObjects.txt_MRMRequestId), 30, "MRM Request ID");
            appUtilLibrary.EnterInputToTextBoxByXPath(pageObjects.txt_MRMRequestId, MRMID, "MRM Request ID", true);
            Thread.Sleep(5000);
            appUtilLibrary.ClickLinkusingByElement(pageObjects.btn_Searchicon, "Search Icon", true);
            Thread.Sleep(10000);
            string message=driver.FindElement(pageObjects.err_mrminvalid).Text;
            //Assert.AreEqual("Invalid Request Id.", message);
            if (String.Compare("Invalid Request Id.", message) == 0)
            {
                frameworkLibrary.UpdateTestLog("Validation", message + " Error message has been displayed. No Metadata are populated.", Status.FAIL);
            }
            else
            {
                frameworkLibrary.UpdateTestLog("Validation", message + " No error message", Status.PASS);
                string metadata = driver.FindElement(pageObjects.txt_Memberfirstname).Text;
                if (metadata == "")
                {
                    frameworkLibrary.UpdateTestLog("Validation", "Metadata are not populated", Status.FAIL);
                }
                else
                {
                    frameworkLibrary.UpdateTestLog("Validation", "Metadata are populated", Status.PASS);
                }
            }
        }

        public void verify_AdminTool()
        {
            string UserID = frameworkLibrary.GetTestData("General_DataSheet", "UserID");
            string BusinessArea = frameworkLibrary.GetTestData("General_DataSheet", "BusinessArea");
            string Department = frameworkLibrary.GetTestData("General_DataSheet", "Department");            

            appUtilLibrary.ExplicitWaitForVisibilityElement(By.Id(pageObjects.btn_acknowledge), 40, "");
            appUtilLibrary.ClickButtonById(pageObjects.btn_acknowledge, "Acknowledge Button");
            Thread.Sleep(10000);
            appUtilLibrary.ClickLinkusingByElement(By.XPath(pageObjects.wdgt_Adminfun), "Admin Functionality widget", true);
            Thread.Sleep(5000);
            appUtilLibrary.ClickLinkusingByElement(By.XPath(pageObjects.wdgt_userProfile), "User Profile widget", true);
            driver.SwitchTo().Frame("contentFrame");
            Thread.Sleep(5000);
            appUtilLibrary.ExplicitWaitForVisibilityElement(By.Id(pageObjects.txt_userID), 10, "");
            appUtilLibrary.EnterInputToTextBoxById(pageObjects.txt_userID, UserID, "User ID", true);
            Thread.Sleep(15000);
            driver.FindElement(By.Id(pageObjects.txt_userID)).SendKeys(Keys.Enter);
            appUtilLibrary.ClickButtonById(pageObjects.btn_searchButton, "Search Button");
            Thread.Sleep(15000);
            appUtilLibrary.SelectDropDownItemByID(pageObjects.drp_BusinessArea, BusinessArea, "Business Area ");
            appUtilLibrary.SelectDropDownItemByID(pageObjects.drp_DepartmentId, Department, "Department");
            appUtilLibrary.ClickButtonById(pageObjects.btn_btnSave, "Save Profile");
            Thread.Sleep(15000);
            string result=driver.FindElement(pageObjects.resultsText).Text;
            frameworkLibrary.UpdateTestLog("Validation", result, Status.PASS);

        }


        /// </// <summary>
        ///To Upload file
        /// <author>SXS2929-Selva Kumar Srinivasan</author> 
        /// </summary>
        public void FileUpload(string path)
        {
            SelectFile(path);
            RunConfiguration.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            appUtilLibrary.ClickButtonByPartialName("Submit", null, null, "Upload file button");

        }

        /// <summary>
        ///To choose the participation file
        /// <author>SXS2929-Selva Kumar Srinivasan</author> 
        /// </summary>
        public void SelectFile(string path)
        {
            By Upload = By.Name("Upload File");
            appUtilLibrary.ExplicitWaitForElement(Upload, 2);
            appUtilLibrary.IsWebElementDisplayed(Upload, "Upload button");
            appUtilLibrary.ClickButtonById("UploadFile", "Browse Button");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3);
            Thread.Sleep(3000);
            SendKeys.SendWait(path);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
            try
            {
                SendKeys.SendWait("{ENTER}");
                frameworkLibrary.UpdateTestLog("File Upload", "Participation file selected", Status.PASS);
            }
            catch (Exception)
            {
                frameworkLibrary.UpdateTestLog("File Upload", "Unable to select the Participation file", Status.FAIL);
            }
        }
        // <summary>
        // This Method will validate weather elemet is displayed or not
        // <author>SXJ7615-Saima Jan</author> 
        // </summary>
        public void ValidateElementIsDisplayed(By locator, string webelementType, string elementDesc)
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2000);
            if (ElementIsDisplayedOnPage(locator) == true)
            {
                frameworkLibrary.UpdateTestLog(webelementType, "(" + elementDesc + ") is available on the page", Status.PASS);
            }
            else
            {
                frameworkLibrary.UpdateTestLog(webelementType, "(" + elementDesc + ") is not available on the page", Status.FAIL);
            }

        }
        // <summary>
        // This Method will validate weather elemet is displayed or not
        // <author>SXJ7615-Saima Jan</author> 
        // </summary>
        public bool ElementIsDisplayedOnPage(By locator)
        {
            for (int i = 0; i < 10; i++)
            {
                IWebElement element;
                try
                {
                    element = driver.FindElement(locator);
                    return element.Displayed;
                    // return true;

                }
                catch (Exception e)
                {
                    Thread.Sleep(2000);
                }
            }
            return false;

        }
        // <summary>
        // This Method will move the mouse to the webelement
        // <author>SXJ7615-Saima Jan</author> 
        // </summary>
        public void MouseHoverTo(By locator, String desc)
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            try
            {
                Actions builder = new Actions(driver);
                builder.MoveToElement(driver.FindElement(locator)).Build().Perform();
                frameworkLibrary.UpdateTestLog("MouseHover ", "Mouse is moved to(" + desc + ")", Status.PASS);
            }
            catch (Exception e)
            {
                frameworkLibrary.UpdateTestLog("Error", "Mouse is not moved to(" + desc + ")", Status.FAIL);
            }

        }

        public string dateAdd(int days)
        {
            string day = DateTime.Today.ToString("dddd");
            DateTime dateValue = DateTime.Today;
            if (days < 0)
                dateValue = DateTime.Today.AddDays(days);
            else
            { 
            if (day.ToLower().Contains("wednesday") || day.ToLower().Contains("thursday"))
                dateValue = DateTime.Today.AddDays(days + 2);
            else
                dateValue = DateTime.Today.AddDays(days);
            }
            string dateadded = dateValue.Date.ToString("MM/dd/yyyy");
            return dateadded;
        }

        //public string dateAdding(int days, string locator)
        //{
        //        string day=DateTime.Today.ToString("dddd");
        //    DateTime dateValue = DateTime.Today;
        //    if (day.ToLower().Contains("saturday")|| day.ToLower().Contains("sunday"))
        //        dateValue = DateTime.Today.AddDays(days+2);
        //    else
        //        dateValue = DateTime.Today.AddDays(days);
        //    string dateAdding = dateValue.Date.ToString("MM/dd/yyyy");
        //        return dateAdding;
        //    //while(locator = driver.FindElement(By.XPath(""))
        //}
            
    }
}


public class ArcherDetails
{
    public string TrackingId
    {
        get;
        set;
    }

    public string MeaSet
    {
        get;
        set;

    }

    public string MeaConfig
    {
        get;
        set;
    }
}




