﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace MRM_Project
{
    public class PageObjects
    {

        //LoginPage
        public By txt_UsName = By.Id("txtUSerName");
        public By txt_psword = By.Id("txtpassword");

        public string btnLogin = "btnLogin";
        public By btn_Login = By.Id("btnLogin");
        public By lnk_workDayApps = By.XPath("//a[@id='apps-heading']");
        public string lnkSTR_workDayApps = "//a[@id='apps-heading']";

        public By lnk_HSS = By.XPath("//a[text()='Humana Self Service (HSS)']");
        public string lnkSTR_HSS = "//a[text()='Humana Self Service (HSS)']";

        public By lnk_RFA = By.XPath("//a[@class='secondary list'][text()='Request For Access']");
        public string lnkSTR_RFA = "//a[@class='secondary list'][text()='Request For Access']";
        public By btn_FileDataAdjustment = By.XPath("//a[text()='File Data Adjustment']");
        public By btn_FileTypeAdjustment = By.Id("ddlFileTypeAdjustment");
        public By val_FileUploadScreen = By.XPath("//div[text()='File Upload to FTP']");
        public By val_filedataAdjustment = By.XPath("//div[text()='File Data Adjustment']");

        public string wdgt_Updatetool = "//*[@id='widget-2']";
        public string wdgt_Adminfun = "//*[@id='widget-1038']";
        public string wdgt_userProfile = "//*[@id='widget-14']";
        public string txt_MRMRequestId = "//label[text()='MRM Request ID:']/following::input[1]";
        public By btn_Searchicon = By.XPath("//button[@title='Search Request Id']");
        public By err_mrminvalid = By.XPath("//span[@class='requestSearchMsg']");
        public By txt_Memberfirstname = By.Id("MemberFirstName");
        public string txt_userID = "userId-search-selectized";
        public string opt_gmm4338 = "//span[text()='GMM4338']";
        public string drp_BusinessArea = "BusinessAreaId";
        public string drp_DepartmentId = "DepartmentId";
        public string btn_acknowledge = "acknowledge";
        public string btn_searchButton = "searchButton";
        public string btn_btnSave = "btnSave";
        public By resultsText = By.Id("resultsText");
        
    }
}



