﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRM_Project
{
    public class WorkstreamConfig
    {
        // Deployment Parameters
        public const string RegDataDeploymentPath = "TestData\\";
        public const string TestIterationDeploymentPath = "TestData\\TestIteration.xml";
    }
}
