package businesscomponents;

import com.google.gson.JsonParser;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;
import com.mongodb.MongoCredential;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;

import frameworkcore.ReusableLibrary;
import frameworkcore.ScriptHelper;
import frameworkseleniumcore.Status;
import frameworkseleniumcore.Util;
import frameworkseleniumcore.APIReusuableLibrary.ASSERT_RESPONSE;
import frameworkseleniumcore.APIReusuableLibrary.COMPARISON;
import frameworkseleniumcore.APIReusuableLibrary.SERVICEFORMAT;
import frameworkseleniumcore.APIReusuableLibrary.SERVICEMETHOD;

import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.io.File;
import java.lang.reflect.Array;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.json.JSONException;

import io.restassured.RestAssured;
import io.restassured.mapper.ObjectMapper;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ResponseBodyExtractionOptions;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

import org.bson.Document;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;

public class COREAPIComponents extends ReusableLibrary {

	HeadersForAPI headers = new HeadersForAPI();
	List<String> swaggerFieldname = null;
	List<String> restFieldname = null;
	String restHealthCondition = "", soapHealthCondition = "", restDescription = "";
	String dbSourcePersonId = "", dbSourcePlatform = "", dbmmctId = "", dbcmpcId = "";
	String restIsAccessible = "", soapIsAccessible = "", restIdType = "";
	String restAdditionalInfo = "", soapAdditionalInfo = "";
	String resthealthCondition = "", restisAccessible = "", restadditionalInfo = "", resthealthCondition1 = "",
			restisAccessible1 = "", restadditionalInfo1 = "", resthealthCondition2 = "", restisAccessible2 = "",
			restadditionalInfo2 = "", resthealthCondition3 = "", restisAccessible3 = "", restadditionalInfo3 = "",
			resthealthCondition4 = "", restisAccessible4 = "", restadditionalInfo4 = "";
	String restPersonId = "", dbPersonId = "";
	String restFirstName = "", dbFirstName = "";
	String restMiddleName = "", dbMiddleName = "";
	String restMiddleInitial = "", dbMiddleInitial = "";
	String restPediatricDentalTermDate = "", restPediatricDentalTermDate1 = "", restPediatricDentalTermDate2 = "",
			restPediatricDentalTermDate3 = "";
	String restLastName = "", dbLastName = "";
	String restDOB = "", dbDOB = "";
	String restplanType = "", restvalidatedOnWeb = "", restconsentType = "", restconsentStartDate = "",
			restconsentEndDate = "", restconsentTermDate = "";
	String restGender = "", dbGender = "";
	String dbPersonGenKey = "", dbmasterPersonId = "", dbfirstName = "", dbmiddleName = "", dblastName = "",
			dbmiddleInitial = "", dbgender = "";
	Date dbdateOfBirth = null;
	String restAddressType = "", dbAddressType = "";
	String restAddressLine1 = "", dbAddressLine1 = "";
	String restAddressLine2 = "", dbAddressLine2 = "";
	String restAddressLine3 = "", dbAddressLine3 = "";
	String restCity = "", dbCity = "";
	String restCountyCode = "", dbCountyCode = "";
	String restStateCode = "", dbStateCode = "";
	String restZipCode = "", dbZipCode = "";
	String restZipPlus = "", dbZipPlus = "";
	String restEmailAddress = "", dbEmailAddress = "", restEmailAddress1 = "", dbEmailAddress1 = "";
	String restType = "", dbType = "", restType1 = "", dbType1 = "";
	String restMemberGenKey = "", dbMemberGenKey = "";
	String restMasterPersonId = "", dbMasterPersonId = "";
	String restGo365EntityKey = "", dbGo365EntityKey = "";
	String restMedicareId = "", dbMedicareId = "";
	String restSSN = "", dbSSN = "";
	String restPlatform = "", restPlatform1 = "", restId1 = "", dbPlatform = "", dbPlatform1 = "";
	String restId = "", dbId = "", dbId1 = "";
	String restid0 = "", restvendorId0 = "", resttypeCode0 = "";
	String restid1 = "", restvendorId1 = "", resttypeCode1 = "";
	String restid2 = "", restvendorId2 = "", resttypeCode2 = "";
	String restid3 = "", restvendorId3 = "", resttypeCode3 = "";
	String restid4 = "", restvendorId4 = "", resttypeCode4 = "";
	String restpackageName = "", reststartDate = "", restendDate = "", restitemCode = "", restitemTypeCode = "",
			restcategoryDescription = "", restpackageKey = "";
	String restdescription = "";

	String restalternateDescription = "", restsource = "", restproductLineCode = "", restproductLineDescription = "",
			restproductTypeCode = "", restsegmentType = "", restmajorLineOfBusinessCode = "",
			restmajorLineOfBusinessDescription = "";
	String restCopayLevelCode = "", dbCopayLevel = "";
	String restCopayPercent = "", dbPercent = "";
	String restEffectiveDate = "";
	String restEndDate = "", restndcCode = "", restformularyId = "", restmedId = "", resttier = "", restisCovered = "",
			restisPriorAuthorizationRequired = "";
	Date dbEndDate = null;
	Date dbEffectiveDate = null;
	String restgroupIdentifiergroupId = "", restgroupIdentifierdivisionId = "", restgroupIdentifierkey = "",
			restgroupIdentifierplatform = "", restgroupIdentifierdisplayGroupId = "",
			restproductIdentifierproductId = "", restproductIdentifierstartDate = "",
			restproductIdentifierplatform = "", restproductIdentifierkey = "", restplancategory = "",
			restplansubCategory = "", restplanlineOfBusiness = "", restcoverageType = "", restbusinessLevel5 = "",
			restbusinessLevel6 = "", restbusinessLevel7 = "", restmarketsellingMarketNumber = "",
			restmarketserviceMarketNumber = "", restmarketsellingMarketDescription = "",
			restmarketserviceMarketDescription = "", restmarketsellingConsolidatedMarketNumber = "",
			restmarketserviceConsolidatedMarketNumber = "", restmarketsellingMarketFinancialProductCode = "",
			restledgerserviceLedgerNumber = "", restledgersellingLedgerDescription = "",
			restledgerserviceLedgerDescription = "", restmedicareContractId = "";
	String restmedicarePbpId = "", restmedicareSegmentId = "", restledgersellingLedgerNumber = "";
	String restmedicationId = "", restmedicationId1 = "", restname1 = "", restbrandName = "", restbrandName1 = "",
			restgenericName = "", restgenericName1 = "", restndcCode1 = "", restimageUrl = "", restimageUrl1 = "",
			restprescriptionRequired = "", restprescriptionRequired1 = "", restmedicationType = "",
			restmedicationType1 = "", restdirections = "", restdirections1 = "", restindication = "",
			restindication1 = "", restnotes = "", restnotes1 = "", restquantity = "", restquantity1 = "",
			restsupply = "", restsupply1 = "", restdrugDoseForm = "", restdrugDoseForm1 = "", restdrugStrength = "",
			restdrugStrength1 = "", restlastFilledDate = "", restlastFilledDate1 = "", restprescriberName = "",
			restprescriberName1 = "", restprescriberNpi = "", restprescriberNpi1 = "", restpharmacyName = "",
			restpharmacyName1 = "", restpharmacyNpi = "", restpharmacyNpi1 = "", restrxNumber = "", restrxNumber1 = "",
			restrefillStatus = "", restrefillStatus1 = "", restrefillsRemaining = "", restrefillsRemaining1 = "",
			restisCurrentlyTaking = "", restisCurrentlyTaking1 = "", restisVerified = "", restisVerified1 = "",
			restremovalReason = "", restremovalReason1 = "", restremovalReasonCode = "", restremovalReasonCode1 = "",
			restcreatedBySystem = "", restcreatedBySystem1 = "", restcreatedDate = "", restcreatedDate1 = "";
	String restgroupIdentifierghGroupId = "", restname = "", restplatform = "", restisAdministrativeServicesOnly = "",
			restenterpriseEmployerPlatform = "", restenterpriseEmployerId = "", restisDsnp = "";
	String restbase = "", restdependentCode = "", restsubscriberGenKey = "", restcoverageKey = "",
			restisNonInsurance = "", restpolicyType = "", restrelationshipToSubscriber = "",
			restpediatricDentalTermDate = "", restoperationalMajorLineOfBusiness = "", restprodPlanId = "",
			reststateOfIssue = "", restoptOut = "", restperiod = "";
	String restbase1 = "", restdependentCode1 = "", restsubscriberGenKey1 = "", restcoverageKey1 = "",
			restisNonInsurance1 = "", restpolicyType1 = "", restrelationshipToSubscriber1 = "",
			restpediatricDentalTermDate1 = "", restoperationalMajorLineOfBusiness1 = "", restprodPlanId1 = "",
			reststateOfIssue1 = "", restoptOut1 = "", restperiod1 = "";
	String restbase2 = "", restdependentCode2 = "", restsubscriberGenKey2 = "", restcoverageKey2 = "",
			restisNonInsurance2 = "", restpolicyType2 = "", restrelationshipToSubscriber2 = "",
			restpediatricDentalTermDate2 = "", restoperationalMajorLineOfBusiness2 = "", restprodPlanId2 = "",
			reststateOfIssue2 = "", restoptOut2 = "", restperiod2 = "";
	String restbase3 = "", restdependentCode3 = "", restsubscriberGenKey3 = "", restcoverageKey3 = "",
			restisNonInsurance3 = "", restpolicyType3 = "", restrelationshipToSubscriber3 = "",
			restpediatricDentalTermDate3 = "", restoperationalMajorLineOfBusiness3 = "", restprodPlanId3 = "",
			reststateOfIssue3 = "", restoptOut3 = "", restperiod3 = "";
	String restsourcePersonId = "", restsourcePlatform = "", restmmctId = "", restcmpcId = "";
	String restrelationshipcode = "", restrelationshipdescription = "";
	String restisSmoker = "", restisRetired = "", restisHumanaEmployee = "", restisPartDOptOut = "",
			restisHcfaDual = "", restisLongTermInst = "", restisMedicareEnrollee = "", restisBlocked = "",
			resttenantId = "";
	String healthCondition = "", restmemberGenKey = "", restcontractId = "", restplanNumber = "",
			restbenefitAmount = "", restplanOptionNumber = "", restperiodicity = "", restisOTCEligible = "",
			restdesigneeId = "", restrole = "", restdesigneeType = "", restOrganizationName = "";
	String restproductLineCode1 = "", restproductLineDescription1 = "", restproductTypeCode1 = "",
			restsegmentType1 = "", restmajorLineOfBusinessCode1 = "", restmajorLineOfBusinessDescription1 = "";
	String restproductLineCode2 = "", restproductLineDescription2 = "", restproductTypeCode2 = "",
			restsegmentType2 = "", restmajorLineOfBusinessCode2 = "", restmajorLineOfBusinessDescription2 = "";
	String restproductLineCode3 = "", restproductLineDescription3 = "", restproductTypeCode3 = "",
			restsegmentType3 = "", restmajorLineOfBusinessCode3 = "", restmajorLineOfBusinessDescription3 = "";

	String restcontractId1 = "", restmemberGenKey1 = "", restsourcePersonId1 = "", restcoverageType1 = "",
			restplatform1 = "", reststartDate1 = "", restendDate1 = "";
	String restcontractId2 = "", restmemberGenKey2 = "", restsourcePersonId2 = "", restcoverageType2 = "",
			restplatform2 = "", reststartDate2 = "", restendDate2 = "";
	String restcontractId3 = "", restmemberGenKey3 = "", restsourcePersonId3 = "", restcoverageType3 = "",
			restplatform3 = "", reststartDate3 = "", restendDate3 = "";

	public COREAPIComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}

	public void validateUser() {

		Map<String, String> headersMap = headers.getHeaders3();
		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1");
		String postBodyContent = dataTable.getData("General_Data", "InputJsonTemplate");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_name", "murug");
		String expectedResponse = dataTable.getData("General_Data", "OutputJsonTemplate");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.POST, SERVICEFORMAT.JSON, postBodyContent, headersMap,
				201);

		apiDriver.assertIt(url, response, ASSERT_RESPONSE.BODY, "", expectedResponse, COMPARISON.IS_EQUALS);
		apiDriver.assertIt(url, response, ASSERT_RESPONSE.TAG, "name", "murug", COMPARISON.IS_EQUALS);
		apiDriver.assertIt(url, response, ASSERT_RESPONSE.HEADER, "", "application/json;", COMPARISON.IS_EXISTS);

	}

	public void restCall() {
		Map<String, String> headersMap = headers.getHeaders3();
		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1");
		String ParameterKeylist = dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "ParameterKey");
		String ParameterValuelist = dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "ParameterValue");
		String[] keyList = ParameterKeylist.split("#");
		String[] ValueList = ParameterValuelist.split("#");
		String parameterlist = "?";
		for (int i = 0; i < keyList.length; i++) {

			parameterlist = parameterlist + keyList[i] + "=" + ValueList[i];

		}
		String FinalURL = url + parameterlist;

		response = apiDriver.sendNReceive(FinalURL, SERVICEMETHOD.GET, headersMap, 200);

		restHealthCondition = extractTagValue(response, "healthCondition", SERVICEFORMAT.JSON);
		restIsAccessible = extractTagValue(response, "isAccessible", SERVICEFORMAT.JSON);
		restAdditionalInfo = extractTagValue(response, "additionalInfo", SERVICEFORMAT.JSON);

		dataTable.putData("INT_DataSheet", "RESTHealthCondition", restHealthCondition);
		dataTable.putData("INT_DataSheet", "RESTIsAccessible", restIsAccessible);
		dataTable.putData("INT_DataSheet", "RESTAdditionalInfo", restAdditionalInfo);

	}

	public void restMemberCall() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1") + dataTable.getData("INT_DataSheet", "MemberGenKey");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restId = extractTagValue(response, "id", SERVICEFORMAT.JSON);
		restPersonId = extractTagValue(response, "personId", SERVICEFORMAT.JSON);
		restFirstName = extractTagValue(response, "firstName", SERVICEFORMAT.JSON);
		restMiddleName = extractTagValue(response, "middleName", SERVICEFORMAT.JSON);
		restMiddleInitial = extractTagValue(response, "middleInitial", SERVICEFORMAT.JSON);
		restLastName = extractTagValue(response, "lastName", SERVICEFORMAT.JSON);
		restDOB = extractTagValue(response, "dateOfBirth", SERVICEFORMAT.JSON);
		restGender = extractTagValue(response, "gender", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestId", restId);
		dataTable.putData("INT_DataSheet", "RestPersonId", restPersonId);
		dataTable.putData("INT_DataSheet", "RestFirstName", restFirstName);
		dataTable.putData("INT_DataSheet", "RestMiddleName", restMiddleName);
		dataTable.putData("INT_DataSheet", "RestMiddleInitial", restMiddleInitial);
		dataTable.putData("INT_DataSheet", "RestLastName", restLastName);
		dataTable.putData("INT_DataSheet", "RestDOB", restDOB);
		dataTable.putData("INT_DataSheet", "RestGender", restGender);
	}

	public void mangoDBDataRetreive() {

		String DatabaseName = dataTable.getData("General_Data", "DatabaseName");
		String UserName = dataTable.getData("General_Data", "UserName");
		char[] password = (dataTable.getData("General_Data", "Password")).toCharArray();

		String ReplicaSet1 = dataTable.getData("General_Data", "ReplicaSet1");
		String ReplicaSet2 = dataTable.getData("General_Data", "ReplicaSet2");
		String ReplicaSet3 = dataTable.getData("General_Data", "ReplicaSet3");

		String CollectionName = dataTable.getData("INT_DataSheet", "CollectionName");
		String QueryKey = dataTable.getData("INT_DataSheet", "QueryKey");
		String QueryValue = dataTable.getData("INT_DataSheet", "MemberGenKey");

		MongoCredential credential = MongoCredential.createCredential(UserName, DatabaseName, password);
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(true).build();
		MongoClient mongoClient = new MongoClient(Arrays.asList(new ServerAddress(ReplicaSet1),
				new ServerAddress(ReplicaSet2), new ServerAddress(ReplicaSet3)), Arrays.asList(credential), options);

		MongoDatabase database = mongoClient.getDatabase(DatabaseName);
		MongoCollection<Document> table = database.getCollection(CollectionName);

		FindIterable<Document> iterDocs = table.find(Filters.eq(QueryKey, QueryValue));

		for (Document iterdoc : iterDocs) {
			// System.out.println("Key-"+iterdoc.getString("key")+"- firstName
			// -"+iterdoc.getString("personGenKey"));

			dbPersonGenKey = iterdoc.getString("personGenKey");
			dbmasterPersonId = iterdoc.getString("masterPersonId");
			dbfirstName = iterdoc.getString("firstName");
			dbmiddleName = iterdoc.getString("middleName");
			dbmiddleInitial = iterdoc.getString("middleInitial");
			dblastName = iterdoc.getString("lastName");
			dbdateOfBirth = iterdoc.getDate("dateOfBirth");
			dbgender = iterdoc.getString("gender");

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String strDate = dateFormat.format(dbdateOfBirth);

			// write it in the excel
			dataTable.putData("INT_DataSheet", "DBPersonGenKey", dbPersonGenKey);
			dataTable.putData("INT_DataSheet", "DBPersonId", dbmasterPersonId);
			dataTable.putData("INT_DataSheet", "DBFirstName", dbfirstName);
			dataTable.putData("INT_DataSheet", "DBMiddleName", dbmiddleName);
			dataTable.putData("INT_DataSheet", "DBMiddleInitial", dbmiddleInitial);
			dataTable.putData("INT_DataSheet", "DBLastName", dblastName);
			dataTable.putData("INT_DataSheet", "DBDOB", strDate);
			dataTable.putData("INT_DataSheet", "DBGender", dbgender);

		}

		mongoClient.close();
	}

	public void validateDetailsAsList() {

		Object expectedList = new ArrayList<String>();
		expectedList = getList();
		ValidatableResponse response;
		Map<String, String> headersMap = null;
		String uri = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.GET, headersMap, 200);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.LIST, "MRData.CircuitTable.Circuits.circuitId", expectedList,
				COMPARISON.IS_EQUALS);

	}

	public void convertFToC() {

		Map<String, String> headersMap = headers.getHeaders2();
		ValidatableResponse response;
		String uri = "https://www.w3schools.com/xml/tempconvert.asmx";

		String postBodyContent = apiDriver.readInput(getTemplatePath() + "FtoC_Input.xml");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_fahrenheit",
				dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "Fahrenheit"));
		String expectedCelcius = dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "Celsius");
		String expectedResponse = apiDriver.readInput(getTemplatePath() + "FtoC_Output.xml");
		expectedResponse = apiDriver.updateContent(expectedResponse, "update_celsius", expectedCelcius);

		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent, headersMap, 200);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.BODY, "", expectedResponse, COMPARISON.IS_EQUALS);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.TAG, "//FahrenheitToCelsiusResult/text()", expectedCelcius,
				COMPARISON.IS_EQUALS);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.HEADER, "", "text/xml;", COMPARISON.IS_EXISTS);
	}

	public void soapCall() {

		Map<String, String> headersMap = headers.getHeaders5();
		ValidatableResponse response;
		String uri = dataTable.getData("General_Data", "URL2");

		String postBodyContent = apiDriver.readInput(getTemplatePath() + "CheckHealthProgramPageView_Input.xml");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_ApplicationKey",
				dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "ApplicationKey"));
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_MemberGenKey",
				dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "MemberGenKey"));
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_PageRequestCriteria",
				dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "PageRequestCriteria"));

		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent, headersMap, 200);

		soapHealthCondition = extractTagValue(response, "a:PageRequestCriteria", SERVICEFORMAT.XML);
		soapIsAccessible = extractTagValue(response, "a:IsAccessible", SERVICEFORMAT.XML);
		soapAdditionalInfo = extractTagValue(response, "a:AdditionalInfo", SERVICEFORMAT.XML);
		;

		dataTable.putData("INT_DataSheet", "SOAPHealthCondition", soapHealthCondition);
		dataTable.putData("INT_DataSheet", "SOAPIsAccessible", soapIsAccessible);
		dataTable.putData("INT_DataSheet", "SOAPAdditionalInfo", soapAdditionalInfo);

	}

	public String extractTagValue(ValidatableResponse response, String tagToValidate, SERVICEFORMAT format) {

		if (format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString();
			String retreiveBody = (((responseBody.replace("\"", "")).replace("]", "")).replace("{", ""))
					.replace("},", "").replace("[", "").replace("}", "");
			String subStringOpen = tagToValidate + ":";
			String subStringClose = ",";
			value = ((retreiveBody.split(subStringOpen))[1].split(subStringClose))[0];
			value = value.trim();
			return value;
		} else {
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];
			return value;
		}
	}

	public String extractTagValue2(ValidatableResponse response, String tagToValidate, SERVICEFORMAT format) {
		String v5 = null;
		List<String> myList = new ArrayList<String>();
		String joined2 = "";
		if (format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString();
			String retreiveBody = (((responseBody.replace("\"", "")).replace("]", "")).replace("{", ""))
					.replace("},", "").replace("[", "");
			String subStringOpen = tagToValidate + ":";
			String subStringClose = ",";
			value = ((retreiveBody.split(subStringOpen))[1]);
			char[] v = value.trim().toCharArray();
			for (char v1 : v) {
				String[] values = value.split(",");
				for (int i = 0; i < 5; i++) {
					v5 = values[i];
					myList.add(v5);
					joined2 = String.join(",", myList);

				}

				return joined2;
			}

		} else {
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];
			return joined2;
		}

		return joined2;
	}

	public String extractTagValue(ValidatableResponse response, String tagToValidate, int tagValue,
			SERVICEFORMAT format) {

		if (format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString();
			JsonPath jsonPath = new JsonPath(responseBody);
			String user_id = jsonPath.getString(tagToValidate);

			String retreiveBody = (((user_id.replace("\"", "")).replace("]", "")).replace("}", "")).replace("},", "")
					.replace("[", "");
			String subStringOpen = tagToValidate + ":";
			String subStringClose = ",";
			value = ((retreiveBody.split(subStringClose))[tagValue]);
			value = value.trim();
			return value;
		} else {
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];
			return value;
		}
	}

	public String extractTagValue(ValidatableResponse response, String tagToValidate, String tagValue,
			SERVICEFORMAT format) {
		String value2 = "";
		if (format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString();
			JsonPath jsonPath = new JsonPath(responseBody);
			String user_id = jsonPath.getString(tagToValidate);
			String retreiveBody = (((user_id.replace("\"", "")).replace("]", "")).replace("}", "")).replace("},", "")
					.replace("[", "");
			String subStringOpen = tagValue + ":";
			String subStringClose = ",";
			value = ((retreiveBody.split(subStringOpen))[1].split(subStringClose))[0];
			value2 = value.trim();
			return value2;
		} else

		{
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];
			return value;
		}
	}

	public String extractTagValue(ValidatableResponse response, String tagToValidate, String tagValue, int tagvalue,
			SERVICEFORMAT format) {
		String value2 = "";
		if (format == SERVICEFORMAT.JSON) {
			String value = "", value1 = "";
			String value3 = "";
			String[] tags;
			String valuesofTag = "";
			String responseBody = response.extract().asString();
			JsonPath jsonPath = new JsonPath(responseBody);
			String user_id = jsonPath.getString(tagToValidate);
			tags = user_id.split("],");
			for (int j = 0; j < 1; j++) {
				valuesofTag = tags[tagvalue];
				value3 = valuesofTag.toString();
				String subStringclose = ",";
				String retreiveBody = (((value3.replace("\"", "")).replace("]", "")).replace("}", "")).replace("},", "")
						.replace("[", "");
				String subStringOpen = tagValue + ":";
				value2 = ((retreiveBody.split(subStringOpen))[1].split(subStringclose))[0];
			}

		} else {
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];
			return value;
		}
		return value2;
	}

	public String extractTagValueDummy(ValidatableResponse response, String tagToValidate, String tagValue,
			int tagvalue, SERVICEFORMAT format) {

		if (format == SERVICEFORMAT.JSON) {
			String value = "", value1 = "", value2 = "";
			String responseBody = response.extract().asString();
			JsonPath jsonPath = new JsonPath(responseBody);
			String user_id = jsonPath.getString(tagToValidate);

			String retreiveBody = (((user_id.replace("\"", "")).replace("]", "")).replace("}", "")).replace("},", "")
					.replace("[", "");
			String subStringOpen = tagValue + ":";
			String subStringClose = ",";
			String subStringclose = ":";
			value = ((retreiveBody.split(subStringOpen))[1].split(subStringClose))[0];
			value1 = value.split(subStringclose)[tagvalue];
			value2 = value1.trim();
			return value2;
		} else {
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];
			return value;
		}
	}

	public String extractTagValue1(ValidatableResponse response, String tagToValidate, SERVICEFORMAT format) {

		if (format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString();
			String retreiveBody = (((responseBody.replace("\"", "")).replace("]", "")).replace("}", ""))
					.replace("},", "").replace("[", "");
			String subStringOpen = tagToValidate + ":";
			String subStringClose = " ";
			value = ((retreiveBody.split(subStringOpen))[1].split(subStringClose))[0];
			value = value.trim();
			return value;
		} else {
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];
			return value;
		}
	}

	public void validateHealthProgramPage() {

		restHealthCondition = dataTable.getData("INT_DataSheet", "RESTHealthCondition");
		restIsAccessible = dataTable.getData("INT_DataSheet", "RESTIsAccessible");
		restAdditionalInfo = dataTable.getData("INT_DataSheet", "RESTAdditionalInfo");

		soapHealthCondition = dataTable.getData("INT_DataSheet", "SOAPHealthCondition");
		soapIsAccessible = dataTable.getData("INT_DataSheet", "SOAPIsAccessible");
		soapAdditionalInfo = dataTable.getData("INT_DataSheet", "SOAPAdditionalInfo");

		if (restHealthCondition.equals(soapHealthCondition)) {
			report.updateTestLog("validateHealthProgramPage", "REST HealthCondition => " + restHealthCondition
					+ ". SOAP HealthCondition => " + soapHealthCondition, Status.PASS);
		} else {
			report.updateTestLog("validateHealthProgramPage", "REST HealthCondition => " + restHealthCondition
					+ ". SOAP HealthCondition => " + soapHealthCondition, Status.FAIL);
		}
		if (restIsAccessible.equals(soapIsAccessible)) {
			report.updateTestLog("validateHealthProgramPage",
					"REST IsAccessible => " + restIsAccessible + ". SOAP IsAccessible => " + soapIsAccessible,
					Status.PASS);
		} else {
			report.updateTestLog("validateHealthProgramPage",
					"REST IsAccessible => " + restIsAccessible + ". SOAP IsAccessible => " + soapIsAccessible,
					Status.FAIL);
		}
		if (restAdditionalInfo.equals(soapAdditionalInfo)) {
			report.updateTestLog("validateHealthProgramPage",
					"REST AdditionalInfo => " + restAdditionalInfo + ". SOAP AdditionalInfo => " + soapAdditionalInfo,
					Status.PASS);
		} else {
			report.updateTestLog("validateHealthProgramPage",
					"REST AdditionalInfo => " + restAdditionalInfo + ". SOAP AdditionalInfo => " + soapAdditionalInfo,
					Status.FAIL);
		}
	}

	public void validatePersonDetails() {

		restId = dataTable.getData("INT_DataSheet", "RestId");
		restPersonId = dataTable.getData("INT_DataSheet", "RestPersonId");
		restFirstName = dataTable.getData("INT_DataSheet", "RestFirstName");
		restMiddleName = dataTable.getData("INT_DataSheet", "RestMiddleName");
		restMiddleInitial = dataTable.getData("INT_DataSheet", "RestMiddleInitial");
		restLastName = dataTable.getData("INT_DataSheet", "RestLastName");
		restDOB = dataTable.getData("INT_DataSheet", "RestDOB");
		restGender = dataTable.getData("INT_DataSheet", "RestGender");

		dbPersonGenKey = dataTable.getData("INT_DataSheet", "DBPersonGenKey");
		dbmasterPersonId = dataTable.getData("INT_DataSheet", "DBPersonId");
		dbfirstName = dataTable.getData("INT_DataSheet", "DBFirstName");
		dbmiddleName = dataTable.getData("INT_DataSheet", "DBMiddleName");
		dbmiddleInitial = dataTable.getData("INT_DataSheet", "DBMiddleInitial");
		dblastName = dataTable.getData("INT_DataSheet", "DBLastName");
		dbDOB = dataTable.getData("INT_DataSheet", "DBDOB");
		dbgender = dataTable.getData("INT_DataSheet", "DBGender");

		if (restId.equals(dbPersonGenKey)) {
			report.updateTestLog("ValidatePersonDetailsofId",
					"REST Id => " + restId + ". DB PersonGenKey=> " + dbPersonGenKey, Status.PASS);
		} else {
			report.updateTestLog("ValidatePersonDetailsofId",
					"REST Id => " + restId + ". DB PersonGenKey=> " + dbPersonGenKey, Status.FAIL);
		}
		if (restPersonId.equals(dbmasterPersonId)) {
			report.updateTestLog("ValidatePersonDetailsofPersonId",
					"REST PersonId => " + restPersonId + ". DB PersonId => " + dbmasterPersonId, Status.PASS);
		} else {
			report.updateTestLog("ValidatePersonDetailsofPersonId",
					"REST PersonId => " + restPersonId + ". DB PersonId => " + dbmasterPersonId, Status.FAIL);
		}
		if (restFirstName.equals(dbfirstName)) {
			report.updateTestLog("ValidatePersonDetailsofFirstName",
					"REST FirstName => " + restFirstName + ". DB FirstName => " + dbfirstName, Status.PASS);
		} else {
			report.updateTestLog("ValidatePersonDetailsofFirstName",
					"REST FirstName => " + restFirstName + ". DB FirstName => " + dbfirstName, Status.FAIL);
		}
		if (restMiddleName.equals(dbmiddleName)) {
			report.updateTestLog("ValidatePersonDetailsofMiddleName",
					"REST MiddleName => " + restMiddleName + " DB MiddleName => " + dbmiddleName, Status.PASS);
		} else {
			report.updateTestLog("ValidatePersonDetailsofMiddleName",
					"REST MiddleName => " + restMiddleName + " DB MiddleName => " + dbmiddleName, Status.FAIL);
		}
		if (restMiddleInitial.equals(dbmiddleInitial)) {
			report.updateTestLog("ValidatePersonDetailsofMiddleInitial",
					"REST MiddleInitial => " + restMiddleInitial + " DB MiddleInitial => " + dbmiddleInitial,
					Status.PASS);
		} else {
			report.updateTestLog("ValidatePersonDetailsofMiddleInitial",
					"REST MiddleInitial => " + restMiddleInitial + " DB MiddleInitial => " + dbmiddleInitial,
					Status.FAIL);
		}
		if (restLastName.equals(dblastName)) {
			report.updateTestLog("ValidatePersonDetailsofLastName",
					"REST LastName => " + restLastName + ". DB LastName => " + dblastName, Status.PASS);
		} else {
			report.updateTestLog("ValidatePersonDetailsofLastName",
					"REST LastName => " + restLastName + ". DB LastName => " + dblastName, Status.FAIL);
		}
		if (restDOB.equals(dbDOB)) {
			report.updateTestLog("ValidatePersonDetailsofDOB", "REST DOB => " + restDOB + ". DB DOB => " + dbDOB,
					Status.PASS);
		} else {
			report.updateTestLog("ValidatePersonDetailsofDOB", "REST DOB => " + restDOB + ". DB DOB => " + dbDOB,
					Status.FAIL);
		}
		if (restGender.equals(dbgender)) {
			report.updateTestLog("ValidatePersonDetailsofGender",
					"REST Gender => " + restGender + ". DB Gender => " + dbgender, Status.PASS);
		} else {
			report.updateTestLog("ValidatePersonDetailsofGender",
					"REST Gender => " + restGender + ". DB Gender => " + dbgender, Status.FAIL);
		}

	}

	public void convertTemparatureInSequence() {
		Map<String, String> headersMap = headers.getHeaders2();
		Map<String, String> headersMap1 = headers.getHeaders4();
		ValidatableResponse response;
		String uri = "https://www.w3schools.com/xml/tempconvert.asmx";

		String postBodyContent = apiDriver.readInput(getTemplatePath() + "FtoC_Input.xml");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_fahrenheit", "50");
		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent, headersMap, 200);
		String celciusFromResponse = apiDriver.extractValue(response, "//FahrenheitToCelsiusResult/text()");
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.TAG, "//FahrenheitToCelsiusResult/text()", "10",
				COMPARISON.IS_EQUALS);

		String postBodyContent1 = apiDriver.readInput(getTemplatePath() + "CtoF_Input.xml");
		postBodyContent1 = apiDriver.updateContent(postBodyContent1, "update_celsius", celciusFromResponse);
		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent1, headersMap1,
				200);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.TAG, "//CelsiusToFahrenheitResult/text()", "50",
				COMPARISON.IS_EQUALS);

	}

	private List<String> getList() {
		List<String> sampleList = new ArrayList<String>();
		sampleList.add("albert_park");
		sampleList.add("americas");
		sampleList.add("bahrain");
		sampleList.add("BAK");
		sampleList.add("catalunya");
		sampleList.add("hungaroring");
		sampleList.add("interlagos");
		sampleList.add("marina_bay");
		sampleList.add("monaco");
		sampleList.add("monza");
		sampleList.add("red_bull_ring");
		sampleList.add("rodriguez");
		sampleList.add("sepang");
		sampleList.add("shanghai");
		sampleList.add("silverstone");
		sampleList.add("sochi");
		sampleList.add("spa");
		sampleList.add("suzuka");
		sampleList.add("villeneuve");
		sampleList.add("yas_marina");

		return sampleList;
	}

	private String getTemplatePath() {
		File frameworkPath = new File(frameworkParameters.getRelativePath());

		String parentPath = frameworkPath.getParent();

		String templatePath = parentPath + Util.getFileSeparator() + "Miscellaneous_Maven" + Util.getFileSeparator()
				+ "EndPointInputs" + Util.getFileSeparator();

		return templatePath;
	}

	public void restMemberCallAddress() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1") + dataTable.getData("INT_DataSheet", "MemberGenKey")
				+ "/" + dataTable.getData("INT_DataSheet", "PageRequestCriteria");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restAddressType = extractTagValue(response, "addressType", SERVICEFORMAT.JSON);
		restAddressLine1 = extractTagValue(response, "addressLine1", SERVICEFORMAT.JSON);
		restAddressLine2 = extractTagValue(response, "addressLine2", SERVICEFORMAT.JSON);
		restAddressLine3 = extractTagValue(response, "addressLine3", SERVICEFORMAT.JSON);
		restCity = extractTagValue(response, "city", SERVICEFORMAT.JSON);
		restCountyCode = extractTagValue(response, "countyCode", SERVICEFORMAT.JSON);
		restStateCode = extractTagValue(response, "stateCode", SERVICEFORMAT.JSON);
		restZipCode = extractTagValue(response, "zipCode", SERVICEFORMAT.JSON);
		restZipPlus = extractTagValue(response, "zipPlus", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestAddressType", restAddressType);
		dataTable.putData("INT_DataSheet", "RestAddressLine1", restAddressLine1);
		dataTable.putData("INT_DataSheet", "RestAddressLine2", restAddressLine2);
		dataTable.putData("INT_DataSheet", "RestAddressLine3", restAddressLine3);
		dataTable.putData("INT_DataSheet", "RestCity", restCity);
		dataTable.putData("INT_DataSheet", "RestCountyCode", restCountyCode);
		dataTable.putData("INT_DataSheet", "RestStateCode", restStateCode);
		dataTable.putData("INT_DataSheet", "RestZipCode", restZipCode);
		dataTable.putData("INT_DataSheet", "RestZipPlus", restZipPlus);

	}

	public void mangoDBDataRetreiveAddress() {

		String DatabaseName = dataTable.getData("General_Data", "DatabaseName");
		String UserName = dataTable.getData("General_Data", "UserName");
		char[] password = (dataTable.getData("General_Data", "Password")).toCharArray();

		String ReplicaSet1 = dataTable.getData("General_Data", "ReplicaSet1");
		String ReplicaSet2 = dataTable.getData("General_Data", "ReplicaSet2");
		String ReplicaSet3 = dataTable.getData("General_Data", "ReplicaSet3");

		String CollectionName = dataTable.getData("INT_DataSheet", "CollectionName");
		String QueryKey = dataTable.getData("INT_DataSheet", "QueryKey");
		String QueryValue = dataTable.getData("INT_DataSheet", "MemberGenKey");

		MongoCredential credential = MongoCredential.createCredential(UserName, DatabaseName, password);
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(true).build();
		MongoClient mongoClient = new MongoClient(Arrays.asList(new ServerAddress(ReplicaSet1),
				new ServerAddress(ReplicaSet2), new ServerAddress(ReplicaSet3)), Arrays.asList(credential), options);

		MongoDatabase database = mongoClient.getDatabase(DatabaseName);
		MongoCollection<Document> table = database.getCollection(CollectionName);

		FindIterable<Document> iterDocs = table.find(Filters.eq(QueryKey, QueryValue));

		for (Document iterdoc : iterDocs) {

			Document x = (Document) iterdoc.get("contact");
			@SuppressWarnings("unchecked")
			ArrayList<Document> y = (ArrayList<Document>) x.get("addresses");
			Document z = (Document) y.get(0);

			dbAddressType = z.getString("type");
			dbAddressLine1 = z.getString("addressLine1");
			dbAddressLine2 = z.getString("addressLine2");
			dbAddressLine3 = z.getString("addressLine3");
			dbCity = z.getString("city");
			dbCountyCode = z.getString("countyCode");
			dbStateCode = z.getString("stateCode");
			dbZipCode = z.getString("zipCode");
			dbZipPlus = z.getString("zipCodePlus");

			// write it in the excel
			dataTable.putData("INT_DataSheet", "DBAddressType", dbAddressType);
			dataTable.putData("INT_DataSheet", "DBAddressLine1", dbAddressLine1);
			dataTable.putData("INT_DataSheet", "DBAddressLine2", dbAddressLine2);
			dataTable.putData("INT_DataSheet", "DBAddressLine3", dbAddressLine3);
			dataTable.putData("INT_DataSheet", "DBCity", dbCity);
			dataTable.putData("INT_DataSheet", "DBCountyCode", dbCountyCode);
			dataTable.putData("INT_DataSheet", "DBStateCode", dbStateCode);
			dataTable.putData("INT_DataSheet", "DBZipCode", dbZipCode);
			dataTable.putData("INT_DataSheet", "DBZipPlus", dbZipPlus);

		}

		mongoClient.close();
	}

	public void validatePersonDetailsForAddress() {

		restAddressType = dataTable.getData("INT_DataSheet", "RestAddressType");
		restAddressLine1 = dataTable.getData("INT_DataSheet", "RestAddressLine1");
		restAddressLine2 = dataTable.getData("INT_DataSheet", "RestAddressLine2");
		restAddressLine3 = dataTable.getData("INT_DataSheet", "RestAddressLine3");
		restCity = dataTable.getData("INT_DataSheet", "RestCity");
		restCountyCode = dataTable.getData("INT_DataSheet", "RestCountyCode");
		restStateCode = dataTable.getData("INT_DataSheet", "RestStateCode");
		restZipCode = dataTable.getData("INT_DataSheet", "RestZipCode");
		restZipPlus = dataTable.getData("INT_DataSheet", "RestZipPlus");

		dbAddressType = dataTable.getData("INT_DataSheet", "DBAddressType");
		dbAddressLine1 = dataTable.getData("INT_DataSheet", "DBAddressLine1");
		dbAddressLine2 = dataTable.getData("INT_DataSheet", "DBAddressLine2");
		dbAddressLine3 = dataTable.getData("INT_DataSheet", "DBAddressLine3");
		dbCity = dataTable.getData("INT_DataSheet", "DBCity");
		dbCountyCode = dataTable.getData("INT_DataSheet", "DBCountyCode");
		dbStateCode = dataTable.getData("INT_DataSheet", "DBStateCode");
		dbZipCode = dataTable.getData("INT_DataSheet", "DBZipCode");
		dbZipPlus = dataTable.getData("INT_DataSheet", "DBZipPlus");
		if (restAddressType.equals(dbAddressType)) {
			report.updateTestLog("validatePersonDetails",
					"REST AddressType => " + restAddressType + ". DB AddressType => " + dbAddressType, Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST AddressType => " + restAddressType + ". DB AddressType => " + dbAddressType, Status.FAIL);
		}
		if (restAddressLine1.equals(dbAddressLine1)) {
			report.updateTestLog("validatePersonDetails",
					"REST AddressLine1 => " + restAddressLine1 + ". DB AddressLine1 => " + dbAddressLine1, Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST AddressLine1 => " + restAddressLine1 + ". DB AddressLine1 => " + dbAddressLine1, Status.FAIL);
		}
		if (restAddressLine2.equals(dbAddressLine2)) {
			report.updateTestLog("validatePersonDetails",
					"REST AddressLine2 => " + restAddressLine2 + " DB AddressLine2 => " + dbAddressLine2, Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST AddressLine2 => " + restAddressLine2 + " DB AddressLine2 => " + dbAddressLine2, Status.FAIL);
		}
		if (restAddressLine3.equals(dbAddressLine3)) {
			report.updateTestLog("validatePersonDetails",
					"REST AddressLine3 => " + restAddressLine3 + " DB AddressLine3 => " + dbAddressLine3, Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST AddressLine3 => " + restAddressLine3 + " DB AddressLine3 => " + dbAddressLine3, Status.FAIL);
		}
		if (restCity.equals(dbCity)) {
			report.updateTestLog("validatePersonDetails", "REST City => " + restCity + ". DB City => " + dbCity,
					Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails", "REST City => " + restCity + ". DB City => " + dbCity,
					Status.FAIL);
		}
		if (restCountyCode.equals(dbCountyCode)) {
			report.updateTestLog("validatePersonDetails",
					"REST CountyCode => " + restCountyCode + ". DB CountyCode => " + dbCountyCode, Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST CountyCode => " + restCountyCode + ". DB CountyCode => " + dbCountyCode, Status.FAIL);
		}
		if (restStateCode.equals(dbStateCode)) {
			report.updateTestLog("validatePersonDetails",
					"REST StateCode => " + restStateCode + ". DB StateCode => " + dbStateCode, Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST StateCode => " + restStateCode + ". DB StateCode => " + dbStateCode, Status.FAIL);
		}
		if (restZipCode.equals(dbZipCode)) {
			report.updateTestLog("validatePersonDetails",
					"REST ZipCode => " + restZipCode + ". DB ZipCode => " + dbZipCode, Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST ZipCode => " + restZipCode + ". DB ZipCode => " + dbZipCode, Status.FAIL);
		}
		if (restZipPlus.equals(dbZipPlus)) {
			report.updateTestLog("validatePersonDetails",
					"REST ZipPlus => " + restZipPlus + ". DB ZipPlus => " + dbZipPlus, Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST ZipPlus => " + restZipPlus + ". DB ZipPlus => " + dbZipPlus, Status.FAIL);
		}
	}

	public void restMemberCallForEmails() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1") + dataTable.getData("INT_DataSheet", "MemberGenKey")
				+ "/" + dataTable.getData("INT_DataSheet", "PageRequestCriteria");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restEmailAddress = extractTagValue(response, "emailAddress", 0, SERVICEFORMAT.JSON);
		restType = extractTagValue(response, "type", 0, SERVICEFORMAT.JSON);
		restEmailAddress1 = extractTagValue(response, "emailAddress", 1, SERVICEFORMAT.JSON);
		restType1 = extractTagValue(response, "type", 1, SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestEmailAddress", restEmailAddress);
		dataTable.putData("INT_DataSheet", "RestType", restType);
		dataTable.putData("INT_DataSheet", "RestEmailAddress1", restEmailAddress1);
		dataTable.putData("INT_DataSheet", "RestType1", restType1);

	}

	public void mangoDBDataRetreiveEmails() {

		String DatabaseName = dataTable.getData("General_Data", "DatabaseName");
		String UserName = dataTable.getData("General_Data", "UserName");
		char[] password = (dataTable.getData("General_Data", "Password")).toCharArray();

		String ReplicaSet1 = dataTable.getData("General_Data", "ReplicaSet1");
		String ReplicaSet2 = dataTable.getData("General_Data", "ReplicaSet2");
		String ReplicaSet3 = dataTable.getData("General_Data", "ReplicaSet3");

		String CollectionName = dataTable.getData("INT_DataSheet", "CollectionName");
		String QueryKey = dataTable.getData("INT_DataSheet", "QueryKey");
		String QueryValue = dataTable.getData("INT_DataSheet", "MemberGenKey");

		MongoCredential credential = MongoCredential.createCredential(UserName, DatabaseName, password);
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(true).build();
		MongoClient mongoClient = new MongoClient(Arrays.asList(new ServerAddress(ReplicaSet1),
				new ServerAddress(ReplicaSet2), new ServerAddress(ReplicaSet3)), Arrays.asList(credential), options);

		MongoDatabase database = mongoClient.getDatabase(DatabaseName);
		MongoCollection<Document> table = database.getCollection(CollectionName);

		FindIterable<Document> iterDocs = table.find(Filters.eq(QueryKey, QueryValue));

		for (Document doc : iterDocs) {

			Document x = (Document) doc.get("contact");

			@SuppressWarnings("unchecked")
			ArrayList<Document> y = (ArrayList<Document>) x.get("emails");
			Document z = (Document) y.get(0);

			Document a = (Document) y.get(1);

			dbType = z.getString("type");
			dbEmailAddress = z.getString("email");
			dbType1 = a.getString("type");
			dbEmailAddress1 = a.getString("email");

			// write it in the excel
			dataTable.putData("INT_DataSheet", "DBEmailAddress", dbEmailAddress);
			dataTable.putData("INT_DataSheet", "DBType", dbType);
			dataTable.putData("INT_DataSheet", "DBEmailAddress1", dbEmailAddress1);
			dataTable.putData("INT_DataSheet", "DBType1", dbType1);

		}

		mongoClient.close();
	}

	public void validatePersonDetailsForEmails() {

		restEmailAddress = dataTable.getData("INT_DataSheet", "RestEmailAddress");
		restType = dataTable.getData("INT_DataSheet", "RestType");
		restEmailAddress1 = dataTable.getData("INT_DataSheet", "RestEmailAddress1");
		restType1 = dataTable.getData("INT_DataSheet", "RestType1");

		dbEmailAddress = dataTable.getData("INT_DataSheet", "DBEmailAddress");
		dbType = dataTable.getData("INT_DataSheet", "DBType");

		dbEmailAddress1 = dataTable.getData("INT_DataSheet", "DBEmailAddress1");
		dbType1 = dataTable.getData("INT_DataSheet", "DBType1");

		if (restEmailAddress.equals(dbEmailAddress)) {
			report.updateTestLog("validatePersonDetails",
					"REST EmailAddress => " + restEmailAddress + ". DB EmailAddress => " + dbEmailAddress, Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST EmailAddress => " + restEmailAddress + ". DB EmailAddress => " + dbEmailAddress, Status.FAIL);
		}
		if (restType.equals(dbType)) {
			report.updateTestLog("validatePersonDetails", "REST Type => " + restType + ". DB Type => " + dbType,
					Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails", "REST Type => " + restType + ". DB Type => " + dbType,
					Status.FAIL);
		}
		if (restEmailAddress1.equals(dbEmailAddress1)) {
			report.updateTestLog("validatePersonDetails",
					"REST EmailAddress => " + restEmailAddress1 + ". DB EmailAddress => " + dbEmailAddress1,
					Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails",
					"REST EmailAddress => " + restEmailAddress1 + ". DB EmailAddress => " + dbEmailAddress1,
					Status.FAIL);
		}
		if (restType1.equals(dbType1)) {
			report.updateTestLog("validatePersonDetails", "REST Type => " + restType1 + ". DB Type => " + dbType1,
					Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetails", "REST Type => " + restType1 + ". DB Type => " + dbType1,
					Status.FAIL);
		}

	}

	public void restMemberCallForIdentifiers() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1") + dataTable.getData("INT_DataSheet", "MemberGenKey")
				+ "/" + dataTable.getData("INT_DataSheet", "PageRequestCriteria");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restMemberGenKey = extractTagValue(response, "memberGenKey", SERVICEFORMAT.JSON);
		restMasterPersonId = extractTagValue(response, "masterPersonId", SERVICEFORMAT.JSON);
		restGo365EntityKey = extractTagValue(response, "go365EntityKey", SERVICEFORMAT.JSON);
		restMedicareId = extractTagValue(response, "medicareId", SERVICEFORMAT.JSON);
		restSSN = extractTagValue(response, "ssn", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestMemberGenKey", restMemberGenKey);
		dataTable.putData("INT_DataSheet", "RestMasterPersonId", restMasterPersonId);
		dataTable.putData("INT_DataSheet", "RestGo365EntityKey", restGo365EntityKey);
		dataTable.putData("INT_DataSheet", "RestMedicareId", restMedicareId);
		dataTable.putData("INT_DataSheet", "RestSSN", restSSN);

	}

	public void mangoDBDataRetreiveIdentifiers() {

		String DatabaseName = dataTable.getData("General_Data", "DatabaseName");
		String UserName = dataTable.getData("General_Data", "UserName");
		char[] password = (dataTable.getData("General_Data", "Password")).toCharArray();

		String ReplicaSet1 = dataTable.getData("General_Data", "ReplicaSet1");
		String ReplicaSet2 = dataTable.getData("General_Data", "ReplicaSet2");
		String ReplicaSet3 = dataTable.getData("General_Data", "ReplicaSet3");

		String CollectionName = dataTable.getData("INT_DataSheet", "CollectionName");
		String QueryKey = dataTable.getData("INT_DataSheet", "QueryKey");
		String QueryValue = dataTable.getData("INT_DataSheet", "MemberGenKey");

		MongoCredential credential = MongoCredential.createCredential(UserName, DatabaseName, password);
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(true).build();
		MongoClient mongoClient = new MongoClient(Arrays.asList(new ServerAddress(ReplicaSet1),
				new ServerAddress(ReplicaSet2), new ServerAddress(ReplicaSet3)), Arrays.asList(credential), options);

		MongoDatabase database = mongoClient.getDatabase(DatabaseName);
		MongoCollection<Document> table = database.getCollection(CollectionName);

		FindIterable<Document> iterDocs = table.find(Filters.eq(QueryKey, QueryValue));

		for (Document iterdoc : iterDocs) {
			// System.out.println("Key-"+iterdoc.getString("key")+"- firstName
			// -"+iterdoc.getString("personGenKey"));

			dbMemberGenKey = iterdoc.getString("personGenKey");
			dbMasterPersonId = iterdoc.getString("masterPersonId");
			dbGo365EntityKey = iterdoc.getString("niExternalSystemEntityId");
			dbMedicareId = iterdoc.getString("medicareId");
			dbSSN = iterdoc.getString("ssn");

			// write it in the excel
			dataTable.putData("INT_DataSheet", "DBMemberGenKey", dbMemberGenKey);
			dataTable.putData("INT_DataSheet", "DBMasterPersonId", dbMasterPersonId);
			dataTable.putData("INT_DataSheet", "DBGo365EntityKey", dbGo365EntityKey);
			dataTable.putData("INT_DataSheet", "DBMedicareId", dbMedicareId);
			dataTable.putData("INT_DataSheet", "DBSSN", dbSSN);

		}

		mongoClient.close();
	}

	public void validatePersonDetailsForIdentifiers() {

		restMemberGenKey = dataTable.getData("INT_DataSheet", "RestMemberGenKey");
		restMasterPersonId = dataTable.getData("INT_DataSheet", "RestMasterPersonId");
		restGo365EntityKey = dataTable.getData("INT_DataSheet", "RestGo365EntityKey");
		restMedicareId = dataTable.getData("INT_DataSheet", "RestMedicareId");
		restSSN = dataTable.getData("INT_DataSheet", "RestSSN");

		dbMemberGenKey = dataTable.getData("INT_DataSheet", "DBMemberGenKey");
		dbMasterPersonId = dataTable.getData("INT_DataSheet", "DBMasterPersonId");
		dbGo365EntityKey = dataTable.getData("INT_DataSheet", "DBGo365EntityKey");
		dbMedicareId = dataTable.getData("INT_DataSheet", "DBMedicareId");
		dbSSN = dataTable.getData("INT_DataSheet", "DBSSN");

		if (restMemberGenKey.equals(dbMemberGenKey)) {
			report.updateTestLog("validatePersonDetailsForMemberGenKey",
					"REST MemberGenKey => " + restMemberGenKey + ". DB MemberGenKey => " + dbMemberGenKey, "",
					Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetailsForMemberGenKey",
					"REST MemberGenKey => " + restMemberGenKey + ". DB MemberGenKey => " + dbMemberGenKey, "",
					Status.FAIL);
		}
		if (restMasterPersonId.equals(dbMasterPersonId)) {
			report.updateTestLog("validatePersonDetailsForMasterPersonId",
					"REST MasterPersonId => " + restMasterPersonId + ". DB MasterPersonId => " + dbMasterPersonId, "",
					Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetailsForMasterPersonId",
					"REST MasterPersonId => " + restMasterPersonId + ". DB MasterPersonId => " + dbMasterPersonId, "",
					Status.FAIL);
		}
		if (restGo365EntityKey.equals(dbGo365EntityKey)) {
			report.updateTestLog("validatePersonDetailsForGo365EntityKey",
					"REST Go365EntityKey => " + restGo365EntityKey + ". DB Go365EntityKey => " + dbGo365EntityKey, "",
					Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetailsForGo365EntityKey",
					"REST Go365EntityKey=> " + restGo365EntityKey + ". DB Go365EntityKey => " + dbGo365EntityKey, "",
					Status.FAIL);
		}
		if (restMedicareId.equals(dbMedicareId)) {
			report.updateTestLog("validatePersonDetailsForMedicareId",
					"REST MedicareId => " + restMedicareId + ". DB MedicareId => " + dbMedicareId, "", Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetailsForMedicareId",
					"REST MedicareId => " + restMedicareId + ". DB MedicareId => " + dbMedicareId, "", Status.FAIL);
		}
		if (restMasterPersonId.equals(dbMasterPersonId)) {
			report.updateTestLog("validatePersonDetailsForSSN", "REST SSN => " + restSSN + ". DB SSN => " + dbSSN, "",
					Status.PASS);
		} else {
			report.updateTestLog("validatePersonDetailsForSSN", "REST SSN => " + restSSN + ". DB SSN => " + dbSSN, "",
					Status.FAIL);
		}

	}

	public void restMemberCallForPlatformIdentifiers() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1") + dataTable.getData("INT_DataSheet", "MemberGenKey")
				+ "/" + dataTable.getData("INT_DataSheet", "PageRequestCriteria");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restPlatform = extractTagValue(response, "platform", 0, SERVICEFORMAT.JSON);
		restId = extractTagValue(response, "id", 0, SERVICEFORMAT.JSON);
		restPlatform1 = extractTagValue(response, "platform", 1, SERVICEFORMAT.JSON);
		restId1 = extractTagValue(response, "id", 1, SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestPlatform", restPlatform);
		dataTable.putData("INT_DataSheet", "RestId", restId);
		dataTable.putData("INT_DataSheet", "RestPlatform1", restPlatform1);
		dataTable.putData("INT_DataSheet", "RestId1", restId1);
	}

	public void mangoDBDataPlatformIdentifiers() {

		String DatabaseName = dataTable.getData("General_Data", "DatabaseName");
		String UserName = dataTable.getData("General_Data", "UserName");
		char[] password = (dataTable.getData("General_Data", "Password")).toCharArray();

		String ReplicaSet1 = dataTable.getData("General_Data", "ReplicaSet1");
		String ReplicaSet2 = dataTable.getData("General_Data", "ReplicaSet2");
		String ReplicaSet3 = dataTable.getData("General_Data", "ReplicaSet3");

		String CollectionName = dataTable.getData("INT_DataSheet", "CollectionName");
		String QueryKey = dataTable.getData("INT_DataSheet", "QueryKey");
		String QueryValue = dataTable.getData("INT_DataSheet", "MemberGenKey");

		MongoCredential credential = MongoCredential.createCredential(UserName, DatabaseName, password);
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(true).build();
		MongoClient mongoClient = new MongoClient(Arrays.asList(new ServerAddress(ReplicaSet1),
				new ServerAddress(ReplicaSet2), new ServerAddress(ReplicaSet3)), Arrays.asList(credential), options);

		MongoDatabase database = mongoClient.getDatabase(DatabaseName);
		MongoCollection<Document> table = database.getCollection(CollectionName);

		FindIterable<Document> iterDocs = table.find(Filters.eq(QueryKey, QueryValue));

		for (Document iterdoc : iterDocs) {
			dbMasterPersonId = iterdoc.getString("masterPersonId");

			// write it in the excel
			dataTable.putData("INT_DataSheet", "DBMasterPersonId", dbMasterPersonId);

		}

		mongoClient.close();
		dummy();
	}

	public void dummy() {
		String DatabaseName = dataTable.getData("General_Data", "DatabaseName");
		String UserName = dataTable.getData("General_Data", "UserName");
		char[] password = (dataTable.getData("General_Data", "Password")).toCharArray();

		String ReplicaSet1 = dataTable.getData("General_Data", "ReplicaSet1");
		String ReplicaSet2 = dataTable.getData("General_Data", "ReplicaSet2");
		String ReplicaSet3 = dataTable.getData("General_Data", "ReplicaSet3");
		MongoCredential credential = MongoCredential.createCredential(UserName, DatabaseName, password);
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(true).build();

		MongoClient mongoClient = new MongoClient(Arrays.asList(new ServerAddress(ReplicaSet1),
				new ServerAddress(ReplicaSet2), new ServerAddress(ReplicaSet3)), Arrays.asList(credential), options);

		String CollectionName1 = dataTable.getData("INT_DataSheet", "CollectionName1");
		String QueryKey1 = dataTable.getData("INT_DataSheet", "QueryKey1");
		String QueryValue1 = dataTable.getData("INT_DataSheet", "DBMasterPersonId");
		MongoDatabase database = mongoClient.getDatabase(DatabaseName);
		MongoCollection<Document> table1 = database.getCollection(CollectionName1);
		FindIterable<Document> iterDocs1 = table1.find(Filters.eq(QueryKey1, QueryValue1));

		for (Document iterdoc1 : iterDocs1) {

			dbPlatform = iterdoc1.getString("platform");
			dbId = iterdoc1.getString("memberSourcePersonId");

			if (dbPlatform.equalsIgnoreCase("EM")) {
				// write it in the excel
				dataTable.putData("INT_DataSheet", "DBPlatform", dbPlatform);
				dataTable.putData("INT_DataSheet", "DBId", dbId);
			} else {

				// write it in the excel
				dataTable.putData("INT_DataSheet", "DBPlatform1", dbPlatform);
				dataTable.putData("INT_DataSheet", "DBId1", dbId);
			}

		}
		mongoClient.close();
	}

	public void validatePersonDetailsForPlatformIdentifiers() {

		restPlatform = dataTable.getData("INT_DataSheet", "RestPlatform");
		restId = dataTable.getData("INT_DataSheet", "RestId");
		restPlatform1 = dataTable.getData("INT_DataSheet", "RestPlatform1");
		restId1 = dataTable.getData("INT_DataSheet", "RestId1");

		dbPlatform = dataTable.getData("INT_DataSheet", "DBPlatform");
		dbId = dataTable.getData("INT_DataSheet", "DBId");
		dbPlatform1 = dataTable.getData("INT_DataSheet", "DBPlatform1");
		dbId1 = dataTable.getData("INT_DataSheet", "DBId1");

		if (restPlatform.equals(dbPlatform)) {
			report.updateTestLog("Validation of person Platform",
					"REST Platform => " + restPlatform + ". DB Platform => " + dbPlatform, "", Status.PASS);
		} else {
			report.updateTestLog("Validation of person Platform",
					"REST Platform => " + restPlatform + ". DB Platform => " + dbPlatform, "", Status.FAIL);
		}
		if (restId.equals(dbId)) {
			report.updateTestLog("Validation of personId", "REST Id => " + restId + ". DB Id => " + dbId, "",
					Status.PASS);
		} else {
			report.updateTestLog("Validation of personId", "REST Id => " + restId + ". DB Id => " + dbId, "",
					Status.FAIL);
		}
		if (restPlatform1.equals(dbPlatform1)) {
			report.updateTestLog("Validation of person Platform",
					"REST Platform => " + restPlatform1 + ". DB Platform => " + dbPlatform1, "", Status.PASS);
		} else {
			report.updateTestLog("Validation of person Platform",
					"REST Platform => " + restPlatform1 + ". DB Platform => " + dbPlatform1, "", Status.FAIL);
		}

		if (restId1.equals(dbId1)) {
			report.updateTestLog("Validation of personId", "REST Id => " + restId1 + ". DB Id => " + dbId1, "",
					Status.PASS);
		} else {
			report.updateTestLog("Validation of personId", "REST Id => " + restId1 + ". DB Id => " + dbId1, "",
					Status.FAIL);
		}

	}

	public void restMemberCallForPlatformLis() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1") + dataTable.getData("INT_DataSheet", "MemberGenKey")
				+ "/" + dataTable.getData("INT_DataSheet", "PageRequestCriteria");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restCopayLevelCode = extractTagValue(response, "copayLevelCode", SERVICEFORMAT.JSON);
		restCopayPercent = extractTagValue(response, "copayPercent", SERVICEFORMAT.JSON);
		restEffectiveDate = extractTagValue(response, "effectiveDate", SERVICEFORMAT.JSON);
		restEndDate = extractTagValue(response, "endDate", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestCopayLevelCode", restCopayLevelCode);
		dataTable.putData("INT_DataSheet", "RestCopayPercent", restCopayPercent);
		dataTable.putData("INT_DataSheet", "RestEffectiveDate", restEffectiveDate);
		dataTable.putData("INT_DataSheet", "RestEndDate", restEndDate);

	}

	public void mangoDBDataPlatformLis() {

		String DatabaseName = dataTable.getData("General_Data", "DatabaseName");
		String UserName = dataTable.getData("General_Data", "UserName");
		char[] password = (dataTable.getData("General_Data", "Password")).toCharArray();

		String ReplicaSet1 = dataTable.getData("General_Data", "ReplicaSet1");
		String ReplicaSet2 = dataTable.getData("General_Data", "ReplicaSet2");
		String ReplicaSet3 = dataTable.getData("General_Data", "ReplicaSet3");

		String CollectionName = dataTable.getData("INT_DataSheet", "CollectionName");
		String QueryKey = dataTable.getData("INT_DataSheet", "QueryKey");
		String QueryValue = dataTable.getData("INT_DataSheet", "DBMasterPersonId");

		MongoCredential credential = MongoCredential.createCredential(UserName, DatabaseName, password);
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(true).build();
		MongoClient mongoClient = new MongoClient(Arrays.asList(new ServerAddress(ReplicaSet1),
				new ServerAddress(ReplicaSet2), new ServerAddress(ReplicaSet3)), Arrays.asList(credential), options);

		MongoDatabase database = mongoClient.getDatabase(DatabaseName);
		MongoCollection<Document> table = database.getCollection(CollectionName);

		FindIterable<Document> iterDocs = table.find(Filters.eq(QueryKey, QueryValue));

		for (Document iterdoc : iterDocs) {
			// System.out.println("Key-"+iterdoc.getString("key")+"- firstName
			// -"+iterdoc.getString("personGenKey"));

			dbCopayLevel = iterdoc.getString("copayLevel");
			dbPercent = iterdoc.getString("percent");
			dbEndDate = iterdoc.getDate("endDate");
			dbEffectiveDate = iterdoc.getDate("effectiveDate");

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String EffectiveDate = dateFormat.format(dbEffectiveDate);
			String EndDate = dateFormat.format(dbEndDate);

			// write it in the excel
			dataTable.putData("INT_DataSheet", "DBCopayLevel", dbCopayLevel);
			dataTable.putData("INT_DataSheet", "DBPercent", dbPercent);
			dataTable.putData("INT_DataSheet", "DBEffectiveDate", EffectiveDate);
			dataTable.putData("INT_DataSheet", "DBEndDate", EndDate);

		}

		mongoClient.close();

	}

	public void validatePersonDetailsForPlatformLis() {
		String date = "";
		restCopayLevelCode = dataTable.getData("INT_DataSheet", "RestCopayLevelCode");
		restCopayPercent = dataTable.getData("INT_DataSheet", "RestCopayPercent");
		restEffectiveDate = dataTable.getData("INT_DataSheet", "RestEffectiveDate");
		restEndDate = dataTable.getData("INT_DataSheet", "RestEndDate");
		if (restEndDate.equals("null")) {
			date = "9999-12-31";
		}
		dbCopayLevel = dataTable.getData("INT_DataSheet", "DBCopayLevel");
		dbPercent = dataTable.getData("INT_DataSheet", "DBPercent");
		String dbEffectiveDate = dataTable.getData("INT_DataSheet", "DBEffectiveDate");
		String dbEndDate = dataTable.getData("INT_DataSheet", "DBEndDate");

		if (restCopayLevelCode.equals(dbCopayLevel)) {
			report.updateTestLog("Validation of person CopayLevel ",
					"REST CopayLevel => " + restCopayLevelCode + ". DB CopayLevel => " + dbCopayLevel, "", Status.PASS);
		} else {
			report.updateTestLog("Validation of person CopayLevel",
					"REST CopayLevel => " + restCopayLevelCode + ". DB CopayLevel => " + dbCopayLevel, "", Status.FAIL);
		}
		if (restCopayPercent.equals(dbPercent)) {
			report.updateTestLog("Validation of person CopayPercent",
					"REST CopayPercent => " + restCopayPercent + ". DB Percent => " + dbPercent, "", Status.PASS);
		} else {
			report.updateTestLog("Validation of person CopayPercent",
					"REST CopayPercent => " + restCopayPercent + ". DB Percent => " + dbPercent, "", Status.FAIL);
		}

		if (restEffectiveDate.equals(dbEffectiveDate)) {
			report.updateTestLog("Validation of person EffectiveDate",
					"REST EffectiveDate => " + restEffectiveDate + ". DB EffectiveDate => " + dbEffectiveDate, "",
					Status.PASS);
		} else {
			report.updateTestLog("Validation of person EffectiveDate",
					"REST EffectiveDate => " + restEffectiveDate + ". DB EffectiveDate => " + dbEffectiveDate, "",
					Status.FAIL);
		}

		if (date.equals(dbEndDate)) {
			report.updateTestLog("Validation of person EndDate",
					"REST EndDate => " + date + ". DB EndDate => " + dbEndDate, "", Status.PASS);
		} else {
			report.updateTestLog("Validation of person EndDate",
					"REST EndDate => " + date + ". DB EndDate => " + dbEndDate, "", Status.FAIL);
		}

	}

	public void restMemberCallForBlankResponse() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 404);

	}

	public void restMemberCallForProductSupplementalRiders() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restid0 = extractTagValue(response, "id", 0, SERVICEFORMAT.JSON);
		restvendorId0 = extractTagValue(response, "vendorId", 0, SERVICEFORMAT.JSON);
		resttypeCode0 = extractTagValue(response, "typeCode", 0, SERVICEFORMAT.JSON);
		restid1 = extractTagValue(response, "id", 1, SERVICEFORMAT.JSON);
		restvendorId1 = extractTagValue(response, "vendorId", 1, SERVICEFORMAT.JSON);
		resttypeCode1 = extractTagValue(response, "typeCode", 1, SERVICEFORMAT.JSON);
		restid2 = extractTagValue(response, "id", 2, SERVICEFORMAT.JSON);
		restvendorId2 = extractTagValue(response, "vendorId", 2, SERVICEFORMAT.JSON);
		resttypeCode2 = extractTagValue(response, "typeCode", 2, SERVICEFORMAT.JSON);
		restid3 = extractTagValue(response, "id", 3, SERVICEFORMAT.JSON);
		restvendorId3 = extractTagValue(response, "vendorId", 3, SERVICEFORMAT.JSON);
		resttypeCode3 = extractTagValue(response, "typeCode", 3, SERVICEFORMAT.JSON);
		restid4 = extractTagValue(response, "id", 4, SERVICEFORMAT.JSON);
		restvendorId4 = extractTagValue(response, "vendorId", 4, SERVICEFORMAT.JSON);
		resttypeCode4 = extractTagValue(response, "typeCode", 4, SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestID_0", restid0);
		dataTable.putData("INT_DataSheet", "RestVendorID_0", restvendorId0);
		dataTable.putData("INT_DataSheet", "RestTypeCode_0", resttypeCode0);
		dataTable.putData("INT_DataSheet", "RestID_1", restid1);
		dataTable.putData("INT_DataSheet", "RestVendorID_1", restvendorId1);
		dataTable.putData("INT_DataSheet", "RestTypeCode_1", resttypeCode1);
		dataTable.putData("INT_DataSheet", "RestID_2", restid2);
		dataTable.putData("INT_DataSheet", "RestVendorID_2", restvendorId2);
		dataTable.putData("INT_DataSheet", "RestTypeCode_2", resttypeCode2);
		dataTable.putData("INT_DataSheet", "RestID_3", restid3);
		dataTable.putData("INT_DataSheet", "RestVendorID_3", restvendorId3);
		dataTable.putData("INT_DataSheet", "RestTypeCode_3", resttypeCode3);
		dataTable.putData("INT_DataSheet", "RestID_4", restid4);
		dataTable.putData("INT_DataSheet", "RestVendorID_4", restvendorId4);
		dataTable.putData("INT_DataSheet", "RestTypeCode_4", resttypeCode4);

		report.updateTestLog("ValidateResponse", "REST Id => " + restid0 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST VendorId => " + restvendorId0 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST TypeCode => " + resttypeCode0 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST Id => " + restid1 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST VendorId => " + restvendorId1 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST TypeCode => " + resttypeCode1 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST Id => " + restid2 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST VendorId => " + restvendorId2 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST TypeCode => " + resttypeCode2 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST Id => " + restid3 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST VendorId => " + restvendorId3 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST TypeCode => " + resttypeCode3 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST Id => " + restid4 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST VendorId => " + restvendorId4 + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "REST TypeCode => " + resttypeCode4 + "", Status.PASS);

	}

	public void restMemberCallForOSBS() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		reststartDate = extractTagValue(response, "startDate", SERVICEFORMAT.JSON);
		restendDate = extractTagValue(response, "endDate", SERVICEFORMAT.JSON);
		restitemCode = extractTagValue(response, "itemCode", SERVICEFORMAT.JSON);
		restitemTypeCode = extractTagValue(response, "itemTypeCode", SERVICEFORMAT.JSON);
		restcategoryDescription = extractTagValue(response, "categoryDescription", SERVICEFORMAT.JSON);
		restpackageKey = extractTagValue(response, "packageKey", SERVICEFORMAT.JSON);
		restpackageName = extractTagValue(response, "packageName", SERVICEFORMAT.JSON);
		if (restendDate.equals("null")) {
			restEndDate = "9999-12-31";
		}

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestStartDate", reststartDate);
		dataTable.putData("INT_DataSheet", "RestEndDate", restEndDate);
		dataTable.putData("INT_DataSheet", "RestItemCode", restitemCode);
		dataTable.putData("INT_DataSheet", "RestItemTypeCode", restitemTypeCode);
		dataTable.putData("INT_DataSheet", "RestCategoryDescription", restcategoryDescription);
		dataTable.putData("INT_DataSheet", "RestPackageKey", restpackageKey);
		dataTable.putData("INT_DataSheet", "RestPackageName", restpackageName);

		report.updateTestLog("Validation of StartDate", "Rest StartDate => " + reststartDate + "", Status.PASS);
		report.updateTestLog("Validation of EndDate", "Rest EndDate => " + restEndDate + "", Status.PASS);
		report.updateTestLog("Validation of ItemCode", "Rest ItemCode => " + restitemCode + "", Status.PASS);
		report.updateTestLog("Validation of ItemTypeCode", "Rest ItemTypeCode=> " + restitemTypeCode + "", Status.PASS);
		report.updateTestLog("Validation of CategoryDescription",
				"Rest CategoryDescription => " + restcategoryDescription + "", Status.PASS);
		report.updateTestLog("Validation of PackageKey", "Rest PackageKey => " + restpackageKey + "", Status.PASS);
		report.updateTestLog("Validation of PackageName", "Rest PackageName => " + restpackageName + "", Status.PASS);

	}

	public void restMemberCallForProduct() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restId = extractTagValue(response, "id", SERVICEFORMAT.JSON);
		restdescription = extractTagValue(response, "description", SERVICEFORMAT.JSON);
		restalternateDescription = extractTagValue(response, "alternateDescription", SERVICEFORMAT.JSON);
		reststartDate = extractTagValue(response, "startDate", SERVICEFORMAT.JSON);
		restEndDate = extractTagValue(response, "endDate", SERVICEFORMAT.JSON);
		restsource = extractTagValue(response, "source", SERVICEFORMAT.JSON);
		restproductLineCode = extractTagValue(response, "productLineCode", SERVICEFORMAT.JSON);
		restproductLineDescription = extractTagValue(response, "productLineDescription", SERVICEFORMAT.JSON);
		restproductTypeCode = extractTagValue(response, "productTypeCode", SERVICEFORMAT.JSON);
		restsegmentType = extractTagValue(response, "segmentType", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode = extractTagValue(response, "majorLineOfBusinessCode", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription = extractTagValue(response, "majorLineOfBusinessDescription",
				SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestId", restId);
		dataTable.putData("INT_DataSheet", "RestDescription", restdescription);
		dataTable.putData("INT_DataSheet", "RestAlternateDescription", restalternateDescription);
		dataTable.putData("INT_DataSheet", "RestStartDate", reststartDate);
		dataTable.putData("INT_DataSheet", "RestEndDate", restEndDate);
		dataTable.putData("INT_DataSheet", "RestSource", restsource);
		dataTable.putData("INT_DataSheet", "RestProductLineCode", restproductLineCode);
		dataTable.putData("INT_DataSheet", "RestProductLineDescription", restproductLineDescription);
		dataTable.putData("INT_DataSheet", "RestProductTypeCode", restproductTypeCode);
		dataTable.putData("INT_DataSheet", "RestSegmentType", restsegmentType);
		dataTable.putData("INT_DataSheet", "RestMajorLineOfBusinessCode", restmajorLineOfBusinessCode);
		dataTable.putData("INT_DataSheet", "RestMajorLineOfBusinessDescription", restmajorLineOfBusinessDescription);

		report.updateTestLog("ValidateResponse", "Rest Id => " + restId + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest Description => " + restdescription + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest AlternateDescription => " + restalternateDescription + "",
				Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest StartDate> " + reststartDate + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest EndDate => " + restEndDate + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest Source => " + restsource + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest ProductLineCode => " + restproductLineCode + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest ProductLineDescription => " + restproductLineDescription + "",
				Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest ProductTypeCode => " + restproductTypeCode + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest SegmentType => " + restsegmentType + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest MajorLineOfBusinessCode=> " + restmajorLineOfBusinessCode + "",
				Status.PASS);
		report.updateTestLog("ValidateResponse",
				"Rest MajorLineOfBusinessDescription => " + restmajorLineOfBusinessDescription + "", Status.PASS);

	}

	public void restMemberCallForGroupCoverage() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response

		restgroupIdentifiergroupId = extractTagValue(response, "groupIdentifier", "groupId", SERVICEFORMAT.JSON);
		restgroupIdentifierdivisionId = extractTagValue(response, "groupIdentifier", "divisionId", SERVICEFORMAT.JSON);
		restgroupIdentifierkey = extractTagValue(response, "groupIdentifier", "key", SERVICEFORMAT.JSON);
		restgroupIdentifierplatform = extractTagValue(response, "groupIdentifier", "platform", SERVICEFORMAT.JSON);
		restgroupIdentifierdisplayGroupId = extractTagValue(response, "groupIdentifier", "displayGroupId",
				SERVICEFORMAT.JSON);
		restproductIdentifierproductId = extractTagValue(response, "productIdentifier", "productId",
				SERVICEFORMAT.JSON);
		restproductIdentifierstartDate = extractTagValue(response, "productIdentifier", "startDate",
				SERVICEFORMAT.JSON);
		restproductIdentifierplatform = extractTagValue(response, "productIdentifier", "platform", SERVICEFORMAT.JSON);
		restproductIdentifierkey = extractTagValue(response, "productIdentifier", "key", SERVICEFORMAT.JSON);
		restplancategory = extractTagValue(response, "plan", "category", SERVICEFORMAT.JSON);
		restplansubCategory = extractTagValue(response, "plan", "subCategory", SERVICEFORMAT.JSON);
		restplanlineOfBusiness = extractTagValue(response, "plan", "lineOfBusiness", SERVICEFORMAT.JSON);
		reststartDate = extractTagValue(response, "startDate", SERVICEFORMAT.JSON);
		restendDate = extractTagValue(response, "endDate", SERVICEFORMAT.JSON);
		restcoverageType = extractTagValue(response, "coverageType", SERVICEFORMAT.JSON);
		restbusinessLevel5 = extractTagValue(response, "businessLevel5", SERVICEFORMAT.JSON);
		restbusinessLevel6 = extractTagValue(response, "businessLevel6", SERVICEFORMAT.JSON);
		restbusinessLevel7 = extractTagValue(response, "businessLevel7", SERVICEFORMAT.JSON);
		restmarketsellingMarketNumber = extractTagValue(response, "market", "sellingMarketNumber", SERVICEFORMAT.JSON);
		restmarketserviceMarketNumber = extractTagValue(response, "market", "serviceMarketNumber", SERVICEFORMAT.JSON);
		restmarketsellingMarketDescription = extractTagValue(response, "market", "sellingMarketDescription",
				SERVICEFORMAT.JSON);
		restmarketserviceMarketDescription = extractTagValue(response, "market", "serviceMarketDescription",
				SERVICEFORMAT.JSON);
		restmarketsellingConsolidatedMarketNumber = extractTagValue(response, "market",
				"sellingConsolidatedMarketNumber", SERVICEFORMAT.JSON);
		restmarketserviceConsolidatedMarketNumber = extractTagValue(response, "market",
				"serviceConsolidatedMarketNumber", SERVICEFORMAT.JSON);
		restmarketsellingMarketFinancialProductCode = extractTagValue(response, "market",
				"sellingMarketFinancialProductCode", SERVICEFORMAT.JSON);
		restledgersellingLedgerNumber = extractTagValue(response, "ledger", "sellingLedgerNumber", SERVICEFORMAT.JSON);
		restledgerserviceLedgerNumber = extractTagValue(response, "ledger", "serviceLedgerNumber", SERVICEFORMAT.JSON);
		restledgersellingLedgerDescription = extractTagValue(response, "ledger", "sellingLedgerDescription",
				SERVICEFORMAT.JSON);
		restledgerserviceLedgerDescription = extractTagValue(response, "ledger", "serviceLedgerDescription",
				SERVICEFORMAT.JSON);
		restmedicareContractId = extractTagValue(response, "medicareContractId", SERVICEFORMAT.JSON);
		restmedicarePbpId = extractTagValue(response, "medicarePbpId", SERVICEFORMAT.JSON);
		restmedicareSegmentId = extractTagValue(response, "medicarePbpId", SERVICEFORMAT.JSON);

		if (restendDate.equals("null")) {
			restEndDate = "9999-12-31";
		}

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierGroupId", restgroupIdentifiergroupId);
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierDivisionId", restgroupIdentifierdivisionId);
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierKey", restgroupIdentifierkey);
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierPlatform", restgroupIdentifierplatform);
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierDisplayGroupId", restgroupIdentifierdisplayGroupId);
		dataTable.putData("INT_DataSheet", "RestProductIdentifierProductId", restproductIdentifierproductId);
		dataTable.putData("INT_DataSheet", "RestProductIdentifierStartDate", restproductIdentifierstartDate);
		dataTable.putData("INT_DataSheet", "RestProductIdentifierPlatform", restproductIdentifierplatform);
		dataTable.putData("INT_DataSheet", "RestProductIdentifierKey", restproductIdentifierkey);
		dataTable.putData("INT_DataSheet", "RestPlanCategory", restplancategory);
		dataTable.putData("INT_DataSheet", "RestPlanSubCategory", restplansubCategory);
		dataTable.putData("INT_DataSheet", "RestPlanLineOfBusiness", restplanlineOfBusiness);
		dataTable.putData("INT_DataSheet", "RestStartDate", reststartDate);
		dataTable.putData("INT_DataSheet", "RestEndDate", restEndDate);
		dataTable.putData("INT_DataSheet", "RestCoverageType", restcoverageType);
		dataTable.putData("INT_DataSheet", "RestBusinessLevel5", restbusinessLevel5);
		dataTable.putData("INT_DataSheet", "RestBusinessLevel6", restbusinessLevel6);
		dataTable.putData("INT_DataSheet", "RestBusinessLevel7", restbusinessLevel7);
		dataTable.putData("INT_DataSheet", "RestMarketSellingMarketNumber", restmarketsellingMarketNumber);
		dataTable.putData("INT_DataSheet", "RestMarketServiceMarketNumber", restmarketserviceMarketNumber);
		dataTable.putData("INT_DataSheet", "RestMarketSellingMarketDescription", restmarketsellingMarketDescription);
		dataTable.putData("INT_DataSheet", "RestMarketServiceMarketDescription", restmarketserviceMarketDescription);
		dataTable.putData("INT_DataSheet", "RestMarketSellingConsolidatedMarketNumber",
				restmarketsellingConsolidatedMarketNumber);
		dataTable.putData("INT_DataSheet", "RestMarketServiceConsolidatedMarketNumber",
				restmarketserviceConsolidatedMarketNumber);
		dataTable.putData("INT_DataSheet", "RestMarketSellingMarketFinancialProductCode",
				restmarketsellingMarketFinancialProductCode);
		dataTable.putData("INT_DataSheet", "RestLedgerSellingLedgerNumber", restledgersellingLedgerNumber);
		dataTable.putData("INT_DataSheet", "RestLedgerServiceLedgerNumber", restledgerserviceLedgerNumber);
		dataTable.putData("INT_DataSheet", "RestLedgerSellingLedgerDescription", restledgersellingLedgerDescription);
		dataTable.putData("INT_DataSheet", "RestLedgerServiceLedgerDescription", restledgerserviceLedgerDescription);
		dataTable.putData("INT_DataSheet", "RestMedicareContractId", restmedicareContractId);
		dataTable.putData("INT_DataSheet", "RestMedicarePbpId", restmedicarePbpId);
		dataTable.putData("INT_DataSheet", "RestMedicareSegmentId", restmedicareSegmentId);

		report.updateTestLog("Validation of GroupId Present in GroupIdentifier",
				"RestGroupIdentifierGroupId => " + restgroupIdentifiergroupId + "", Status.PASS);
		report.updateTestLog("Validation of DivisionId Present in GroupIdentifier",
				"RestGroupIdentifierDivisionId => " + restgroupIdentifierdivisionId + "", Status.PASS);
		report.updateTestLog("Validation of Key Present in GroupIdentifier",
				"RestGroupIdentifierKey => " + restgroupIdentifierkey + "", Status.PASS);
		report.updateTestLog("Validation of Platform Present in GroupIdentifier",
				"RestGroupIdentifierPlatform => " + restgroupIdentifierplatform + "", Status.PASS);
		report.updateTestLog("Validation of DisplayGroupId Present in GroupIdentifier",
				"RestGroupIdentifierDisplayGroupId => " + restgroupIdentifierdisplayGroupId + "", Status.PASS);
		report.updateTestLog("Validation of ProductId Present in ProductIdentifier",
				"RestProductIdentifierProductId => " + restproductIdentifierproductId + "", Status.PASS);
		report.updateTestLog("Validation of StartDate Present in ProductIdentifier",
				"RestProductIdentifierStartDate => " + restproductIdentifierstartDate + "", Status.PASS);
		report.updateTestLog("Validation of Platform Present in ProductIdentifier",
				"RestProductIdentifierPlatform => " + restproductIdentifierplatform + "", Status.PASS);
		report.updateTestLog("Validation of Key Present in ProductIdentifier",
				"RestProductIdentifierKey => " + restproductIdentifierkey + "", Status.PASS);
		report.updateTestLog("Validation of Category Present in Plan", "RestPlanCategory => " + restplancategory + "",
				Status.PASS);
		report.updateTestLog("Validation of SubCategory Present in Plan",
				"RestPlanSubCategory=> " + restplansubCategory + "", Status.PASS);
		report.updateTestLog("Validation of LineofBusiness Present in Plan",
				"RestPlanLineOfBusiness => " + restplanlineOfBusiness + "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "RestStartDate => " + reststartDate + "", Status.PASS);
		report.updateTestLog("Validation of EndDate", "RestEndDate => " + restEndDate + "", Status.PASS);
		report.updateTestLog("Validation of CoverageType", "RestCoverageType => " + restcoverageType + "", Status.PASS);
		report.updateTestLog("Validation of BusinessLevel5", "RestBusinessLevel5 => " + restbusinessLevel5 + "",
				Status.PASS);
		report.updateTestLog("Validation of BusinessLevel6 ", "RestBusinessLevel6 => " + restbusinessLevel6 + "",
				Status.PASS);
		report.updateTestLog("Validation of BusinessLevel7", "RestBusinessLevel7 => " + restbusinessLevel7 + "",
				Status.PASS);
		report.updateTestLog("Validation of SellingMarketNumber Present in Market",
				"RestMarketSellingMarketNumber => " + restmarketsellingMarketNumber + "", Status.PASS);
		report.updateTestLog("Validation of ServiceMarketNumber Present in Market",
				"RestMarketServiceMarketNumber => " + restmarketserviceMarketNumber + "", Status.PASS);
		report.updateTestLog("Validation of SellingMarketDescription Present in Market",
				"RestMarketSellingMarketDescription => " + restmarketsellingMarketDescription + "", Status.PASS);
		report.updateTestLog("Validation of ServiceMarketDescription Present in Market",
				"RestMarketServiceMarketDescription => " + restmarketserviceMarketDescription + "", Status.PASS);
		report.updateTestLog("Validation of SellingConsolidatedMarketNumber Present in Market",
				"RestMarketSellingConsolidatedMarketNumber => " + restmarketsellingConsolidatedMarketNumber + "",
				Status.PASS);
		report.updateTestLog("Validation of ServiceConsolidatedMarketNumber Present in Market",
				"RestMarketServiceConsolidatedMarketNumber => " + restmarketserviceConsolidatedMarketNumber + "",
				Status.PASS);

		report.updateTestLog("Validation of SellingMarketFinancialProductCode Present in Market",
				"RestMarketSellingMarketFinancialProductCode => " + restmarketsellingMarketFinancialProductCode + "",
				Status.PASS);
		report.updateTestLog("Validation of SellingLedgerNumber Present in Ledger",
				"RestLedgerSellingLedgerNumber => " + restledgersellingLedgerNumber + "", Status.PASS);
		report.updateTestLog("Validation of ServiceLedgerNumber Present in Ledger",
				"RestLedgerServiceLedgerNumber => " + restledgerserviceLedgerNumber + "", Status.PASS);
		report.updateTestLog("Validation of SellingLedgerDescription Present in Ledger",
				"RestLedgerSellingLedgerDescription => " + restledgersellingLedgerDescription + "", Status.PASS);
		report.updateTestLog("Validation of ServiceLedgerDescription Present in Ledger",
				"RestLedgerServiceLedgerDescription => " + restledgerserviceLedgerDescription + "", Status.PASS);

		report.updateTestLog("Validation of MedicareContractId",
				"RestMedicareContractId => " + restmedicareContractId + "", Status.PASS);
		report.updateTestLog("Validation of MedicarePbpId", "RestMedicarePbpId => " + restmedicarePbpId + "",
				Status.PASS);
		report.updateTestLog("Validation of MedicareSegmentId",
				"RestMedicareSegmentId => " + restmedicareSegmentId + "", Status.PASS);

	}

	public void restMemberCallForGROUP() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response

		restgroupIdentifiergroupId = extractTagValue(response, "groupIdentifier", "groupId", SERVICEFORMAT.JSON);
		restgroupIdentifierdivisionId = extractTagValue(response, "groupIdentifier", "divisionId", SERVICEFORMAT.JSON);
		restgroupIdentifierkey = extractTagValue(response, "groupIdentifier", "key", SERVICEFORMAT.JSON);
		restgroupIdentifierplatform = extractTagValue(response, "groupIdentifier", "platform", SERVICEFORMAT.JSON);
		restgroupIdentifierghGroupId = extractTagValue(response, "groupIdentifier", "ghGroupId", SERVICEFORMAT.JSON);

		restname = extractTagValue(response, "name", SERVICEFORMAT.JSON);
		restplatform = extractTagValue(response, "platform", SERVICEFORMAT.JSON);
		restisAdministrativeServicesOnly = extractTagValue(response, "isAdministrativeServicesOnly",
				SERVICEFORMAT.JSON);
		restenterpriseEmployerPlatform = extractTagValue(response, "enterpriseEmployerPlatform", SERVICEFORMAT.JSON);
		restenterpriseEmployerId = extractTagValue(response, "enterpriseEmployerId", SERVICEFORMAT.JSON);
		restisDsnp = extractTagValue(response, "isDsnp", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierGroupId", restgroupIdentifiergroupId);
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierDivisionId", restgroupIdentifierdivisionId);
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierKey", restgroupIdentifierkey);
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierPlatform", restgroupIdentifierplatform);
		dataTable.putData("INT_DataSheet", "RestGroupIdentifierghGroupId", restgroupIdentifierghGroupId);
		dataTable.putData("INT_DataSheet", "RestName", restname);
		dataTable.putData("INT_DataSheet", "RestPlatform", restplatform);
		dataTable.putData("INT_DataSheet", "RestIsAdministrativeServicesOnly", restisAdministrativeServicesOnly);
		dataTable.putData("INT_DataSheet", "RestEnterpriseEmployerPlatform", restenterpriseEmployerPlatform);
		dataTable.putData("INT_DataSheet", "RestEnterpriseEmployerId", restenterpriseEmployerId);
		dataTable.putData("INT_DataSheet", "RestIsDsnp", restisDsnp);

		report.updateTestLog("ValidateResponse", "RestGroupIdentifierGroupId => " + restgroupIdentifiergroupId + "",
				Status.PASS);
		report.updateTestLog("ValidateResponse",
				"RestGroupIdentifierDivisionId => " + restgroupIdentifierdivisionId + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "RestGroupIdentifierKey => " + restgroupIdentifierkey + "",
				Status.PASS);
		report.updateTestLog("ValidateResponse", "RestGroupIdentifierPlatform => " + restgroupIdentifierplatform + "",
				Status.PASS);
		report.updateTestLog("ValidateResponse", "RestGroupIdentifierghGroupId => " + restgroupIdentifierghGroupId + "",
				Status.PASS);
		report.updateTestLog("ValidateResponse", "RestName => " + restname + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "RestPlatform => " + restplatform + "", Status.PASS);
		report.updateTestLog("ValidateResponse",
				"RestIsAdministrativeServicesOnly => " + restisAdministrativeServicesOnly + "", Status.PASS);
		report.updateTestLog("ValidateResponse",
				"RestEnterpriseEmployerPlatform => " + restenterpriseEmployerPlatform + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "RestEnterpriseEmployerId => " + restenterpriseEmployerId + "",
				Status.PASS);
		report.updateTestLog("ValidateResponse", "RestIsDsnp=> " + restisDsnp + "", Status.PASS);

	}

	public void restMemberCallForCoverageIdentifiers() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restsourcePersonId = extractTagValue(response, "sourcePersonId", SERVICEFORMAT.JSON);
		restsourcePlatform = extractTagValue(response, "sourcePlatform", SERVICEFORMAT.JSON);
		restmmctId = extractTagValue(response, "mmctId", SERVICEFORMAT.JSON);
		restcmpcId = extractTagValue(response, "mmctId", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestSourcePersonId", restsourcePersonId);
		dataTable.putData("INT_DataSheet", "RestSourcePlatform", restsourcePlatform);
		dataTable.putData("INT_DataSheet", "RestmmctId", restmmctId);
		dataTable.putData("INT_DataSheet", "RestcmpcId", restcmpcId);

		report.updateTestLog("ValidateResponse", "Rest SourcePersonId=> " + restsourcePersonId + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest SourcePlatform=> " + restsourcePlatform + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest mmctId=> " + restmmctId + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest cmpcId=> " + restcmpcId + "", Status.PASS);

	}

	public void restMemberCallForHipaa() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restrelationshipcode = extractTagValue(response, "relationship", "code", SERVICEFORMAT.JSON);
		restrelationshipdescription = extractTagValue(response, "relationship", "description", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestRelationshipCode", restrelationshipcode);
		dataTable.putData("INT_DataSheet", "RestRelationshipDescription", restrelationshipdescription);

		report.updateTestLog("ValidateResponse", "Rest RelationshipCode=> " + restrelationshipcode + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest RelationshipDescription=> " + restrelationshipdescription + "",
				Status.PASS);

	}

	public void restMemberCallForIndicators() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restisSmoker = extractTagValue(response, "isSmoker", SERVICEFORMAT.JSON);
		restisRetired = extractTagValue(response, "isRetired", SERVICEFORMAT.JSON);
		restisHumanaEmployee = extractTagValue(response, "isHumanaEmployee", SERVICEFORMAT.JSON);
		restisPartDOptOut = extractTagValue(response, "isPartDOptOut", SERVICEFORMAT.JSON);
		restisHcfaDual = extractTagValue(response, "isHcfaDual", SERVICEFORMAT.JSON);
		restisLongTermInst = extractTagValue(response, "isLongTermInst", SERVICEFORMAT.JSON);
		restisMedicareEnrollee = extractTagValue(response, "isMedicareEnrollee", SERVICEFORMAT.JSON);
		restisBlocked = extractTagValue(response, "isBlocked", SERVICEFORMAT.JSON);
		resttenantId = extractTagValue(response, "tenantId", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestIsSmoker", restisSmoker);
		dataTable.putData("INT_DataSheet", "RestIsRetired", restisRetired);
		dataTable.putData("INT_DataSheet", "RestIsHumanaEmployee", restisHumanaEmployee);
		dataTable.putData("INT_DataSheet", "RestIsPartDOptOut", restisPartDOptOut);
		dataTable.putData("INT_DataSheet", "RestIsHcfaDual", restisHcfaDual);
		dataTable.putData("INT_DataSheet", "RestIsLongTermInst", restisLongTermInst);
		dataTable.putData("INT_DataSheet", "RestIsMedicareEnrollee", restisMedicareEnrollee);
		dataTable.putData("INT_DataSheet", "RestIsBlocked", restisBlocked);
		dataTable.putData("INT_DataSheet", "RestTenantId", resttenantId);

		report.updateTestLog("ValidateResponse", "Rest IsSmoker=> " + restisSmoker + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest IsRetired=> " + restisRetired + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest IsHumanaEmployee=> " + restisHumanaEmployee + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest IsPartDOptOut=> " + restisPartDOptOut + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest IsHcfaDual=> " + restisHcfaDual + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest IsLongTermInst=> " + restisLongTermInst + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest IsMedicareEnrollee=> " + restisMedicareEnrollee + "",
				Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest IsBlocked=> " + restisBlocked + "", Status.PASS);
		report.updateTestLog("ValidateResponse", "Rest TenantId=> " + resttenantId + "", Status.PASS);

	}

	public void restMemberCallForMembersGenkeys() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restplatform = extractTagValue(response, "platform", SERVICEFORMAT.JSON);
		restsourcePersonId = extractTagValue(response, "sourcePersonId", SERVICEFORMAT.JSON);
		restmemberGenKey = extractTagValue(response, "memberGenKey", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestPlatform", restplatform);
		dataTable.putData("INT_DataSheet", "RestSourcePersonId", restsourcePersonId);
		dataTable.putData("INT_DataSheet", "RestMemberGenKey", restmemberGenKey);

		report.updateTestLog("Validation of Platform", "Rest Platform => " + restplatform + "", Status.PASS);
		report.updateTestLog("Validation of SourcePersonId", "Rest SourcePersonId => " + restsourcePersonId + "",
				Status.PASS);
		report.updateTestLog("Validation of RestMemberGenKey", "RestMemberGenKey => " + restmemberGenKey + "",
				Status.PASS);

	}

	public void restMemberCallForMembersProducts() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restId = extractTagValue(response, "id", SERVICEFORMAT.JSON);
		restDescription = extractTagValue(response, "description", SERVICEFORMAT.JSON);
		restalternateDescription = extractTagValue(response, "alternateDescription", SERVICEFORMAT.JSON);
		reststartDate = extractTagValue(response, "startDate", SERVICEFORMAT.JSON);
		restendDate = extractTagValue(response, "endDate", SERVICEFORMAT.JSON);
		restproductLineDescription = extractTagValue(response, "productLineDescription", SERVICEFORMAT.JSON);
		restproductTypeCode = extractTagValue(response, "productTypeCode", SERVICEFORMAT.JSON);
		restsource = extractTagValue(response, "source", SERVICEFORMAT.JSON);
		restproductLineCode = extractTagValue(response, "productLineCode", SERVICEFORMAT.JSON);
		restsegmentType = extractTagValue(response, "segmentType", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode = extractTagValue(response, "majorLineOfBusinessCode", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription = extractTagValue(response, "majorLineOfBusinessDescription",
				SERVICEFORMAT.JSON);

		if (restendDate.equals("null")) {
			restEndDate = "9999-12-31";
		}

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestId", restId);
		dataTable.putData("INT_DataSheet", "RestDescription", restDescription);
		dataTable.putData("INT_DataSheet", "RestAlternateDescription", restalternateDescription);
		dataTable.putData("INT_DataSheet", "RestStartDate", reststartDate);
		dataTable.putData("INT_DataSheet", "RestEndDate", restEndDate);
		dataTable.putData("INT_DataSheet", "RestProductLineDescription", restproductLineDescription);
		dataTable.putData("INT_DataSheet", "RestProductTypeCode", restproductTypeCode);
		dataTable.putData("INT_DataSheet", "RestSource", restsource);
		dataTable.putData("INT_DataSheet", "RestProductLineCode", restproductLineCode);
		dataTable.putData("INT_DataSheet", "RestSegmentType", restsegmentType);
		dataTable.putData("INT_DataSheet", "RestMajorLineOfBusinessCode", restmajorLineOfBusinessCode);
		dataTable.putData("INT_DataSheet", "RestMajorLineOfBusinessDescription", restmajorLineOfBusinessDescription);

		report.updateTestLog("Validation of Id", "RestId => " + restId + "", Status.PASS);
		report.updateTestLog("Validation of Description", "RestDescription => " + restDescription + "", Status.PASS);
		report.updateTestLog("Validation of AlternateDescription",
				"RestAlternateDescription => " + restalternateDescription + "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "RestStartDate => " + reststartDate + "", Status.PASS);
		report.updateTestLog("Validation of EndDate", "RestEndDate => " + restEndDate + "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription",
				"RestProductLineDescription => " + restproductLineDescription + "", Status.PASS);
		report.updateTestLog("Validation of ProductTypeCode", "RestProductTypeCode => " + restproductTypeCode + "",
				Status.PASS);
		report.updateTestLog("Validation of Source", "RestSource => " + restsource + "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode", "RestProductLineCode => " + restproductLineCode + "",
				Status.PASS);
		report.updateTestLog("Validation of SegmentType", "RestSegmentType => " + restsegmentType + "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode",
				"RestMajorLineOfBusinessCode => " + restmajorLineOfBusinessCode + "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescription",
				"RestMajorLineOfBusinessDescription => " + restmajorLineOfBusinessDescription + "", Status.PASS);

	}

	public void restMemberCallForGroupCoverageProducts() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restId = extractTagValue(response, "id", SERVICEFORMAT.JSON);
		restdescription = extractTagValue2(response, "description", SERVICEFORMAT.JSON);
		restalternateDescription = extractTagValue(response, "alternateDescription", SERVICEFORMAT.JSON);
		reststartDate = extractTagValue(response, "startDate", SERVICEFORMAT.JSON);
		restendDate = extractTagValue(response, "endDate", SERVICEFORMAT.JSON);
		restproductLineDescription = extractTagValue(response, "productLineDescription", SERVICEFORMAT.JSON);
		restproductTypeCode = extractTagValue(response, "productTypeCode", SERVICEFORMAT.JSON);
		restsource = extractTagValue(response, "source", SERVICEFORMAT.JSON);
		restproductLineCode = extractTagValue(response, "productLineCode", SERVICEFORMAT.JSON);
		restsegmentType = extractTagValue(response, "segmentType", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode = extractTagValue(response, "majorLineOfBusinessCode", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription = extractTagValue(response, "majorLineOfBusinessDescription",
				SERVICEFORMAT.JSON);

		if (restendDate.equals("null")) {
			restEndDate = "9999-12-31";
		}

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestId", restId);
		dataTable.putData("INT_DataSheet", "RestDescription", restdescription);
		dataTable.putData("INT_DataSheet", "RestAlternateDescription", restalternateDescription);
		dataTable.putData("INT_DataSheet", "RestStartDate", reststartDate);
		dataTable.putData("INT_DataSheet", "RestEndDate", restEndDate);
		dataTable.putData("INT_DataSheet", "RestProductLineDescription", restproductLineDescription);
		dataTable.putData("INT_DataSheet", "RestProductTypeCode", restproductTypeCode);
		dataTable.putData("INT_DataSheet", "RestSource", restsource);
		dataTable.putData("INT_DataSheet", "RestProductLineCode", restproductLineCode);
		dataTable.putData("INT_DataSheet", "RestSegmentType", restsegmentType);
		dataTable.putData("INT_DataSheet", "RestMajorLineOfBusinessCode", restmajorLineOfBusinessCode);
		dataTable.putData("INT_DataSheet", "RestMajorLineOfBusinessDescription", restmajorLineOfBusinessDescription);

		report.updateTestLog("Validation of Id", "RestId => " + restId + "", Status.PASS);
		report.updateTestLog("Validation of Description", "RestDescription => " + restdescription + "", Status.PASS);
		report.updateTestLog("Validation of AlternateDescription",
				"RestAlternateDescription => " + restalternateDescription + "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "RestStartDate => " + reststartDate + "", Status.PASS);
		report.updateTestLog("Validation of EndDate", "RestEndDate => " + restEndDate + "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription",
				"RestProductLineDescription => " + restproductLineDescription + "", Status.PASS);
		report.updateTestLog("Validation of ProductTypeCode", "RestProductTypeCode => " + restproductTypeCode + "",
				Status.PASS);
		report.updateTestLog("Validation of Source", "RestSource => " + restsource + "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode", "RestProductLineCode => " + restproductLineCode + "",
				Status.PASS);
		report.updateTestLog("Validation of SegmentType", "RestSegmentType => " + restsegmentType + "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode",
				"RestMajorLineOfBusinessCode => " + restmajorLineOfBusinessCode + "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescription",
				"RestMajorLineOfBusinessDescription => " + restmajorLineOfBusinessDescription + "", Status.PASS);

	}

	public void restMemberCallForMedicationsOTCAllowance() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restcontractId = extractTagValue(response, "contractId", SERVICEFORMAT.JSON);
		restplanNumber = extractTagValue(response, "planNumber", SERVICEFORMAT.JSON);
		restbenefitAmount = extractTagValue(response, "benefitAmount", SERVICEFORMAT.JSON);
		restplanOptionNumber = extractTagValue(response, "planOptionNumber", SERVICEFORMAT.JSON);
		restperiodicity = extractTagValue(response, "periodicity", SERVICEFORMAT.JSON);
		restisOTCEligible = extractTagValue(response, "isOTCEligible", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestContractId", restcontractId);
		dataTable.putData("INT_DataSheet", "RestPlanNumber", restplanNumber);
		dataTable.putData("INT_DataSheet", "RestBenefitAmount", restbenefitAmount);
		dataTable.putData("INT_DataSheet", "RestPlanOptionNumber", restplanOptionNumber);
		dataTable.putData("INT_DataSheet", "RestPeriodicity", restperiodicity);
		dataTable.putData("INT_DataSheet", "RestisOTCEligible", restisOTCEligible);

		report.updateTestLog("Validation of ContractId", "Rest ContractId => " + restcontractId + "", "", Status.PASS);
		report.updateTestLog("Validation of PlanNumber", "Rest PlanNumber => " + restplanNumber + "", "", Status.PASS);
		report.updateTestLog("Validation of BenefitAmount", "Rest BenefitAmount => " + restbenefitAmount + "", "",
				Status.PASS);
		report.updateTestLog("Validation of PlanOptionNumber", "Rest PlanOptionNumber => " + restplanOptionNumber + "",
				"", Status.PASS);
		report.updateTestLog("Validation of Periodicity", "Rest Periodicity => " + restperiodicity + "", "",
				Status.PASS);
		report.updateTestLog("Validation of isOTCEligible", "Rest isOTCEligible => " + restisOTCEligible + "", "",
				Status.PASS);

	}

	public void restMemberCallForDesigneeId() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restdesigneeId = extractTagValue(response, "designeeId", SERVICEFORMAT.JSON);
		restrole = extractTagValue(response, "role", SERVICEFORMAT.JSON);
		restdesigneeType = extractTagValue(response, "designeeType", SERVICEFORMAT.JSON);
		restFirstName = extractTagValue(response, "firstName", SERVICEFORMAT.JSON);
		restMiddleName = extractTagValue(response, "middleName", SERVICEFORMAT.JSON);
		restLastName = extractTagValue(response, "lastName", SERVICEFORMAT.JSON);
		restDOB = extractTagValue(response, "dateOfBirth", SERVICEFORMAT.JSON);
		restOrganizationName = extractTagValue(response, "middleName", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestDesigneeId", restdesigneeId);
		dataTable.putData("INT_DataSheet", "RestRole", restrole);
		dataTable.putData("INT_DataSheet", "RestDesigneeType", restdesigneeType);
		dataTable.putData("INT_DataSheet", "RestFirstName", restFirstName);
		dataTable.putData("INT_DataSheet", "RestMiddleName", restMiddleName);
		dataTable.putData("INT_DataSheet", "RestLastName", restLastName);
		dataTable.putData("INT_DataSheet", "RestDOB", restDOB);
		dataTable.putData("INT_DataSheet", "RestOrganizationName", restOrganizationName);

		report.updateTestLog("Validation of designeeId", "Rest DesigneeId => " + restdesigneeId + "", Status.PASS);
		report.updateTestLog("Validation of role", "Rest Roler => " + restrole + "", Status.PASS);
		report.updateTestLog("Validation of designeeType", "Rest DesigneeType => " + restdesigneeType + "",
				Status.PASS);
		report.updateTestLog("Validation of firstName", "Rest FirstName => " + restFirstName + "", Status.PASS);
		report.updateTestLog("Validation of middleName", "Rest MiddleName => " + restMiddleName + "", Status.PASS);
		report.updateTestLog("Validation of lastName", "Rest LastName => " + restLastName + "", Status.PASS);
		report.updateTestLog("Validation of dateOfBirth", "Rest DOB => " + restDOB + "", Status.PASS);
		report.updateTestLog("Validation of organizationName", "Rest OrganizationName => " + restOrganizationName + "",
				Status.PASS);

	}

	public String extractResponse(ValidatableResponse response, SERVICEFORMAT format) {

		if (format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString().replace("{", "").replace("}", "").replace("[", "")
					.replace("]", "").replace("},", "");
			String[] namesList = responseBody.split(",");
			for (String name : namesList) {
				String[] tagname = name.split(":");
				String tagHeading = tagname[0].replace("{", "").replace('"', ' ').trim();
				String tagValue = tagname[1].replace("{", "").replace('"', ' ').trim();
				String TagName = tagHeading.substring(0, 1).toUpperCase() + tagHeading.substring(1);
				if (name.endsWith("null")) {
					name = "endDate:9999-12-31";
				}
				report.updateTestLog("Validation of " + tagHeading + "", "Response => " + name + "", Status.PASS);
				dataTable.putData("INT_DataSheet", "Rest" + TagName + "", tagValue);
			}

			return value;
		} else {
			String value = null;
			return value;
		}
	}

	public String extractResponse1(ValidatableResponse response, SERVICEFORMAT format) {

		if (format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString().replace("{", "").replace("}", "").replace("[", "")
					.replace("]", "").replace("},", "");
			String[] namesList = responseBody.split(",");
			for (String name : namesList) {
				String[] tagname = name.split(":");
				String tagHeading = tagname[0].replace("{", "").replace('"', ' ').trim();
				String tagValue = tagname[1].replace("{", "").replace('"', ' ').trim();
				String TagName = tagHeading.substring(0, 1).toUpperCase() + tagHeading.substring(1);
				if (name.endsWith("null")) {
					name = "endDate:9999-12-31";
				}
				report.updateTestLog("Validation of " + tagHeading + "", "Response => " + name + "", Status.PASS);
				dataTable.putData("Parametrized_Checkpoints", "Rest" + TagName + "", tagValue);
			}

			return value;
		} else {
			String value = null;
			return value;
		}
	}

	public void restResponseValidation() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);
		String ResponseValidation = extractResponse(response, SERVICEFORMAT.JSON);

	}

	public void restresponseValidation() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);
		String ResponseValidation = extractResponse1(response, SERVICEFORMAT.JSON);

	}

	public void restMemberCallForMedicationsDrugCoverage() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restndcCode = extractTagValue(response, "ndcCode", SERVICEFORMAT.JSON);
		restformularyId = extractTagValue(response, "formularyId", SERVICEFORMAT.JSON);
		restmedId = extractTagValue(response, "medId", SERVICEFORMAT.JSON);
		resttier = extractTagValue(response, "coverage", "tier", SERVICEFORMAT.JSON);
		restisCovered = extractTagValue(response, "coverage", "isCovered", SERVICEFORMAT.JSON);
		restisPriorAuthorizationRequired = extractTagValue(response, "coverage", "isPriorAuthorizationRequired",
				SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestNdcCode", restndcCode);
		dataTable.putData("INT_DataSheet", "RestFormularyId", restformularyId);
		dataTable.putData("INT_DataSheet", "RestMedId", restmedId);
		dataTable.putData("INT_DataSheet", "RestTier", resttier);
		dataTable.putData("INT_DataSheet", "RestIsCovered", restisCovered);
		dataTable.putData("INT_DataSheet", "RestIsPriorAuthorizationRequired", restisPriorAuthorizationRequired);

		report.updateTestLog("Validation of ndcCode", "Rest ndcCode => " + restndcCode + "", Status.PASS);
		report.updateTestLog("Validation of formularyId", "Rest formularyId => " + restformularyId + "", Status.PASS);
		report.updateTestLog("Validation of medId", "Rest medId => " + restmedId + "", Status.PASS);
		report.updateTestLog("Validation of tier", "Rest tier => " + resttier + "", Status.PASS);
		report.updateTestLog("Validation of isCovered", "Rest isCovered => " + restisCovered + "", Status.PASS);
		report.updateTestLog("Validation of isPriorAuthorizationRequired",
				"Rest isPriorAuthorizationRequired => " + restisPriorAuthorizationRequired + "", Status.PASS);

	}

	public void restMemberCallForMedications() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restmedicationId = extractTagValue(response, "medicationId", 0, SERVICEFORMAT.JSON);
		restmedicationId1 = extractTagValue(response, "medicationId", 1, SERVICEFORMAT.JSON);
		restname = extractTagValue(response, "name", 0, SERVICEFORMAT.JSON);
		restname1 = extractTagValue(response, "name", 1, SERVICEFORMAT.JSON);
		restbrandName = extractTagValue(response, "brandName", 0, SERVICEFORMAT.JSON);
		restbrandName1 = extractTagValue(response, "brandName", 1, SERVICEFORMAT.JSON);
		restgenericName = extractTagValue(response, "genericName", 0, SERVICEFORMAT.JSON);
		restgenericName1 = extractTagValue(response, "genericName", 1, SERVICEFORMAT.JSON);
		restndcCode = extractTagValue(response, "ndcCode", 0, SERVICEFORMAT.JSON);
		restndcCode1 = extractTagValue(response, "ndcCode", 1, SERVICEFORMAT.JSON);
		restimageUrl = extractTagValue(response, "imageUrl", 0, SERVICEFORMAT.JSON);
		restimageUrl1 = extractTagValue(response, "imageUrl", 0, SERVICEFORMAT.JSON);
		restprescriptionRequired = extractTagValue(response, "prescriptionRequired", 0, SERVICEFORMAT.JSON);
		restprescriptionRequired1 = extractTagValue(response, "prescriptionRequired", 1, SERVICEFORMAT.JSON);
		restmedicationType = extractTagValue(response, "medicationType", 0, SERVICEFORMAT.JSON);
		restmedicationType1 = extractTagValue(response, "medicationType", 1, SERVICEFORMAT.JSON);
		restdirections = extractTagValue(response, "directions", 0, SERVICEFORMAT.JSON);
		restdirections1 = extractTagValue(response, "directions", 1, SERVICEFORMAT.JSON);
		restindication = extractTagValue(response, "indication", 0, SERVICEFORMAT.JSON);
		restindication1 = extractTagValue(response, "indication", 1, SERVICEFORMAT.JSON);
		restnotes = extractTagValue(response, "notes", 0, SERVICEFORMAT.JSON);
		restnotes1 = extractTagValue(response, "notes", 1, SERVICEFORMAT.JSON);
		restquantity = extractTagValue(response, "quantity", 0, SERVICEFORMAT.JSON);
		restquantity1 = extractTagValue(response, "quantity", 1, SERVICEFORMAT.JSON);
		restsupply = extractTagValue(response, "supply", 0, SERVICEFORMAT.JSON);
		restsupply1 = extractTagValue(response, "supply", 1, SERVICEFORMAT.JSON);
		restdrugDoseForm = extractTagValue(response, "drugDoseForm", 0, SERVICEFORMAT.JSON);
		restdrugDoseForm1 = extractTagValue(response, "drugDoseForm", 1, SERVICEFORMAT.JSON);
		restdrugStrength = extractTagValue(response, "drugStrength", 0, SERVICEFORMAT.JSON);
		restdrugStrength1 = extractTagValue(response, "drugStrength", 1, SERVICEFORMAT.JSON);
		restlastFilledDate = extractTagValue(response, "lastFilledDate", 0, SERVICEFORMAT.JSON);
		restlastFilledDate1 = extractTagValue(response, "lastFilledDate", 1, SERVICEFORMAT.JSON);
		restprescriberName = extractTagValue(response, "prescriberName", 0, SERVICEFORMAT.JSON);
		restprescriberName1 = extractTagValue(response, "prescriberName", 1, SERVICEFORMAT.JSON);
		restprescriberNpi = extractTagValue(response, "prescriberNpi", 0, SERVICEFORMAT.JSON);
		restprescriberNpi1 = extractTagValue(response, "prescriberNpi", 1, SERVICEFORMAT.JSON);
		restpharmacyName = extractTagValue(response, "pharmacyName", 0, SERVICEFORMAT.JSON);
		restpharmacyName1 = extractTagValue(response, "pharmacyName", 1, SERVICEFORMAT.JSON);
		restpharmacyNpi = extractTagValue(response, "pharmacyNpi", 0, SERVICEFORMAT.JSON);
		restpharmacyNpi1 = extractTagValue(response, "pharmacyNpi", 1, SERVICEFORMAT.JSON);
		restrxNumber = extractTagValue(response, "rxNumber", 0, SERVICEFORMAT.JSON);
		restrxNumber1 = extractTagValue(response, "rxNumber", 1, SERVICEFORMAT.JSON);
		restrefillStatus = extractTagValue(response, "refillStatus", 0, SERVICEFORMAT.JSON);
		restrefillStatus1 = extractTagValue(response, "refillStatus", 1, SERVICEFORMAT.JSON);
		restrefillsRemaining = extractTagValue(response, "refillsRemaining", 0, SERVICEFORMAT.JSON);
		restrefillsRemaining1 = extractTagValue(response, "refillsRemaining", 1, SERVICEFORMAT.JSON);
		restisCurrentlyTaking = extractTagValue(response, "isCurrentlyTaking", 0, SERVICEFORMAT.JSON);
		restisCurrentlyTaking1 = extractTagValue(response, "isCurrentlyTaking", 1, SERVICEFORMAT.JSON);
		restisVerified = extractTagValue(response, "isVerified", 0, SERVICEFORMAT.JSON);
		restisVerified1 = extractTagValue(response, "isVerified", 1, SERVICEFORMAT.JSON);
		restremovalReason = extractTagValue(response, "removalReason", 0, SERVICEFORMAT.JSON);
		restremovalReason1 = extractTagValue(response, "removalReason", 1, SERVICEFORMAT.JSON);
		restremovalReasonCode = extractTagValue(response, "removalReasonCode", 0, SERVICEFORMAT.JSON);
		restremovalReasonCode1 = extractTagValue(response, "removalReasonCode", 1, SERVICEFORMAT.JSON);
		restcreatedBySystem = extractTagValue(response, "createdBySystem", 0, SERVICEFORMAT.JSON);
		restcreatedBySystem1 = extractTagValue(response, "createdBySystem", 1, SERVICEFORMAT.JSON);
		restcreatedDate = extractTagValue(response, "createdDate", 0, SERVICEFORMAT.JSON);
		restcreatedDate1 = extractTagValue(response, "createdDate", 1, SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("INT_DataSheet", "RestMedicationId", restmedicationId);
		dataTable.putData("INT_DataSheet", "RestMedicationId1", restmedicationId1);
		dataTable.putData("INT_DataSheet", "RestName", restname);
		dataTable.putData("INT_DataSheet", "RestName1", restname1);
		dataTable.putData("INT_DataSheet", "RestBrandName", restbrandName);
		dataTable.putData("INT_DataSheet", "RestBrandName1", restbrandName1);
		dataTable.putData("INT_DataSheet", "RestNdcCode", restndcCode);
		dataTable.putData("INT_DataSheet", "RestNdcCode1", restndcCode1);
		dataTable.putData("INT_DataSheet", "RestGenericName", restgenericName);
		dataTable.putData("INT_DataSheet", "RestGenericName1", restgenericName1);
		dataTable.putData("INT_DataSheet", "RestImageUrl", restimageUrl);
		dataTable.putData("INT_DataSheet", "RestImageUrl1", restimageUrl1);
		dataTable.putData("INT_DataSheet", "RestPrescriptionRequired", restprescriptionRequired);
		dataTable.putData("INT_DataSheet", "RestPrescriptionRequired1", restprescriptionRequired1);
		dataTable.putData("INT_DataSheet", "RestMedicationType", restmedicationType);
		dataTable.putData("INT_DataSheet", "RestMedicationType1", restmedicationType1);
		dataTable.putData("INT_DataSheet", "RestDirections", restdirections);
		dataTable.putData("INT_DataSheet", "RestDirections1", restdirections1);
		dataTable.putData("INT_DataSheet", "RestIndication", restindication);
		dataTable.putData("INT_DataSheet", "RestIndication1", restindication1);
		dataTable.putData("INT_DataSheet", "RestNotes", restnotes);
		dataTable.putData("INT_DataSheet", "RestNotes1", restnotes1);
		dataTable.putData("INT_DataSheet", "RestQuantity", restquantity);
		dataTable.putData("INT_DataSheet", "RestQuantity1", restquantity1);
		dataTable.putData("INT_DataSheet", "RestSupply", restsupply);
		dataTable.putData("INT_DataSheet", "RestSupply1", restsupply1);
		dataTable.putData("INT_DataSheet", "RestDrugDoseForm", restdrugDoseForm);
		dataTable.putData("INT_DataSheet", "RestDrugDoseForm1", restdrugDoseForm1);
		dataTable.putData("INT_DataSheet", "RestDrugStrength", restdrugStrength);
		dataTable.putData("INT_DataSheet", "RestDrugStrength1", restdrugStrength1);
		dataTable.putData("INT_DataSheet", "RestLastFilledDate", restlastFilledDate);
		dataTable.putData("INT_DataSheet", "RestLastFilledDate1", restlastFilledDate1);
		dataTable.putData("INT_DataSheet", "RestPrescriberName", restprescriberName);
		dataTable.putData("INT_DataSheet", "RestPrescriberName1", restprescriberName1);
		dataTable.putData("INT_DataSheet", "RestPrescriberNpi", restprescriberNpi);
		dataTable.putData("INT_DataSheet", "RestPrescriberNpi1", restprescriberNpi1);
		dataTable.putData("INT_DataSheet", "RestPharmacyName", restpharmacyName);
		dataTable.putData("INT_DataSheet", "RestPharmacyName1", restpharmacyName1);
		dataTable.putData("INT_DataSheet", "RestPharmacyNpi", restpharmacyNpi);
		dataTable.putData("INT_DataSheet", "RestPharmacyNpi1", restpharmacyNpi1);
		dataTable.putData("INT_DataSheet", "RestRxNumber", restrxNumber);
		dataTable.putData("INT_DataSheet", "RestRxNumber1", restrxNumber1);
		dataTable.putData("INT_DataSheet", "RestRefillStatus", restrefillStatus);
		dataTable.putData("INT_DataSheet", "RestRefillStatus1", restrefillStatus1);
		dataTable.putData("INT_DataSheet", "RestRefillsRemaining", restrefillsRemaining);
		dataTable.putData("INT_DataSheet", "RestRefillsRemaining1", restrefillsRemaining1);
		dataTable.putData("INT_DataSheet", "RestIsCurrentlyTaking", restisCurrentlyTaking);
		dataTable.putData("INT_DataSheet", "RestIsCurrentlyTaking1", restisCurrentlyTaking1);
		dataTable.putData("INT_DataSheet", "RestIsVerified", restisVerified);
		dataTable.putData("INT_DataSheet", "RestIsVerified1", restisVerified1);
		dataTable.putData("INT_DataSheet", "RestRemovalReason", restremovalReason);
		dataTable.putData("INT_DataSheet", "RestRemovalReason1", restremovalReason1);
		dataTable.putData("INT_DataSheet", "RestRemovalReasonCode", restremovalReasonCode);
		dataTable.putData("INT_DataSheet", "RestRemovalReasonCode1", restremovalReasonCode1);
		dataTable.putData("INT_DataSheet", "RestCreatedBySystem", restcreatedBySystem);
		dataTable.putData("INT_DataSheet", "RestCreatedBySystem1", restcreatedBySystem1);
		dataTable.putData("INT_DataSheet", "RestCreatedDate", restcreatedDate);
		dataTable.putData("INT_DataSheet", "RestCreatedDate1", restcreatedDate1);

		report.updateTestLog("Validation of medicationId", "Rest MedicationId => " + restmedicationId + "",
				Status.PASS);
		report.updateTestLog("Validation of name", "Rest Name => " + restname + "", Status.PASS);
		report.updateTestLog("Validation of brandName", "Rest BrandName => " + restbrandName + "", Status.PASS);
		report.updateTestLog("Validation of ndcCode", "Rest NdcCode => " + restndcCode + "", Status.PASS);
		report.updateTestLog("Validation of genericName", "Rest GenericName => " + restgenericName + "", Status.PASS);
		report.updateTestLog("Validation of imageUrl", "Rest ImageUrl => " + restimageUrl + "", Status.PASS);
		report.updateTestLog("Validation of prescriptionRequired",
				"Rest PrescriptionRequired => " + restprescriptionRequired + "", Status.PASS);
		report.updateTestLog("Validation of medicationType", "Rest MedicationType => " + restmedicationType + "",
				Status.PASS);
		report.updateTestLog("Validation of directions", "Rest Directions => " + restdirections + "", Status.PASS);
		report.updateTestLog("Validation of indication", "Rest Indication => " + restindication + "", Status.PASS);
		report.updateTestLog("Validation of notes", "Rest Notes => " + restnotes + "", Status.PASS);
		report.updateTestLog("Validation of quantity", "Rest Quantity => " + restquantity + "", Status.PASS);
		report.updateTestLog("Validation of supply", "Rest Supply => " + restsupply + "", Status.PASS);
		report.updateTestLog("Validation of drugDoseForm", "Rest DrugDoseForm => " + restdrugDoseForm + "",
				Status.PASS);
		report.updateTestLog("Validation of drugStrength", "Rest DrugStrength => " + restdrugStrength + "",
				Status.PASS);
		report.updateTestLog("Validation of lastFilledDate", "Rest LastFilledDate => " + restlastFilledDate + "",
				Status.PASS);
		report.updateTestLog("Validation of prescriberName", "Rest PrescriberName => " + restprescriberName + "",
				Status.PASS);
		report.updateTestLog("Validation of prescriberNpi", "Rest PrescriberNpi => " + restprescriberNpi + "",
				Status.PASS);
		report.updateTestLog("Validation of pharmacyName", "Rest PharmacyName => " + restpharmacyName + "",
				Status.PASS);
		report.updateTestLog("Validation of pharmacyNpi", "Rest PharmacyNpi => " + restpharmacyNpi + "", Status.PASS);
		report.updateTestLog("Validation of rxNumber", "Rest RxNumber => " + restrxNumber + "", Status.PASS);
		report.updateTestLog("Validation of refillStatus", "Rest RefillStatus => " + restrefillStatus + "",
				Status.PASS);
		report.updateTestLog("Validation of refillsRemaining", "Rest RefillsRemaining => " + restrefillsRemaining + "",
				Status.PASS);
		report.updateTestLog("Validation of isCurrentlyTaking",
				"Rest IsCurrentlyTaking => " + restisCurrentlyTaking + "", Status.PASS);
		report.updateTestLog("Validation of isVerified", "Rest IsVerified => " + restisVerified + "", Status.PASS);
		report.updateTestLog("Validation of removalReason", "Rest RemovalReason => " + restremovalReason + "",
				Status.PASS);
		report.updateTestLog("Validation of removalReasonCode",
				"Rest RemovalReasonCode => " + restremovalReasonCode + "", Status.PASS);
		report.updateTestLog("Validation of createdBySystem", "Rest CreatedBySystem => " + restcreatedBySystem + "",
				Status.PASS);
		report.updateTestLog("Validation of createdDate", "Rest CreatedDate => " + restcreatedDate + "", Status.PASS);

		report.updateTestLog("Validation of medicationId", "Rest MedicationId => " + restmedicationId1 + "",
				Status.PASS);
		report.updateTestLog("Validation of name", "Rest Name => " + restname1 + "", Status.PASS);
		report.updateTestLog("Validation of brandName", "Rest BrandName => " + restbrandName1 + "", Status.PASS);
		report.updateTestLog("Validation of ndcCode", "Rest NdcCode => " + restndcCode1 + "", Status.PASS);
		report.updateTestLog("Validation of genericName", "Rest GenericName => " + restgenericName1 + "", Status.PASS);
		report.updateTestLog("Validation of imageUrl", "Rest ImageUrl => " + restimageUrl1 + "", Status.PASS);
		report.updateTestLog("Validation of prescriptionRequired",
				"Rest PrescriptionRequired => " + restprescriptionRequired1 + "", Status.PASS);
		report.updateTestLog("Validation of medicationType", "Rest RestMedicationType => " + restmedicationType1 + "",
				Status.PASS);
		report.updateTestLog("Validation of directions", "Rest Directions => " + restdirections1 + "", Status.PASS);
		report.updateTestLog("Validation of indication", "Rest Indication => " + restindication1 + "", Status.PASS);
		report.updateTestLog("Validation of notes", "Rest Notes => " + restnotes1 + "", Status.PASS);
		report.updateTestLog("Validation of quantity", "Rest Quantity => " + restquantity1 + "", Status.PASS);
		report.updateTestLog("Validation of supply", "Rest Supply => " + restsupply1 + "", Status.PASS);
		report.updateTestLog("Validation of drugDoseForm", "Rest DrugDoseForm => " + restdrugDoseForm1 + "",
				Status.PASS);
		report.updateTestLog("Validation of drugStrength", "Rest DrugStrength => " + restdrugStrength1 + "",
				Status.PASS);
		report.updateTestLog("Validation of lastFilledDate", "Rest LastFilledDate => " + restlastFilledDate1 + "",
				Status.PASS);
		report.updateTestLog("Validation of prescriberName", "Rest PrescriberName => " + restprescriberName1 + "",
				Status.PASS);
		report.updateTestLog("Validation of prescriberNpi", "Rest PrescriberNpi => " + restprescriberNpi1 + "",
				Status.PASS);
		report.updateTestLog("Validation of pharmacyName", "Rest PharmacyName => " + restpharmacyName1 + "",
				Status.PASS);
		report.updateTestLog("Validation of pharmacyNpi", "Rest PharmacyNpi => " + restpharmacyNpi1 + "", Status.PASS);
		report.updateTestLog("Validation of rxNumber", "Rest RxNumber => " + restrxNumber1 + "", Status.PASS);
		report.updateTestLog("Validation of refillStatus", "Rest RefillStatus => " + restrefillStatus1 + "",
				Status.PASS);
		report.updateTestLog("Validation of refillsRemaining", "Rest RefillsRemaining => " + restrefillsRemaining1 + "",
				Status.PASS);
		report.updateTestLog("Validation of isCurrentlyTaking",
				"Rest IsCurrentlyTaking => " + restisCurrentlyTaking1 + "", Status.PASS);
		report.updateTestLog("Validation of isVerified", "Rest IsVerified => " + restisVerified1 + "", Status.PASS);
		report.updateTestLog("Validation of removalReason", "Rest RemovalReason => " + restremovalReason1 + "",
				Status.PASS);
		report.updateTestLog("Validation of removalReasonCode",
				"Rest RemovalReasonCode => " + restremovalReasonCode1 + "", Status.PASS);
		report.updateTestLog("Validation of createdBySystem", "Rest CreatedBySystem => " + restcreatedBySystem1 + "",
				Status.PASS);
		report.updateTestLog("Validation of createdDate", "Rest CreatedDate => " + restcreatedDate1 + "", Status.PASS);
	}

	public void restMemberCallForPatientshealthProgram() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		resthealthCondition = extractTagValue(response, "healthCondition", 0, SERVICEFORMAT.JSON);
		restisAccessible = extractTagValue(response, "isAccessible", 0, SERVICEFORMAT.JSON);
		restadditionalInfo = extractTagValue(response, "additionalInfo", 0, SERVICEFORMAT.JSON);

		resthealthCondition1 = extractTagValue(response, "healthCondition", 1, SERVICEFORMAT.JSON);
		restisAccessible1 = extractTagValue(response, "isAccessible", 1, SERVICEFORMAT.JSON);
		restadditionalInfo1 = extractTagValue(response, "additionalInfo", 1, SERVICEFORMAT.JSON);

		resthealthCondition2 = extractTagValue(response, "healthCondition", 2, SERVICEFORMAT.JSON);
		restisAccessible2 = extractTagValue(response, "isAccessible", 2, SERVICEFORMAT.JSON);
		restadditionalInfo2 = extractTagValue(response, "additionalInfo", 2, SERVICEFORMAT.JSON);

		resthealthCondition3 = extractTagValue(response, "healthCondition", 3, SERVICEFORMAT.JSON);
		restisAccessible3 = extractTagValue(response, "isAccessible", 3, SERVICEFORMAT.JSON);
		restadditionalInfo3 = extractTagValue(response, "additionalInfo", 3, SERVICEFORMAT.JSON);

		resthealthCondition4 = extractTagValue(response, "healthCondition", 4, SERVICEFORMAT.JSON);
		restisAccessible4 = extractTagValue(response, "isAccessible", 4, SERVICEFORMAT.JSON);
		restadditionalInfo4 = extractTagValue(response, "additionalInfo", 4, SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("Parametrized_Checkpoints", "RestHealthCondition", resthealthCondition);
		dataTable.putData("Parametrized_Checkpoints", "RestIsAccessible", restisAccessible);
		dataTable.putData("Parametrized_Checkpoints", "RestAdditionalInfo", restadditionalInfo);

		dataTable.putData("Parametrized_Checkpoints", "RestHealthCondition1", resthealthCondition1);
		dataTable.putData("Parametrized_Checkpoints", "RestIsAccessible1", restisAccessible1);
		dataTable.putData("Parametrized_Checkpoints", "RestAdditionalInfo1", restadditionalInfo1);
		dataTable.putData("Parametrized_Checkpoints", "RestHealthCondition2", resthealthCondition2);
		dataTable.putData("Parametrized_Checkpoints", "RestIsAccessible2", restisAccessible2);
		dataTable.putData("Parametrized_Checkpoints", "RestAdditionalInfo2", restadditionalInfo2);
		dataTable.putData("Parametrized_Checkpoints", "RestHealthCondition3", resthealthCondition3);
		dataTable.putData("Parametrized_Checkpoints", "RestIsAccessible3", restisAccessible3);
		dataTable.putData("Parametrized_Checkpoints", "RestAdditionalInfo3", restadditionalInfo3);
		dataTable.putData("Parametrized_Checkpoints", "RestHealthCondition4", resthealthCondition4);
		dataTable.putData("Parametrized_Checkpoints", "RestIsAccessible4", restisAccessible4);
		dataTable.putData("Parametrized_Checkpoints", "RestAdditionalInfo4", restadditionalInfo4);

		report.updateTestLog("Validation of HealthCondition", "REST healthCondition => " + resthealthCondition + "",
				Status.PASS);
		report.updateTestLog("Validation of IsAccessible", "REST isAccessible => " + restisAccessible + "",
				Status.PASS);
		report.updateTestLog("Validation of AdditionalInfo", "REST additionalInfo => " + restadditionalInfo + "",
				Status.PASS);

		report.updateTestLog("Validation of HealthCondition", "REST healthCondition => " + resthealthCondition1 + "",
				Status.PASS);
		report.updateTestLog("Validation of IsAccessible", "REST isAccessible => " + restisAccessible1 + "",
				Status.PASS);
		report.updateTestLog("Validation of AdditionalInfo", "REST additionalInfo => " + restadditionalInfo1 + "",
				Status.PASS);

		report.updateTestLog("Validation of HealthCondition", "REST healthCondition => " + resthealthCondition2 + "",
				Status.PASS);
		report.updateTestLog("Validation of IsAccessible", "REST isAccessible => " + restisAccessible2 + "",
				Status.PASS);
		report.updateTestLog("Validation of AdditionalInfo", "REST additionalInfo => " + restadditionalInfo2 + "",
				Status.PASS);

		report.updateTestLog("Validation of HealthCondition", "REST healthCondition => " + resthealthCondition3 + "",
				Status.PASS);
		report.updateTestLog("Validation of IsAccessible", "REST isAccessible => " + restisAccessible3 + "",
				Status.PASS);
		report.updateTestLog("Validation of AdditionalInfo", "REST additionalInfo => " + restadditionalInfo3 + "",
				Status.PASS);

		report.updateTestLog("Validation of HealthCondition", "REST healthCondition => " + resthealthCondition4 + "",
				Status.PASS);
		report.updateTestLog("Validation of IsAccessible", "REST isAccessible => " + restisAccessible4 + "",
				Status.PASS);
		report.updateTestLog("Validation of AdditionalInfo", "REST additionalInfo => " + restadditionalInfo4 + "",
				Status.PASS);

	}

	public void restMemberCallForCurrentdateCoverage() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restbase = extractTagValue(response, "memberIdentifiers", "base", SERVICEFORMAT.JSON);
		restdependentCode = extractTagValue(response, "memberIdentifiers", "dependentCode", SERVICEFORMAT.JSON);
		restmemberGenKey = extractTagValue(response, "memberIdentifiers", "memberGenKey", SERVICEFORMAT.JSON);
		restsubscriberGenKey = extractTagValue(response, "memberIdentifiers", "subscriberGenKey", SERVICEFORMAT.JSON);
		restsourcePersonId = extractTagValue(response, "memberIdentifiers", "sourcePersonId", SERVICEFORMAT.JSON);
		restcoverageKey = extractTagValue(response, "coverageKey", SERVICEFORMAT.JSON);
		restcoverageType = extractTagValue(response, "coverageType", SERVICEFORMAT.JSON);
		restisNonInsurance = extractTagValue(response, "isNonInsurance", SERVICEFORMAT.JSON);
		restplatform = extractTagValue(response, "platform", SERVICEFORMAT.JSON);
		reststartDate = extractTagValue(response, "startDate", SERVICEFORMAT.JSON);
		restendDate = extractTagValue(response, "endDate", SERVICEFORMAT.JSON);
		if (restendDate.endsWith("null")) {
			restEndDate = "9999-12-31";
		}

		restpolicyType = extractTagValue(response, "policyType", SERVICEFORMAT.JSON);
		restrelationshipToSubscriber = extractTagValue(response, "relationshipToSubscriber", SERVICEFORMAT.JSON);
		restpediatricDentalTermDate = extractTagValue(response, "pediatricDentalTermDate", SERVICEFORMAT.JSON);
		if (restpediatricDentalTermDate.endsWith("null")) {
			restpediatricDentalTermDate = "9999-12-31";
		}
		restoperationalMajorLineOfBusiness = extractTagValue(response, "operationalMajorLineOfBusiness",
				SERVICEFORMAT.JSON);
		restcontractId = extractTagValue(response, "contractId", SERVICEFORMAT.JSON);
		restprodPlanId = extractTagValue(response, "prodPlanId", SERVICEFORMAT.JSON);
		reststateOfIssue = extractTagValue(response, "stateOfIssue", SERVICEFORMAT.JSON);
		restoptOut = extractTagValue(response, "optOut", SERVICEFORMAT.JSON);
		restperiod = extractTagValue(response, "period", SERVICEFORMAT.JSON);
		restproductLineCode = extractTagValue(response, "productCategory", "productLineCode", SERVICEFORMAT.JSON);
		restproductLineDescription = extractTagValue(response, "productCategory", "productLineDescription",
				SERVICEFORMAT.JSON);
		restsegmentType = extractTagValue(response, "productCategory", "segmentType", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription = extractTagValue(response, "productCategory",
				"majorLineOfBusinessDescription", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode = extractTagValue(response, "productCategory", "majorLineOfBusinessCode",
				SERVICEFORMAT.JSON);

		// Writing back the data to excel

		dataTable.putData("Parametrized_Checkpoints", "RestBase", restbase);
		dataTable.putData("Parametrized_Checkpoints", "RestDependentCode", restdependentCode);
		dataTable.putData("Parametrized_Checkpoints", "RestMemberGenKey", restmemberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSubscriberGenKey", restsubscriberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId", restsourcePersonId);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey", restcoverageKey);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageType", restcoverageType);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance", restisNonInsurance);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform", restplatform);
		dataTable.putData("Parametrized_Checkpoints", "RestStartDate", reststartDate);
		dataTable.putData("Parametrized_Checkpoints", "RestEndDate", restEndDate);
		dataTable.putData("Parametrized_Checkpoints", "RestPolicyType", restpolicyType);
		dataTable.putData("Parametrized_Checkpoints", "RestRelationshipToSubscriber", restrelationshipToSubscriber);
		dataTable.putData("Parametrized_Checkpoints", "RestPediatricDentalTermDate", restpediatricDentalTermDate);
		dataTable.putData("Parametrized_Checkpoints", "RestOperationalMajorLineOfBusiness",
				restoperationalMajorLineOfBusiness);
		dataTable.putData("Parametrized_Checkpoints", "RestContractId", restcontractId);
		dataTable.putData("Parametrized_Checkpoints", "RestProdPlanId", restprodPlanId);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineCode", restproductLineCode);
		dataTable.putData("Parametrized_Checkpoints", "RestStateOfIssue", reststateOfIssue);
		dataTable.putData("Parametrized_Checkpoints", "RestOptOut", restoptOut);
		dataTable.putData("Parametrized_Checkpoints", "RestPeriod", restperiod);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineDescription", restproductLineDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestSegmentType", restsegmentType);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessDescription",
				restmajorLineOfBusinessDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessCode", restmajorLineOfBusinessCode);

		report.updateTestLog("Validation of Base Present in memberIdentifiers", "REST base => " + restbase + "",
				Status.PASS);
		report.updateTestLog("Validation of DependentCode Present in memberIdentifiers",
				"REST dependentCode => " + restdependentCode + "", Status.PASS);
		report.updateTestLog("Validation of MemberGenKey Present in memberIdentifiers",
				"REST memberGenKey => " + restmemberGenKey + "", Status.PASS);
		report.updateTestLog("Validation of SubscriberGenKey Present in memberIdentifiers",
				"REST subscriberGenKey => " + restsubscriberGenKey + "", Status.PASS);
		report.updateTestLog("Validation of SourcePersonId Present in memberIdentifiers",
				"REST sourcePersonId => " + restsourcePersonId + "", Status.PASS);
		report.updateTestLog("Validation of CoverageKey", "REST coverageKey => " + restcoverageKey + "", Status.PASS);
		report.updateTestLog("Validation of CoverageType", "REST coverageType => " + restcoverageType + "",
				Status.PASS);
		report.updateTestLog("Validation of IsNonInsurance", "REST isNonInsurance => " + restisNonInsurance + "",
				Status.PASS);
		report.updateTestLog("Validation of Platform", "REST platform => " + restplatform + "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "REST startDate => " + reststartDate + "", Status.PASS);

		report.updateTestLog("Validation of EndDate", "REST endDate => " + restEndDate + "", Status.PASS);
		report.updateTestLog("Validation of PolicyType", "REST policyType => " + restpolicyType + "", Status.PASS);
		report.updateTestLog("Validation of RelationshipToSubscriber",
				"REST relationshipToSubscriber => " + restrelationshipToSubscriber + "", Status.PASS);
		report.updateTestLog("Validation of PediatricDentalTermDate",
				"REST pediatricDentalTermDate => " + restpediatricDentalTermDate + "", Status.PASS);
		report.updateTestLog("Validation of OperationalMajorLineOfBusiness",
				"REST operationalMajorLineOfBusiness => " + restoperationalMajorLineOfBusiness + "", Status.PASS);
		report.updateTestLog("Validation of ContractId", "REST contractId => " + restcontractId + "", Status.PASS);
		report.updateTestLog("Validation of ProdPlanId", "REST prodPlanId => " + restprodPlanId + "", Status.PASS);
		report.updateTestLog("Validation of OptOut", "REST optOut => " + restoptOut + "", Status.PASS);
		report.updateTestLog("Validation of Period", "REST period => " + restperiod + "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode Present in productCategory",
				"REST productLineCode => " + restproductLineCode + "", Status.PASS);
		report.updateTestLog("Validation of StateOfIssue Present in productCategory",
				"REST stateOfIssue => " + reststateOfIssue + "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription Present in productCategory",
				"REST productLineDescription => " + restproductLineDescription + "", Status.PASS);
		report.updateTestLog("Validation of SegmentType Present in productCategory",
				"REST segmentType => " + restsegmentType + "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescription Present in productCategory",
				"REST majorLineOfBusinessDescription => " + restmajorLineOfBusinessDescription + "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode Present in productCategory",
				"REST majorLineOfBusinessCode => " + restmajorLineOfBusinessCode + "", Status.PASS);

	}

	public void restMemberCallForFuturedateCoverage() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restbase = extractTagValue(response, "memberIdentifiers", "base", SERVICEFORMAT.JSON);
		restdependentCode = extractTagValue(response, "memberIdentifiers", "dependentCode", SERVICEFORMAT.JSON);
		restmemberGenKey = extractTagValue(response, "memberIdentifiers", "memberGenKey", SERVICEFORMAT.JSON);
		restsubscriberGenKey = extractTagValue(response, "memberIdentifiers", "subscriberGenKey", SERVICEFORMAT.JSON);
		restsourcePersonId = extractTagValue(response, "memberIdentifiers", "sourcePersonId", SERVICEFORMAT.JSON);
		restcoverageKey = extractTagValue(response, "coverageKey", SERVICEFORMAT.JSON);
		restcoverageType = extractTagValue(response, "coverageType", SERVICEFORMAT.JSON);
		restisNonInsurance = extractTagValue(response, "isNonInsurance", SERVICEFORMAT.JSON);
		restplatform = extractTagValue(response, "platform", SERVICEFORMAT.JSON);
		reststartDate = extractTagValue(response, "startDate", SERVICEFORMAT.JSON);
		restendDate = extractTagValue(response, "endDate", SERVICEFORMAT.JSON);
		if (restendDate.endsWith("null")) {
			restEndDate = "9999-12-31";
		}
		restpolicyType = extractTagValue(response, "policyType", SERVICEFORMAT.JSON);
		restrelationshipToSubscriber = extractTagValue(response, "relationshipToSubscriber", SERVICEFORMAT.JSON);
		restpediatricDentalTermDate = extractTagValue(response, "pediatricDentalTermDate", SERVICEFORMAT.JSON);
		if (restpediatricDentalTermDate.endsWith("null")) {
			restPediatricDentalTermDate = "9999-12-31";
		}
		restoperationalMajorLineOfBusiness = extractTagValue(response, "operationalMajorLineOfBusiness",
				SERVICEFORMAT.JSON);
		restcontractId = extractTagValue(response, "contractId", SERVICEFORMAT.JSON);
		restprodPlanId = extractTagValue(response, "prodPlanId", SERVICEFORMAT.JSON);
		reststateOfIssue = extractTagValue(response, "stateOfIssue", SERVICEFORMAT.JSON);
		restoptOut = extractTagValue(response, "optOut", SERVICEFORMAT.JSON);
		restperiod = extractTagValue(response, "period", SERVICEFORMAT.JSON);
		restproductLineCode = extractTagValue(response, "productCategory", "productLineCode", SERVICEFORMAT.JSON);
		restproductLineDescription = extractTagValue(response, "productCategory", "productLineDescription",
				SERVICEFORMAT.JSON);
		// restsegmentType = extractTagValue(response, "productCategory", "segmentType",
		// SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription = extractTagValue(response, "productCategory",
				"majorLineOfBusinessDescription", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode = extractTagValue(response, "productCategory", "majorLineOfBusinessCode",
				SERVICEFORMAT.JSON);

		// Writing back the data to excel

		dataTable.putData("Parametrized_Checkpoints", "RestBase", restbase);
		dataTable.putData("Parametrized_Checkpoints", "RestDependentCode", restdependentCode);
		dataTable.putData("Parametrized_Checkpoints", "RestMemberGenKey", restmemberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSubscriberGenKey", restsubscriberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId", restsourcePersonId);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey", restcoverageKey);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageType", restcoverageType);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance", restisNonInsurance);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform", restplatform);
		dataTable.putData("Parametrized_Checkpoints", "RestStartDate", reststartDate);
		dataTable.putData("Parametrized_Checkpoints", "RestEndDate", restEndDate);
		dataTable.putData("Parametrized_Checkpoints", "RestPolicyType", restpolicyType);
		dataTable.putData("Parametrized_Checkpoints", "RestRelationshipToSubscriber", restrelationshipToSubscriber);
		dataTable.putData("Parametrized_Checkpoints", "RestPediatricDentalTermDate", restPediatricDentalTermDate);
		dataTable.putData("Parametrized_Checkpoints", "RestOperationalMajorLineOfBusiness",
				restoperationalMajorLineOfBusiness);
		dataTable.putData("Parametrized_Checkpoints", "RestContractId", restcontractId);
		dataTable.putData("Parametrized_Checkpoints", "RestProdPlanId", restprodPlanId);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineCode", restproductLineCode);
		dataTable.putData("Parametrized_Checkpoints", "RestStateOfIssue", reststateOfIssue);
		dataTable.putData("Parametrized_Checkpoints", "RestOptOut", restoptOut);
		dataTable.putData("Parametrized_Checkpoints", "RestPeriod", restperiod);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineDescription", restproductLineDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestSegmentType", restsegmentType);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessDescription",
				restmajorLineOfBusinessDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessCode", restmajorLineOfBusinessCode);

		report.updateTestLog("Validation of Base Present in memberIdentifiers", "REST base=> " + restbase + "", "",
				Status.PASS);
		report.updateTestLog("Validation of DependentCode Present in memberIdentifiers",
				"REST dependentCode => " + restdependentCode + "", "", Status.PASS);
		report.updateTestLog("Validation of MemberGenKey Present in memberIdentifiers",
				"REST memberGenKey => " + restmemberGenKey + "", "", Status.PASS);
		report.updateTestLog("Validation of SubscriberGenKey Present in memberIdentifiers",
				"REST subscriberGenKey => " + restsubscriberGenKey + "", "", Status.PASS);
		report.updateTestLog("Validation of SourcePersonId Present in memberIdentifiers",
				"REST sourcePersonId => " + restsourcePersonId + "", "", Status.PASS);
		report.updateTestLog("Validation of coverageKey", "REST coverageKey=> " + restcoverageKey + "", "",
				Status.PASS);
		report.updateTestLog("Validation of coverageType", "REST coverageType=> " + restcoverageType + "", "",
				Status.PASS);
		report.updateTestLog("Validation of IsNonInsurance ", "REST isNonInsurance => " + restisNonInsurance + "", "",
				Status.PASS);
		report.updateTestLog("Validation of platform", "REST platform=> " + restplatform + "", "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "REST startDate=> " + reststartDate + "", "", Status.PASS);
		report.updateTestLog("Validation of EndDate ", "REST endDate => " + restEndDate + "", "", Status.PASS);
		report.updateTestLog("Validation of PolicyType", "REST policyType=> " + restpolicyType + "", "", Status.PASS);
		report.updateTestLog("Validation of RelationshipToSubscriber",
				"REST relationshipToSubscriber=> " + restrelationshipToSubscriber + "", "", Status.PASS);
		report.updateTestLog("Validation of PediatricDentalTermDate",
				"REST pediatricDentalTermDate=> " + restPediatricDentalTermDate + "", "", Status.PASS);
		report.updateTestLog("Validation of OperationalMajorLineOfBusiness",
				"REST operationalMajorLineOfBusiness=> " + restoperationalMajorLineOfBusiness + "", "", Status.PASS);
		report.updateTestLog("Validation of ContractId", "REST contractId=> " + restcontractId + "", "", Status.PASS);
		report.updateTestLog("Validation of ProdPlanId", "REST prodPlanId => " + restprodPlanId + "", "", Status.PASS);
		report.updateTestLog("Validation of optOut", "REST optOut=> " + restoptOut + "", "", Status.PASS);
		report.updateTestLog("Validation of Period", "REST period=> " + restperiod + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode Present in productCategory",
				"REST productLineCode=> " + restproductLineCode + "", "", Status.PASS);
		report.updateTestLog("Validation of StateOfIssue Present in productCategory",
				"REST stateOfIssue => " + reststateOfIssue + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription Present in productCategory",
				"REST productLineDescription => " + restproductLineDescription + "", "", Status.PASS);
		report.updateTestLog("Validation of SegmentType Present in productCategory",
				"REST segmentType => " + restsegmentType + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescription Present in productCategory",
				"REST majorLineOfBusinessDescription=> " + restmajorLineOfBusinessDescription + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode Present in productCategory",
				"REST majorLineOfBusinessCode => " + restmajorLineOfBusinessCode + "", "", Status.PASS);

	}

	public void restMemberCallForKeyCoverage() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restbase = extractTagValue(response, "memberIdentifiers", "base", SERVICEFORMAT.JSON);
		restdependentCode = extractTagValue(response, "memberIdentifiers", "dependentCode", SERVICEFORMAT.JSON);
		restmemberGenKey = extractTagValue(response, "memberIdentifiers", "memberGenKey", SERVICEFORMAT.JSON);
		restsubscriberGenKey = extractTagValue(response, "memberIdentifiers", "subscriberGenKey", SERVICEFORMAT.JSON);
		restsourcePersonId = extractTagValue(response, "memberIdentifiers", "sourcePersonId", SERVICEFORMAT.JSON);
		restcoverageKey = extractTagValue(response, "coverageKey", SERVICEFORMAT.JSON);
		restcoverageType = extractTagValue(response, "coverageType", SERVICEFORMAT.JSON);
		restisNonInsurance = extractTagValue(response, "isNonInsurance", SERVICEFORMAT.JSON);
		restplatform = extractTagValue(response, "platform", SERVICEFORMAT.JSON);
		reststartDate = extractTagValue(response, "startDate", SERVICEFORMAT.JSON);
		restendDate = extractTagValue(response, "endDate", SERVICEFORMAT.JSON);
		if (restendDate.endsWith("null")) {
			restEndDate = "9999-12-31";
		}
		restpolicyType = extractTagValue(response, "policyType", SERVICEFORMAT.JSON);
		restrelationshipToSubscriber = extractTagValue(response, "relationshipToSubscriber", SERVICEFORMAT.JSON);
		restpediatricDentalTermDate = extractTagValue(response, "pediatricDentalTermDate", SERVICEFORMAT.JSON);
		if (restpediatricDentalTermDate.endsWith("null")) {
			restPediatricDentalTermDate = "9999-12-31";
		}
		restoperationalMajorLineOfBusiness = extractTagValue(response, "operationalMajorLineOfBusiness",
				SERVICEFORMAT.JSON);
		restcontractId = extractTagValue(response, "contractId", SERVICEFORMAT.JSON);
		restprodPlanId = extractTagValue(response, "prodPlanId", SERVICEFORMAT.JSON);
		reststateOfIssue = extractTagValue(response, "stateOfIssue", SERVICEFORMAT.JSON);
		restoptOut = extractTagValue(response, "optOut", SERVICEFORMAT.JSON);
		restperiod = extractTagValue(response, "period", SERVICEFORMAT.JSON);
		restproductLineCode = extractTagValue(response, "productCategory", "productLineCode", SERVICEFORMAT.JSON);
		restproductLineDescription = extractTagValue(response, "productCategory", "productLineDescription",
				SERVICEFORMAT.JSON);
		restsegmentType = extractTagValue(response, "productCategory", "segmentType", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription = extractTagValue(response, "productCategory",
				"majorLineOfBusinessDescription", SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode = extractTagValue(response, "productCategory", "majorLineOfBusinessCode",
				SERVICEFORMAT.JSON);

		// Writing back the data to excel

		dataTable.putData("Parametrized_Checkpoints", "RestBase", restbase);
		dataTable.putData("Parametrized_Checkpoints", "RestDependentCode", restdependentCode);
		dataTable.putData("Parametrized_Checkpoints", "RestMemberGenKey", restmemberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSubscriberGenKey", restsubscriberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId", restsourcePersonId);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey", restcoverageKey);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageType", restcoverageType);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance", restisNonInsurance);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform", restplatform);
		dataTable.putData("Parametrized_Checkpoints", "RestStartDate", reststartDate);
		dataTable.putData("Parametrized_Checkpoints", "RestEndDate", restEndDate);
		dataTable.putData("Parametrized_Checkpoints", "RestPolicyType", restpolicyType);
		dataTable.putData("Parametrized_Checkpoints", "RestRelationshipToSubscriber", restrelationshipToSubscriber);
		dataTable.putData("Parametrized_Checkpoints", "RestPediatricDentalTermDate", restPediatricDentalTermDate);
		dataTable.putData("Parametrized_Checkpoints", "RestOperationalMajorLineOfBusiness",
				restoperationalMajorLineOfBusiness);
		dataTable.putData("Parametrized_Checkpoints", "RestContractId", restcontractId);
		dataTable.putData("Parametrized_Checkpoints", "RestProdPlanId", restprodPlanId);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineCode", restproductLineCode);
		dataTable.putData("Parametrized_Checkpoints", "RestStateOfIssue", reststateOfIssue);
		dataTable.putData("Parametrized_Checkpoints", "RestOptOut", restoptOut);
		dataTable.putData("Parametrized_Checkpoints", "RestPeriod", restperiod);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineDescription", restproductLineDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestSegmentType", restsegmentType);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessDescription",
				restmajorLineOfBusinessDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessCode", restmajorLineOfBusinessCode);

		report.updateTestLog("Validation of Base Present in memberIdentifiers", "REST base=> " + restbase + "", "",
				Status.PASS);
		report.updateTestLog("Validation of DependentCode Present in memberIdentifiers",
				"REST dependentCode => " + restdependentCode + "", "", Status.PASS);
		report.updateTestLog("Validation of MemberGenKey Present in memberIdentifiers",
				"REST memberGenKey => " + restmemberGenKey + "", "", Status.PASS);
		report.updateTestLog("Validation of SubscriberGenKey Present in memberIdentifiers",
				"REST subscriberGenKey => " + restsubscriberGenKey + "", "", Status.PASS);
		report.updateTestLog("Validation of SourcePersonId Present in memberIdentifiers",
				"REST sourcePersonId => " + restsourcePersonId + "", "", Status.PASS);
		report.updateTestLog("Validation of coverageKey", "REST coverageKey=> " + restcoverageKey + "", "",
				Status.PASS);
		report.updateTestLog("Validation of coverageType", "REST coverageType=> " + restcoverageType + "", "",
				Status.PASS);
		report.updateTestLog("Validation of IsNonInsurance ", "REST isNonInsurance => " + restisNonInsurance + "", "",
				Status.PASS);
		report.updateTestLog("Validation of platform", "REST platform=> " + restplatform + "", "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "REST startDate=> " + reststartDate + "", "", Status.PASS);
		report.updateTestLog("Validation of EndDate ", "REST endDate => " + restEndDate + "", "", Status.PASS);
		report.updateTestLog("Validation of PolicyType", "REST policyType=> " + restpolicyType + "", "", Status.PASS);
		report.updateTestLog("Validation of RelationshipToSubscriber",
				"REST relationshipToSubscriber=> " + restrelationshipToSubscriber + "", "", Status.PASS);
		report.updateTestLog("Validation of PediatricDentalTermDate",
				"REST pediatricDentalTermDate=> " + restPediatricDentalTermDate + "", "", Status.PASS);
		report.updateTestLog("Validation of OperationalMajorLineOfBusiness",
				"REST operationalMajorLineOfBusiness=> " + restoperationalMajorLineOfBusiness + "", "", Status.PASS);
		report.updateTestLog("Validation of ContractId", "REST contractId=> " + restcontractId + "", "", Status.PASS);
		report.updateTestLog("Validation of ProdPlanId", "REST prodPlanId => " + restprodPlanId + "", "", Status.PASS);
		report.updateTestLog("Validation of optOut", "REST optOut=> " + restoptOut + "", "", Status.PASS);
		report.updateTestLog("Validation of Period", "REST period=> " + restperiod + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode Present in productCategory",
				"REST productLineCode=> " + restproductLineCode + "", "", Status.PASS);
		report.updateTestLog("Validation of StateOfIssue Present in productCategory",
				"REST stateOfIssue => " + reststateOfIssue + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription Present in productCategory",
				"REST productLineDescription => " + restproductLineDescription + "", "", Status.PASS);
		report.updateTestLog("Validation of SegmentType Present in productCategory",
				"REST segmentType => " + restsegmentType + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescription Present in productCategory",
				"REST majorLineOfBusinessDescription=> " + restmajorLineOfBusinessDescription + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode Present in productCategory",
				"REST majorLineOfBusinessCode => " + restmajorLineOfBusinessCode + "", "", Status.PASS);

	}

	public void restMemberCallForPastdateCoverage() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response

		restbase = extractTagValue(response, "memberIdentifiers", "base", 0, SERVICEFORMAT.JSON);
		restbase1 = extractTagValue(response, "memberIdentifiers", "base", 1, SERVICEFORMAT.JSON);
		restbase2 = extractTagValue(response, "memberIdentifiers", "base", 2, SERVICEFORMAT.JSON);
		restbase3 = extractTagValue(response, "memberIdentifiers", "base", 3, SERVICEFORMAT.JSON);

		restdependentCode = extractTagValue(response, "memberIdentifiers", "dependentCode", 0, SERVICEFORMAT.JSON);
		restdependentCode1 = extractTagValue(response, "memberIdentifiers", "dependentCode", 1, SERVICEFORMAT.JSON);
		restdependentCode2 = extractTagValue(response, "memberIdentifiers", "dependentCode", 2, SERVICEFORMAT.JSON);
		restdependentCode3 = extractTagValue(response, "memberIdentifiers", "dependentCode", 3, SERVICEFORMAT.JSON);

		restmemberGenKey = extractTagValue(response, "memberIdentifiers", "memberGenKey", 0, SERVICEFORMAT.JSON);
		restmemberGenKey1 = extractTagValue(response, "memberIdentifiers", "memberGenKey", 1, SERVICEFORMAT.JSON);
		restmemberGenKey2 = extractTagValue(response, "memberIdentifiers", "memberGenKey", 2, SERVICEFORMAT.JSON);
		restmemberGenKey3 = extractTagValue(response, "memberIdentifiers", "memberGenKey", 3, SERVICEFORMAT.JSON);

		restsubscriberGenKey = extractTagValue(response, "memberIdentifiers", "subscriberGenKey", 0,
				SERVICEFORMAT.JSON);
		restsubscriberGenKey1 = extractTagValue(response, "memberIdentifiers", "subscriberGenKey", 1,
				SERVICEFORMAT.JSON);
		restsubscriberGenKey2 = extractTagValue(response, "memberIdentifiers", "subscriberGenKey", 2,
				SERVICEFORMAT.JSON);
		restsubscriberGenKey3 = extractTagValue(response, "memberIdentifiers", "subscriberGenKey", 3,
				SERVICEFORMAT.JSON);

		restsourcePersonId = extractTagValue(response, "memberIdentifiers", "sourcePersonId", 0, SERVICEFORMAT.JSON);
		restsourcePersonId1 = extractTagValue(response, "memberIdentifiers", "sourcePersonId", 1, SERVICEFORMAT.JSON);
		restsourcePersonId2 = extractTagValue(response, "memberIdentifiers", "sourcePersonId", 2, SERVICEFORMAT.JSON);
		restsourcePersonId3 = extractTagValue(response, "memberIdentifiers", "sourcePersonId", 3, SERVICEFORMAT.JSON);

		restcoverageKey = extractTagValue(response, "coverageKey", 0, SERVICEFORMAT.JSON);
		restcoverageKey1 = extractTagValue(response, "coverageKey", 1, SERVICEFORMAT.JSON);
		restcoverageKey2 = extractTagValue(response, "coverageKey", 2, SERVICEFORMAT.JSON);
		restcoverageKey3 = extractTagValue(response, "coverageKey", 3, SERVICEFORMAT.JSON);

		restcoverageType = extractTagValue(response, "coverageType", 0, SERVICEFORMAT.JSON);
		restcoverageType1 = extractTagValue(response, "coverageType", 1, SERVICEFORMAT.JSON);
		restcoverageType2 = extractTagValue(response, "coverageType", 2, SERVICEFORMAT.JSON);
		restcoverageType3 = extractTagValue(response, "coverageType", 3, SERVICEFORMAT.JSON);

		restisNonInsurance = extractTagValue(response, "isNonInsurance", 0, SERVICEFORMAT.JSON);
		restisNonInsurance1 = extractTagValue(response, "isNonInsurance", 1, SERVICEFORMAT.JSON);
		restisNonInsurance2 = extractTagValue(response, "isNonInsurance", 2, SERVICEFORMAT.JSON);
		restisNonInsurance3 = extractTagValue(response, "isNonInsurance", 3, SERVICEFORMAT.JSON);

		restplatform = extractTagValue(response, "platform", 0, SERVICEFORMAT.JSON);
		restplatform1 = extractTagValue(response, "platform", 1, SERVICEFORMAT.JSON);
		restplatform2 = extractTagValue(response, "platform", 2, SERVICEFORMAT.JSON);
		restplatform3 = extractTagValue(response, "platform", 3, SERVICEFORMAT.JSON);

		reststartDate = extractTagValue(response, "startDate", 0, SERVICEFORMAT.JSON);
		reststartDate1 = extractTagValue(response, "startDate", 1, SERVICEFORMAT.JSON);
		reststartDate2 = extractTagValue(response, "startDate", 2, SERVICEFORMAT.JSON);
		reststartDate3 = extractTagValue(response, "startDate", 3, SERVICEFORMAT.JSON);

		restendDate = extractTagValue(response, "endDate", 0, SERVICEFORMAT.JSON);
		restendDate1 = extractTagValue(response, "endDate", 1, SERVICEFORMAT.JSON);
		restendDate2 = extractTagValue(response, "endDate", 2, SERVICEFORMAT.JSON);
		restendDate3 = extractTagValue(response, "endDate", 3, SERVICEFORMAT.JSON);

		restpolicyType = extractTagValue(response, "policyType", 0, SERVICEFORMAT.JSON);
		restpolicyType1 = extractTagValue(response, "policyType", 1, SERVICEFORMAT.JSON);
		restpolicyType2 = extractTagValue(response, "policyType", 2, SERVICEFORMAT.JSON);
		restpolicyType3 = extractTagValue(response, "policyType", 3, SERVICEFORMAT.JSON);

		restrelationshipToSubscriber = extractTagValue(response, "relationshipToSubscriber", 0, SERVICEFORMAT.JSON);
		restrelationshipToSubscriber1 = extractTagValue(response, "relationshipToSubscriber", 1, SERVICEFORMAT.JSON);
		restrelationshipToSubscriber2 = extractTagValue(response, "relationshipToSubscriber", 2, SERVICEFORMAT.JSON);
		restrelationshipToSubscriber3 = extractTagValue(response, "relationshipToSubscriber", 3, SERVICEFORMAT.JSON);

		restpediatricDentalTermDate = extractTagValue(response, "pediatricDentalTermDate", 0, SERVICEFORMAT.JSON);
		if (restpediatricDentalTermDate.endsWith("null")) {
			restPediatricDentalTermDate = "9999-12-31";
		}
		restpediatricDentalTermDate1 = extractTagValue(response, "pediatricDentalTermDate", 1, SERVICEFORMAT.JSON);
		if (restpediatricDentalTermDate1.endsWith("null")) {
			restPediatricDentalTermDate1 = "9999-12-31";
		}
		restpediatricDentalTermDate2 = extractTagValue(response, "pediatricDentalTermDate", 2, SERVICEFORMAT.JSON);
		if (restpediatricDentalTermDate2.endsWith("null")) {
			restPediatricDentalTermDate2 = "9999-12-31";
		}
		restpediatricDentalTermDate3 = extractTagValue(response, "pediatricDentalTermDate", 3, SERVICEFORMAT.JSON);
		if (restpediatricDentalTermDate3.endsWith("null")) {
			restPediatricDentalTermDate3 = "9999-12-31";
		}

		restoperationalMajorLineOfBusiness = extractTagValue(response, "operationalMajorLineOfBusiness", 0,
				SERVICEFORMAT.JSON);
		restoperationalMajorLineOfBusiness1 = extractTagValue(response, "operationalMajorLineOfBusiness", 1,
				SERVICEFORMAT.JSON);
		restoperationalMajorLineOfBusiness2 = extractTagValue(response, "operationalMajorLineOfBusiness", 2,
				SERVICEFORMAT.JSON);
		restoperationalMajorLineOfBusiness3 = extractTagValue(response, "operationalMajorLineOfBusiness", 3,
				SERVICEFORMAT.JSON);

		restcontractId = extractTagValue(response, "contractId", 0, SERVICEFORMAT.JSON);
		restcontractId1 = extractTagValue(response, "contractId", 1, SERVICEFORMAT.JSON);
		restcontractId2 = extractTagValue(response, "contractId", 2, SERVICEFORMAT.JSON);
		restcontractId3 = extractTagValue(response, "contractId", 3, SERVICEFORMAT.JSON);

		restprodPlanId = extractTagValue(response, "prodPlanId", 0, SERVICEFORMAT.JSON);
		restprodPlanId1 = extractTagValue(response, "prodPlanId", 1, SERVICEFORMAT.JSON);
		restprodPlanId2 = extractTagValue(response, "prodPlanId", 2, SERVICEFORMAT.JSON);
		restprodPlanId3 = extractTagValue(response, "prodPlanId", 3, SERVICEFORMAT.JSON);

		reststateOfIssue = extractTagValue(response, "stateOfIssue", 0, SERVICEFORMAT.JSON);
		reststateOfIssue1 = extractTagValue(response, "stateOfIssue", 1, SERVICEFORMAT.JSON);
		reststateOfIssue2 = extractTagValue(response, "stateOfIssue", 2, SERVICEFORMAT.JSON);
		reststateOfIssue3 = extractTagValue(response, "stateOfIssue", 3, SERVICEFORMAT.JSON);

		restoptOut = extractTagValue(response, "optOut", 0, SERVICEFORMAT.JSON);
		restoptOut1 = extractTagValue(response, "optOut", 1, SERVICEFORMAT.JSON);
		restoptOut2 = extractTagValue(response, "optOut", 2, SERVICEFORMAT.JSON);
		restoptOut3 = extractTagValue(response, "optOut", 3, SERVICEFORMAT.JSON);

		restperiod = extractTagValue(response, "period", 0, SERVICEFORMAT.JSON);
		restperiod1 = extractTagValue(response, "period", 1, SERVICEFORMAT.JSON);
		restperiod2 = extractTagValue(response, "period", 2, SERVICEFORMAT.JSON);
		restperiod3 = extractTagValue(response, "period", 3, SERVICEFORMAT.JSON);

		restproductLineCode = extractTagValue(response, "productCategory", "productLineCode", 0, SERVICEFORMAT.JSON);
		restproductLineCode1 = extractTagValue(response, "productCategory", "productLineCode", 1, SERVICEFORMAT.JSON);
		restproductLineCode2 = extractTagValue(response, "productCategory", "productLineCode", 2, SERVICEFORMAT.JSON);
		restproductLineCode3 = extractTagValue(response, "productCategory", "productLineCode", 3, SERVICEFORMAT.JSON);

		restproductLineDescription = extractTagValue(response, "productCategory", "productLineDescription", 0,
				SERVICEFORMAT.JSON);
		restproductLineDescription1 = extractTagValue(response, "productCategory", "productLineDescription", 1,
				SERVICEFORMAT.JSON);
		restproductLineDescription2 = extractTagValue(response, "productCategory", "productLineDescription", 2,
				SERVICEFORMAT.JSON);
		restproductLineDescription3 = extractTagValue(response, "productCategory", "productLineDescription", 3,
				SERVICEFORMAT.JSON);

		/*
		 * restsegmentType = extractTagValue(response, "productCategory", "segmentType",
		 * 0, SERVICEFORMAT.JSON); restsegmentType1 = extractTagValue(response,
		 * "productCategory", "segmentType", 1, SERVICEFORMAT.JSON); restsegmentType2 =
		 * extractTagValue(response, "productCategory", "segmentType", 2,
		 * SERVICEFORMAT.JSON); restsegmentType3 = extractTagValue(response,
		 * "productCategory", "segmentType", 3, SERVICEFORMAT.JSON);
		 */
		restmajorLineOfBusinessDescription = extractTagValue(response, "productCategory",
				"majorLineOfBusinessDescription", 0, SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription1 = extractTagValue(response, "productCategory",
				"majorLineOfBusinessDescription", 1, SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription2 = extractTagValue(response, "productCategory",
				"majorLineOfBusinessDescription", 2, SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription3 = extractTagValue(response, "productCategory",
				"majorLineOfBusinessDescription", 3, SERVICEFORMAT.JSON);

		restmajorLineOfBusinessCode = extractTagValue(response, "productCategory", "majorLineOfBusinessCode", 0,
				SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode1 = extractTagValue(response, "productCategory", "majorLineOfBusinessCode", 1,
				SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode2 = extractTagValue(response, "productCategory", "majorLineOfBusinessCode", 2,
				SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode3 = extractTagValue(response, "productCategory", "majorLineOfBusinessCode", 3,
				SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("Parametrized_Checkpoints", "RestBase", restbase);
		dataTable.putData("Parametrized_Checkpoints", "RestDependentCode", restdependentCode);
		dataTable.putData("Parametrized_Checkpoints", "RestMemberGenKey", restmemberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSubscriberGenKey", restsubscriberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId", restsourcePersonId);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey", restcoverageKey);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageType", restcoverageType);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance", restisNonInsurance);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform", restplatform);
		dataTable.putData("Parametrized_Checkpoints", "RestStartDate", reststartDate);
		dataTable.putData("Parametrized_Checkpoints", "RestEndDate", restendDate);
		dataTable.putData("Parametrized_Checkpoints", "RestPolicyType", restpolicyType);
		dataTable.putData("Parametrized_Checkpoints", "RestRelationshipToSubscriber", restrelationshipToSubscriber);
		dataTable.putData("Parametrized_Checkpoints", "RestPediatricDentalTermDate", restPediatricDentalTermDate);
		dataTable.putData("Parametrized_Checkpoints", "RestOperationalMajorLineOfBusiness",
				restoperationalMajorLineOfBusiness);
		dataTable.putData("Parametrized_Checkpoints", "RestContractId", restcontractId);
		dataTable.putData("Parametrized_Checkpoints", "RestProdPlanId", restprodPlanId);
		dataTable.putData("Parametrized_Checkpoints", "RestStateOfIssue", reststateOfIssue);
		dataTable.putData("Parametrized_Checkpoints", "RestOptOut", restoptOut);
		dataTable.putData("Parametrized_Checkpoints", "RestPeriod", restperiod);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineCode", restproductLineCode);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineDescription", restproductLineDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestSegmentType", restsegmentType);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessDescription",
				restmajorLineOfBusinessDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessCode", restmajorLineOfBusinessCode);

		dataTable.putData("Parametrized_Checkpoints", "RestBase1", restbase1);
		dataTable.putData("Parametrized_Checkpoints", "RestDependentCode1", restdependentCode1);
		dataTable.putData("Parametrized_Checkpoints", "RestMemberGenKey1", restmemberGenKey1);
		dataTable.putData("Parametrized_Checkpoints", "RestSubscriberGenKey1", restsubscriberGenKey1);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId1", restsourcePersonId1);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey1", restcoverageKey1);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageType1", restcoverageType1);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance1", restisNonInsurance1);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform1", restplatform1);
		dataTable.putData("Parametrized_Checkpoints", "RestStartDate1", reststartDate1);
		dataTable.putData("Parametrized_Checkpoints", "RestEndDate1", restendDate1);
		dataTable.putData("Parametrized_Checkpoints", "RestPolicyType1", restpolicyType1);
		dataTable.putData("Parametrized_Checkpoints", "RestRelationshipToSubscriber1", restrelationshipToSubscriber1);
		dataTable.putData("Parametrized_Checkpoints", "RestPediatricDentalTermDate1", restPediatricDentalTermDate1);
		dataTable.putData("Parametrized_Checkpoints", "RestOperationalMajorLineOfBusiness1",
				restoperationalMajorLineOfBusiness1);
		dataTable.putData("Parametrized_Checkpoints", "RestContractId1", restcontractId1);
		dataTable.putData("Parametrized_Checkpoints", "RestProdPlanId1", restprodPlanId1);
		dataTable.putData("Parametrized_Checkpoints", "RestStateOfIssue1", reststateOfIssue1);
		dataTable.putData("Parametrized_Checkpoints", "RestOptOut1", restoptOut1);
		dataTable.putData("Parametrized_Checkpoints", "RestPeriod1", restperiod1);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineCode1", restproductLineCode1);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineDescription1", restproductLineDescription1);
		dataTable.putData("Parametrized_Checkpoints", "RestSegmentType1", restsegmentType1);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessDescription1",
				restmajorLineOfBusinessDescription1);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessCode1", restmajorLineOfBusinessCode1);

		dataTable.putData("Parametrized_Checkpoints", "RestBase2", restbase2);
		dataTable.putData("Parametrized_Checkpoints", "RestDependentCode2", restdependentCode2);
		dataTable.putData("Parametrized_Checkpoints", "RestMemberGenKey2", restmemberGenKey2);
		dataTable.putData("Parametrized_Checkpoints", "RestSubscriberGenKey2", restsubscriberGenKey2);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId2", restsourcePersonId2);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey2", restcoverageKey2);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageType2", restcoverageType2);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance2", restisNonInsurance2);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform2", restplatform2);
		dataTable.putData("Parametrized_Checkpoints", "RestStartDate2", reststartDate2);
		dataTable.putData("Parametrized_Checkpoints", "RestEndDate2", restendDate2);
		dataTable.putData("Parametrized_Checkpoints", "RestPolicyType2", restpolicyType2);
		dataTable.putData("Parametrized_Checkpoints", "RestRelationshipToSubscriber2", restrelationshipToSubscriber2);
		dataTable.putData("Parametrized_Checkpoints", "RestPediatricDentalTermDate2", restPediatricDentalTermDate2);
		dataTable.putData("Parametrized_Checkpoints", "RestOperationalMajorLineOfBusiness2",
				restoperationalMajorLineOfBusiness2);
		dataTable.putData("Parametrized_Checkpoints", "RestContractId2", restcontractId2);
		dataTable.putData("Parametrized_Checkpoints", "RestProdPlanId2", restprodPlanId2);
		dataTable.putData("Parametrized_Checkpoints", "RestStateOfIssue2", reststateOfIssue2);
		dataTable.putData("Parametrized_Checkpoints", "RestOptOut2", restoptOut2);
		dataTable.putData("Parametrized_Checkpoints", "RestPeriod2", restperiod2);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineCode2", restproductLineCode2);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineDescription2", restproductLineDescription2);
		dataTable.putData("Parametrized_Checkpoints", "RestSegmentType2", restsegmentType2);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessDescription2",
				restmajorLineOfBusinessDescription2);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessCode2", restmajorLineOfBusinessCode2);

		dataTable.putData("Parametrized_Checkpoints", "RestBase3", restbase3);
		dataTable.putData("Parametrized_Checkpoints", "RestDependentCode3", restdependentCode3);
		dataTable.putData("Parametrized_Checkpoints", "RestMemberGenKey3", restmemberGenKey3);
		dataTable.putData("Parametrized_Checkpoints", "RestSubscriberGenKey3", restsubscriberGenKey3);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId3", restsourcePersonId3);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey3", restcoverageKey3);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageType3", restcoverageType3);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance3", restisNonInsurance3);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform3", restplatform3);
		dataTable.putData("Parametrized_Checkpoints", "RestStartDate3", reststartDate3);
		dataTable.putData("Parametrized_Checkpoints", "RestEndDate3", restendDate3);
		dataTable.putData("Parametrized_Checkpoints", "RestPolicyType3", restpolicyType3);
		dataTable.putData("Parametrized_Checkpoints", "RestRelationshipToSubscriber3", restrelationshipToSubscriber3);
		dataTable.putData("Parametrized_Checkpoints", "RestPediatricDentalTermDate3", restPediatricDentalTermDate3);
		dataTable.putData("Parametrized_Checkpoints", "RestOperationalMajorLineOfBusiness3",
				restoperationalMajorLineOfBusiness3);
		dataTable.putData("Parametrized_Checkpoints", "RestContractId3", restcontractId3);
		dataTable.putData("Parametrized_Checkpoints", "RestProdPlanId3", restprodPlanId3);
		dataTable.putData("Parametrized_Checkpoints", "RestStateOfIssue3", reststateOfIssue3);
		dataTable.putData("Parametrized_Checkpoints", "RestOptOut3", restoptOut3);
		dataTable.putData("Parametrized_Checkpoints", "RestPeriod3", restperiod3);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineCode3", restproductLineCode3);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineDescription3", restproductLineDescription3);
		dataTable.putData("Parametrized_Checkpoints", "RestSegmentType3", restsegmentType3);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessDescription3",
				restmajorLineOfBusinessDescription3);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessCode3", restmajorLineOfBusinessCode3);

		report.updateTestLog("Validation of Base Present in memberIdentifiers", "REST base=> " + restbase + "", "",
				Status.PASS);
		report.updateTestLog("Validation of DependentCode Present in memberIdentifiers",
				"REST dependentCode => " + restdependentCode + "", "", Status.PASS);
		report.updateTestLog("Validation of MemberGenKey Present in memberIdentifiers",
				"REST memberGenKey => " + restmemberGenKey + "", "", Status.PASS);
		report.updateTestLog("Validation of SubscriberGenKey Present in memberIdentifiers",
				"REST subscriberGenKey => " + restsubscriberGenKey + "", "", Status.PASS);
		report.updateTestLog("Validation of SourcePersonId Present in memberIdentifiers",
				"REST sourcePersonId => " + restsourcePersonId + "", "", Status.PASS);
		report.updateTestLog("Validation of coverageKey", "REST coverageKey=> " + restcoverageKey + "", "",
				Status.PASS);
		report.updateTestLog("Validation of coverageType", "REST coverageType=> " + restcoverageType + "", "",
				Status.PASS);
		report.updateTestLog("Validation of IsNonInsurance ", "REST isNonInsurance => " + restisNonInsurance + "", "",
				Status.PASS);
		report.updateTestLog("Validation of platform", "REST platform=> " + restplatform + "", "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "REST startDate=> " + reststartDate + "", "", Status.PASS);

		report.updateTestLog("Validation of EndDate ", "REST endDate => " + restendDate + "", "", Status.PASS);
		report.updateTestLog("Validation of PolicyType", "REST policyType=> " + restpolicyType + "", "", Status.PASS);
		report.updateTestLog("Validation of RelationshipToSubscriber",
				"REST relationshipToSubscriber=> " + restrelationshipToSubscriber + "", "", Status.PASS);
		report.updateTestLog("Validation of PediatricDentalTermDate",
				"REST pediatricDentalTermDate=> " + restPediatricDentalTermDate + "", "", Status.PASS);

		report.updateTestLog("Validation of OperationalMajorLineOfBusiness",
				"REST operationalMajorLineOfBusiness=> " + restoperationalMajorLineOfBusiness + "", "", Status.PASS);
		report.updateTestLog("Validation of ContractId", "REST contractId=> " + restcontractId + "", "", Status.PASS);
		report.updateTestLog("Validation of ProdPlanId", "REST prodPlanId => " + restprodPlanId + "", "", Status.PASS);
		report.updateTestLog("Validation of optOut", "REST optOut=> " + restoptOut + "", "", Status.PASS);
		report.updateTestLog("Validation of Period", "REST period=> " + restperiod + "", "", Status.PASS);

		report.updateTestLog("Validation of ProductLineCode Present in productCategory",
				"REST productLineCode=> " + restproductLineCode + "", "", Status.PASS);
		report.updateTestLog("Validation of StateOfIssue Present in productCategory",
				"REST stateOfIssue => " + reststateOfIssue + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription Present in productCategory",
				"REST productLineDescription => " + restproductLineDescription + "", "", Status.PASS);
		report.updateTestLog("Validation of SegmentType Present in productCategory",
				"REST segmentType => " + restsegmentType + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescription Present in productCategory",
				"REST majorLineOfBusinessDescription=> " + restmajorLineOfBusinessDescription + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode Present in productCategory",
				"REST majorLineOfBusinessCode => " + restmajorLineOfBusinessCode + "", "", Status.PASS);

		report.updateTestLog("Validation of Base Present in memberIdentifiers", "REST base=> " + restbase1 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of DependentCode Present in memberIdentifiers",
				"REST dependentCode => " + restdependentCode1 + "", "", Status.PASS);
		report.updateTestLog("Validation of MemberGenKey Present in memberIdentifiers",
				"REST memberGenKey => " + restmemberGenKey1 + "", "", Status.PASS);
		report.updateTestLog("Validation of SubscriberGenKey Present in memberIdentifiers",
				"REST subscriberGenKey => " + restsubscriberGenKey1 + "", "", Status.PASS);
		report.updateTestLog("Validation of sourcePersonId Present in memberIdentifiers",
				"REST sourcePersonId => " + restsourcePersonId1 + "", "", Status.PASS);
		report.updateTestLog("Validation of CoverageKey", "REST coverageKey=> " + restcoverageKey1 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of coverageType", "REST coverageType=> " + restcoverageType1 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of IsNonInsurance ", "REST isNonInsurance => " + restisNonInsurance1 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of platform", "REST platform=> " + restplatform1 + "", "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "REST startDate=> " + reststartDate1 + "", "", Status.PASS);
		report.updateTestLog("Validation of EndDate ", "REST endDate => " + restendDate1 + "", "", Status.PASS);
		report.updateTestLog("Validation of PolicyType", "REST policyType=> " + restpolicyType1 + "", "", Status.PASS);
		report.updateTestLog("Validation of RelationshipToSubscriber",
				"REST relationshipToSubscriber=> " + restrelationshipToSubscriber1 + "", "", Status.PASS);
		report.updateTestLog("Validation of PediatricDentalTermDate",
				"REST pediatricDentalTermDate=> " + restPediatricDentalTermDate1 + "", "", Status.PASS);
		report.updateTestLog("Validation of OperationalMajorLineOfBusiness",
				"REST operationalMajorLineOfBusiness=> " + restoperationalMajorLineOfBusiness1 + "", "", Status.PASS);
		report.updateTestLog("Validation of ContractId", "REST contractId=> " + restcontractId1 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProdPlanId", "REST prodPlanId => " + restprodPlanId1 + "", "", Status.PASS);
		report.updateTestLog("Validation of optOut", "REST optOut=> " + restoptOut1 + "", "", Status.PASS);
		report.updateTestLog("Validation of Period", "REST period=> " + restperiod1 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode Present in productCategory",
				"REST productLineCode=> " + restproductLineCode1 + "", "", Status.PASS);
		report.updateTestLog("Validation of StateOfIssue Present in productCategory",
				"REST stateOfIssue => " + reststateOfIssue1 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription Present in productCategory",
				"REST productLineDescription => " + restproductLineDescription1 + "", "", Status.PASS);
		report.updateTestLog("Validation of SegmentType Present in productCategory",
				"REST segmentType => " + restsegmentType1 + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescription Present in productCategory",
				"REST majorLineOfBusinessDescription=> " + restmajorLineOfBusinessDescription1 + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode Present in productCategory",
				"REST majorLineOfBusinessCode => " + restmajorLineOfBusinessCode1 + "", "", Status.PASS);

		report.updateTestLog("Validation of Base Present in memberIdentifiers", "REST base=> " + restbase2 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of DependentCode Present in memberIdentifiers",
				"REST dependentCode => " + restdependentCode2 + "", "", Status.PASS);
		report.updateTestLog("Validation of MemberGenKey Present in memberIdentifiers",
				"REST memberGenKey => " + restmemberGenKey2 + "", "", Status.PASS);
		report.updateTestLog("Validation of SubscriberGenKey Present in memberIdentifiers",
				"REST subscriberGenKey => " + restsubscriberGenKey2 + "", "", Status.PASS);
		report.updateTestLog("Validation of sourcePersonId Present in memberIdentifiers",
				"REST sourcePersonId => " + restsourcePersonId2 + "", "", Status.PASS);
		report.updateTestLog("Validation of CoverageKey", "REST coverageKey=> " + restcoverageKey2 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of coverageType", "REST coverageType=> " + restcoverageType2 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of IsNonInsurance ", "REST isNonInsurance => " + restisNonInsurance2 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of platform", "REST platform=> " + restplatform2 + "", "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "REST startDate=> " + reststartDate2 + "", "", Status.PASS);
		report.updateTestLog("Validation of EndDate ", "REST endDate => " + restendDate2 + "", "", Status.PASS);
		report.updateTestLog("Validation of PolicyType", "REST policyType=> " + restpolicyType2 + "", "", Status.PASS);
		report.updateTestLog("Validation of RelationshipToSubscriber",
				"REST relationshipToSubscriber=> " + restrelationshipToSubscriber2 + "", "", Status.PASS);
		report.updateTestLog("Validation of PediatricDentalTermDate",
				"REST pediatricDentalTermDate=> " + restPediatricDentalTermDate2 + "", "", Status.PASS);
		report.updateTestLog("Validation of OperationalMajorLineOfBusiness",
				"REST operationalMajorLineOfBusiness=> " + restoperationalMajorLineOfBusiness2 + "", "", Status.PASS);
		report.updateTestLog("Validation of ContractId", "REST contractId=> " + restcontractId2 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProdPlanId", "REST prodPlanId => " + restprodPlanId2 + "", "", Status.PASS);
		report.updateTestLog("Validation of optOut", "REST optOut=> " + restoptOut2 + "", "", Status.PASS);
		report.updateTestLog("Validation of Period", "REST period=> " + restperiod2 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode Present in productCategory",
				"REST productLineCode=> " + restproductLineCode2 + "", "", Status.PASS);
		report.updateTestLog("Validation of StateOfIssue Present in productCategory",
				"REST stateOfIssue => " + reststateOfIssue2 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription Present in productCategory",
				"REST productLineDescription => " + restproductLineDescription2 + "", "", Status.PASS);
		report.updateTestLog("Validation of SegmentType Present in productCategory",
				"REST segmentType => " + restsegmentType2 + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescriptionPresent in productCategory",
				"REST majorLineOfBusinessDescription=> " + restmajorLineOfBusinessDescription2 + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode Present in productCategory",
				"REST majorLineOfBusinessCode => " + restmajorLineOfBusinessCode2 + "", "", Status.PASS);

		report.updateTestLog("Validation of Base Present in memberIdentifiers", "REST base=> " + restbase3 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of DependentCode Present in memberIdentifiers",
				"REST dependentCode => " + restdependentCode3 + "", "", Status.PASS);
		report.updateTestLog("Validation of MemberGenKey Present in memberIdentifiers",
				"REST memberGenKey => " + restmemberGenKey3 + "", "", Status.PASS);
		report.updateTestLog("Validation of SubscriberGenKey Present in memberIdentifiers",
				"REST subscriberGenKey => " + restsubscriberGenKey3 + "", "", Status.PASS);
		report.updateTestLog("Validation of sourcePersonId Present in memberIdentifiers",
				"REST sourcePersonId => " + restsourcePersonId3 + "", "", Status.PASS);
		report.updateTestLog("Validation of RestCoverageKey", "REST coverageKey=> " + restcoverageKey3 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of coverageType", "REST coverageType=> " + restcoverageType3 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of IsNonInsurance ", "REST isNonInsurance => " + restisNonInsurance3 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of platform", "REST platform=> " + restplatform3 + "", "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "REST startDate=> " + reststartDate3 + "", "", Status.PASS);
		report.updateTestLog("Validation of EndDate ", "REST endDate => " + restendDate3 + "", "", Status.PASS);
		report.updateTestLog("Validation of PolicyType", "REST policyType=> " + restpolicyType3 + "", "", Status.PASS);
		report.updateTestLog("Validation of RelationshipToSubscriber",
				"REST relationshipToSubscriber=> " + restrelationshipToSubscriber3 + "", "", Status.PASS);
		report.updateTestLog("Validation of PediatricDentalTermDate",
				"REST pediatricDentalTermDate=> " + restPediatricDentalTermDate3 + "", "", Status.PASS);
		report.updateTestLog("Validation of OperationalMajorLineOfBusiness",
				"REST operationalMajorLineOfBusiness=> " + restoperationalMajorLineOfBusiness3 + "", "", Status.PASS);
		report.updateTestLog("Validation of ContractId", "REST contractId=> " + restcontractId3 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProdPlanId", "REST prodPlanId => " + restprodPlanId3 + "", "", Status.PASS);
		report.updateTestLog("Validation of optOut", "REST optOut=> " + restoptOut3 + "", "", Status.PASS);
		report.updateTestLog("Validation of Period", "REST period=> " + restperiod3 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode Present in productCategory",
				"REST productLineCode=> " + restproductLineCode3 + "", "", Status.PASS);
		report.updateTestLog("Validation of StateOfIssue Present in productCategory",
				"REST stateOfIssue => " + reststateOfIssue3 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription Present in productCategory",
				"REST productLineDescription => " + restproductLineDescription3 + "", "", Status.PASS);
		report.updateTestLog("Validation of SegmentType Present in productCategory",
				"REST segmentType => " + restsegmentType3 + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescriptionPresent in productCategory",
				"REST majorLineOfBusinessDescription=> " + restmajorLineOfBusinessDescription3 + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode Present in productCategory",
				"REST majorLineOfBusinessCode => " + restmajorLineOfBusinessCode3 + "", "", Status.PASS);

	}

	public void restMemberCallForKeyFamilyCoverage() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response

		restbase = extractTagValue(response, "memberIdentifiers", "base", 0, SERVICEFORMAT.JSON);
		restbase1 = extractTagValue(response, "memberIdentifiers", "base", 1, SERVICEFORMAT.JSON);
		restdependentCode = extractTagValue(response, "memberIdentifiers", "dependentCode", 0, SERVICEFORMAT.JSON);
		restdependentCode1 = extractTagValue(response, "memberIdentifiers", "dependentCode", 1, SERVICEFORMAT.JSON);

		restmemberGenKey = extractTagValue(response, "memberIdentifiers", "memberGenKey", 0, SERVICEFORMAT.JSON);
		restmemberGenKey1 = extractTagValue(response, "memberIdentifiers", "memberGenKey", 1, SERVICEFORMAT.JSON);

		restsubscriberGenKey = extractTagValue(response, "memberIdentifiers", "subscriberGenKey", 0,
				SERVICEFORMAT.JSON);
		restsubscriberGenKey1 = extractTagValue(response, "memberIdentifiers", "subscriberGenKey", 1,
				SERVICEFORMAT.JSON);

		restsourcePersonId = extractTagValue(response, "memberIdentifiers", "sourcePersonId", 0, SERVICEFORMAT.JSON);
		restsourcePersonId1 = extractTagValue(response, "memberIdentifiers", "sourcePersonId", 1, SERVICEFORMAT.JSON);

		restcoverageKey = extractTagValue(response, "coverageKey", 0, SERVICEFORMAT.JSON);
		restcoverageKey1 = extractTagValue(response, "coverageKey", 1, SERVICEFORMAT.JSON);

		restcoverageType = extractTagValue(response, "coverageType", 0, SERVICEFORMAT.JSON);
		restcoverageType1 = extractTagValue(response, "coverageType", 1, SERVICEFORMAT.JSON);

		restisNonInsurance = extractTagValue(response, "isNonInsurance", 0, SERVICEFORMAT.JSON);
		restisNonInsurance1 = extractTagValue(response, "isNonInsurance", 1, SERVICEFORMAT.JSON);

		restplatform = extractTagValue(response, "platform", 0, SERVICEFORMAT.JSON);
		restplatform1 = extractTagValue(response, "platform", 1, SERVICEFORMAT.JSON);

		reststartDate = extractTagValue(response, "startDate", 0, SERVICEFORMAT.JSON);
		reststartDate1 = extractTagValue(response, "startDate", 1, SERVICEFORMAT.JSON);

		restendDate = extractTagValue(response, "endDate", 0, SERVICEFORMAT.JSON);
		restendDate1 = extractTagValue(response, "endDate", 1, SERVICEFORMAT.JSON);

		restpolicyType = extractTagValue(response, "policyType", 0, SERVICEFORMAT.JSON);
		restpolicyType1 = extractTagValue(response, "policyType", 1, SERVICEFORMAT.JSON);

		restrelationshipToSubscriber = extractTagValue(response, "relationshipToSubscriber", 0, SERVICEFORMAT.JSON);
		restrelationshipToSubscriber1 = extractTagValue(response, "relationshipToSubscriber", 1, SERVICEFORMAT.JSON);

		restpediatricDentalTermDate = extractTagValue(response, "pediatricDentalTermDate", 0, SERVICEFORMAT.JSON);
		if (restpediatricDentalTermDate.endsWith("null")) {
			restPediatricDentalTermDate = "9999-12-31";
		}
		restpediatricDentalTermDate1 = extractTagValue(response, "pediatricDentalTermDate", 1, SERVICEFORMAT.JSON);
		if (restpediatricDentalTermDate1.endsWith("null")) {
			restPediatricDentalTermDate1 = "9999-12-31";
		}

		restoperationalMajorLineOfBusiness = extractTagValue(response, "operationalMajorLineOfBusiness", 0,
				SERVICEFORMAT.JSON);
		restoperationalMajorLineOfBusiness1 = extractTagValue(response, "operationalMajorLineOfBusiness", 1,
				SERVICEFORMAT.JSON);

		restcontractId = extractTagValue(response, "contractId", 0, SERVICEFORMAT.JSON);
		restcontractId1 = extractTagValue(response, "contractId", 1, SERVICEFORMAT.JSON);

		restprodPlanId = extractTagValue(response, "prodPlanId", 0, SERVICEFORMAT.JSON);
		restprodPlanId1 = extractTagValue(response, "prodPlanId", 1, SERVICEFORMAT.JSON);

		reststateOfIssue = extractTagValue(response, "stateOfIssue", 0, SERVICEFORMAT.JSON);
		reststateOfIssue1 = extractTagValue(response, "stateOfIssue", 1, SERVICEFORMAT.JSON);

		restoptOut = extractTagValue(response, "optOut", 0, SERVICEFORMAT.JSON);
		restoptOut1 = extractTagValue(response, "optOut", 1, SERVICEFORMAT.JSON);

		restperiod = extractTagValue(response, "period", 0, SERVICEFORMAT.JSON);
		restperiod1 = extractTagValue(response, "period", 1, SERVICEFORMAT.JSON);

		restproductLineCode = extractTagValue(response, "productCategory", "productLineCode", 0, SERVICEFORMAT.JSON);
		restproductLineCode1 = extractTagValue(response, "productCategory", "productLineCode", 1, SERVICEFORMAT.JSON);

		restproductLineDescription = extractTagValue(response, "productCategory", "productLineDescription", 0,
				SERVICEFORMAT.JSON);
		restproductLineDescription1 = extractTagValue(response, "productCategory", "productLineDescription", 1,
				SERVICEFORMAT.JSON);

		restsegmentType = extractTagValue(response, "productCategory", "segmentType", 0, SERVICEFORMAT.JSON);
		restsegmentType1 = extractTagValue(response, "productCategory", "segmentType", 1, SERVICEFORMAT.JSON);

		restmajorLineOfBusinessDescription = extractTagValue(response, "productCategory",
				"majorLineOfBusinessDescription", 0, SERVICEFORMAT.JSON);
		restmajorLineOfBusinessDescription1 = extractTagValue(response, "productCategory",
				"majorLineOfBusinessDescription", 1, SERVICEFORMAT.JSON);

		restmajorLineOfBusinessCode = extractTagValue(response, "productCategory", "majorLineOfBusinessCode", 0,
				SERVICEFORMAT.JSON);
		restmajorLineOfBusinessCode1 = extractTagValue(response, "productCategory", "majorLineOfBusinessCode", 1,
				SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("Parametrized_Checkpoints", "RestBase", restbase);
		dataTable.putData("Parametrized_Checkpoints", "RestDependentCode", restdependentCode);
		dataTable.putData("Parametrized_Checkpoints", "RestMemberGenKey", restmemberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSubscriberGenKey", restsubscriberGenKey);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId", restsourcePersonId);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey", restcoverageKey);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageType", restcoverageType);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance", restisNonInsurance);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform", restplatform);
		dataTable.putData("Parametrized_Checkpoints", "RestStartDate", reststartDate);
		dataTable.putData("Parametrized_Checkpoints", "RestEndDate", restendDate);
		dataTable.putData("Parametrized_Checkpoints", "RestPolicyType", restpolicyType);
		dataTable.putData("Parametrized_Checkpoints", "RestRelationshipToSubscriber", restrelationshipToSubscriber);
		dataTable.putData("Parametrized_Checkpoints", "RestPediatricDentalTermDate", restPediatricDentalTermDate);
		dataTable.putData("Parametrized_Checkpoints", "RestOperationalMajorLineOfBusiness",
				restoperationalMajorLineOfBusiness);
		dataTable.putData("Parametrized_Checkpoints", "RestContractId", restcontractId);
		dataTable.putData("Parametrized_Checkpoints", "RestProdPlanId", restprodPlanId);
		dataTable.putData("Parametrized_Checkpoints", "RestStateOfIssue", reststateOfIssue);
		dataTable.putData("Parametrized_Checkpoints", "RestOptOut", restoptOut);
		dataTable.putData("Parametrized_Checkpoints", "RestPeriod", restperiod);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineCode", restproductLineCode);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineDescription", restproductLineDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestSegmentType", restsegmentType);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessDescription",
				restmajorLineOfBusinessDescription);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessCode", restmajorLineOfBusinessCode);

		dataTable.putData("Parametrized_Checkpoints", "RestBase1", restbase1);
		dataTable.putData("Parametrized_Checkpoints", "RestDependentCode1", restdependentCode1);
		dataTable.putData("Parametrized_Checkpoints", "RestMemberGenKey1", restmemberGenKey1);
		dataTable.putData("Parametrized_Checkpoints", "RestSubscriberGenKey1", restsubscriberGenKey1);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId1", restsourcePersonId1);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey1", restcoverageKey1);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageType1", restcoverageType1);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance1", restisNonInsurance1);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform1", restplatform1);
		dataTable.putData("Parametrized_Checkpoints", "RestStartDate1", reststartDate1);
		dataTable.putData("Parametrized_Checkpoints", "RestEndDate1", restendDate1);
		dataTable.putData("Parametrized_Checkpoints", "RestPolicyType1", restpolicyType1);
		dataTable.putData("Parametrized_Checkpoints", "RestRelationshipToSubscriber1", restrelationshipToSubscriber1);
		dataTable.putData("Parametrized_Checkpoints", "RestPediatricDentalTermDate1", restPediatricDentalTermDate1);
		dataTable.putData("Parametrized_Checkpoints", "RestOperationalMajorLineOfBusiness1",
				restoperationalMajorLineOfBusiness1);
		dataTable.putData("Parametrized_Checkpoints", "RestContractId1", restcontractId1);
		dataTable.putData("Parametrized_Checkpoints", "RestProdPlanId1", restprodPlanId1);
		dataTable.putData("Parametrized_Checkpoints", "RestStateOfIssue1", reststateOfIssue1);
		dataTable.putData("Parametrized_Checkpoints", "RestOptOut1", restoptOut1);
		dataTable.putData("Parametrized_Checkpoints", "RestPeriod1", restperiod1);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineCode1", restproductLineCode1);
		dataTable.putData("Parametrized_Checkpoints", "RestProductLineDescription1", restproductLineDescription1);
		dataTable.putData("Parametrized_Checkpoints", "RestSegmentType1", restsegmentType1);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessDescription1",
				restmajorLineOfBusinessDescription1);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusinessCode1", restmajorLineOfBusinessCode1);

		report.updateTestLog("Validation of Base Present in memberIdentifiers", "REST base => " + restbase + "", "",
				Status.PASS);
		report.updateTestLog("Validation of DependentCode Present in memberIdentifiers",
				"REST dependentCode => " + restdependentCode + "", "", Status.PASS);
		report.updateTestLog("Validation of MemberGenKey Present in memberIdentifiers",
				"REST memberGenKey => " + restmemberGenKey + "", "", Status.PASS);
		report.updateTestLog("Validation of SubscriberGenKey Present in memberIdentifiers",
				"REST subscriberGenKey => " + restsubscriberGenKey + "", "", Status.PASS);
		report.updateTestLog("Validation of SourcePersonId Present in memberIdentifiers",
				"REST sourcePersonId => " + restsourcePersonId + "", "", Status.PASS);
		report.updateTestLog("Validation of CoverageKey", "REST coverageKey => " + restcoverageKey + "", "",
				Status.PASS);
		report.updateTestLog("Validation of CoverageType", "REST coverageType => " + restcoverageType + "", "",
				Status.PASS);
		report.updateTestLog("Validation of IsNonInsurance", "REST isNonInsurance => " + restisNonInsurance + "", "",
				Status.PASS);
		report.updateTestLog("Validation of Platform", "REST platform => " + restplatform + "", "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "REST startDate => " + reststartDate + "", "", Status.PASS);

		report.updateTestLog("Validation of EndDate", "REST endDate => " + restendDate + "", "", Status.PASS);
		report.updateTestLog("Validation of PolicyType", "REST policyType => " + restpolicyType + "", "", Status.PASS);
		report.updateTestLog("Validation of RelationshipToSubscriber",
				"REST relationshipToSubscriber => " + restrelationshipToSubscriber + "", "", Status.PASS);
		report.updateTestLog("Validation of PediatricDentalTermDate",
				"REST pediatricDentalTermDate => " + restPediatricDentalTermDate + "", "", Status.PASS);
		report.updateTestLog("Validation of OperationalMajorLineOfBusiness",
				"REST operationalMajorLineOfBusiness => " + restoperationalMajorLineOfBusiness + "", "", Status.PASS);
		report.updateTestLog("Validation of RestContractId", "REST restcontractId => " + restcontractId + "", "",
				Status.PASS);
		report.updateTestLog("Validation of ProdPlanId", "REST prodPlanId => " + restprodPlanId + "", "", Status.PASS);
		report.updateTestLog("Validation of OptOut", "REST optOut => " + restoptOut + "", "", Status.PASS);
		report.updateTestLog("Validation of Period", "REST period => " + restperiod + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode Present in productCategory",
				"REST productLineCode => " + restproductLineCode + "", "", Status.PASS);
		report.updateTestLog("Validation of StateOfIssue Present in productCategory",
				"REST stateOfIssue => " + reststateOfIssue + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription Present in productCategory",
				"REST productLineDescription => " + restproductLineDescription + "", "", Status.PASS);
		report.updateTestLog("Validation of SegmentType Present in productCategory",
				"REST segmentType => " + restsegmentType + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescription Present in productCategory",
				"REST majorLineOfBusinessDescription => " + restmajorLineOfBusinessDescription + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode Present in productCategory",
				"REST majorLineOfBusinessCode => " + restmajorLineOfBusinessCode + "", "", Status.PASS);

		report.updateTestLog("Validation of Base Present in memberIdentifiers", "REST base => " + restbase1 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of DependentCode Present in memberIdentifiers",
				"REST dependentCode => " + restdependentCode1 + "", "", Status.PASS);
		report.updateTestLog("Validation of MemberGenKey Present in memberIdentifiers",
				"REST memberGenKey => " + restmemberGenKey1 + "", "", Status.PASS);
		report.updateTestLog("Validation of SubscriberGenKey Present in memberIdentifiers",
				"REST subscriberGenKey => " + restsubscriberGenKey1 + "", "", Status.PASS);
		report.updateTestLog("Validation of SourcePersonId Present in memberIdentifiers",
				"REST sourcePersonId => " + restsourcePersonId1 + "", "", Status.PASS);
		report.updateTestLog("Validation of CoverageKey", "REST coverageKey => " + restcoverageKey1 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of CoverageType", "REST coverageType => " + restcoverageType1 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of IsNonInsurance", "REST isNonInsurance => " + restisNonInsurance1 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of Platform", "REST platform => " + restplatform1 + "", "", Status.PASS);
		report.updateTestLog("Validation of StartDate", "REST startDate => " + reststartDate1 + "", "", Status.PASS);
		report.updateTestLog("Validation of EndDate", "REST endDate => " + restendDate1 + "", "", Status.PASS);
		report.updateTestLog("Validation of PolicyType", "REST policyType => " + restpolicyType1 + "", "", Status.PASS);
		report.updateTestLog("Validation of RelationshipToSubscriber",
				"REST relationshipToSubscriber => " + restrelationshipToSubscriber1 + "", "", Status.PASS);
		report.updateTestLog("Validation of PediatricDentalTermDate",
				"REST pediatricDentalTermDate => " + restPediatricDentalTermDate1 + "", "", Status.PASS);
		report.updateTestLog("Validation of OperationalMajorLineOfBusiness",
				"REST operationalMajorLineOfBusiness => " + restoperationalMajorLineOfBusiness1 + "", "", Status.PASS);
		report.updateTestLog("Validation of ContractId", "REST contractId => " + restcontractId1 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProdPlanId", "REST prodPlanId => " + restprodPlanId1 + "", "", Status.PASS);
		report.updateTestLog("Validation of OptOut", "REST optOut => " + restoptOut1 + "", "", Status.PASS);
		report.updateTestLog("Validation of Period", "REST period => " + restperiod1 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineCode Present in productCategory",
				"REST productLineCode => " + restproductLineCode1 + "", "", Status.PASS);
		report.updateTestLog("Validation of StateOfIssue Present in productCategory",
				"REST stateOfIssue => " + reststateOfIssue1 + "", "", Status.PASS);
		report.updateTestLog("Validation of ProductLineDescription Present in productCategory",
				"REST productLineDescription => " + restproductLineDescription1 + "", "", Status.PASS);
		report.updateTestLog("Validation of SegmentType Present in productCategory",
				"REST segmentType => " + restsegmentType1 + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessDescription Present in productCategory",
				"REST majorLineOfBusinessDescription => " + restmajorLineOfBusinessDescription1 + "", "", Status.PASS);
		report.updateTestLog("Validation of MajorLineOfBusinessCode Present in productCategory",
				"REST majorLineOfBusinessCode => " + restmajorLineOfBusinessCode1 + "", "", Status.PASS);
	}

	public void restMemberForBillsProfiles() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restbase = extractTagValue(response, "profileExists", SERVICEFORMAT.JSON);
		restId = extractTagValue(response, "profiles", "id", SERVICEFORMAT.JSON);
		restIdType = extractTagValue(response, "profiles", "idType", SERVICEFORMAT.JSON);
		restplatform = extractTagValue(response, "profiles", "platform", SERVICEFORMAT.JSON);

		dataTable.putData("Parametrized_Checkpoints", "RestBase", restbase);
		dataTable.putData("Parametrized_Checkpoints", "RestId", restId);
		dataTable.putData("Parametrized_Checkpoints", "RestIdType", restIdType);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform", restplatform);

		report.updateTestLog("Validation of Base", "REST Base => " + restbase + "", "", Status.PASS);
		report.updateTestLog("Validation of Id", "REST Id => " + restId + "", "", Status.PASS);
		report.updateTestLog("Validation of IdType", "REST IdType => " + restIdType + "", "", Status.PASS);
		report.updateTestLog("Validation of Platform", "REST Platform => " + restplatform + "", "", Status.PASS);

	}

	public void restMemberForRelationships() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restplanType = extractTagValue(response, "planType", SERVICEFORMAT.JSON);
		restvalidatedOnWeb = extractTagValue(response, "validatedOnWeb", SERVICEFORMAT.JSON);
		restconsentType = extractTagValue(response, "consents", "consentType", SERVICEFORMAT.JSON);
		restconsentStartDate = extractTagValue(response, "consents", "consentStartDate", SERVICEFORMAT.JSON);
		restconsentEndDate = extractTagValue(response, "consents", "consentEndDate", SERVICEFORMAT.JSON);
		restconsentTermDate = extractTagValue(response, "consents", "consentTermDate", SERVICEFORMAT.JSON);

		dataTable.putData("Parametrized_Checkpoints", "RestPlanType", restplanType);
		dataTable.putData("Parametrized_Checkpoints", "RestValidatedOnWeb", restvalidatedOnWeb);
		dataTable.putData("Parametrized_Checkpoints", "RestConsentType", restconsentType);
		dataTable.putData("Parametrized_Checkpoints", "RestConsentStartDate", restconsentStartDate);
		dataTable.putData("Parametrized_Checkpoints", "RestConsentEndDate", restconsentEndDate);
		dataTable.putData("Parametrized_Checkpoints", "RestConsentTermDate", restconsentTermDate);

		report.updateTestLog("Validation of PlanType", "REST PlanType => " + restplanType + "", "", Status.PASS);
		report.updateTestLog("Validation of ValidatedOnWeb", "REST ValidatedOnWeb => " + restvalidatedOnWeb + "", "",
				Status.PASS);
		report.updateTestLog("Validation of ConsentType", "REST ConsentType => " + restconsentType + "", "",
				Status.PASS);
		report.updateTestLog("Validation of ConsentStartDate", "REST ConsentStartDate => " + restconsentStartDate + "",
				"", Status.PASS);
		report.updateTestLog("Validation of ConsentEndDate", "REST ConsentEndDate => " + restconsentEndDate + "", "",
				Status.PASS);
		report.updateTestLog("Validation of ConsentTermDate", "REST ConsentTermDate => " + restconsentTermDate + "", "",
				Status.PASS);

	}

	public void swaggerMemberForId() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		String validationNull1 = ValidatingNullValues(response, "id", SERVICEFORMAT.JSON);
		String validationNull = ValidatingNullValues(response, "personId", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public void restfieldValidation() throws InterruptedException {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		swaggerFieldname = swaggerForMemberId();
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public String extractRestResponse(ValidatableResponse response, SERVICEFORMAT format) {
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		formatter.setLenient(false);
		if (format == SERVICEFORMAT.JSON) {
			String value = "", tagHeading = "", tagValue = "";
			String responseBody = response.extract().asString().replace("{", "").replace("}", "").replace("[", "")
					.replace("]", "").replace("},", "");
			String[] namesList = responseBody.split(",");
			for (String name : namesList) {
				String[] tagname = name.split(":");
				tagHeading = tagname[0].replace("{", "").replace('"', ' ').trim();
				tagValue = tagname[1].replace("{", "").replace('"', ' ').trim();
				String dataType = tagValue.getClass().getSimpleName();

				if (dataType.equalsIgnoreCase("String")) {

					if (tagHeading.equals("endDate") && tagValue.equals("null")) {
						String endDateValue = "9999-12-31";
						report.updateTestLog("DataTypeValidation",
								"Rest  " + tagHeading + " value: " + endDateValue + " =>is  " + dataType + " datatype.",
								"", Status.PASS);

						report.updateTestLog("DateFormatValidation",
								"Rest  " + tagHeading + " value: " + endDateValue + " =>is valid date format.", "",
								Status.PASS);

					} else {
						if (tagValue.equals("true") || tagValue.equals("false")) {
							report.updateTestLog("DataTypeValidation",
									"Rest  " + tagHeading + " value: " + tagValue + " =>is a Boolean datatype.", "",
									Status.PASS);
						} else {
							report.updateTestLog("DataTypeValidation",
									"Rest  " + tagHeading + " value: " + tagValue + " =>is  " + dataType + " datatype.",
									"", Status.PASS);
						}
					}
					try {
						Date date = formatter.parse(tagValue);
						String dob = formatter.format(date);
						System.out.println(dob);
						if (tagValue.equals(dob)) {
							report.updateTestLog("DateFormatValidation",
									"Rest  " + tagHeading + " value: " + tagValue + " =>is valid date format.", "",
									Status.PASS);
						} else {
							report.updateTestLog("DateFormatValidation",
									"Rest  " + tagHeading + " value: " + tagValue + " =>is not a valid date format.",
									"", Status.FAIL);
						}
					} catch (ParseException e) {
						// If input date is in different format or invalid.
					}
				} else {
					report.updateTestLog("DataTypeValidation",
							"Rest  " + tagHeading + " value: " + tagValue + " =>is  not a " + dataType + " datatype.",
							"", Status.FAIL);
				}

			}

			return value;
		} else

		{
			String value = null;
			return value;
		}
	}

	public String ValidatingNullValues(ValidatableResponse response, String tagToValidate, SERVICEFORMAT format) {

		if (format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString();
			String retreiveBody = (((responseBody.replace("\"", "")).replace("]", "")).replace("{", ""))
					.replace("},", "").replace("[", "");
			String subStringOpen = tagToValidate + ":";
			String subStringClose = ",";
			value = ((retreiveBody.split(subStringOpen))[1].split(subStringClose))[0];
			value = value.trim();
			if (value != null && !value.isEmpty()) {
				report.updateTestLog("NullValueValidation", "Rest " + tagToValidate + " is not a null Value.", "",
						Status.PASS);
			} else {
				report.updateTestLog("NullValueValidation", "Rest " + tagToValidate + " is a null Value.", "",
						Status.FAIL);
			}
			return value;

		} else {
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];
			return value;
		}
	}

	public String ValidatingNullValues(ValidatableResponse response, String tagToValidate, String tagValue,
			SERVICEFORMAT format) {

		if (format == SERVICEFORMAT.JSON) {
			String value = "";
			String responseBody = response.extract().asString();
			JsonPath jsonPath = new JsonPath(responseBody);
			String user_id = jsonPath.getString(tagToValidate);
			String retreiveBody = (((user_id.replace("\"", "")).replace("]", "")).replace("{", "")).replace("},", "")
					.replace("[", "");
			String subStringOpen = tagValue + ":";
			String subStringClose = ",";
			value = ((retreiveBody.split(subStringOpen))[1].split(subStringClose))[0];
			value = value.trim();
			if (value != null && !value.isEmpty()) {
				report.updateTestLog("NullValueValidation",
						"Rest " + tagToValidate + " under " + tagValue + " is not a null Value.", "", Status.PASS);
			} else {
				report.updateTestLog("NullValueValidation",
						"Rest " + tagToValidate + " under " + tagValue + " is a null Value.", "", Status.FAIL);
			}
			return value;

		} else {
			String value = "";
			String responseBody = response.extract().asString();
			String subStringOpen = "<" + tagToValidate + ">";
			String subStringClose = "</" + tagToValidate + ">";
			value = ((responseBody.split(subStringClose))[0].split(subStringOpen))[1];
			return value;
		}
	}

	public List<String> swaggerForMemberId() throws InterruptedException {
		List<String> itemsToAdd = new ArrayList<String>();
		String value = "";
		String url = dataTable.getData("General_Data", "SwaggerUrl").toString();
		driver.navigate().to(url);
		Thread.sleep(2000);
		report.updateTestLog("Navigation", "SwaggerUrl => " + url + "", "", Status.PASS);
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String responseCode = driver
				.findElement(By.xpath("(//table[@class='responses-table']//tbody//tr[@class='response '])[1]"))
				.getAttribute("data-code");
		if (responseCode.equals("200")) {
			report.updateTestLog("SwaggerURL Response code", "StatusCode: 200 ", "StatusCode: " + responseCode,
					Status.PASS);
			Thread.sleep(2000);
			int ele = driver.findElements(By.xpath("(//pre[@class='example microlight'])[1]/span")).size();
			Thread.sleep(2000);
			String text = driver.findElement(By.xpath("(//pre[@class='example microlight'])[1]")).getText()
					.replace("{", "").replace("}", "").replace("\n ", "").replace("\n", "").replace('"', ' ')
					.replace("[", "").replace("]", "").trim();
			// System.out.println(text);
			String[] a = text.split(",");
			for (int i = 0; i < a.length; i++) {
				String va = a[i];
				String subStringClose = ":";
				value = ((va.split(subStringClose))[0]).replaceAll("\\s+", "");
				itemsToAdd.add(value);

			}
		}

		else

		{
			report.updateTestLog(url, "StatusCode: " + responseCode, "StatusCode: " + responseCode, Status.FAIL);
		}
		return itemsToAdd;

	}

	public List<String> restFieldName(ValidatableResponse response, SERVICEFORMAT format) {
		List<String> itemsToAdd = new ArrayList<String>();
		if (format == SERVICEFORMAT.JSON) {
			String value = "", tagHeading = "", tagValue = "";
			String responseBody = response.extract().asString().replace("{", "").replace("}", "").replace("[", "")
					.replace("]", "").replace("},", "");
			String[] namesList = responseBody.split(",");
			for (String name : namesList) {
				String[] tagname = name.split(":");
				tagHeading = tagname[0].replace("{", "").replace('"', ' ').trim();
				itemsToAdd.add(tagHeading);
			}
		}
		return itemsToAdd;
	}

	public void swaggerMemberForAddress() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public void swaggerMemberForIdentifiers() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		String validationNull1 = ValidatingNullValues(response, "memberGenKey", SERVICEFORMAT.JSON);
		String validationNull = ValidatingNullValues(response, "masterPersonId", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public void swaggerMemberForLis() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		String validationNull = ValidatingNullValues(response, "effectiveDate", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public void ValidatingNullValues(ValidatableResponse response, SERVICEFORMAT format) {
		String value = "", tagHeading = "", tagValue = "";
		if (format == SERVICEFORMAT.JSON) {

			String responseBody = response.extract().asString().replace("{", "").replace("}", "").replace("[", "")
					.replace("]", "").replace("},", "");
			String[] namesList = responseBody.split(",");
			for (String name : namesList) {
				String[] tagname = name.split(":");
				tagHeading = tagname[0].replace("{", "").replace('"', ' ').trim();
				tagValue = tagname[1].replace("{", "").replace('"', ' ').trim();
				if (tagValue != null && !tagValue.isEmpty()) {
					report.updateTestLog("NullValueValidation", "Rest " + tagHeading + " is not a null Value.", "",
							Status.PASS);
				} else {
					report.updateTestLog("NullValueValidation", "Rest " + tagHeading + " is  null Value.", "",
							Status.FAIL);
				}

			}
		}

	}

	public void swaggerMemberForKeyProduct() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		String idNull = ValidatingNullValues(response, "id", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "startDate", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public void swaggerMemberForKeyOSBS() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		String idNull = ValidatingNullValues(response, "startDate", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "endDate", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public void swaggerMemberForKeyCoverageIdentifiers() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		String idNull = ValidatingNullValues(response, "sourcePersonId", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "sourcePlatform", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public void swaggerMemberForIndicators() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public void swaggerMemberForGenkey() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		String platformNull = ValidatingNullValues(response, "platform", SERVICEFORMAT.JSON);
		String sourcePersonIdNull = ValidatingNullValues(response, "sourcePersonId", SERVICEFORMAT.JSON);
		String memberGenKeyNull = ValidatingNullValues(response, "memberGenKey", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}

			}

		}

	}

	public void swaggerMemberForProducts() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		String idNull = ValidatingNullValues(response, "id", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "startDate", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerMemberForOTC_Allowance() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerMemberForMedications() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerMemberForDesigneeId() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerMemberForScripts() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerMemberForRXPlan() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerMemberKeyCoverageProduct() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseGroup(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public String extractRestResponseVar(ValidatableResponse response, SERVICEFORMAT format) {
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		formatter.setLenient(false);
		if (format == SERVICEFORMAT.JSON) {
			String value = "", tagHeading = "", tagValue = "";
			String responseBody = response.extract().asString().replace("{", "").replace("}", "").replace("[", "")
					.replace("]", "").replace("},", "");

			String[] namesList = responseBody.split(",");

			for (String name : namesList) {
				String[] tagname = name.split(":");
				tagHeading = tagname[0].replace("{", "").replace('"', ' ').trim();
				tagValue = tagname[1].replace("{", "").trim();
				if (tagValue.equals("true") || tagValue.equals("false")) {
					// System.out.println(tagValue + " is a Boolean DataType");
					report.updateTestLog("DataTypeValidation",
							"Rest  " + tagHeading + " value: " + tagValue + " =>is a Boolean datatype.", "",
							Status.PASS);
				} else {
					try {
						Integer.parseInt(tagValue);
						// System.out.println(tagValue + " is a Integer DataType");
						report.updateTestLog("DataTypeValidation",
								"Rest  " + tagHeading + " value: " + tagValue + " =>is a Integer DataType.", "",
								Status.PASS);
					} catch (Exception e) {
						if (tagHeading.equals("endDate") && tagValue.equals("null")) {
							String endDateValue = "9999-12-31";
							report.updateTestLog("DataTypeValidation",
									"Rest  " + tagHeading + " value: " + endDateValue + " =>is a String DataType.", "",
									Status.PASS);
							report.updateTestLog("DateFormatValidation",
									"Rest  " + tagHeading + " value: " + endDateValue + " =>is valid date format.", "",
									Status.PASS);

						} else {
							// System.out.println(tagValue + " is a String DataType");
							report.updateTestLog("DataTypeValidation",
									"Rest  " + tagHeading + " value: " + tagValue + " =>is a String DataType.", "",
									Status.PASS);
						}

					}
				}

				try {
					String DataFormatValue = tagValue.replace('"', ' ').trim();
					Date date = formatter.parse(DataFormatValue);
					String dob = formatter.format(date);
					// System.out.println(dob);
					if (DataFormatValue.equals(dob)) {
						report.updateTestLog("DateFormatValidation",
								"Rest  " + tagHeading + " value: " + DataFormatValue + " =>is valid date format.", "",
								Status.PASS);
					} else {
						report.updateTestLog("DateFormatValidation",
								"Rest  " + tagHeading + " value: " + DataFormatValue + " =>is not a valid date format.",
								"", Status.FAIL);
					}
				} catch (ParseException e) {
					// If input date is in different format or invalid.
				}

			}

			return value;
		} else

		{
			String value = null;
			return value;
		}
	}

	public void extractRestResponseWithoutTag(ValidatableResponse response, SERVICEFORMAT format) {

		if (format == SERVICEFORMAT.JSON) {
			String value = "", tagHeading = "", tagValue = "", firstWord = "";
			String responseBody = response.extract().asString().replace("{", "").replace("}", "").replace("[", "")
					.replace("]", "").replace("},", "");
			String[] namesList = responseBody.split(",");
			for (String name : namesList) {
				String[] tagname = name.split(":");
				for (int i = 0; i <= tagname.length; i++) {

					int tagLength = tagname.length;
					if (tagLength >= 3) {
						tagHeading = tagname[1].replace("{", "").replace('"', ' ').trim();
						firstWord = tagHeading.substring(0, 1).toUpperCase();
						tagHeading = firstWord + tagHeading.substring(1);
						tagValue = tagname[2].replace("{", "").trim();
						dataTable.putData("Parametrized_Checkpoints", "Rest" + tagHeading, tagValue);
						report.updateTestLog("Validation of " + tagHeading, "REST " + tagHeading + "=>" + tagValue + "",
								"", Status.PASS);
						break;

					} else {
						tagHeading = tagname[0].replace("{", "").replace('"', ' ').trim();
						firstWord = tagHeading.substring(0, 1).toUpperCase();
						tagHeading = firstWord + tagHeading.substring(1);
						tagValue = tagname[1].replace("{", "").trim();
						dataTable.putData("Parametrized_Checkpoints", "Rest" + tagHeading, tagValue);
						report.updateTestLog("Validation of " + tagHeading, "REST " + tagHeading + "=>" + tagValue + "",
								"", Status.PASS);
						break;
					}
				}
			}
		}

	}

	public String extractRestResponseGroup(ValidatableResponse response, SERVICEFORMAT format) {
		String v5 = null;
		List<String> myList = new ArrayList<String>();
		String joined2 = "";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		formatter.setLenient(false);
		if (format == SERVICEFORMAT.JSON) {
			String value = "", tagHeading = "", tagValue = "";

			String responseBody = response.extract().asString().replace("{", "").replace("}", "").replace("[", "")
					.replace("]", "").replace("},", "");
			String[] list = responseBody.split(",", 2);
			String li = list[1];
			String[] namesList = responseBody.split(",");

			for (String name : namesList) {

				if (name.contains("description")) {

					String subStringOpen = tagHeading + ":";
					String subStringClose = ",";
					value = ((li.split(subStringOpen))[0]);
					char[] v = value.trim().toCharArray();
					for (char v1 : v) {
						String[] values = value.split(",");
						for (int i = 0; i < 5; i++) {
							v5 = values[i];
							myList.add(v5);
							joined2 = String.join(",", myList);
						}
						break;
					}
					String join = joined2.replace("description", "").replace(":", "");
					report.updateTestLog("DataTypeValidation",
							"Rest description value: " + join + " =>is a String DataType.", "", Status.PASS);

				} else {

					if (name.equals("D3000") || name.equals("OP5000") || name.equals("OV35/65")
							|| name.replace('"', ' ').equals("10 ")) {

					} else {

						String[] tagname = name.split(":");
						tagHeading = tagname[0].replace("{", "").replace('"', ' ').trim();

						tagValue = tagname[1].replace("{", "").trim();

						if (tagValue.equals("true") || tagValue.equals("false")) {
							// System.out.println(tagValue + " is a Boolean DataType");
							report.updateTestLog("DataTypeValidation",
									"Rest  " + tagHeading + " value: " + tagValue + " =>is a Boolean datatype.", "",
									Status.PASS);
						} else {
							try {
								Integer.parseInt(tagValue);
								// System.out.println(tagValue + " is a Integer DataType");
								report.updateTestLog("DataTypeValidation",
										"Rest  " + tagHeading + " value: " + tagValue + " =>is a Integer DataType.", "",
										Status.PASS);
							} catch (Exception e) {
								if (tagHeading.equals("endDate") && tagValue.equals("null")) {
									String endDateValue = "9999-12-31";
									report.updateTestLog("DataTypeValidation", "Rest  " + tagHeading + " value: "
											+ endDateValue + " =>is a String DataType.", "", Status.PASS);
									report.updateTestLog("DateFormatValidation", "Rest  " + tagHeading + " value: "
											+ endDateValue + " =>is valid date format.", "", Status.PASS);

								} else {
									// System.out.println(tagValue + " is a String DataType");
									report.updateTestLog("DataTypeValidation",
											"Rest  " + tagHeading + " value: " + tagValue + " =>is a String DataType.",
											"", Status.PASS);
								}

							}
						}
					}
				}

				try {
					String DataFormatValue = tagValue.replace('"', ' ').trim();
					Date date = formatter.parse(DataFormatValue);
					String dob = formatter.format(date);
					// System.out.println(dob);
					if (DataFormatValue.equals(dob)) {
						report.updateTestLog("DateFormatValidation",
								"Rest  " + tagHeading + " value: " + DataFormatValue + " =>is valid date format.", "",
								Status.PASS);
					} else {
						report.updateTestLog("DateFormatValidation",
								"Rest  " + tagHeading + " value: " + DataFormatValue + " =>is not a valid date format.",
								"", Status.FAIL);
					}
				} catch (ParseException e) {
					// If input date is in different format or invalid.
				}

			}

			return value;
		} else

		{
			String value = null;
			return value;
		}
	}

	public String restResponse(ValidatableResponse response, SERVICEFORMAT format) {
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		formatter.setLenient(false);
		if (format == SERVICEFORMAT.JSON) {
			String value = "", tagHeading = "", tagValue = "";
			String responseBody = response.extract().asString().replace("{", "").replace("}", "").replace("[", "")
					.replace("]", "").replace("},", "");

			String[] namesList = responseBody.split(",");

			for (String name : namesList) {
				String[] tagname = name.split(":");
				int tagLength = tagname.length;
				if (tagLength >= 3) {
					tagHeading = tagname[1].replace("{", "").replace('"', ' ').trim();
					tagValue = tagname[2].replace("{", "").trim();

				} else {
					tagHeading = tagname[0].replace("{", "").replace('"', ' ').trim();
					tagValue = tagname[1].replace("{", "").trim();
				}
				if (tagValue.equals("true") || tagValue.equals("false")) {
					// System.out.println(tagValue + " is a Boolean DataType");
					report.updateTestLog("DataTypeValidation",
							"Rest  " + tagHeading + " value: " + tagValue + " =>is a Boolean datatype.", "",
							Status.PASS);
				} else {
					try {
						Integer.parseInt(tagValue);
						// System.out.println(tagValue + " is a Integer DataType");
						report.updateTestLog("DataTypeValidation",
								"Rest  " + tagHeading + " value: " + tagValue + " =>is a Integer DataType.", "",
								Status.PASS);
					} catch (Exception e) {
						if (tagHeading.equals("endDate") && tagValue.equals("null")
								|| tagHeading.equals("pediatricDentalTermDate") && tagValue.equals("null")) {
							String endDateValue = "9999-12-31";
							report.updateTestLog("DataTypeValidation",
									"Rest  " + tagHeading + " value: " + endDateValue + " =>is a String DataType.", "",
									Status.PASS);
							report.updateTestLog("DateFormatValidation",
									"Rest  " + tagHeading + " value: " + endDateValue + " =>is valid date format.", "",
									Status.PASS);

						} else {
							// System.out.println(tagValue + " is a String DataType");
							report.updateTestLog("DataTypeValidation",
									"Rest  " + tagHeading + " value: " + tagValue + " =>is a String DataType.", "",
									Status.PASS);
						}

					}
				}

				try {
					String DataFormatValue = tagValue.replace('"', ' ').trim();
					Date date = formatter.parse(DataFormatValue);
					String dob = formatter.format(date);
					// System.out.println(dob);
					if (DataFormatValue.equals(dob)) {
						report.updateTestLog("DateFormatValidation",
								"Rest  " + tagHeading + " value: " + DataFormatValue + " =>is valid date format.", "",
								Status.PASS);
					} else {
						report.updateTestLog("DateFormatValidation",
								"Rest  " + tagHeading + " value: " + DataFormatValue + " =>is not a valid date format.",
								"", Status.FAIL);
					}
				} catch (ParseException e) {
					// If input date is in different format or invalid.
				}

			}

			return value;
		} else

		{
			String value = null;
			return value;
		}
	}

	public void swaggerMemberEmails() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerPlatformIdentifiers() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		ValidatingNullValues(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerSupplementalRiders() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerHealthProgram() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = extractRestResponseVar(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCurrentDateCoverage() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);
		String sourcePersonIdNull = ValidatingNullValues(response, "sourcePersonId", SERVICEFORMAT.JSON);
		String isNonInsuranceNull = ValidatingNullValues(response, "isNonInsurance", SERVICEFORMAT.JSON);
		String platformNull = ValidatingNullValues(response, "platform", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "startDate", SERVICEFORMAT.JSON);
		String coverageKeyNull = ValidatingNullValues(response, "coverageKey", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerPastDateCoverage() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);
		String sourcePersonIdNull = ValidatingNullValues(response, "sourcePersonId", SERVICEFORMAT.JSON);
		String isNonInsuranceNull = ValidatingNullValues(response, "isNonInsurance", SERVICEFORMAT.JSON);
		String platformNull = ValidatingNullValues(response, "platform", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "startDate", SERVICEFORMAT.JSON);
		String coverageKeyNull = ValidatingNullValues(response, "coverageKey", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerFutureDateCoverage() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);
		String sourcePersonIdNull = ValidatingNullValues(response, "sourcePersonId", SERVICEFORMAT.JSON);
		String isNonInsuranceNull = ValidatingNullValues(response, "isNonInsurance", SERVICEFORMAT.JSON);
		String platformNull = ValidatingNullValues(response, "platform", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "startDate", SERVICEFORMAT.JSON);
		String coverageKeyNull = ValidatingNullValues(response, "coverageKey", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerConsumerRoles() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesKey() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);
		String sourcePersonIdNull = ValidatingNullValues(response, "sourcePersonId", SERVICEFORMAT.JSON);
		String isNonInsuranceNull = ValidatingNullValues(response, "isNonInsurance", SERVICEFORMAT.JSON);
		String platformNull = ValidatingNullValues(response, "platform", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "startDate", SERVICEFORMAT.JSON);
		String coverageKeyNull = ValidatingNullValues(response, "coverageKey", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesKeyFamily() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);
		String sourcePersonIdNull = ValidatingNullValues(response, "sourcePersonId", SERVICEFORMAT.JSON);
		String isNonInsuranceNull = ValidatingNullValues(response, "isNonInsurance", SERVICEFORMAT.JSON);
		String platformNull = ValidatingNullValues(response, "platform", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "startDate", SERVICEFORMAT.JSON);
		String coverageKeyNull = ValidatingNullValues(response, "coverageKey", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesKeyGroup() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);
		String sourcePersonIdNull = ValidatingNullValues(response, "groupId", SERVICEFORMAT.JSON);
		String isNonInsuranceNull = ValidatingNullValues(response, "divisionId", SERVICEFORMAT.JSON);
		String groupPlatformNull = ValidatingNullValues(response, "groupIdentifier", "platform", SERVICEFORMAT.JSON);
		String platformNull = ValidatingNullValues(response, "platform", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesKeyGroupCoverage() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);
		String sourcePersonIdNull = ValidatingNullValues(response, "groupId", SERVICEFORMAT.JSON);
		String isNonInsuranceNull = ValidatingNullValues(response, "divisionId", SERVICEFORMAT.JSON);
		String groupPlatformNull = ValidatingNullValues(response, "groupIdentifier", "platform", SERVICEFORMAT.JSON);
		String platformNull = ValidatingNullValues(response, "productId", SERVICEFORMAT.JSON);
		String productStartDate = ValidatingNullValues(response, "productIdentifier", "startDate", SERVICEFORMAT.JSON);
		String productPlatform = ValidatingNullValues(response, "productIdentifier", "platform", SERVICEFORMAT.JSON);
		String startDateNull = ValidatingNullValues(response, "startDate", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesKeyHipaa() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		String productStartDate = ValidatingNullValues(response, "relationship", "code", SERVICEFORMAT.JSON);
		String productPlatform = ValidatingNullValues(response, "relationship", "description", SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerDrugCoverage() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerDesigneeIdRelationship() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);
		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerBillsProfiles() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerBillsIdProfiles() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void restMemberCallForConsumerRoles() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		String restRoleType = extractTagValue(response, "roleType", SERVICEFORMAT.JSON);
		String restIdentifierType = extractTagValue(response, "identifiers", "identifierType", SERVICEFORMAT.JSON);
		String restValue = extractTagValue(response, "identifiers", "value", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("Parametrized_Checkpoints", "RestRoleType", restRoleType);
		dataTable.putData("Parametrized_Checkpoints", "RestIdentifierType", restIdentifierType);
		dataTable.putData("Parametrized_Checkpoints", "RestValue", restValue);

		report.updateTestLog("Validation of Rest RoleType", "REST Id => " + restRoleType + "", "", Status.PASS);
		report.updateTestLog("Validation of Rest IdentifierType", "REST VendorId => " + restIdentifierType + "", "",
				Status.PASS);
		report.updateTestLog("Validation of Rest Value", "REST TypeCode => " + restValue + "", "", Status.PASS);

	}

	public void restMemberCallforBillingIdProfiles() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// extractRestResponseWithoutTag(response, SERVICEFORMAT.JSON);

		// Retrieving the value from response
		String restprofileExists = extractTagValue(response, "profileExists", SERVICEFORMAT.JSON);
		String restid = extractTagValue(response, "profiles", "id", 0, SERVICEFORMAT.JSON);
		String restidType = extractTagValue(response, "profiles", "idType", 0, SERVICEFORMAT.JSON);
		String restplatform = extractTagValue(response, "profiles", "platform", 0, SERVICEFORMAT.JSON);
		String restid1 = extractTagValue(response, "profiles", "id", 1, SERVICEFORMAT.JSON);
		String restidType1 = extractTagValue(response, "profiles", "idType", 1, SERVICEFORMAT.JSON);
		String restplatform1 = extractTagValue(response, "profiles", "platform", 1, SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("Parametrized_Checkpoints", "RestProfileExists", restprofileExists);
		dataTable.putData("Parametrized_Checkpoints", "RestId", restid);
		dataTable.putData("Parametrized_Checkpoints", "RestIdType", restidType);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform", restplatform);
		dataTable.putData("Parametrized_Checkpoints", "RestId1", restid1);
		dataTable.putData("Parametrized_Checkpoints", "RestIdType1", restidType);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform1", restplatform1);

		report.updateTestLog("Validation of ProfileExists", "REST ProfileExists => " + restprofileExists + "", "",
				Status.PASS);
		report.updateTestLog("Validation of Profiles", "REST Id => " + restid + "", "", Status.PASS);
		report.updateTestLog("Validation of Profiles", "REST IdType => " + restidType + "", "", Status.PASS);
		report.updateTestLog("Validation of Profiles", "REST Platform => " + restplatform + "", "", Status.PASS);
		report.updateTestLog("Validation of Profiles", "REST Id => " + restid1 + "", "", Status.PASS);
		report.updateTestLog("Validation of Profiles", "REST IdType => " + restidType1 + "", "", Status.PASS);
		report.updateTestLog("Validation of Profiles", "REST Platform => " + restplatform1 + "", "", Status.PASS);

	}

	public void restMemberCallforBillingIdProfiles_periodasofdate() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		String restprofileExists = extractTagValue(response, "profileExists", SERVICEFORMAT.JSON);
		String restid = extractTagValue(response, "profiles", "id", SERVICEFORMAT.JSON);
		String restidType = extractTagValue(response, "profiles", "idType", SERVICEFORMAT.JSON);
		String restplatform = extractTagValue(response, "profiles", "platform", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("Parametrized_Checkpoints", "RestProfileExists", restprofileExists);
		dataTable.putData("Parametrized_Checkpoints", "RestId", restid);
		dataTable.putData("Parametrized_Checkpoints", "RestIdType", restidType);
		dataTable.putData("Parametrized_Checkpoints", "RestPlatform", restplatform);

		report.updateTestLog("Validation of ProfileExists", "REST ProfileExists => " + restprofileExists + "", "",
				Status.PASS);
		report.updateTestLog("Validation of Profiles", "REST Id => " + restid + "", "", Status.PASS);
		report.updateTestLog("Validation of Profiles", "REST IdType => " + restidType + "", "", Status.PASS);
		report.updateTestLog("Validation of Profiles", "REST Platform => " + restplatform + "", "", Status.PASS);

	}

	public void restMemberCallForConsumerRoles_ValidMembergenkey() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		String restRoleType = extractTagValue(response, "roleType", 0, SERVICEFORMAT.JSON);
		String restIdentifierType = extractTagValue(response, "identifiers", "identifierType", 0, SERVICEFORMAT.JSON);
		String restValue = extractTagValue(response, "identifiers", "value", 0, SERVICEFORMAT.JSON);
		String restRoleType1 = extractTagValue(response, "roleType", 1, SERVICEFORMAT.JSON);
		String restIdentifierType1 = extractTagValue(response, "identifiers", "identifierType", 1, SERVICEFORMAT.JSON);
		String restValue1 = extractTagValue(response, "identifiers", "value", 1, SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("Parametrized_Checkpoints", "RestRoleType", restRoleType);
		dataTable.putData("Parametrized_Checkpoints", "RestIdentifierType", restIdentifierType);
		dataTable.putData("Parametrized_Checkpoints", "RestValue", restValue);
		dataTable.putData("Parametrized_Checkpoints", "RestRoleType1", restRoleType1);
		dataTable.putData("Parametrized_Checkpoints", "RestIdentifierType1", restIdentifierType1);
		dataTable.putData("Parametrized_Checkpoints", "RestValue1", restValue1);

		report.updateTestLog("Validation of Rest RoleType", "REST Id => " + restRoleType + "", "", Status.PASS);
		report.updateTestLog("Validation of Rest IdentifierType", "REST VendorId => " + restIdentifierType + "", "",
				Status.PASS);
		report.updateTestLog("Validation of Rest Value", "REST TypeCode => " + restValue + "", "", Status.PASS);
		report.updateTestLog("Validation of Rest RoleType", "REST Id => " + restRoleType1 + "", "", Status.PASS);
		report.updateTestLog("Validation of Rest IdentifierType", "REST VendorId => " + restIdentifierType1 + "", "",
				Status.PASS);
		report.updateTestLog("Validation of Rest Value", "REST TypeCode => " + restValue1 + "", "", Status.PASS);
	}

	public void restMemberCallForGivenCoverageKey() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		String restCoverageKey = extractTagValue(response, "coverageKey", SERVICEFORMAT.JSON);
		String restMajorLineOfBusiness = extractTagValue(response, "majorLineOfBusiness", SERVICEFORMAT.JSON);
		String restProducthashkey = extractTagValue(response, "productHashKey", SERVICEFORMAT.JSON);
		String restProductKey = extractTagValue(response, "productKey", SERVICEFORMAT.JSON);
		String restParentProductKey = extractTagValue(response, "parentProductKey", SERVICEFORMAT.JSON);
		String restParentProductHashKey = extractTagValue(response, "parentProductHashKey", SERVICEFORMAT.JSON);
		String restCoverageStartDate = extractTagValue(response, "coverageStartDate", SERVICEFORMAT.JSON);
		String restCoverageEndDate = extractTagValue(response, "coverageEndDate", SERVICEFORMAT.JSON);
		String restIsNonInsurance = extractTagValue(response, "isNonInsurance", SERVICEFORMAT.JSON);
		String restGroupKey = extractTagValue(response, "groupKey", SERVICEFORMAT.JSON);

		// Writing back the data to excel

		dataTable.putData("Parametrized_Checkpoints", "RestCoverageKey", restCoverageKey);
		dataTable.putData("Parametrized_Checkpoints", "RestMajorLineOfBusiness", restMajorLineOfBusiness);
		dataTable.putData("Parametrized_Checkpoints", "RestProducthashkey", restProducthashkey);
		dataTable.putData("Parametrized_Checkpoints", "RestProductKey", restProductKey);
		dataTable.putData("Parametrized_Checkpoints", "RestParentProductKey", restParentProductKey);
		dataTable.putData("Parametrized_Checkpoints", "RestParentProductHashKey", restParentProductHashKey);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageStartDate", restCoverageStartDate);
		dataTable.putData("Parametrized_Checkpoints", "RestCoverageEndDate", restCoverageEndDate);
		dataTable.putData("Parametrized_Checkpoints", "RestIsNonInsurance", restIsNonInsurance);
		dataTable.putData("Parametrized_Checkpoints", "RestGroupKey", restGroupKey);

		report.updateTestLog("Validation of coverageKey", "REST coverageKey=> " + restCoverageKey + "", "",
				Status.PASS);
		report.updateTestLog("Validation of majorLineOfBusiness",
				"REST majorLineOfBusiness=> " + restMajorLineOfBusiness + "", "", Status.PASS);
		report.updateTestLog("Validation of producthashkey", "REST producthashkey => " + restProducthashkey + "", "",
				Status.PASS);
		report.updateTestLog("Validation of productKey", "REST productKey=> " + restProductKey + "", "", Status.PASS);
		report.updateTestLog("Validation of parentProductKey", "REST parentProductKey=> " + restParentProductKey + "",
				"", Status.PASS);
		report.updateTestLog("Validation of parentProductHashKey ",
				"REST parentProductHashKey => " + restParentProductHashKey + "", "", Status.PASS);
		report.updateTestLog("Validation of coverageStartDate",
				"REST coverageStartDate=> " + restCoverageStartDate + "", "", Status.PASS);
		report.updateTestLog("Validation of coverageEndDate", "REST coverageEndDate=> " + restCoverageEndDate + "", "",
				Status.PASS);
		report.updateTestLog("Validation of isNonInsurance", "REST isNonInsurance => " + restIsNonInsurance + "", "",
				Status.PASS);
		report.updateTestLog("Validation of groupKey", "REST groupKey=> " + restGroupKey + "", "", Status.PASS);

	}

	public void restMemberCallForValidDesigneeId() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		extractRestResponseWithoutTag(response, SERVICEFORMAT.JSON);

	}

	public void restMemberCallForDesigneeRelationship() {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		String restPlanType = extractTagValue(response, "planType", SERVICEFORMAT.JSON);
		String restValidatedOnWeb = extractTagValue(response, "validatedOnWeb", SERVICEFORMAT.JSON);
		String restConsentStartDate = extractTagValue(response, "consents", "consentStartDate", SERVICEFORMAT.JSON);
		String restConsentEndDate = extractTagValue(response, "consents", "consentEndDate", SERVICEFORMAT.JSON);
		String restConsentTermDate = extractTagValue(response, "consents", "consentTermDate", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("Parametrized_Checkpoints", "RestPlanType", restPlanType);
		dataTable.putData("Parametrized_Checkpoints", "RestValidatedOnWeb", restValidatedOnWeb);
		dataTable.putData("Parametrized_Checkpoints", "RestConsentStartDate", restConsentStartDate);
		dataTable.putData("Parametrized_Checkpoints", "RestConsentEndDate", restConsentEndDate);
		dataTable.putData("Parametrized_Checkpoints", "RestConsentTermDate", restConsentTermDate);

		report.updateTestLog("Validation of planType", "Rest PlanType => " + restPlanType + "", Status.PASS);
		report.updateTestLog("Validation of validatedOnWeb", "Rest ValidatedOnWeb => " + restValidatedOnWeb + "",
				Status.PASS);
		report.updateTestLog("Validation of consentStartDate", "Rest ConsentStartDate => " + restConsentStartDate + "",
				Status.PASS);
		report.updateTestLog("Validation of consentEndDate", "Rest ConsentEndDate => " + restConsentEndDate + "",
				Status.PASS);
		report.updateTestLog("Validation of consentTermDate", "Rest ConsentTermDate => " + restConsentTermDate + "",
				Status.PASS);

	}

	public void swaggerConsumerRolesResponse() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesIdResponse() throws InterruptedException {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is not Matched with Swagger fieldname " + name + "", "",
							Status.FAIL);
				}
			}
		}
	}

	public void swaggerCoveragesKeyResponse() throws InterruptedException {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesIdentifiersResponse() throws InterruptedException {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesFamilyResponse() throws InterruptedException {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesHipaaResponse() throws InterruptedException {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerCoveragesOSBResponse() throws InterruptedException {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerDesigneeIdResponse() throws InterruptedException {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void swaggerDesigneeRealtionshipResponse() throws InterruptedException {
		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");
		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);
		ValidatableResponse response;
		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		String ResponseValidation = restResponse(response, SERVICEFORMAT.JSON);

		swaggerFieldname = swaggerForMemberId();
		restFieldname = restFieldName(response, SERVICEFORMAT.JSON);
		for (String name : swaggerFieldname) {
			for (String name1 : restFieldname) {
				if (name.equals(name1)) {
					report.updateTestLog("FieldNameValidation",
							"Rest fieldname  " + name1 + " is Matched with Swagger fieldname " + name + "", "",
							Status.PASS);
					break;
				} else {

				}
			}
		}
	}

	public void restMemberCallCoverageIdentifiers() {

		String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
		String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

		Map<String, String> headersMap = headers.getHeaders3();
		headersMap.put(headerKey, headerValue);

		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL2");
		response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

		// Retrieving the value from response
		restsourcePersonId = extractTagValue(response, "sourcePersonId", SERVICEFORMAT.JSON);
		restsourcePlatform = extractTagValue(response, "sourcePlatform", SERVICEFORMAT.JSON);
		restmmctId = extractTagValue(response, "mmctId", SERVICEFORMAT.JSON);
		restcmpcId = extractTagValue(response, "cmpcId", SERVICEFORMAT.JSON);

		// Writing back the data to excel
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePersonId", restsourcePersonId);
		dataTable.putData("Parametrized_Checkpoints", "RestSourcePlatform", restsourcePlatform);
		dataTable.putData("Parametrized_Checkpoints", "RestmmctId", restmmctId);
		dataTable.putData("Parametrized_Checkpoints", "RestcmpcId", restcmpcId);

	}

	public void mangoDBDataCoverageIdentifiers() {

		String DatabaseName = dataTable.getData("General_Data", "DatabaseName");
		String UserName = dataTable.getData("General_Data", "UserName");
		char[] password = (dataTable.getData("General_Data", "Password")).toCharArray();

		String ReplicaSet1 = dataTable.getData("General_Data", "ReplicaSet1");
		String ReplicaSet2 = dataTable.getData("General_Data", "ReplicaSet2");
		String ReplicaSet3 = dataTable.getData("General_Data", "ReplicaSet3");

		String CollectionName = dataTable.getData("INT_DataSheet", "CollectionName");
		String QueryKey = dataTable.getData("INT_DataSheet", "QueryKey");
		String QueryValue = dataTable.getData("INT_DataSheet", "MemberGenKey");

		MongoCredential credential = MongoCredential.createCredential(UserName, DatabaseName, password);
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(true).build();
		MongoClient mongoClient = new MongoClient(Arrays.asList(new ServerAddress(ReplicaSet1),
				new ServerAddress(ReplicaSet2), new ServerAddress(ReplicaSet3)), Arrays.asList(credential), options);

		MongoDatabase database = mongoClient.getDatabase(DatabaseName);
		MongoCollection<Document> table = database.getCollection(CollectionName);

		FindIterable<Document> iterDocs = table.find(Filters.eq(QueryKey, QueryValue));

		for (Document iterdoc : iterDocs) {

			Document x = (Document) iterdoc.get("member");
			
			dbSourcePersonId = x.getString("id");
			dbSourcePlatform = x.getString("platform");
			
			Document z = (Document) iterdoc.get("identifiers");
			dbmmctId = z.getString("mmctAlternateId");
			dbcmpcId = z.getString("cmpcAlternateId");

			// write it in the excel
			dataTable.putData("Parametrized_Checkpoints", "DBSourcePersonId", dbSourcePersonId);
			dataTable.putData("Parametrized_Checkpoints", "DBSourcePlatform", dbSourcePlatform);
			dataTable.putData("Parametrized_Checkpoints", "DBmmctId", dbmmctId);
			dataTable.putData("Parametrized_Checkpoints", "DBcmpcId", dbcmpcId);

		}

		mongoClient.close();

	}

	public void validateCoverageIdentifiers() {

		restsourcePersonId = dataTable.getData("Parametrized_Checkpoints", "RestSourcePersonId");
		restsourcePlatform = dataTable.getData("Parametrized_Checkpoints", "RestSourcePlatform");
		restmmctId = dataTable.getData("Parametrized_Checkpoints", "RestmmctId");
		restcmpcId = dataTable.getData("Parametrized_Checkpoints", "RestcmpcId");

		dbSourcePersonId = dataTable.getData("Parametrized_Checkpoints", "DBSourcePersonId");
		dbSourcePlatform = dataTable.getData("Parametrized_Checkpoints", "DBSourcePlatform");
		dbmmctId = dataTable.getData("Parametrized_Checkpoints", "DBmmctId");
		dbcmpcId = dataTable.getData("Parametrized_Checkpoints", "DBcmpcId");

		if (restsourcePersonId.equals(dbSourcePersonId)) {
			report.updateTestLog("Validation of person sourcePersonId ",
					"REST SourcePersonId => " + restsourcePersonId + ". DB SourcePersonId => " + dbSourcePersonId, "", Status.PASS);
		} else {
			report.updateTestLog("Validation of person sourcePersonId",
					"REST SourcePersonId => " + restsourcePersonId + ". DB SourcePersonId => " + dbSourcePersonId, "", Status.FAIL);
		}
		if (restsourcePlatform.equals(dbSourcePlatform)) {
			report.updateTestLog("Validation of person SourcePlatform",
					"REST SourcePlatform => " + restsourcePlatform + ". DB SourcePlatform => " + dbSourcePlatform, "", Status.PASS);
		} else {
			report.updateTestLog("Validation of person SourcePlatform",
					"REST SourcePlatform => " + restsourcePlatform + ". DB SourcePlatform => " + dbSourcePlatform, "", Status.FAIL);
		}

		if (restmmctId.equals(dbmmctId)) {
			report.updateTestLog("Validation of person mmctId",
					"REST mmctId => " + restmmctId + ". DB mmctId => " + dbmmctId, "",
					Status.PASS);
		} else {
			report.updateTestLog("Validation of person mmctId",
					"REST mmctId => " + restmmctId + ". DB mmctId => " + dbmmctId, "",
					Status.FAIL);
		}
		
		
		if (restcmpcId.equals(dbcmpcId)) {
			report.updateTestLog("Validation of person cmpcId",
					"REST cmpcId => " + restcmpcId + ". DB cmpcId => " + dbcmpcId, "",
					Status.PASS);
		} else {
			report.updateTestLog("Validation of person cmpcId",
					"REST cmpcId => " + restcmpcId + ". DB cmpcId => " + dbcmpcId, "",
					Status.FAIL);
		}

	}

public void restMemberCallForCoverageFamily() {
	String headerKey = dataTable.getData("INT_DataSheet", "ParameterKey");
	String headerValue = dataTable.getData("INT_DataSheet", "ParameterValue");

	Map<String, String> headersMap = headers.getHeaders3();
	headersMap.put(headerKey, headerValue);

	ValidatableResponse response;

	String url = dataTable.getData("General_Data", "URL2");

	response = apiDriver.sendNReceive(url, SERVICEMETHOD.GET, headersMap, 200);

	// Retrieving the value from response
	String restMemberIdentifiers = extractTagValue(response, "planType", SERVICEFORMAT.JSON);
	String restBase = extractTagValue(response, "validatedOnWeb", SERVICEFORMAT.JSON);
	String restDependentCode = extractTagValue(response, "consents", "consentStartDate", SERVICEFORMAT.JSON);
	String restMemberGenKey = extractTagValue(response, "consents", "consentEndDate", SERVICEFORMAT.JSON);
	String restSubscriberGenKey = extractTagValue(response, "consents", "consentTermDate", SERVICEFORMAT.JSON);
	String restSourcePersonId = extractTagValue(response, "consents", "consentTermDate", SERVICEFORMAT.JSON);
	String restCoverageKey = extractTagValue(response, "planType", SERVICEFORMAT.JSON);
	String restCoverageType = extractTagValue(response, "validatedOnWeb", SERVICEFORMAT.JSON);
	String restIsNonInsurance = extractTagValue(response, "consents", "consentStartDate", SERVICEFORMAT.JSON);
	String restPlatform = extractTagValue(response, "consents", "consentEndDate", SERVICEFORMAT.JSON);
	String restStartDate = extractTagValue(response, "consents", "consentTermDate", SERVICEFORMAT.JSON);
	String restEndDate = extractTagValue(response, "planType", SERVICEFORMAT.JSON);
	String restPolicyType = extractTagValue(response, "validatedOnWeb", SERVICEFORMAT.JSON);
	String restRelationshipToSubscriber = extractTagValue(response, "consents", "consentStartDate", SERVICEFORMAT.JSON);
	String restPediatricDentalTermDate = extractTagValue(response, "consents", "consentEndDate", SERVICEFORMAT.JSON);
	String restOperationalMajorLineOfBusiness = extractTagValue(response, "consents", "consentTermDate", SERVICEFORMAT.JSON);
	String restContractId = extractTagValue(response, "planType", SERVICEFORMAT.JSON);
	String restProdPlanId = extractTagValue(response, "validatedOnWeb", SERVICEFORMAT.JSON);
	String restStateOfIssue = extractTagValue(response, "consents", "consentStartDate", SERVICEFORMAT.JSON);
	String restOptOut = extractTagValue(response, "consents", "consentEndDate", SERVICEFORMAT.JSON);
	String restPeriod = extractTagValue(response, "consents", "consentTermDate", SERVICEFORMAT.JSON);
	String restProductCategory = extractTagValue(response, "consents", "consentTermDate", SERVICEFORMAT.JSON);
	String restProductLineCode = extractTagValue(response, "planType", SERVICEFORMAT.JSON);
	String restProductLineDescription= extractTagValue(response, "validatedOnWeb", SERVICEFORMAT.JSON);
	String restProductTypeCode = extractTagValue(response, "consents", "consentStartDate", SERVICEFORMAT.JSON);
	String restSegmentType = extractTagValue(response, "consents", "consentEndDate", SERVICEFORMAT.JSON);
	String restMajorLineOfBusinessDescription = extractTagValue(response, "consents", "consentTermDate", SERVICEFORMAT.JSON);
	String restMajorLineOfBusinessCode = extractTagValue(response, "planType", SERVICEFORMAT.JSON);


	// Writing back the data to excel
	

}
}
