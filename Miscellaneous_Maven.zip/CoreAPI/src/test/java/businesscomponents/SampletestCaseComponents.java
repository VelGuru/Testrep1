package businesscomponents;

import org.openqa.selenium.By;

import frameworkcore.ReusableLibrary;
import frameworkcore.ScriptHelper;
import frameworkseleniumcore.Status;
import pages.Samplepageobjects;

public class SampletestCaseComponents extends ReusableLibrary  {

	private static final String PASSENGER_DATA = "Passenger_Data";

	public SampletestCaseComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	
	public void logintoApplication() throws InterruptedException {
				
		String url=dataTable.getData("General_Data", "Applicationurl").toString();
		driver.navigate().to(url);
		Thread.sleep(5000);
		report.updateTestLog("Login","Hi-Humana Portal ", Status.PASS);
		Thread.sleep(5000);
	}

	public void navigateEphonebook() {
		driver.findElement(By.xpath("//a[@id='apps-heading']/span[3]")).click();
		driver.findElement(Samplepageobjects.ele_Phonebook).click();
		report.updateTestLog("Navigation","Navigate To EphoneBook page ", Status.PASS);
		
	}

	
	public void userValidation() throws InterruptedException {
		
		driver.findElement(Samplepageobjects.ele_Searchbox).sendKeys((dataTable.getData(PASSENGER_DATA, "UserName")));
		Thread.sleep(2000);
		driver.findElement(Samplepageobjects.ele_ButtonAssociates).click();
		Thread.sleep(2000);
			String txt=driver.findElement(By.xpath("//h4[@class='info']")).getText();
			if(txt.equals("No matches found.")) {
				report.updateTestLog("VALIDATION","User Validation ", Status.PASS);
			}else {
				report.updateTestLog("VALIDATION","User Validation ", Status.FAIL);	
			}
		
	}

	public void logoutToApplication() {
				
		driver.quit();
		report.updateTestLog("Logout", "Logout from application ",	Status.DONE);	
	}
	
	public void logintoHSS() throws InterruptedException {
		
		String url=dataTable.getData("General_Data", "Applicationurl").toString();
		driver.navigate().to(url);
		Thread.sleep(5000);
		String userName=dataTable.getData("General_Data", "Username").toString();
		String passWord=dataTable.getData("General_Data", "Password").toString();
		EnterInputToTextBoxById(Samplepageobjects.ele_usrtxtBox,userName,"Username",true);
		EnterInputToTextBoxById(Samplepageobjects.ele_usrpwdBox,passWord,"Password",true);
		report.updateTestLog("Login","Hi-Humana Portal ", Status.PASS);
		Thread.sleep(5000);
	}
	
}
