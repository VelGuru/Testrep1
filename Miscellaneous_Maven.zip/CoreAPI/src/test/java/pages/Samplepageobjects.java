package pages;

import org.openqa.selenium.By;

import frameworkcore.ScriptHelper;

/**
 * BookFlightPage class
 * 
 * @author Cognizant
 */
public class Samplepageobjects  {
public static By ele_AppsHeading=By.xpath("//a[@id='apps-heading']");
	
	public static By ele_Phonebook=By.xpath("//a[text()='e-Phonebook']");
	
	public static By ele_Searchbox=By.id("txtName");
	
	public static By ele_ButtonAssociates=By.id("btnSearchAssociates");
	
	public static By ele_Name=By.id("lblName_0");
	
	public static By ele_PersonalDeatils=By.xpath("//section[@class='content persondetails']/h2/strong");
	
	public static By ele_Department=By.id("department");
	
	public static By ele_Facility=By.xpath("//label[@for='lblfacility']");
	
	public static By ele_LinkMManager=By.id("managerLink");
	
	public static By ele_ButtonSearch=By.id("btnSearchAgain");
	
	public static String ele_usrtxtBox="txtUserid";
	
	public static String ele_usrpwdBox="txtPassword";
	
	public static String ele_btnLogin="btnLogin";
	
	

	public Samplepageobjects(ScriptHelper scriptHelper) {
		super();
		// TODO Auto-generated constructor stub
	}

	//public static final By imgFlights = By.xpath("//a/img");s
}