package testscripts;

import org.testng.annotations.Test;

import frameworkcore.DriverScript;
import frameworkcore.TestConfigurations;
import frameworkselenium.SeleniumTestParameters;

public class COREAPI extends TestConfigurations {

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void ExternalSystem_REST_SOAP(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate Additional Info in External service using REST and SOAP Service");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void MembersAPI_DirectMongo(SeleniumTestParameters testParameters) {

		testParameters
				.setCurrentTestDescription("Test to validate details of Response API against the details of Mongo DB");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_01_MembersId_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member ID for Response API against the details of Mongo DB");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_04_MembersAddress_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Address for Response API against the details of Mongo DB ");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_44_MembersEmail_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Emails for Response API against the details of Mongo DB ");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_45_MembersIdentifiers_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Identifiers for Response API against the details of Mongo DB ");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_58_MembersPlatformIdentifiers_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Platform Identifiers for Response API against the details of Mongo DB ");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_47_MembersLIS_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Lis for Response API against the details of Mongo DB ");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_10_MembersConsumerRoles_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters
				.setCurrentTestDescription("Test to validate details of Member Id Consumer Roles of API Response ");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_20_MembersCoveragesKey_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription("Test to validate details of Member Id Coverages Key of API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_23_MembersCoveragesFamily_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key Family of API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_26_MembersCoveragesGroup_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters
				.setCurrentTestDescription("Test to validate details of Member Id Coverages Key Group of API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_29_MembersCoveragesGroupCoverage_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key Group of Group Coverage  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_32_MembersCoveragesProduct_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key Product of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_35_MembersCoveragesHIPAA_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key Hipaa of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_38_MembersCoveragesMedicationsOtcAllowance_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key MedicareOtcAllowance of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_41_MembersCoveragesOSBS_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters
				.setCurrentTestDescription("Test to validate details of Member Id Coverages Key Osbs of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_47_MembersCoveragesProductSupplementalRiders_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key ProductSupplementalRiders of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_50_MembersCoveragesRXPlan_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_46_MembersCoveragesProductSupplementalRiders_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key ProductSupplementalRiders of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	public void TC_40_MembersCoveragesOSBS_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters
				.setCurrentTestDescription("Test to validate details of Member Id Coverages Key OSBS of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_31_MembersCoveragesProduct_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key Product of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_28_MembersCoveragesGroupCoverage_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key Group of Group Coverage  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_25_MembersCoveragesGroup_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key Group of Group Valid  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_02_MembersId_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member ID for Response API against the details of Mongo DB");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_15_MembersCoverages_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member ID for Response API against the details of Mongo DB");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_19_MembersCoverageIdentifiers_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member ID for Response API against the details of Mongo DB");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_20_MembersCoverageIdentifiers_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member ID for Response API against the details of Mongo DB");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_34_MembersCoveragesHIPAA_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of  API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_61_MembersIdentifiers_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of  Identifeirs Valid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_85_MembersPlatformIdentifiers_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_63_MembersIndicators_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_64_MembersIndicators_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_82_MembersPatientshealthProgram_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_90_MembersGenkeys_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_91_MembersGenkeys_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_67_MembersLis_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_87_MembersProducts_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_88_MembersProducts_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_31_MembersGroupCoverageProducts_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_32_MembersGroupCoverageProducts_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_37_MembersMedicationsOTCAllowance_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_52_MembersDesigneeId_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_53_MembersDesigneeId_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_56_MembersDesigneeIdRelationship_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_75_MembersMedicationsDrugCoverage_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_78_MembersMedicationsScripts_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_79_MembersMedicationsScripts_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_69_MembersMedications_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_81_MembersPatientshealthProgram_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_12_MembersCoveragesForCurrentDate_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_14_MembersCoveragesForPastDate_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_56_MembersMedicationsDrugCoverage_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_59_MembersBillsProfiles_InValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_57_MembersCoveragesKeyRxPlan_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_58_MembersBillsProfiles_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_55_MembersDesigneeRelationship_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_13_MembersCoveragesForFutureDate_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_19_MembersCoveragesKey_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_22_MembersCoveragesKeyFamily_ValidResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_03_MembersId_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_05_MembersAddress_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_45_MembersIdentifiers_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_68_MembersIdLis_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_33_MembersKeyProduct_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_42_MembersKeyOSBS_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_21_MembersKeyCoverageIdentifiers_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_65_MembersIdIndicators_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_92_MembersGenkeys_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_89_MembersProducts_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_39_MembersMedicationsOTC_Allowance_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_71_MembersMedications_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_54_MembersDesigneeId_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_80_MembersMedicationsScripts_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_51_MembersKeyRX_Plan_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_33_MembersKeyGroupCoverageProduct_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_68_MembersIdEmails_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_86_MembersIdPlatformIdentifiers_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_48_MembersProductSupplementalRiders_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_83_MembersPatientsHealthProgram_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_16_MembersCoverageCurrentDate_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_16_MembersCoveragePastDate_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_16_MembersCoverageFutureDate_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_11_MembersIdConsumerRoles_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_19_MembersIdCoveragesKey_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_24_MembersIdCoveragesKeyFamily_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_27_MembersIdCoveragesKeyGroup_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_30_MembersIdCoveragesKeyGroupCoverage_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_36_MembersIdCoveragesKeyHipaa_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_77_MembersMedicationsDrugCoverage_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_57_MembersDesigneeIdRelationship_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_08_MembersIdBillsProfiles_SwaggerResponse(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_01_VerifiyingResponseofBillingProfiles_ValidMembergenkey(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the Billing profile details are displayed when membergenkey is provided as input");
		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_02_VerifiyingResponseofBillingProfiles_InvalidInput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid membergenkey is provided as input");
		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_03_VerificationofBillingProfilesAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Test to validate details of Member Id Coverages Key RXPlan of Invalid API Response");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_04_VerifyingresponseofBillingProfiles_Genkeydateandperiod(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the Billing profile details are displayed when genkey, asofdate and period are provided as input values");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_05_VerifyingresponseofConsumerRoles_ValidMembergenkey(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the Consumer Role details are displayed when membergenkey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_06_VerifyingresponseofConsumerRoles_Invalidinput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid membergenkey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_09_VerifyingresponseofCoverages_Invalidinput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid membergenkey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_12_VerifyingresponsofgivenCoveragekey_ValidMembergenkey(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the given coverage key details of a member are displayed when membergenkey and coveragekey are provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_13_VerifyingresponsofCoveragekeys_InValidinput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid membergenkey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_16_VerifyingresponsofCoverageIdentifiers_InValidinput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid coveragekey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_19_VerifyingresponsofCoverageFamily_InValidinput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid coveragekey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_22_VerifyingresponsofCoverageHipaa_InValidinput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid coveragekey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_25_VerifyingresponsofCoverageOSB_InValidinput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid coveragekey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_27_VerifyingresponsofDesignee_ValidDesigneeId(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the Designee details are displayed when designee ID is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_28_VerifyingresponsofDesignee_InValidInput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid designee ID is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_30_VerifyingresponsofDesigneeRelationship_ValidDesigneeId(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the Designee Relationship details are displayed when designee ID is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_31_VerifyingresponsofDesigneeRelationship_InValidInput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the blank response is displayed when a invalid designee ID is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_07_VerificationofConsumerRolesAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if all the fields are displayed in the Consumer Roles Get response as per the swagger schema");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_10_VerificationofCoveragesIdAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if all the fields are displayed in the Coverages Get response as per the swagger schema");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_14_VerificationofCoverageKeyAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if all the fields are displayed in the Coverages Get response as per the swagger schema");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_17_VerificationofCoverageIdentifiersAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if all the fields are displayed in the Coverage identifiers Get response as per the swagger schema");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_20_VerificationofCoverageFamilyAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if all the fields are displayed in the Coverage Family Get response as per the swagger schema");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_23_VerificationofCoverageHipaaAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if all the fields are displayed in the Coverage Hipaa Get response as per the swagger schema");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_26_VerificationofCoverageOSBAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if all the fields are displayed in the Coverage OSB Get response as per the swagger schema");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_29_VerificationofDesigneeIdAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if all the fields are displayed in the Designee Get response as per the swagger schema");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	

	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_32_VerificationofDesigneeRealtionshipAgainst_SwaggerSchema(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if all the fields are displayed in the Designee Relationship Get response as per the swagger schema");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_15_VerificationofCoverageIdentifiersAgainst_MongoDB(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the coverage identifier details of a member are displayed when coveragekey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
	
	@Test(dataProvider = "API", dataProviderClass = TestConfigurations.class)
	public void TC_18_VerifyingresponsofCoverageFamily_Validinput(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription(
				"Verify if the family coverage details are displayed when coveragekey is provided as input");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}
}
