package testscripts;

import org.testng.annotations.Test;

import frameworkcore.DriverScript;
import frameworkcore.TestConfigurations;
import frameworkselenium.SeleniumTestParameters;

public class SampletestCase extends TestConfigurations {
	

	@Test(dataProvider = "DesktopBrowsers", dataProviderClass = TestConfigurations.class)
	public void validateUser(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription("Validating user able to Login");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);

}
	
	@Test(dataProvider = "DesktopBrowsers", dataProviderClass = TestConfigurations.class)
	public void ValidateMemeberSearch(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription("Validating user able to Login");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}
	
}
