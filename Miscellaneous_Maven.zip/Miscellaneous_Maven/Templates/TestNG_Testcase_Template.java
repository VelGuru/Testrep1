package testscripts;

import org.testng.annotations.Test;

import com.cognizant.craft.DriverScript;
import com.cognizant.framework.selenium.SeleniumTestParameters;


// Class Name should be scenario Name - equalent to Datatable-excel Name
public class TestNG_Testcase_Template extends TestConfigurations {

	
	@Test(dataProvider = "DesktopBrowsers")
	public void testCaseName1(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription("Description if the test case");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

	@Test(dataProvider = "DesktopBrowsers")
	public void testcaseName2(SeleniumTestParameters testParameters) {

		testParameters.setCurrentTestDescription("Description if the test case");
		
		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();

		tearDownTestRunner(testParameters, driverScript);
	}

}
