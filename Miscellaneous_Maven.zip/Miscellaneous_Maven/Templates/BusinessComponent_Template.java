package businesscomponents;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.ReusableLibrary;
import com.cognizant.craft.ScriptHelper;

/**
 * Class for storing general purpose business components
 * 
 * @author Cognizant
 */
public class BusinessComponent_Template extends ReusableLibrary {
	/**
	 * Constructor to initialize the component library
	 * 
	 * @param scriptHelper
	 *            The {@link ScriptHelper} object passed from the
	 *            {@link DriverScript}
	 */
	public BusinessComponent_Template(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}

}