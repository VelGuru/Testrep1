package testscripts.APIScenario;

import java.io.File;
import java.util.Map;

import org.testng.annotations.Test;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.TestConfigurationsLite;
import com.cognizant.framework.Util;
import com.cognizant.framework.APIReusuableLibrary.ASSERT_RESPONSE;
import com.cognizant.framework.APIReusuableLibrary.COMPARISON;
import com.cognizant.framework.APIReusuableLibrary.SERVICEFORMAT;
import com.cognizant.framework.APIReusuableLibrary.SERVICEMETHOD;
import com.cognizant.framework.selenium.SeleniumTestParameters;

import businesscomponents.HeadersForAPI;
import io.restassured.response.ValidatableResponse;

/**
 * Test for login with invalid user credentials
 * 
 * @author Cognizant
 */
public class TemparatureConvertion_SOAP extends TestConfigurationsLite {

	HeadersForAPI headers = new HeadersForAPI();

	@Test(dataProvider = "API", dataProviderClass = TestConfigurationsLite.class)
	public void testRunner(SeleniumTestParameters testParameters) {
		testParameters.setCurrentTestDescription("Test API for Temparture Convertions");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Override
	public void setUp() {

	}

	@Override
	public void executeTest() {

		try {
			convertFToC();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void tearDown() {

		try {
			convertTemparatureInSequence();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void convertFToC() {

		Map<String, String> headersMap = headers.getHeaders2();
		ValidatableResponse response;
		String uri = "https://www.w3schools.com/xml/tempconvert.asmx";

		String postBodyContent = apiDriver.readInput(getTemplatePath() + "FtoC_Input.xml");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_fahrenheit",
				dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "Fahrenheit"));
		String expectedCelcius = dataTable.getData(properties.getProperty("ENV") + "_Datasheet", "Celsius");
		String expectedResponse = apiDriver.readInput(getTemplatePath() + "FtoC_Output.xml");
		expectedResponse = apiDriver.updateContent(expectedResponse, "update_celsius", expectedCelcius);

		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent, headersMap, 200);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.BODY, "", expectedResponse, COMPARISON.IS_EQUALS);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.TAG, "//FahrenheitToCelsiusResult/text()", expectedCelcius,
				COMPARISON.IS_EQUALS);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.HEADER, "", "text/xml;", COMPARISON.IS_EXISTS);
	}


	public void convertTemparatureInSequence() {
		Map<String, String> headersMap = headers.getHeaders2();
		Map<String, String> headersMap1 = headers.getHeaders4();
		ValidatableResponse response;
		String uri = "https://www.w3schools.com/xml/tempconvert.asmx";

		String postBodyContent = apiDriver.readInput(getTemplatePath() + "FtoC_Input.xml");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_fahrenheit", "50");
		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent, headersMap, 200);
		String celciusFromResponse = apiDriver.extractValue(response, "//FahrenheitToCelsiusResult/text()");
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.TAG, "//FahrenheitToCelsiusResult/text()", "10",
				COMPARISON.IS_EQUALS);

		String postBodyContent1 = apiDriver.readInput(getTemplatePath() + "CtoF_Input.xml");
		postBodyContent1 = apiDriver.updateContent(postBodyContent1, "update_celsius", celciusFromResponse);
		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.POST, SERVICEFORMAT.XML, postBodyContent1, headersMap1,
				200);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.TAG, "//CelsiusToFahrenheitResult/text()", "50",
				COMPARISON.IS_EQUALS);

	}
	
	private String getTemplatePath() {
		File frameworkPath = new File(frameworkParameters.getRelativePath());

		String parentPath = frameworkPath.getParent();

		String templatePath = parentPath + Util.getFileSeparator() + "Miscellaneous_Classic" + Util.getFileSeparator()
				+ "EndPointInputs" + Util.getFileSeparator();

		return templatePath;
	}

}