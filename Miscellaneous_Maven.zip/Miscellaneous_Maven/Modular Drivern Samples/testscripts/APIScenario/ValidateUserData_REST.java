package testscripts.APIScenario;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.TestConfigurationsLite;
import com.cognizant.framework.APIReusuableLibrary.ASSERT_RESPONSE;
import com.cognizant.framework.APIReusuableLibrary.COMPARISON;
import com.cognizant.framework.APIReusuableLibrary.SERVICEFORMAT;
import com.cognizant.framework.APIReusuableLibrary.SERVICEMETHOD;
import com.cognizant.framework.selenium.SeleniumTestParameters;

import businesscomponents.HeadersForAPI;
import io.restassured.response.ValidatableResponse;

/**
 * Test for login with invalid user credentials
 * 
 * @author Cognizant
 */
public class ValidateUserData_REST extends TestConfigurationsLite {

	HeadersForAPI headers = new HeadersForAPI();

	@Test(dataProvider = "API", dataProviderClass = TestConfigurationsLite.class)
	public void testRunner(SeleniumTestParameters testParameters) {
		testParameters.setCurrentTestDescription("Test API for User data");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Override
	public void setUp() {

	}

	@Override
	public void executeTest() {

		Map<String, String> headersMap = headers.getHeaders3();
		ValidatableResponse response;

		String url = dataTable.getData("General_Data", "URL1");
		String postBodyContent = dataTable.getData("General_Data", "InputJsonTemplate");
		postBodyContent = apiDriver.updateContent(postBodyContent, "update_name", "murug");
		String expectedResponse = dataTable.getData("General_Data", "OutputJsonTemplate");

		response = apiDriver.sendNReceive(url, SERVICEMETHOD.POST, SERVICEFORMAT.JSON, postBodyContent, headersMap,
				201);

		apiDriver.assertIt(url, response, ASSERT_RESPONSE.BODY, "", expectedResponse, COMPARISON.IS_EQUALS);
		apiDriver.assertIt(url, response, ASSERT_RESPONSE.TAG, "name", "murug", COMPARISON.IS_EQUALS);
		apiDriver.assertIt(url, response, ASSERT_RESPONSE.HEADER, "", "application/json;", COMPARISON.IS_EXISTS);
		
		Object expectedList = new ArrayList<String>();
		expectedList = getList();
		String uri = dataTable.getData("General_Data", "URL2");

		response = apiDriver.sendNReceive(uri, SERVICEMETHOD.GET, headersMap, 200);
		apiDriver.assertIt(uri, response, ASSERT_RESPONSE.LIST, "MRData.CircuitTable.Circuits.circuitId", expectedList,
				COMPARISON.IS_EQUALS);

	}

	@Override
	public void tearDown() {

	}

	private List<String> getList() {
		List<String> sampleList = new ArrayList<String>();
		sampleList.add("albert_park");
		sampleList.add("americas");
		sampleList.add("bahrain");
		sampleList.add("BAK");
		sampleList.add("catalunya");
		sampleList.add("hungaroring");
		sampleList.add("interlagos");
		sampleList.add("marina_bay");
		sampleList.add("monaco");
		sampleList.add("monza");
		sampleList.add("red_bull_ring");
		sampleList.add("rodriguez");
		sampleList.add("sepang");
		sampleList.add("shanghai");
		sampleList.add("silverstone");
		sampleList.add("sochi");
		sampleList.add("spa");
		sampleList.add("suzuka");
		sampleList.add("villeneuve");
		sampleList.add("yas_marina");

		return sampleList;
	}

}