package testscripts.MobileTestingScenario;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.TestConfigurationsLite;
import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.SeleniumTestParameters;

import pages.TiesPages;

/**
 * Test for login with invalid user credentials
 * 
 * @author Cognizant
 */
public class TiesSelection extends TestConfigurationsLite {

	@Test(dataProvider = "MobileDevice", dataProviderClass = TestConfigurationsLite.class)
	public void testRunner(SeleniumTestParameters testParameters) {
		testParameters.setCurrentTestDescription("Selection of Ties");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Override
	public void setUp() {

		driver.get(properties.getProperty("ApplicationUrlRWD"));

		WebDriverWait wait = new WebDriverWait(driver.getWebDriver(), 60);
		WebElement logo = driver.findElement(TiesPages.collections);
		wait.until(ExpectedConditions.visibilityOf(logo));

		report.updateTestLog("Launch App", "Application Launched Succesfully", Status.PASS);
	}

	@Override
	public void executeTest() {
		navigateToCollections();
		selectQuantity();

		PauseScript(3);
		driver.findElement(TiesPages.add_to_cart).click();
		PauseScript(3);
		driver.findElement(TiesPages.checkout).click();
		report.updateTestLog("CheckOut", "Checked out the product", Status.PASS);

		TiesPages tiesPage = new TiesPages(scriptHelper);
		tiesPage.provideDetails();
	}

	@Override
	public void tearDown() {

	}

	public void navigateToCollections() {

		driver.findElement(By.xpath("//*[@id='nav']/ol/li[1]/a")).click();
		driver.findElement(TiesPages.arrivals).click();
		report.updateTestLog("Arrivals Page", "Navigated to Arrivals Page Sucessfully", Status.PASS);
	}

	public void selectQuantity() {

		driver.findElement(TiesPages.select_tie).click();
		driver.findElement(TiesPages.quantity).click();
		report.updateTestLog("Quantity Selection", "Selected the required Quantity", Status.PASS);
	}

}