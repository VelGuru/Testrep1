package testscripts.MobileTestingScenario;

import org.testng.annotations.Test;

import com.cognizant.craft.DriverScript;
import com.cognizant.craft.TestConfigurationsLite;
import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.SeleniumTestParameters;

import pages.TestMunkPage;

/**
 * Test for login with invalid user credentials
 * 
 * @author Cognizant
 */
public class TestMunkSignIn extends TestConfigurationsLite {

	@Test(dataProvider = "MobileDevice", dataProviderClass = TestConfigurationsLite.class)
	public void testRunner(SeleniumTestParameters testParameters) {
		testParameters.setCurrentTestDescription("Test for Login for Test Munk");

		DriverScript driverScript = new DriverScript(testParameters);
		driverScript.driveTestExecution();
		tearDownTestRunner(testParameters, driverScript);
	}

	@Override
	public void setUp() {
		TestMunkPage testMunkPage = new TestMunkPage(scriptHelper);
		testMunkPage.login();
		if (driver.findElement(TestMunkPage.lblHome).isDisplayed()) {
			report.updateTestLog("Home Screen", "Home Screen Displayed succesfully", Status.PASS);
		} else {
			report.updateTestLog("Home Screen", "Home Screen didnot display", Status.FAIL);
		}

	}

	@Override
	public void executeTest() {
		
		report.updateTestLog("Perform Operations", "Performing Operations", Status.SCREENSHOT);
		driver.findElement(TestMunkPage.btnSkip).click();
		driver.findElement(TestMunkPage.btnSecond).click();
		driver.findElement(TestMunkPage.btnAlert).click();
		driver.findElement(TestMunkPage.btnDismiss).click();
		driver.findElement(TestMunkPage.btnTable).click();
		driver.findElement(TestMunkPage.btnSection).click();
		driver.findElement(TestMunkPage.btnBack).click();
		driver.findElement(TestMunkPage.btnHome).click();
		report.updateTestLog("Home Screen", "Home Screen Displayed succesfully", Status.PASS);
	}

	@Override
	public void tearDown() {

	}

}