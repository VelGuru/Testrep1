[CmdletBinding()]
param($dllpath,$jsonpath,$vsaccount,$project,$user,$pwd,$testResult,$outputfolder)

# For more information on the VSTS Task SDK:
# https://github.com/Microsoft/vsts-task-lib
Import-Module -Name $dllpath -Verbose

Trace-VstsEnteringInvocation $MyInvocation
try {

      # Get the inputs.
    [string]$testResultPath = $testResult
    [string]$username = $user
    [string]$password = $pwd
    [string]$outputFolder = $outputfolder
    [string]$jsonMapping = $jsonpath  
    [string]$inputType = "file"
    if($inputType -eq "file"){
              $jsonMapping = $jsonpath
              Write-host "Using file $jsonMapping for JSON mapping"
    }
    else
    {
        Write-host "-----------------------"
        Write-host "Json test mapping"
        Write-host "-----------------------"
        Write-host `"$jsonMapping`"
    }

    
    $vsoAccountName = $vsaccount
    $projectName = $project

    Write-host "-----------------------"
    Write-host "Config"
    Write-host "-----------------------"
    Write-host "Tests path= $testResultPath"
    Write-host "Project name (var)= $projectName"
    Write-host "Visual Studio Account name (var)= $vsoAccountName"
    Write-host "Output folder= $outputFolder"

    #Set the working directory.
    $cwd = "bin"
    Assert-VstsPath -LiteralPath $cwd -PathType Container
    Write-host "Setting working directory to '$cwd'."
    Set-Location $cwd

    Write-host "Creation of dynamic .NET DLL using ROSLYN..."
    Write-host "-------------------------------------------------"

    Invoke-VstsTool -FileName ".\UnitTestGenerator\Microsoft.DX.JavaTestBridge.UnitTestGenerator.exe" -Arguments "AutomatedTestAssembly `"$jsonMapping`" $testResultPath" -RequireExitCodeZero
    
    if($LASTEXITCODE -eq 0){

        Write-host ".NET Unit test assembly created (AutomatedTestAssembly.dll)"
        
        Write-host "Association of tests with VSTS..."
        Write-host "-------------------------------------------------"

    }
    else
    {
      Write-Error "Creation of .NET dynamic test DLL failed";
    }

   
} finally {
    Trace-VstsLeavingInvocation $MyInvocation
}