﻿
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace JavaConnect
{
   [TestClass]
    public class Class1
    {
        [TestMethod]
        public void Test()
        {
            Assert.AreEqual("", "");
        }

        [TestMethod]
        public void Add()
        {
            int a = 1, b = 4,c;
            c = a + b;
            Console.WriteLine(c);
            Assert.AreEqual("", "");
        }

        [TestMethod]
        public void feature()
        {
            try
            {
                string reportDirectory = @"./junitreports/";
                //string[] Documents = System.IO.Directory.GetFiles("../../junitreports/");
                string path = Directory.GetCurrentDirectory();
                string testClassName = "TEST-com.cucumbercraft.runners.RunCucumberTests_Regression";
               // string path = @"../../junitreports/" + Path.DirectorySeparatorChar + testClassName + ".xml";
                string testMethodName = "feature";

                var xDoc = XDocument.Load(new StreamReader(reportDirectory + Path.DirectorySeparatorChar + testClassName + ".xml"));

                var testCases = from t in xDoc.Element("testsuite").Elements("testcase")
                                where t.Attribute("name").Value == testMethodName
                                select t;

                var test = testCases.FirstOrDefault();
                if (test == null)
                    throw new Exception("Java Method not found");

                var failures = test.Descendants("failure");
                if (failures.Count() > 0)
                {
                    Assert.Fail(failures.First().Attribute("message").Value);
                }

            }
            catch (Exception ex)
            {
             
                Assert.Fail(ex.Message);
            }
        }

    }
}
