package com.cucumbercraft.pages;

import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



public class HomePage extends Base {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	//Utility utl = new Utility();

	@FindBy(xpath = "//input[@id='txtName']")
	WebElement text_search;

	@FindBy(xpath = "//input[@id='btnSearchAssociates']")
	WebElement btn_search;

	WebElement count;

	@FindBy(xpath = "//*[@id='tblAssociatesInfo_filter']/label/input[@aria-controls='tblAssociatesInfo']")
	WebElement search_field;

	@FindBy(xpath = "//*[@id='tblAssociatesInfo']/tbody/tr/td/a")
	WebElement Name;

	@FindBy(xpath = "//*[@id='department']")
	WebElement Costcenter;

	// created method searching name
	public void phoneSearch(String value) {
				text_search.sendKeys(value);
				

	}

	//Click on search button
	public void clickSearch() {

				btn_search.click();
	}
  
	// Get total search results (Names) count
	public void count() {
				count.getText();
	}

	// Get the search text
	public void searchDetails() throws Exception {

		System.out.println(Costcenter.getText());

	}

	/*
	 * Method to search contact 
	 * 
	 * from the search list
	 * 
	 * 
	 */
	public void searchcontact(String name, WebDriver driver) throws Exception {
		Thread.sleep(2000);
		
		  List<WebElement> contacttablerow =
		  driver.findElements(By.xpath("//*[@id='tblAssociatesInfo']//tbody//tr"));
		  System.out.println("No of rwos" + contacttablerow.size()); for (int i = 1; i
		  <= contacttablerow.size(); i++) {
		  WebElement ele = driver
		  .findElement(By.xpath("//*[@id='tblAssociatesInfo']//tbody//tr[" + i +
		  "]//td[1]//a"));
		  
		  if (ele.getText().equals(name)) { ele.click(); break; }
		  
		  }
		
	}
	
	/*
	 * Method to search for the first result 
	 * 
	 * on contact search
	 * 
	 * 
	 */
	public boolean serachFinding(WebDriver driver) throws Exception
	{
		Thread.sleep(5000);
		WebElement ele = driver.findElement(By.xpath("//*[@id='tblAssociatesInfo']/tbody/tr/td/a"));
		boolean visibility=ele.isDisplayed();
		if(visibility)
		{
		ele.click();
		return true;
	     }
		else 
		{
			return false;
		}
	
	}
	
}
