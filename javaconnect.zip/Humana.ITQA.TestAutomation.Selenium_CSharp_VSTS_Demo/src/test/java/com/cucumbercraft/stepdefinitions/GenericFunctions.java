package com.cucumbercraft.stepdefinitions;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
/*import org.openqa.selenium.interactions.Coordinates;
import org.openqa.selenium.interactions.Locatable;*/
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumber.listener.Reporter;
import com.cucumbercraft.framework.Util;

public class GenericFunctions extends MasterStepDefs {

	private static final String Constants = null;
	private static final By locator = null;
	private static final String value = null;
	public static WebDriver driver;
	public static Alert TxtBoxContent;

	//Open firefox browser
	public static void openFirefoxBrowser() {

		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("URL");

	}

	// Launch the browser like which browser u want to open
	public static WebDriver createWebDriver(String browser) {
		System.out.println("Browser: " + browser);

		switch (browser.toLowerCase()) {
		case "ff":
		case "firefox":
			driver = new FirefoxDriver();
			break;

		case "ch":
		case "chrome":
			System.setProperty("webdriver.chrome.driver", "C:\\Maven\\CucumberDemoBDDFramework\\src\\main\\java\\com\\app\\resources\\chromedriver.exe");
			driver = new ChromeDriver();
			break;

		case "ie":
		case "internetexplorer":
			driver = new InternetExplorerDriver();
			break;

		default:
			System.out.println("Invalid browser name " + browser);
			System.exit(0);
			break;
		}// switch

		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(45, TimeUnit.SECONDS);

		return driver;
	} 


	// Getting the bowser name from config properties 
	public static String getBrowserName() {
		String browserName = System.getProperty("browser");

		if (browserName == null)
			browserName = "ie";
		return browserName;
	}

	//Select element by Value
	public static void selectElementByValueMethod(WebElement element,
			String value) {
		Select selectitem = new Select(element);
		selectitem.selectByValue(value);
	}

	// Select element by Index
	public static void selectElementByIndexMethod(WebElement element, int index) {
		Select selectitem = new Select(element);
		selectitem.selectByIndex(index);
	}

	// Click on the checkboxes from list 
	public static void clickCheckboxFromList(String xpathOfElement,
			String valueToSelect) {

		List<WebElement> lst = driver.findElements(By.xpath(xpathOfElement));
		for (int i = 0; i < lst.size(); i++) {
			List<WebElement> dr = lst.get(i).findElements(By.tagName("label"));
			for (WebElement f : dr) {
				System.out.println("value in the list : " + f.getText());
				if (valueToSelect.equals(f.getText())) {
					f.click();
					break;
				}
			}
		}
	}

	// Select by element by visible text 
	public static void fn_SelectByText(WebElement WE, String VisibleText){
		Select selObj=new Select(WE);
		selObj.selectByVisibleText(VisibleText);
	}


	//  Select web Element by index
	public static void selectElementByIndex(WebElement element, int index) {
		Select selectitem = new Select(element);
		selectitem.selectByIndex(index);
	}



	// Select Item from dropdown using Value
	public static void fn_SelectWebElement(WebElement WE, String Value){
		Select selObj=new Select(WE);
		selObj.selectByValue(Value);
	}


	// Select Item from dropdown using Name
	public static void selectElementByNameMethod(WebElement element, String Name) {
		Select selectitem = new Select(element);
		selectitem.selectByVisibleText(Name);
	}



	//  Select Item from dropdown using Index
	public static void fn_SelectByIndex(WebElement WE, int IndexValue){
		Select selObj=new Select(WE);
		selObj.selectByIndex(IndexValue);

	}

	// Enter Input to TextBox by ID
	public static void EnterValuebyID(String ID, String Value){
		driver.findElement(By.id(ID)).sendKeys(Value);
		Reporter.addStepLog(Value + " is entered in Textbox" + ID);
		//currentScenario.embed(Util.takeScreenshot(driver), "image/png");
	}


	// Clear the text in input field 
	public static void clearTextField(WebElement element) {
		element.clear();

	}

	// Get current method name
	public static String getMethodName() {

		String methodName = Thread.currentThread().getStackTrace()[1]
				.getMethodName(); System.out.println(methodName);

				return methodName; 
	}

	//  Wait for web element and click
	public static void waitForElement(WebElement element) {

		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	// wait for element visible
	public static void waitTillElementFound(WebElement ElementTobeFound,
			int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		wait.until(ExpectedConditions.visibilityOf(ElementTobeFound));
	}

	// Takes screenshot of web element
	public static void takeScreenshotOfWebelement(WebDriver driver,
			WebElement element, String Destination) throws Exception {
		File v = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		BufferedImage bi = ImageIO.read(v);
		org.openqa.selenium.Point p = element.getLocation();
		int n = element.getSize().getWidth();
		int m = element.getSize().getHeight();
		BufferedImage d = bi.getSubimage(p.getX(), p.getY(), n, m);
		ImageIO.write(d, "png", v);

		FileUtils.copyFile(v, new File(Destination));
	}


	// Take screen shot
	public static void takeScreenshotMethod(String Destination)
			throws Exception {
		File f = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File(Destination));
	}


	// Set the window size
	public static void setWindowSize(int Dimension1, int dimension2) {
		driver.manage().window().setSize(new Dimension(Dimension1, dimension2));

	}

	// Press the Key Down
	public static void pressKeyDown(WebElement element) {
		element.sendKeys(Keys.DOWN);
	}



	// Press Key Enter
	public void pressKeyEnter(WebElement element) {
		element.sendKeys(Keys.ENTER);
	}


	// Press Key Up
	public static void pressKeyUp(WebElement element) {
		element.sendKeys(Keys.UP);
	}

	// Move to tab like alt+tab
	public static void moveToTab(WebElement element) {
		element.sendKeys(Keys.chord(Keys.ALT, Keys.TAB));
	}


	//  Get element through Java Script
	public static void Visible() {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("document.getElementById('periodId').style.display='block';");
	}

	// Handle IeBowroser HTTPS
	public static void handleHTTPS_IEbrowser() {
		driver.navigate().to("javascript:document.getElementById(�overridelink�).click()); ");
	}


	// Firefox profile untrusted certificates
	public static void handleHTTPS_Firefox() {
		FirefoxProfile profile = new FirefoxProfile();
		profile.setAcceptUntrustedCertificates(false);
		//	driver = new FirefoxDriver(profile);
		driver = new FirefoxDriver((Capabilities) profile);
	}

	// Wit for till page load
	public static void waitTillPageLoad(int i) {
		driver.manage().timeouts().pageLoadTimeout(i, TimeUnit.SECONDS);
	}

	// Click the all links in that page
	public static void clickAllLinksInPage(String destinationOfScreenshot)
			throws Exception {

		List<WebElement> Links = driver.findElements(By.tagName("a"));
		System.out.println("Total number of links :" + Links.size());

		for (int p = 0; p < Links.size(); p++) {
			System.out.println("Elements present the body : "+ Links.get(p).getText());
			Links.get(p).click();
			Thread.sleep(3000);
			System.out.println("Url of the page � + p + �)"	+ driver.getCurrentUrl());
			takeScreenshotMethod(destinationOfScreenshot + p);
			navigate_back();
			Thread.sleep(2000);
		}

	}

	// Keyboard events 
	public static void keyboardEvents(WebElement webelement, Keys key,
			String alphabet) {
		webelement.sendKeys(Keys.chord(key, alphabet));

	}

	// Navigate to forward
	public static void navigate_forward() {
		driver.navigate().forward();
	}

	// Navigate to back
	public static void navigate_back() {
		driver.navigate().back();
	}

	// Refresh the browser
	public static void refresh() {
		driver.navigate().refresh();
	}


	// Implicit wait time
	public static void waitMyTime(int i) {
		driver.manage().timeouts().implicitlyWait(i, TimeUnit.SECONDS);

	}

	// click on webelement
	public static void clickWebelement(WebElement element) {
		try {
			boolean elementIsClickable = element.isEnabled();
			while (elementIsClickable) {
				element.click();
			}

		} catch (Exception e) {
			System.out.println("Element is not enabled");
			e.printStackTrace();
		}
	}

	//Click multiple elements
	public static void clickMultipleElements(WebElement someElement,
			WebElement someOtherElement) {
		Actions builder = new Actions(driver);
		builder.keyDown(Keys.CONTROL).click(someElement)
		.click(someOtherElement).keyUp(Keys.CONTROL).build().perform();
	}

	// Highlight the web element
	public static void highlightelement(WebElement element) {
		for (int i = 0; i < 4; i++) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute(style, arguments[1]);", element, " color: solid red; border: 6px solid yellow");
			js.executeScript("arguments[0].setAttribute(style, arguments[1]);",element, "");

		}

	}

	// Accept the alert
	public static boolean checkAlert_Accept() {
		try {
			Alert a = driver.switchTo().alert();
			String str = a.getText();
			System.out.println(str);

			a.accept();
			return true;

		} catch (Exception e) {

			System.out.println("no alert");
			return false;

		}
	}

	// Dismiss the alert
	public static boolean checkAlert_Dismiss() {
		try {
			Alert a = driver.switchTo().alert();
			String str = a.getText();
			System.out.println(str);

			a.dismiss();
			return true;

		} catch (Exception e) {

			System.out.println("no alert");
			return false;

		}
	}


	// Item present or not?	
	public static void boleanItemPresent() {
		Boolean isItemPresent = driver.findElements(By.id("locater ")).size() > 0;
	}

	/*// Scroll to till element present
	public static void scrolltoElement(WebElement ScrolltoThisElement) {
		Coordinates coordinate = ((Locatable) ScrolltoThisElement)
				.getCoordinates();
		coordinate.onPage();
		coordinate.inViewPort();
	}*/



	// check the check box
	public static void checkbox_Checking(WebElement checkbox) {
		boolean checkstatus;
		checkstatus = checkbox.isSelected();
		if (checkstatus == true) {
			System.out.println("Checkbox is already checked");
		} else {
			checkbox.click();
			System.out.println("Checked the checkbox");
		}
	}

	// Select the radio button
	public static void radiobutton_Select(WebElement Radio) {
		boolean checkstatus;
		checkstatus = Radio.isSelected();
		if (checkstatus == true) {
			System.out.println("RadioButton is already checked");
		} else {
			Radio.click();
			System.out.println("Selected the Radiobutton");
		}
	}

	//Un checking checkbox
	public static void checkbox_Unchecking(WebElement checkbox) {
		boolean checkstatus;
		checkstatus = checkbox.isSelected();
		if (checkstatus == true) {
			checkbox.click();
			System.out.println("Checkbox is unchecked");
		} else {
			System.out.println("Checkbox is already unchecked");
		}
	}

	//Deselect the radio button
	public static void radioButton_Deselect(WebElement Radio) {
		boolean checkstatus;
		checkstatus = Radio.isSelected();
		if (checkstatus == true) {
			Radio.click();
			System.out.println("Radio Button is deselected");
		} else {
			System.out.println("Radio Button was already Deselected");
		}
	}

	// Drag and drop
	public static void dragAndDrop(WebElement fromWebElement,
			WebElement toWebElement) {
		Actions builder = new Actions(driver);
		builder.dragAndDrop(fromWebElement, toWebElement);
	}

	// Drag and drop to particular web element
	public static void dragAndDrop_Method2(WebElement fromWebElement,
			WebElement toWebElement) {
		Actions builder = new Actions(driver);
		Action dragAndDrop = builder.clickAndHold(fromWebElement)
				.moveToElement(toWebElement).release(toWebElement).build();
		dragAndDrop.perform();
	}



	// Drag and drop to web element

	public static void dragAndDrop_Method3(WebElement fromWebElement,
			WebElement toWebElement) throws InterruptedException {
		Actions builder = new Actions(driver);
		builder.clickAndHold(fromWebElement).moveToElement(toWebElement)
		.perform();
		Thread.sleep(2000);
		builder.release(toWebElement).build().perform();
	}


	// Hover the web element
	public static void hoverWebelement(WebElement HovertoWebElement)
			throws InterruptedException {
		Actions builder = new Actions(driver);
		builder.moveToElement(HovertoWebElement).perform();
		Thread.sleep(2000);

	}


	//Tool tip
	public static String getToolTip(WebElement toolTipofWebElement)
			throws InterruptedException {
		String tooltip = toolTipofWebElement.getAttribute("title");
		System.out.println("Tool text :"  + tooltip);
		return tooltip;
	}

	// Download file
	public static void downloadFile(String href, String fileName)
			throws Exception {
		URL url = null;
		URLConnection con = null;
		int i;
		url = new URL(href);
		con = url.openConnection();
		File file = new File(".//OutputData//" + fileName);
		BufferedInputStream bis = new BufferedInputStream(con.getInputStream());
		BufferedOutputStream bos = new BufferedOutputStream(
				new FileOutputStream(file));
		while ((i = bis.read()) != -1) {
			bos.write(i);
		}
		bos.flush();
		bis.close();
	}

	// Navigate to evessry link page 
	public static void navigateToEveryLinkInPage() throws InterruptedException {

		List<WebElement> linksize = driver.findElements(By.tagName("a"));
		int linksCount = linksize.size();
		System.out.println("Total no of links Available: " + linksCount);
		String[] links = new String[linksCount];
		System.out.println("List of links Available: ");
		// print all the links from webpage
		for (int i = 0; i < linksCount; i++) {
			links[i] = linksize.get(i).getAttribute("href");
			System.out.println(linksize.get(i).getAttribute("href"));
		}


		//navigate to each Link on the webpage
		for (int i = 0; i < linksCount; i++) {
			driver.navigate().to(links[i]);
			Thread.sleep(3000);
			System.out.println(driver.getTitle());
		}
	}

	// Wait time
	public static void wait(int w) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(w, TimeUnit.SECONDS);
	}

	// Actions
	public static Actions getAction() {
		Actions action = new Actions(driver);
		return action;
	}

	// Choose web element
	public static WebElement chooseElement(int x,String path){

		WebElement webElement = null;

		switch (x){
		case 1:         
			webElement=driver.findElement(By.id(path));
			break;
		case 2:
			webElement=driver.findElement(By.className(path));
			break;
		case 3:
			webElement=driver.findElement(By.linkText(path));
			break;
		case 4:
			webElement=driver.findElement(By.xpath(path)); 
			break;
		case 5:
			webElement=driver.findElement(By.cssSelector(path));
			break;
		case 6:
			webElement = driver.findElement(By.tagName(path));
			break;
		}           
		return webElement;      
	}

	// Select element by index 
	public static Select ddElement(WebElement webElement, int dx,Object dindex){

		Select select = new Select(webElement);

		switch (dx){
		case 1:     
			System.out.println("case 1");
			select.selectByVisibleText((String) dindex);
			break;
		case 2:
			System.out.println("case 2");
			select.selectByValue((String) dindex);
			break;
		case 3:
			System.out.println("case 3");
			select.selectByIndex((int) dindex);
			break;  
		}           
		return select;      
	}


	// Mouse over
	public static void mouseOver(int x, String path) throws InterruptedException {      
		WebElement mO=chooseElement(x, path);        
		getAction().moveToElement(mO).perform();        
	}

	// Send the values in text box
	public static void textBox (int x, String path, String text) throws InterruptedException {          
		chooseElement(x, path).sendKeys(text);      
		getAction().sendKeys(Keys.ESCAPE);
	}


	// Click on element
	public static void click(int x, String path) throws InterruptedException {          
		chooseElement(x, path).click(); 
	}


	//Get text
	public static String getTxt(int x, String path) throws InterruptedException {               
		String returnText = chooseElement(x, path).getText();
		return returnText;
	}

	// Drop down 
	public static void dropDown(int x, String path, int dx,Object dindex) throws InterruptedException {
		try {               
			WebElement webElement=chooseElement(x, path);
			ddElement(webElement,dx,dindex); // Value index                  
		}
		catch (NoSuchElementException e) {

		}
	}

	// Switch to new window
	public static void switchToNewWindow() {
		Set s = driver.getWindowHandles();
		Iterator itr = s.iterator();
		String w1 = (String) itr.next();
		String w2 = (String) itr.next();
		driver.switchTo().window(w2);
	}

	// Switch to old window
	public static void switchToOldWindow() {
		Set s = driver.getWindowHandles();
		Iterator itr = s.iterator();
		String w1 = (String) itr.next();
		String w2 = (String) itr.next();
		driver.switchTo().window(w1);
	}


	//Switch to parent window
	public static void switchToParentWindow() {
		driver.switchTo().defaultContent();
	}

	//Verify the title
	public void verifyTitle(String locator, String data) {    
		String txt = getElement(locator).getText();
		if (txt.equals(data)) {
			System.out.println("Title name present");
		}
	}



	// Get element
	private Alert getElement(String locator) {
		// TODO Auto-generated method stub
		return null;
	}

	// Verify element title 
	public void verifyElementTitle(String locator, String data) {
		String expectedTxt = data;
		String actualTxt = getElement(locator).getText();
		if (actualTxt.equals(expectedTxt)) {
			System.out.println("Title name present");
			//return Constants.Pass;
		} else
			System.out.println("Title mismach or not present");
		// return Constants.FAIL;
	}

	// Get title
	public void verifyTitle() {
		WebElement title = driver.findElement(By.tagName("title"));
		System.out.println(title.getText());
	}

	// Get PAge title
	public void pageTitle() {

		driver.get("http://referencewebapp.qaautomation.net/");

		String pageTitle = driver.getTitle();

		assertEquals("Current page title", "Reference Web App - QA Automation", pageTitle);

	}

	private void assertEquals(String string, String string2, String pageTitle) {
		// TODO Auto-generated method stub

	}

	//ValidateTextParagraph

	public static void VerifyPagagraph() {

		String Txt = TxtBoxContent.getText();
		System.out.println(Txt);

	}

	// validate text
	public static void text () {
		String WebelementID = null;
		WebElement TxtBoxContent = driver.findElement(By.id(WebelementID));
		System.out.println("Printing " + TxtBoxContent.getAttribute("value"));
	}

	// No of elements found
	public void noelements() {

		int numberOfElementsFound = getNumberOfElementsFound(locator);
		for (int pos = 0; pos < numberOfElementsFound; pos++) {
			getElementWithIndex(locator, pos).click();
		}
	}

	// Get no of elements found

	public int getNumberOfElementsFound(By by) {
		return driver.findElements(by).size();
	}

	// Get element by index
	public WebElement getElementWithIndex(By by, int pos) {
		return driver.findElements(by).get(pos);
	}


	// Click on web element
	public static void clickOnWebelement(WebElement element) {
		try {
			boolean elementIsClickable = element.isEnabled();
			while (elementIsClickable) {
				element.click();
			}

		} catch (Exception e) {
			System.out.println("Element is not enabled");
			e.printStackTrace();
		}
	}

	// Click on radio button
	public void clickonRadioBtn() {
		List<WebElement> select = driver.findElements(locator);

		for (WebElement radio : select){
			if (radio.getAttribute("value").equalsIgnoreCase(value))
				radio.click();
		}
	}

	// Select radio button
	public void RadioBntClick() {
		Select select= new Select (driver.findElement(locator));
		select.selectByVisibleText(value);

	}

	// Send keys to input box
	public void sendKeysinputbox() {

		WebElement field = driver.findElement(locator);
		field.clear();
		field.sendKeys(value);
	}
	//is element visible
	public void IsElementVisible() {


		if(driver.findElement(By.xpath("noRecordId")).isDisplayed() )                                                                                                         
		{         
			System.out.println(" Element is displayed");  
		}    
		else    
		{     
			System.out.println("Element is not displayed");
		}

	}

	public boolean isAlertPresent() 
	{ 
	    try 
	    { 
	        driver.switchTo().alert(); 
	        return true; 
	    }   // try 
	    catch (NoAlertPresentException Ex) 
	    { 
	        return false; 
	    }   // catch 
	} 



}










