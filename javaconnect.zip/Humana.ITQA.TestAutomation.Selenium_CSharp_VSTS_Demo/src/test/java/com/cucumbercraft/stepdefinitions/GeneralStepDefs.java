package com.cucumbercraft.stepdefinitions;

import static org.testng.Assert.assertTrue;

import java.nio.file.Paths;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

//import com.codoid.products.fillo.Fillo;
import com.cucumber.listener.Reporter;
import com.cucumbercraft.framework.DriverManager;
import com.cucumbercraft.framework.EncrptText;
import com.cucumbercraft.framework.Util;
import com.cucumbercraft.framework.WebDriverUtil;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;





public class GeneralStepDefs extends MasterStepDefs {
	GeneralMethods gm = new GeneralMethods();
	

//	TestContext testContext;
	
	static Logger log = Logger.getLogger(GeneralStepDefs.class);

	WebDriver driver = DriverManager.getWebDriver();
	WebDriverUtil driverutil = new WebDriverUtil(driver);
	@Given("^Navigate to application \"(.*?)\" using URL \"(.*?)\"$")
	public void Navigate_to_Application(String Applciation, String appURL) throws InterruptedException {
		
		driver.get(appURL);	
		
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		
		assertTrue(driver.getTitle().contains(Applciation));	
		Thread.sleep(4000);
	}
	
	@Given("^I’m validating \"(.*?)\" using URL \"(.*?)\"$")
	public void Validating_to_Application(String Applciation, String appURL) throws InterruptedException {
		WebDriverWait wait=new WebDriverWait(driver, 100);
		/*
		driver.get(appURL);	
		
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		wait.until(ExpectedConditions.titleContains(Applciation));
		assertTrue(driver.getTitle().contains(Applciation));	
		Thread.sleep(4000);*/
		driver.get(appURL);
		System.out.println(driver.getTitle());
		
	}
	
	@And("^Enter Value \"(.*?)\" in Textbox$")
	public void entervalue_Generic_Textbox(String Value) throws InterruptedException {
		if (!driver.findElements(By.xpath("(//input[contains(@type,'text') or contains(@type,'search') or contains(@class,'text')  or contains(@type,*)])[1]")).isEmpty()) {
		WebElement editbox=driver.findElement(By.xpath("(//input[contains(@type,'text') or contains(@type,'search')  or contains(@type,*) or contains(@class,'text')])[1]"));
		editbox.sendKeys(Value);
		Reporter.addStepLog(Value + " is entered in Textbox ");			
		Thread.sleep(1000);			
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		else {
			Reporter.addStepLog("Textbox field is not displayed");
			Assert.fail();
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		
	}
	@And("^Enter in Password value \"(.*?)\"$")
	public void enter_passowrd(String pass) throws InterruptedException {
		WebElement editbox=driver.findElement(By.xpath("//input[@type='password']"));
		editbox.sendKeys(pass);
		Reporter.addStepLog("Password is entered in Textbox ");			
		Thread.sleep(1000);			
	}
	@And("^Enter in Textbox \"(.*?)\" value \"(.*?)\"$")
	
	public void Enter_Value_By_ID(String ID, String Value) throws InterruptedException {	
		
		if (!driver.findElements(By.xpath("(*//label[starts-with(normalize-space(),'"+ID+"')]//following::input)[1]")).isEmpty()) {
			int s=driver.findElements(By.xpath("*//label[starts-with(normalize-space(),'"+ID+"')]")).size();
			WebElement editbox=driver.findElement(By.xpath("((*//label[starts-with(normalize-space(),'"+ID+"')])["+1+"]//following::input[@type='text' or contains(@type,*)])[1]"));
			editbox.sendKeys(Value+Keys.TAB);
			Reporter.addStepLog(Value + " is entered in Textbox " + ID);			
			Thread.sleep(1000);			
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
			else if (!driver.findElements(By.xpath("(*//*[contains(*,'"+ID+"')]//following::input)[1]")).isEmpty()) {
				int s=driver.findElements(By.xpath("*//*[contains(*,'"+ID+"')]")).size();
				WebElement editbox=driver.findElement(By.xpath("((*//*[contains(*,'"+ID+"')])["+s+"]//following::input)[1]"));
				editbox.sendKeys(Value);
				Reporter.addStepLog(Value + " is entered in Textbox " + ID);			
				Thread.sleep(1000);			
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		else if (!driver.findElements(By.xpath("(*//span[contains(text(),'"+ID+"')]//following::input)[1]")).isEmpty()) {
			int s=driver.findElements(By.xpath("*//span[contains(text(),'"+ID+"')]")).size();
			WebElement editbox=driver.findElement(By.xpath("((*//span[contains(text(),'"+ID+"')])["+s+"]//following::input)[1]"));
			editbox.sendKeys(Value);
			Reporter.addStepLog(Value + " is entered in Textbox " + ID);			
			Thread.sleep(1000);			
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		else if(!driver.findElements(By.xpath("//input[contains(@placeholder,'"+ID+"')]")).isEmpty()) {
			
			WebElement editbox=driver.findElement(By.xpath("//input[contains(@placeholder,'"+ID+"')]"));
			editbox.sendKeys(Value);
			Reporter.addStepLog(Value + " is entered in Textbox " + ID);			
			Thread.sleep(1000);			
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		else if(!driver.findElements(By.xpath("//input[contains(@value,'"+ID+"')]")).isEmpty()) {
			
			WebElement editbox=driver.findElement(By.xpath("//input[contains(@value,'"+ID+"')]"));
			editbox.sendKeys(Value);
			Reporter.addStepLog(Value + " is entered in Textbox " + ID);			
			Thread.sleep(1000);			
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		else {
			Reporter.addStepLog(ID + " field is not displayed");
			Assert.fail();
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		
	}
	
	@And("^Enter Value in Textbox \"(.*?)\" Value \"(.*?)\" using XPath \"(.*?)\"$")
	public void enter_value_TextBox_Xpath(String Name, String Value,String xpath) throws InterruptedException {
		WebElement editbox=driver.findElement(By.xpath(xpath));
		try {
			editbox.clear();
		editbox.sendKeys(Value);
		}catch(NoSuchElementException e)
		{
			new Actions(driver).moveToElement(editbox).perform();
			editbox.sendKeys(Value);
		}
		Reporter.addStepLog(Value + " is entered in Textbox " + Name);			
		Thread.sleep(1000);			
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
	}
	
	@And("^Enter in \"(.*?)\" \"(.*?)\" and select \"(.*?)\" using AutoSuggestion$")
	public void entervalue_and_autoselect(String ID, String Value, String ActValue) throws InterruptedException {
		if(!driver.findElements(By.xpath("//input[contains(@placeholder,'"+ID+"') or contains(@value,'"+ID+"')]")).isEmpty()) {
			
			WebElement editbox=driver.findElement(By.xpath("//input[contains(@placeholder,'"+ID+"') or contains(@value,'"+ID+"')]"));
			editbox.sendKeys(Value);
			Reporter.addStepLog(Value + " is entered in Textbox " + ID);	
			editbox.sendKeys(Keys.DOWN);
			Thread.sleep(4000);
			int abc=driver.findElements(By.xpath("(((//input[contains(@placeholder,'"+ID+"') or contains(@value,'"+ID+"')]//following::*[contains(@class,'dropdown') or contains(@class,'auto') or contains(@class,'Auto') or contains(@class,'predictions')  or contains(@class,'sugges')]))/*[contains(*,'"+ActValue+"')])")).size();
			WebElement as=driver.findElement(By.xpath("(((//input[contains(@placeholder,'"+ID+"') or contains(@value,'"+ID+"')]//following::*[contains(@class,'dropdown') or contains(@class,'auto') or contains(@class,'Auto')  or contains(@class,'sugges')]))/*[contains(*,'"+ActValue+"')])["+abc+"]"));
			as.click();
			Reporter.addStepLog(ActValue + " is selected from AutoSuggestion " + ID);	
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			Thread.sleep(3000);
		}	
		
		else { 
			Reporter.addStepLog(ID + " field is not displayed");
			Assert.fail();
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
				
		
	}
//	
//	@When("^Click \"(.*?)\" button with Partial Name$")	
//	public void ClickButtonByID_Partial(String ID) throws InterruptedException {
//		
//		WebDriverWait wait = new WebDriverWait(driver, 5);	
//		//WebElement btnButton=driver.findElement(By.xpath("//*[(contains(text(),'"+ID+"') or @value='"+ID+"' or contains(@id,'"+ID+"')) and( (contains(@id,'btn') or @type='submit' or @type='button' or contains(@id,'button')) )]"));
//		WebElement btnButton=driver.findElement(By.xpath("//*[(contains(text(),'"+ID+"') or @value='"+ID+"' or contains(@id,'"+ID+"') and @type='submit')]"));
//		btnButton.click();
//		/*if (btnValue=="") {
//			btnValue="ID";
//		}*/
//		Reporter.addStepLog(ID + " Button is Clicked");
//		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//		
//	}
//	
	
	@And("^Click LINK using Partial Name \"(.*?)\"$")	
	public void Click_Link_By_Text(String Text) throws InterruptedException {
		Actions actions = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 5);		
		WebElement ele = driver.findElement(By.xpath("*//*[contains(text(),'"+Text+"')]"));

		//		actions.moveToElement(ele).perform();
		ele.click();
		
		Reporter.addStepLog(Text  + " Link is Clicked");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		
	}
	
	@And("^Click LINK using Actual Name \"(.*?)\"$")	
	public void Click_Link_By_ActualText(String Text) throws InterruptedException {
		Actions actions = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 5);		
		WebElement ele = driver.findElement(By.xpath("(*//a[normalize-space(.)='"+Text+"' and not(contains(@style,'display:none'))])[1]"));
		//ele.sendKeys(Keys.SHIFT);
//		actions.moveToElement(ele).build().perform();
		
		Thread.sleep(2000);
		ele.click();
		
		Reporter.addStepLog(Text  + " Link is Clicked");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");		
	}
	
	@And("^Select VALUE \"(.*?)\" from \"(.*?)\" DROPDOWN$")
	public void Select_Value_From_Dropdown_Using_ID_Property(String Value, String ID) throws InterruptedException {
		WebElement dList=driver.findElement(By.xpath("(*//*[starts-with(normalize-space(),'"+ID+"')]//following::select)[1]"));
//		WebElement dList=driver.findElement(By.xpath("(*//*[text()='"+ID+"')]//following::select)[1]"));
		Select selectitem = new Select(dList);
		Thread.sleep(2000);
		dList.click();
		Thread.sleep(2000);
		selectitem.selectByVisibleText(Value);
		Reporter.addStepLog(Value  + " is selected in "+ ID+" Dropdown ");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
	}
	
	@And("^Select VALUE \"(.*?)\" from \"(.*?)\" dropdown using XPath \"(.*?)\"$")
	public void select_value_Dropdown_xpath(String Value, String Name, String xpath) throws InterruptedException {
		WebElement dList=driver.findElement(By.xpath(xpath));
//		WebElement dList=driver.findElement(By.xpath("(*//*[text()='"+ID+"')]//following::select)[1]"));
		Select selectitem = new Select(dList);
		Thread.sleep(2000);
		dList.click();
		Thread.sleep(2000);
		selectitem.selectByVisibleText(Value);
		Reporter.addStepLog(Value  + " is selected in "+ Name+" Dropdown ");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
	}
	
	@And("^Select \"(.*?)\" from \"(.*?)\" radio button$")
	public void select_radioButton(String Value, String DisplayName) {
		//int Cou=driver.findElements(By.xpath("*//*[starts-with(normalize-space(),'"+Value+"')]//Self::*[@type='raio']")).size();										//				
		WebElement objRadio=driver.findElement(By.xpath(("(*//*[starts-with(normalize-space(),'"+DisplayName+"')]//following::*[starts-with(normalize-space(), '"+Value+"')]//self::*[@type='radio'])[1]")));
		
		if (objRadio.isDisplayed() ) {
			objRadio.click();
			Reporter.addStepLog(Value + "is selcted in "+ DisplayName+" Radio Button");
		} else {
			objRadio.click();
			Reporter.addStepLog(Value + "is selcted in "+ DisplayName+" Radio Button");
		}
		
	}
	
	@Then("^Verify displayed link \"(.*?)\"$")
	
	public void Search_Validation(String strText) throws InterruptedException {
		boolean ele = driver.findElements(By.xpath("*//a[contains(text(),'"+strText+"')]")).isEmpty();
		boolean eles=driver.findElements(By.xpath("*//a[contains(*,'"+strText+"')]")).isEmpty();
		if(!ele )                                                                                                         
		{         
			Reporter.addStepLog(strText + " is displayed");
			// pass the stored webelement to javascript executor
						
						Thread.sleep(1000);;
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}    
		else if(!eles )                                                                                                         
		{         
			Reporter.addStepLog(strText + " is displayed");
			// pass the stored webelement to javascript executor
						
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}   
		else    
		{     
			
			Reporter.addStepLog(strText + " is not displayed");
			Assert.fail();
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		
	}
	
	@Then("^Verify displayed webelement \"(.*?)\"$")
	public void Search_Validation_Label(String strText) {
		//WebElement ele = driver.findElement(By.xpath("*//td[contains(text(),'"+strText+"')]"));
		if(!driver.findElements(By.xpath("*//*[contains(text(),'"+strText+"')]")).isEmpty() )                                                                                                            
		{         
			WebElement ele=driver.findElement(By.xpath("*//*[contains(text(),'"+strText+"')]"));
			Reporter.addStepLog(strText + " is displayed");
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].style.border='2px solid red'", ele);
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		} 
	else if(!driver.findElements(By.xpath("*//td[contains(text(),'"+strText+"')]")).isEmpty() )                                                                                                         
		{         
			Reporter.addStepLog(strText + " is displayed6");
			//JavascriptExecutor jse = (JavascriptExecutor) driver;
			//jse.executeScript("arguments[0].style.border='2px solid red'", ele);
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}    
		
		else if(!driver.findElements(By.xpath("*//a[contains(text(),'"+strText+"')]")).isEmpty() )                                                                                                            
		{         
			Reporter.addStepLog(strText + " is displayed");
			//JavascriptExecutor jse = (JavascriptExecutor) driver;
			//jse.executeScript("arguments[0].style.border='2px solid red'", ele);
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		} 
		else if(!driver.findElements(By.xpath("*//span[contains(text(),'"+strText+"')]")).isEmpty() )                                                                                                           
		{         
			WebElement ele=driver.findElement(By.xpath("*//*[contains(text(),'"+strText+"')]"));
			Reporter.addStepLog(strText + " is displayed");
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].style.border='2px solid red'", ele);
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		} 
		
		 
		
		else    
		{     
			
			
			Reporter.addStepLog(strText + " is not displayed");
			Assert.fail();
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		
	}
//	@And("^Click the First Link which have value \"(.*?)\"$")
//	public void clickFirstLinkDisplayed(String Name) throws InterruptedException {
//		WebElement ele = driver.findElement(By.xpath("*//a[contains(text(),'"+Name+"')]"));
//		if(ele.isDisplayed() )                                                                                                         
//		{         
//			ele.click();
//			Thread.sleep(5000);
//			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//		}    
//		else    
//		{     
//			
//			Reporter.addStepLog(Name + " is not displayed");
//			Assert.fail();
//			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//		}
//
//		
//	}

//	@And("^Fetch email id of the user displayed as Link$")
//	public void FetchEmailID() throws InterruptedException {
//		WebElement eMailID=driver.findElement(By.xpath("*//a[contains(text(),'.com')]"));
//		if(eMailID.isDisplayed() )                                                                                                         
//		{         
//			//ele.click();
//			String eMailIDValue=eMailID.getText();
//			Reporter.addStepLog("The Retieved Email iD is "+eMailIDValue);	
//			eMailID.sendKeys(Keys.DOWN);
//			
//			// pass the stored webelement to javascript executor
//			JavascriptExecutor jse = (JavascriptExecutor) driver;
//			jse.executeScript("arguments[0].style.border='2px solid red'", eMailID);
//			Thread.sleep(1000);;
//
//		
//
//			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//		}
//		else    
//		{     
//			
//			Reporter.addStepLog("Email ID is not displayed");
//			Assert.fail();
//			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//		}
//	}
	@When("^Screenshot taken$")
	public void take_Screenshot() {
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
	}
	@And("^Click VALUE (.*) in RADIO BUTTON (.*) using ID (.*)$")
	public  void radiobutton_Select_using_ID(String Value, String Name, String ID) {
		WebElement objRadio=driver.findElement(By.xpath("//*[@id='"+ID+"']"));
		Boolean checkstatus;
		checkstatus = objRadio.isSelected();
		if (checkstatus == true) {
			Reporter.addStepLog(Value + "is selcted in "+ Name+" Radio Button");
		} else {
			objRadio.click();
			Reporter.addStepLog(Value + "is selcted in "+ Name+" Radio Button");
		}
	}
	
	@And("^Click IMAGE with Tooltip name as \"(.*?)\"$")
	public void click_Image_With_Alt(String alt) throws InterruptedException {
		WebElement objImage=driver.findElement(By.xpath("//img[contains(@alt, '"+alt+"')]"));		
		
		objImage.click();
			Reporter.addStepLog(alt + " Image is Clicked");
			Thread.sleep(3000);
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
		
	@And("^Enable/Select CHECKBOX \"(.*?)\"$")
	public void click_Checkbox(String displayName) throws InterruptedException {
//		int 	Cou=driver.findElements(By.xpath("*//*[starts-with(normalize-space(),'"+displayName+"')]//preceding::input[@type='checkbox']")).size();
		WebElement objchk=driver.findElement(By.xpath(("(*//*[starts-with(normalize-space(), '"+displayName+"')]//self::*[@type='checkbox'])[1]")));
		
		if (objchk.isDisplayed() ) {
			objchk.click();
			Reporter.addStepLog(displayName + " checkbox selected");
		} else {
			objchk.click();
			Reporter.addStepLog(displayName + " checkbox selected");
		}
		Thread.sleep(3000);
	}
	
	@And("^Mouse hover on \"(.*?)\" and select \"(.*?)\"$")
	public void Mouse_Hover_Select_Link(String Parent, String Child) throws InterruptedException {
		Actions actions = new Actions(driver);
		WebElement mainMenu = driver.findElement(By.xpath("//*[contains(text(),'"+Parent+"')]"));
		actions.moveToElement(mainMenu).build().perform();;
		Reporter.addStepLog("Mouse hover completed on "+ Parent);
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		Thread.sleep(4000);
		String str = Child;
        String[] arrOfStr = str.split("#"); 
        if (arrOfStr.length>1){
		WebElement subMenu = driver.findElement(By.xpath("(//*[contains(text(),'"+arrOfStr[0]+"')]//following::*[contains(text(),'"+arrOfStr[1]+"')])[1]"));
		actions.moveToElement(subMenu);
        }
        else {
        	WebElement subMenu = driver.findElement(By.xpath("(//*[contains(text(),'"+Parent+"')]//following::*[contains(text(),'"+Child+"')])[1]"));
        	actions.moveToElement(subMenu);
        }
		
		Thread.sleep(2000);
		actions.click().build().perform();
		Reporter.addStepLog("Clicked on Submenu "+ Child);
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
	}
	
	@And("^Wait for page to load (.*)$")
	public void waitforPageLoad(int timeinsec) throws InterruptedException{
		Thread.sleep(timeinsec*1000);
		
	}
			
	
	@When("^Mouse hover Two levels and select \"(.*?)\"$")
	public void Mouse_Hover_Two_Level_Select(String Flow) throws InterruptedException {
		String str = Flow;
        String[] arrOfStr = str.split("#"); 
        Actions actions = new Actions(driver);
		WebElement mainMenu = driver.findElement(By.xpath("//*[contains(text(),'"+arrOfStr[0]+"')]"));
		actions.moveToElement(mainMenu).perform();;
		Reporter.addStepLog("Mouse hover completed on "+ arrOfStr[0]);
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		Thread.sleep(1000);
		WebElement mainMenu1 = driver.findElement(By.xpath("//*[contains(text(),'"+arrOfStr[1]+"')]"));
		actions.moveToElement(mainMenu1).perform();;
		Reporter.addStepLog("Mouse hover completed on "+ arrOfStr[1]);
		WebElement subMenu = driver.findElement(By.xpath("//*[contains(text(),'"+arrOfStr[2]+"')]"));
//		WebElement subMenu = driver.findElement(By.xpath("(//*[contains(text(),'"+arrOfStr[1]+"')]//following::*[contains(text(),'"+arrOfStr[2]+"')])[1]"));
		
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		Thread.sleep(1000);
		actions.moveToElement(subMenu);
		actions.click().build().perform();
		Reporter.addStepLog("Clicked on link "+ arrOfStr[2]);
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
        
  
	}
	
//	@Then("^Validate Page title \"(.*?)\"$")
//	public void Validate_PageTitle(String Title)	{
//		assertTrue(driver.getTitle().contains(Title));
//		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//	}
	
//	@Then("^Validate Heading \"(.*?)\"$")
//	public void validate_Heading(String Heading) {
//		WebElement heading=driver.findElement(By.xpath("*//h1[contains(text(),'"+Heading+"')]"));
//		if(heading.isDisplayed()) {
//			Reporter.addStepLog("Heading "+ Heading + " is displayed");
//			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//		}
//		else {
//			Assert.fail();
//			Reporter.addStepLog("Heading "+ Heading + " is not displayed");
//			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//		}
//	}
	
	@Then("^Verify Table with column Name \"(.*?)\" is displayed$")
	public void VerifyWebtabledisplayed(String ColumnName) {
		int cout=driver.findElements(By.xpath("(*//th[contains(text(),'"+ColumnName+"')]//ancestor::table)")).size();
		if (cout>=0) {
			  List<WebElement> rows = driver.findElements(By.xpath("(*//th[contains(text(),'"+ColumnName+"')]//ancestor::table)["+cout+"]/tbody/tr/td[1]"));
			Reporter.addStepLog("Table displayed with "+ rows.size() + " rows is displayed");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");			
		}
		else {
			Reporter.addStepLog("Table is not displayed");
			Assert.fail();
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
	}
	@Then("^Verify Value \"(.*?)\" is displayed in the table with Column Name \"(.*?)\"$")
	public void VerifyValueintheTable(String Value, String ColumnName) throws InterruptedException {
		int cout=driver.findElements(By.xpath("(*//th[contains(text(),'"+ColumnName+"')]//ancestor::table)")).size();
		if (cout>=0) {
			if (!(driver.findElements(By.xpath("(*//th[contains(text(),'"+ColumnName+"')]//ancestor::table)["+cout+"]/tbody/tr/td[contains(text(),'"+Value+"')]")).isEmpty())){
		
			  WebElement elements = driver.findElement(By.xpath("(*//th[contains(text(),'"+ColumnName+"')]//ancestor::table)["+cout+"]/tbody/tr/td[contains(text(),'"+Value+"')]"));
			  if(elements.isDisplayed()) {
				  	
					Reporter.addStepLog(Value + " is displayed in the table");
					
					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			  }
			  
			
		}
			else {
				 			  
				  Reporter.addStepLog(Value + " is not displayed in the table");
				  Assert.fail();
				  currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			
			  }
	}
		
}

	@When("^Mouse hover on webelement \"(.*?)\"$")
	public void Mouse_hover_on(String Parent) throws InterruptedException {
		Actions actions = new Actions(driver);
		// Move mouse any attribute using @alt
		WebElement mainMenu = driver.findElement(By.xpath("//*[contains(@alt,'" + Parent + "') or contains(@title,'"+Parent+"')]"));
		actions.moveToElement(mainMenu).build().perform();
		Thread.sleep(5000);
		String toolTipTxt = mainMenu.getText();
		Reporter.addStepLog("Tooltip on web element " + toolTipTxt);
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		Thread.sleep(3000);

	}
	
	
	@When("^Moving slider(.*)$")
	public void Moving_Slider(String ID) throws InterruptedException {
		driver.switchTo().frame(0);
		WebElement slider = driver.findElement(By.id("slider"));
		gm.clickAndHold(slider);
		gm.moveByOffset(25, 75);
		Reporter.addStepLog("Move slider one place to another place ");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		Thread.sleep(3000);

	}

	@When("^Drag and Drop (.*) with (.*)$")
	public void Drag_and_Drop(String sourceId,String destinationId) throws InterruptedException {
		gm.swithToFrmae(0);
		WebElement Source = driver.findElement(By.xpath("//*[@id='"+sourceId+"']"));
		WebElement Destination = driver.findElement(By.xpath(("//*[@id='"+destinationId+"']")));
		gm.dragAndDrop(Source, Destination);
		Reporter.addStepLog("Drag text source to destination ");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");

	}

	@When("^Select Date \"(.*?)\"$")
	public void Selecting_DateS(String Date) throws InterruptedException {
		String Day = Date.substring(0, 2);
		System.out.println(Day);
		//int day = Integer.parseInt(Day);
		gm.swithToFrmae(0);
		WebElement calElement = driver.findElement(By.id("datepicker"));
		calElement.click();
		Thread.sleep(10000);
		WebElement dateWidgetFrom = driver.findElement(By.xpath("//tbody"));
		java.util.List<WebElement> columns = dateWidgetFrom.findElements(By.tagName("td"));
		for (WebElement cell : columns) {
			// If you want to click 18th Date
			if (cell.getText().equals(Day)) {
				cell.click();
				Thread.sleep(5000);

			}
		}

	}

	@When("^Select Tab \"(.*?)\"$")
	public void Selecting_Tabs(String Text) throws InterruptedException {
		
			WebElement Tab = driver.findElement(By.xpath("//a[normalize-space()='"+ Text + "')]"));
			Tab.click();
			Thread.sleep(10000);
		}

	

//	@When("^Goto Panel \"(.*?)\"$")
//	public void Goto_Pannel(String Name) throws InterruptedException {
//		WebElement Panel = driver.findElement(By.xpath("//p[contains(text(),'" + Name + "')]"));
//		// WebElement Panel=driver.findElement(By.xpath("//p[contains(text(),'The language for building web pages')]"));
//		if (Panel.isDisplayed()) {
//			Reporter.addStepLog("Panel " + Panel + " is displayed");
//			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//		} else {
//			Reporter.addStepLog("Panel " + Panel + " is not displayed");
//			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
//		}
//
//	}
	
	@When("^Validate Ratings \"(.*?)\"$")
	public void Validate_Ratings(String Rating) {
		
		 WebElement rating=driver.findElement(By.xpath("*//div[contains(@class,'"+Rating+"')]"));
		if (rating.isDisplayed()) {
			Reporter.addStepLog("Rating " + Rating + " is displayed");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		} else {
			Reporter.addStepLog("Rating " + Rating + " is not displayed");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}

	}

	@And("^Move to Windows \"(.*?)\"$")
	public void Move_t0_Windows(String WindowName) {
		String your_title = WindowName;
		String currentWindow = driver.getWindowHandle();  
		for(String winHandle : driver.getWindowHandles()){
		   if (driver.switchTo().window(winHandle).getTitle().contains(your_title)) {
		        break;
		   } 
		   else {
		      driver.switchTo().window(currentWindow);
		   } 
		} 
		Reporter.addStepLog("Moved to "+WindowName+"Page/Tab");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
	}
	@And("^Select VALUE \"(.*?)\" from \"(.*?)\" DROPDOWN followed by \"(.*?)\" keyword$")
	public void select_Value_from_Dropdown_Duplicate(String Value, String ID, String Keyword) throws InterruptedException {
		WebElement dList=driver.findElement(By.xpath("(*//*[starts-with(normalize-space(),'"+Keyword+"')]//following::*[starts-with(normalize-space(),'"+ID+"')]//following::select)[1]"));
//		WebElement dList=driver.findElement(By.xpath("(*//*[text()='"+ID+"')]//following::select)[1]"));
		Select selectitem = new Select(dList);
		Thread.sleep(2000);
		dList.click();
		Thread.sleep(2000);
		selectitem.selectByVisibleText(Value);
		Reporter.addStepLog(Value  + " is selected in "+ ID+" Dropdown ");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
	}
		
	@And("^Enter in Textbox \"(.*?)\" value \"(.*?)\" followed by \"(.*?)\" Keyword$")
	public void enter_value_for_Duplicate_Editbox(String Value, String ID, String Keyword) throws InterruptedException {
		WebElement editElement=driver.findElement(By.xpath("(*//*[starts-with(normalize-space(),'"+Keyword+"')]//following::*[starts-with(normalize-space(),'"+ID+"')]//following::input[@type='text'])[1]"));
//		
		Thread.sleep(2000);
		editElement.sendKeys(Value);	
		
		Reporter.addStepLog(Value  + " is entered in "+ ID+" Editbox ");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		
	}
	
	@And("^Click LINK using Actual Name \"(.*?)\" followed by \"(.*?)\" keyword$")
		public void click_Link_For_Duplicate_Link(String Text, String keyword) throws InterruptedException {
		WebElement linkEle=driver.findElement(By.xpath("(*//*[starts-with(normalize-space(),'"+Text+"')]//following::a[normalize-space()='"+keyword+"'])[1]"));
		Thread.sleep(2000);
		linkEle.clear();	
		
		Reporter.addStepLog(Text  + " link is clicked");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		
	}
	
	@And("^Click \"(.*?)\" button followed by \"(.*?)\" keyword$") 
	public void click_Button_Duplicate(String Name, String KeyWord) {
		WebDriverWait wait = new WebDriverWait(driver, 5);	
		Actions actions = new Actions(driver);
		if(!driver.findElements(By.xpath("*//*[normalize-space()='"+KeyWord+"']//following::button[normalize-space()='"+Name+"' or @value='"+Name+"' and not(contains(@style,'display:none'))]")).isEmpty()) {
			WebElement btn=driver.findElement(By.xpath("(*//*[normalize-space()='"+KeyWord+"']//following::button[normalize-space()='"+Name+"' or @value='"+Name+"' and not(contains(@style,'display:none'))])[1]"));
//			actions.moveToElement(btn).perform();
			btn.click();
			Reporter.addStepLog(Name + " Button is Clicked");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		
		}
		else if(!driver.findElements(By.xpath("*//*[normalize-space()='"+KeyWord+"']//following::input[normalize-space()='"+Name+"' or @value='"+Name+"' and not(contains(@style,'display:none'))]")).isEmpty()) {
			WebElement btn=driver.findElement(By.xpath("(*//*[normalize-space()='"+KeyWord+"']//following::input[normalize-space()='"+Name+"' or @value='"+Name+"' and not(contains(@style,'display:none'))])[1]"));
//			actions.moveToElement(btn).perform();
			btn.click();
			Reporter.addStepLog(Name + " Button is Clicked");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}	
		
		else {
			Reporter.addStepLog(Name + " Button is Not Clicked");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			
		}		
			
		}
//	@And("^GetValue from \"(.*?)\" $")
//	public String DataTableData(String Field) {
//		Fillo fillo=new Fillo();
//		return Field;
//	}
	
	
	@And("^RightClick using xpath \"(.*?)\"$")    
    public void ClickButtonByID_Actual1(String ID) throws InterruptedException {
        Actions actions1 = new Actions(driver);
                
        WebDriverWait wait1 = new WebDriverWait(driver, 5);    
        WebElement btn1=driver.findElement(By.xpath(ID));

            actions1.contextClick(btn1).perform();
            Thread.sleep(2000);
            
            Reporter.addStepLog(ID + " Button is Clicked");
            currentScenario.embed(Util.takeScreenshot(driver), "image/png");
    }	
	
	@And("^Switch frame using frame id \"(.*?)\"$")
	public void Switch_frame(String frameid)
	{
		char[] chars =frameid.toCharArray();
		if(frameid.toLowerCase().contains("defaultcontent"))
		{
			driver.switchTo().defaultContent();
		}else {
		if(Character.isDigit(chars[0]))
		{
			driver.switchTo().frame(Integer.parseInt(frameid));
			Reporter.addStepLog("Switching to iframe using index"+frameid);
		}else
		{
		driver.switchTo().frame(frameid);
		Reporter.addStepLog("Switching to iframe"+frameid);
		}
		}
	}
		@And("^Switching default frame$")
		public void Switch_defaultframe()
		{
			driver.switchTo().defaultContent();
		}
	
	
	@And("^Accepting the Alert message popup$")
	public void Accept_alert()
	{
		Alert simpleAlert = driver.switchTo().alert();
		String alert=simpleAlert.getText();
		simpleAlert.accept();
		Reporter.addStepLog("Accepting the pop up"+alert);
	}

	@And("^Upload Document$")
	public void upload_doc()
	{try {
		driver.findElement(By.xpath("//input[@id='upload']")).sendKeys(Paths.get("").toAbsolutePath().toString()+"//UploadDocument//1.png");
		Thread.sleep(2000);
	}catch (Exception e) {
		System.out.println(e);
	}
	}
	
	@When("^Click \"(.*?)\" button$")	
	public void ClickButtonByID_Actual(String ID) throws InterruptedException {
		
		WebDriverWait wait = new WebDriverWait(driver, 5);	
		Actions actions = new Actions(driver);
		if(!driver.findElements(By.xpath("*//input[normalize-space()='"+ID+"' or @value='"+ID+"' and not(contains(@style,'display:none'))]")).isEmpty()) {
			WebElement btn=driver.findElement(By.xpath("(*//input[normalize-space()='"+ID+"' or @value='"+ID+"' and not(contains(@style,'display:none'))])[1]"));
//			actions.moveToElement(btn).perform();
			btn.click();
			Reporter.addStepLog(ID + " Button is Clicked");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}	
		else if(!driver.findElements(By.xpath("*//button[normalize-space()='"+ID+"' or @value='"+ID+"' and not(contains(@style,'display:none'))]")).isEmpty()) {
			WebElement btn=driver.findElement(By.xpath("(*//button[normalize-space()='"+ID+"' or @value='"+ID+"' and not(contains(@style,'display:none'))])[1]"));
//			actions.moveToElement(btn).perform();
			btn.click();
			Reporter.addStepLog(ID + " Button is Clicked");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		
		}
		else if(!driver.findElements(By.xpath("*//*[normalize-space()='"+ID+"' and not(contains(@style,'display:none'))]")).isEmpty()) {
			WebElement btn=driver.findElement(By.xpath("(*//*[normalize-space()='"+ID+"' or @value='"+ID+"' and not(contains(@style,'display:none'))])[1]"));
//			actions.moveToElement(btn).perform();
			btn.click();
			Reporter.addStepLog(ID + " Button is Clicked");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			
		}
		else {
			Reporter.addStepLog(ID + " Button is Not Clicked");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
			
		}
			
		
		
		
	}
}