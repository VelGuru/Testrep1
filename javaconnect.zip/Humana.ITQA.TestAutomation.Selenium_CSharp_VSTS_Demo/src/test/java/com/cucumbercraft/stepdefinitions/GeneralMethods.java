package com.cucumbercraft.stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.*;

import com.cucumbercraft.framework.DriverManager;

public class GeneralMethods {

	WebDriver driver = DriverManager.getWebDriver();
	Actions actions = new Actions(driver);

	public void dragAndDrop(WebElement Source, WebElement Destination) {
		actions.dragAndDrop(Source, Destination).build().perform();
	}

	public void clickAndHold(WebElement source) {
		actions.clickAndHold(source);
	}

	public void moveByOffset(int xaxis, int yaxis) {

		actions.moveByOffset(xaxis, yaxis).build().perform();

	}

	public void swithToFrmae(int frameIndex) {
		driver.switchTo().frame(frameIndex);
	}
	
	
}