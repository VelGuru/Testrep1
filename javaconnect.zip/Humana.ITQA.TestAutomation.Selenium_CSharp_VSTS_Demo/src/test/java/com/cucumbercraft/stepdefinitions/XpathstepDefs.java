package com.cucumbercraft.stepdefinitions;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.cucumbercraft.framework.DriverManager;
import com.cucumbercraft.framework.Util;
import com.cucumbercraft.framework.WebDriverUtil;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class XpathstepDefs extends MasterStepDefs {
	GeneralMethods gm = new GeneralMethods();

	// TestContext testContext;

	static Logger log = Logger.getLogger(GeneralStepDefs.class);

	WebDriver driver = DriverManager.getWebDriver();
	WebDriverUtil driverutil = new WebDriverUtil(driver);

	@Given("^Click LINK using XPath \"([^\"]*)\" and fieldname is \"([^\"]*)\"$")
	public void Click_Link_By_Xpath(String xpath, String fieldname) throws InterruptedException {
		Actions actions = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 5);
		WebElement ele = driver.findElement(By.xpath(xpath));
		// ele.sendKeys(Keys.SHIFT);
		// actions.moveToElement(ele).build().perform();

		Thread.sleep(2000);
		ele.click();

		Reporter.addStepLog(fieldname + " Link is Clicked");
		currentScenario.embed(Util.takeScreenshot(driver), "image/png");
	}

	@When("^Click on button using XPath \"(.*?)\" and button name is \"(.*?)\"$")	
	public void ClickButtonByXpath_Actual(String xpath,String buttonname) throws InterruptedException {
		
		WebDriverWait wait = new WebDriverWait(driver, 5);	
		Actions actions = new Actions(driver);
			WebElement btn=driver.findElement(By.xpath(xpath));
//			actions.moveToElement(btn).perform();
			btn.click();
			try {
				wait.until(ExpectedConditions.alertIsPresent());
			
				driver.switchTo().alert().accept();
				
			}catch (TimeoutException e) {
				
			}
			Reporter.addStepLog(buttonname + " Button is Clicked");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
				
	}

	@And("^Click VALUE (.*) in RADIO BUTTON (.*) using XPath (.*)$")
	public void radiobutton_Select_using_Xpath(String Value, String Name, String Xpath) {
		WebElement objRadio = driver.findElement(By.xpath(Xpath));
		Boolean checkstatus;
		checkstatus = objRadio.isSelected();
		if (checkstatus == true) {
			Reporter.addStepLog(Value + "is selcted in " + Name + " Radio Button");
		} else {
			objRadio.click();
			Reporter.addStepLog(Value + "is selcted in " + Name + " Radio Button");
		}
	}

	@And("^Enable/Select CHECKBOX using XPath \"(.*?)\" and fieldname is \"(.*?)\"$")
	public void click_CheckboxByxpath(String xpath,String displayName) throws InterruptedException {
		WebElement objchk=driver.findElement(By.xpath(xpath));
		
		if (objchk.isSelected()) {
			Reporter.addStepLog(displayName + " checkbox selected");
		} else {
			objchk.click();
			Reporter.addStepLog(displayName + " checkbox selected");
		}
		Thread.sleep(3000);
	}

	@Then("^Verify Value \"(.*?)\" is displayed in the table using the xpath \"(.*?)\"$")
	public void VerifyValueintheTable(String Value, String xpath) throws InterruptedException {
		int cout = driver.findElements(By.xpath(xpath)).size();
		if (cout >= 0) {
			if (!(driver.findElements(By.xpath(xpath)).isEmpty())) {

				WebElement elements = driver.findElement(By.xpath(xpath));
				if (elements.isDisplayed()) {

					Reporter.addStepLog(Value + " is displayed in the table");

					currentScenario.embed(Util.takeScreenshot(driver), "image/png");
				}
			} else {

				Reporter.addStepLog(Value + " is not displayed in the table");
				Assert.fail();
				currentScenario.embed(Util.takeScreenshot(driver), "image/png");

			}
		}
	}

	@Then("^Verify Table with column Name using xpath \"(.*?)\" is displayed$")
	public void VerifyWebtabledisplayed(String xpath) {
		int cout = driver.findElements(By.xpath(xpath)).size();
		if (cout >= 0) {
			List<WebElement> rows = driver.findElements(By.xpath(xpath));

			Reporter.addStepLog("Table displayed with " + rows.size() + " rows is displayed");
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		} else {
			Reporter.addStepLog("Table is not displayed");
			Assert.fail();
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}
	}
	
	@Then("^Verify displayed webelement using XPath\"(.*?)\"$")
	public void Search_Validation_Label(String xpath) {
		if (!driver.findElements(By.xpath(xpath)).isEmpty()) {
			WebElement ele = driver.findElement(By.xpath(xpath));
			Reporter.addStepLog(xpath + " is displayed");
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].style.border='2px solid red'", ele);
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		} 
		else {
			Reporter.addStepLog(xpath + " is not displayed");
			Assert.fail();
			currentScenario.embed(Util.takeScreenshot(driver), "image/png");
		}

	}
	
	@And("^Validate Claims Number \"(.*?)\"$")
    public void Claim_Validation(String ClaimNo) throws InterruptedException {
 
                    if(driver.findElement(By.id("ClaimsViewAllContainer")).isDisplayed())
                    {
                    	driver.findElement(By.xpath("//a[contains(text(),'See all claims')]")).click();
                    	driver.findElement(By.id("btnListView")).click();

                    	while(driver.findElement(By.xpath("//a[text()='See more claims']")).isDisplayed())
                    	{
                    		driver.findElement(By.xpath("//a[text()='See more claims']")).click();
                    	}
                    	
                    }
                    else
                    {
                    	
                    }
                    String currentWindow = driver.getWindowHandle();  
                    WebElement objClaim=driver.findElement(By.xpath("*//span[normalize-space()='"+ClaimNo+"']"));
                    String strProvider=driver.findElement(By.xpath("(*//span[normalize-space()='"+ ClaimNo+"']//following::span)[1]")).getText();
                    String strDOS=driver.findElement(By.xpath("(*//span[normalize-space()='"+ ClaimNo+"']//following::span)[2]")).getText();
                    String strStatus=driver.findElement(By.xpath("(*//span[normalize-space()='"+ ClaimNo+"']//following::span)[3]")).getText();
                    objClaim.click();
                    Thread.sleep(20000);
                    int intProvider=driver.findElements(By.xpath("//*[@id='claimDetailModal']//following::div[normalize-space()='"+strProvider+"']")).size();
                    if(intProvider>1) {
                                    WebElement ele=driver.findElement(By.xpath("(//*[@id='claimDetailModal']//following::div[normalize-space()='"+strProvider+"'])[1]"));
                                    JavascriptExecutor jse = (JavascriptExecutor) driver;
                                    jse.executeScript("arguments[0].style.border='2px solid red'", ele);
                                    Reporter.addStepLog("Provider: "+strProvider+" is  displayed as expected");
                                    currentScenario.embed(Util.takeScreenshot(driver), "image/png");
                    }
                    else {
                                    Reporter.addStepLog("Provider: "+strProvider+" is not displayed");
                                    Assert.fail();
                                    currentScenario.embed(Util.takeScreenshot(driver), "image/png");
                    }
                                    
                    int intDOS=driver.findElements(By.xpath("//*[@id='claimDetailModal']//following::*[normalize-space()='"+strDOS+"']")).size();
                    if(intDOS>0) {
                                    WebElement ele=driver.findElement(By.xpath("(//*[@id='claimDetailModal']//following::*[normalize-space()='"+strDOS+"'])[1]"));
                                    JavascriptExecutor jse = (JavascriptExecutor) driver;
                                    jse.executeScript("arguments[0].style.border='2px solid red'", ele);
                                    Reporter.addStepLog("Date of service: "+strDOS+" is  displayed as expected");
                                    currentScenario.embed(Util.takeScreenshot(driver), "image/png");
                    }
                    else {
                                    Reporter.addStepLog("Date of service: "+strDOS+" is not displayed");
                                    Assert.fail();
                                    currentScenario.embed(Util.takeScreenshot(driver), "image/png");
                    }
                                    
                    int intStatus=driver.findElements(By.xpath("//*[@id='claimDetailModal']//following::span[normalize-space()='"+strStatus+"' and @class='claim-status-desc']")).size();
                    if(intStatus>0) {
                                    WebElement ele=driver.findElement(By.xpath("(//*[@id='claimDetailModal']//following::span[normalize-space()='"+strStatus+"' and @class='claim-status-desc'])[1]"));
                                    JavascriptExecutor jse = (JavascriptExecutor) driver;
                                    jse.executeScript("arguments[0].style.border='2px solid red'", ele);
                                    Reporter.addStepLog("Staus: "+strStatus+" is  displayed as expected");
                                    currentScenario.embed(Util.takeScreenshot(driver), "image/png");
                    }
                    else {
                                    Reporter.addStepLog("Status: "+strStatus+" is not displayed");
                                    Assert.fail();
                                    currentScenario.embed(Util.takeScreenshot(driver), "image/png");
                    }
                    Thread.sleep(4000);
    
                    driver.findElement(By.xpath("//*[@id='claimDetailModal']//a[@aria-label='Close']")).click();
    }
	
	@And("^Selecting \"(.*?)\" in the beneficiary dropdown$")
	public void select_dropdown(String  beneficiarymember)
	{
		driver.findElement(By.id("SelectedMemberIcon")).click();
		String xpath="//ul[@id='SelectFrom']//li//following::div[contains(text(),'"+beneficiarymember+"')]";
		String classname=driver.findElement(By.xpath(xpath+"//ancestor-or-self::li")).getAttribute("class");
		System.out.println(classname);
		if(classname.contains("family-list-locked"))
		{
			Reporter.addStepLog(beneficiarymember + " You do not have access to view this information");
			Assert.fail("Requested beneficiary is disabled");
		}
		else
		{
			driver.findElement(By.xpath(xpath)).click();
			Reporter.addStepLog(beneficiarymember + " is Selected");
		}
		
	}
	


}
