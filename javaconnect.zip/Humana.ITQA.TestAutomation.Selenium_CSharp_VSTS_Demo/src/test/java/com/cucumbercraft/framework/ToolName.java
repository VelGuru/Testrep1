package com.cucumbercraft.framework;

public enum ToolName {

	/**
	 * Use Appium for execution
	 */
	APPIUM, DEFAULT, REMOTEDRIVER;

}
