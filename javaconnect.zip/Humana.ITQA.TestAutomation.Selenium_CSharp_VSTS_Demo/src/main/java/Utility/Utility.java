package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.codehaus.plexus.util.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utility {

	public WebDriver driver;
	public Properties prop;
	public FileInputStream fis;

	//Method for wait to element visible 
	public void waitForElementVisible(WebElement we, int value) {
		WebDriverWait wait = new WebDriverWait(driver, value);

		wait.until(ExpectedConditions.visibilityOf(we));

	}
  
	//Set up browser for chrome
	public void setUpBrowser(WebDriver driver) throws Exception {
		fis = new FileInputStream("config.properties");
		prop = new Properties();
		prop.load(fis);
		System.setProperty("webdriver.chrome.driver", prop.getProperty("Path_driver"));

	}

	/*
	 * Method to configure the xml for Extent report
	 * 
	 * 
	 */
	public String getReportConfigPath() throws Exception {
		fis = new FileInputStream("extent-config.xml");
		prop = new Properties();
		String reportConfigPath = prop.getProperty("reportConfigPath");
		if (reportConfigPath != null)
			return reportConfigPath;
		else
			throw new RuntimeException(
					"Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
	}

	}



