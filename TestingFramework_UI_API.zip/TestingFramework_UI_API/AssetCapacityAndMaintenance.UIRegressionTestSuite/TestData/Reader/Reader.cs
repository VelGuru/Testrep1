﻿using System.Collections.Concurrent;
using System.Threading.Tasks;
using GenevaUICommonUtils.Controller;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.TestData.Reader
{
    public class Reader : IReader
    {
        private static ConcurrentDictionary<string, dynamic> _configurationData = new ConcurrentDictionary<string, dynamic>();
        private readonly ReaderController readerController = new ReaderController();
        public static string Country => _configurationData["Country"];

        public static string City => _configurationData["City"];

        public static string Owners => _configurationData["Owners"];

        public static string AssetType => _configurationData["AssetType"];

        public static string Assets => _configurationData["Assets"];

        public static string UnitType => _configurationData["UnitType"];

        public static string UnitSubType => _configurationData["UnitSubType"];

        public static string Unit => _configurationData["Unit"];        

        public async Task<dynamic> LoadConfigurationJson(string scenarioName, string jsonFilePath)
        {
            _configurationData.Clear();
            _configurationData = await readerController.ReadJasonData(scenarioName, jsonFilePath);
            return _configurationData;
        }
    }
}
