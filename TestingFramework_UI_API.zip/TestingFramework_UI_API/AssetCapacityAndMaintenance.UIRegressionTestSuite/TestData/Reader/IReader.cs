﻿using System.Threading.Tasks;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.TestData.Reader
{
    public interface IReader
    {
        static string Country { get; }
        static string City { get; }
        static string Owners { get; }
        static string AssetType { get; }
        static string Assets { get; }
        static string UnitType { get; }
        static string UnitSubType { get; }
        static string Unit { get; }
        Task<dynamic> LoadConfigurationJson(string scenarioName, string jsonFilePath = null);
    }
}
