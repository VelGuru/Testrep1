﻿using System.IO;
using System.Collections.Generic;
using System.Reflection;
using System;
using System.Text.RegularExpressions;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Config
{
    public class Paths
    {
        public static string BaseFolder => GetApplicationPath();        
        public static string TotalCapacityScreen => $@"{BaseFolder}\TestData\TotalCapacityScreen.json";
        public static string ExtentReport => $@"{BaseFolder}\Reports\";
        private static string GetApplicationPath()
        {
            return AppDomain.CurrentDomain.BaseDirectory?.Substring(0, AppDomain.CurrentDomain.BaseDirectory.Substring(
                    0,
                    AppDomain.CurrentDomain.BaseDirectory.Substring(0,
                            AppDomain.CurrentDomain.BaseDirectory
                                .Substring(0, AppDomain.CurrentDomain.BaseDirectory.LastIndexOf('\\'))
                                .LastIndexOf('\\'))
                        .LastIndexOf('\\'))
                .LastIndexOf('\\'));
        }
    }
}
