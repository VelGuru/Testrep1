﻿using System;
using Microsoft.Graph;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using ExpectedConditions = OpenQA.Selenium.Support.UI.ExpectedConditions;
using OpenQA.Selenium.Interactions;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using NUnit.Framework;
using TechTalk.SpecFlow.CommonModels;
using GenevaUICommonUtils.Selenium;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.PageObject.Pages
{
    public class AssetCapacityPage
    {
        public static IWebDriver WebDriver = Driver.getDriver;
        public WebDriverWait WebDriverWait;
        IJavaScriptExecutor executor = (IJavaScriptExecutor)WebDriver;


        By ClickonProgramMenu = By.XPath("//li[@class='sidebar-menu-item item-1']//child::button[@id='dropdown']");
        By ClickonCapacityTotal = By.XPath("//*[contains(text(),'Capacity - Total')]");
        By GetAssetCapacityTitle = By.XPath("//*/div/main/div/div[2]/div[1]/div/div[1]/h3");
        By ReadAssetCapacity = By.XPath("//*[contains(text(),'Asset Capacity')]");
        By ClickonFilterButton = By.XPath("//*[@class='k-icon k-i-filter k-icon']");
        By SearchCountry = By.XPath("//*[@Id='country-search-box']");
        By SearchCity = By.XPath("//*[@Id='city-search-box']");
        By SearchCompany = By.XPath("//*[@id='company-search-box']");
        By SearchAssetType = By.XPath("//*[@Id='assetClass-search-box']");
        By SearchAsset = By.XPath("//*[@Id='asset-search-box']");
        By SearchUnityType = By.XPath("//*[@Id='unitType-search-box']");
        By SearchSubUnit = By.XPath("//*[@Id='unitSubType-search-box']");
        By SearchUnit = By.XPath("//*[@Id='unit-search-box']");
        By ApplyButtonClick = By.XPath("//*[@class='reset-clear apply']");
        //By ClickOnUnit = By.XPath("//*preceding-sibling::input[@class='k-button-group bg-solid mx-3 pull-right']");


        public AssetCapacityPage(int waitInMilliSecond = 50)
        {
            WebDriverWait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(waitInMilliSecond));
        }
        //public IWebElement Unit => WebDriver.FindElement(By.XPath("//*[@class='k-button k-primary btn border k-group-end']"));

        public void ClickProgramMenu()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            var ProgramMenu = WebDriver.FindElement(ClickonProgramMenu);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(ProgramMenu));
            ProgramMenu.Click();
        }

        public void ClickCapacityTotal()
        {
            var CapacityTotal = WebDriver.FindElement(ClickonCapacityTotal);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(CapacityTotal));
            CapacityTotal.Click();
        }

        public string GetAssetCapacityText()
        {
            string AssetCapacity = WebDriver.FindElement(GetAssetCapacityTitle).Text;
            WebDriverWait.Until(ExpectedConditions.ElementIsVisible(ReadAssetCapacity));
            return AssetCapacity;
        }

        public void ClickFilter()
        {
            var Filter = WebDriver.FindElement(ClickonFilterButton);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Filter));
            Filter.Click();
        }

        public void ClickSearchCountry()
        {
            //Actions ClickEnter = new Actions(WebDriver);
            var Search_Country = WebDriver.FindElement(SearchCountry);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Country));
            Search_Country.Click();

        }

        public void SelectCountryFromList(string country)
        {
            var Search_Country = WebDriver.FindElement(SearchCountry);
            Search_Country.SendKeys(country);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findcheckbox = WebDriver.FindElement(By.XPath("//*[text()='" + country + "']/preceding-sibling::input[@name='Countries']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findcheckbox);
        }

        public void ClickSearchCity()
        {
            var Search_City = WebDriver.FindElement(SearchCity);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_City));
            Search_City.Click();
        }

        public void SelectCityFromList(string city)
        {
            var Search_City = WebDriver.FindElement(SearchCity);
            Search_City.SendKeys(city);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findcheckbox = WebDriver.FindElement(By.XPath("//*[text()='" + city + "']/preceding-sibling::input[@name='Cities']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findcheckbox);
        }
        public void ClickSearchCompany()
        {
            var Search_Company = WebDriver.FindElement(SearchCompany);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Company));
            Search_Company.Click();
        }

        public void SelectCompanyFromList(string company)
        {
            var Search_Company = WebDriver.FindElement(SearchCompany);
            Search_Company.SendKeys(company);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findcheckbox = WebDriver.FindElement(By.XPath("//*[text()='" + company + "']/preceding-sibling::input[@name='Companies']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findcheckbox);
            Search_Company.Clear();
        }
        public void ClickSearchAssetType()
        {
            var Search_AssetType = WebDriver.FindElement(SearchAssetType);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_AssetType));
            Search_AssetType.Click();
        }

        public void SelectAssetTypeFromList(string assetType)
        {
            var Search_AssetType = WebDriver.FindElement(SearchAssetType);
            Search_AssetType.SendKeys(assetType);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findcheckbox = WebDriver.FindElement(By.XPath("//*[text()='" + assetType + "']/preceding-sibling::input[@name='AssetClasses']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findcheckbox);
        }
        public void ClickSearchAsset()
        {

            var Search_Assets = WebDriver.FindElement(SearchAsset);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Assets));
            Search_Assets.Click();
        }

        public void SelectAssetFromList(string asset)
        {
            var Search_Assets = WebDriver.FindElement(SearchAsset);
            Search_Assets.SendKeys(asset);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findcheckbox = WebDriver.FindElement(By.XPath("//*[text()='" + asset + "']/preceding-sibling::input[@name='Assets/AssetFilter']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findcheckbox);
            Search_Assets.Clear();
        }
        public void ClickSearchUnitType()
        {
            var Search_UnitType = WebDriver.FindElement(By.XPath("//*[@Id='unitType-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_UnitType));
            Search_UnitType.Click();
        }

        public void SelectUnitTypeFromList(string unitType)
        {
            try
            {
                var Search_UnitType = WebDriver.FindElement(SearchUnityType);
                Search_UnitType.SendKeys(unitType);
                WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
                var count = WebDriver.FindElements(By.XPath("//*[text()='" + unitType + "']/preceding-sibling::input[@name='AssetUnitTypes']")).Count;
                if (count > 0)
                {
                    var findcheckbox = WebDriver.FindElement(By.XPath("//*[text()='" + unitType + "']/preceding-sibling::input[@name='AssetUnitTypes']"));
                    executor = (IJavaScriptExecutor)WebDriver;
                    var returnType = executor.ExecuteScript("arguments[0].click();", findcheckbox);
                }
                else
                {
                    Console.WriteLine(unitType + "Not Visible");

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }
        public void ClickSearchUnitSubType()
        {
            var Search_UnitSubType = WebDriver.FindElement(SearchUnityType);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_UnitSubType));
            Search_UnitSubType.Click();
        }

        public void SelectSubUnitFromList(string subUnit)
        {
            var Search_UnitSubType = WebDriver.FindElement(SearchSubUnit);
            Search_UnitSubType.SendKeys(subUnit);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findcheckbox = WebDriver.FindElement(By.XPath("//*[text()='" + subUnit + "']/preceding-sibling::input[@name='AssetUnitSubtypes']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findcheckbox);
        }

        public void ClickSearchUnit()
        {
            var Search_Unit = WebDriver.FindElement(SearchSubUnit);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Unit));
            Search_Unit.Click();
        }

        public void SelectUnitFromList(string unit)
        {
                var Search_Unit = WebDriver.FindElement(SearchUnit);
                Search_Unit.SendKeys(unit);
                WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
                var findcheckbox = WebDriver.FindElement(By.XPath("//*[text()='" + unit + "']/preceding-sibling::input[@name='AssetUnits/AssetUnitFilter']"));
                executor = (IJavaScriptExecutor)WebDriver;
                executor.ExecuteScript("arguments[0].click();", findcheckbox);
                Search_Unit.Clear();
        }
        public void ClickApplyButton()
        {
            var Apply_Button = WebDriver.FindElement(ApplyButtonClick);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Apply_Button));
            Apply_Button.Click();
        }

        public ArrayList GetListFromGrid()
        {
            //IWebElement Element = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[3]/div/div[1]/div/div"));
            WebDriverWait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//*[@id='capacityscreen']/div[3]/div/div[1]/div/div")));
            ArrayList getList = new ArrayList();
            var getgridcount = WebDriver.FindElements(By.XPath("//*[@id='capacityscreen']/div[3]/div/div[1]/div/div")).Count;
            if (getgridcount > 0)
            {
                for (int i = 0; i < getgridcount; i++)
                {
                    /*String list = WebDriver.FindElement(By.XPath("//p/strong["+(i+1)+"]")).Text;
                    getList.Add(list);*/
                    IList list = WebDriver.FindElements(By.XPath("//p/strong"));
                    foreach (IWebElement element in list)
                    {
                        var GetText = element.Text;
                        getList.Add(GetText);
                        //Console.WriteLine(GetText);
                    }
                    break;
                }
            }

            return getList;
        }
        public void ClickButtonBaseline()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var Unit = WebDriver.FindElement(By.XPath("(//*[@unit-id=3])[1]"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", Unit);

            var BaseLine_Button = WebDriver.FindElement(By.XPath("//*[@class='td-data ']/button"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(BaseLine_Button));
            BaseLine_Button.Click();
            Thread.Sleep(1000);
        }

        public void ClickonNewEvent()
        {
            Thread.Sleep(1000);
            var ClickonEvent = WebDriver.FindElement(By.XPath("//*[@class='k-button-group bg-solid']/button[contains(text(),'New Event')]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(ClickonEvent));
            ClickonEvent.Click();
        }
        
        public void RecordAddedSuccess(int countBeforeEvent, int countAfterEvent, String toastMessage)
        {

            if(countAfterEvent > countBeforeEvent)
            {
                //var getMessage = WebDriver.FindElement(By.XPath("//*[@class='Toastify__toast-body']")).Text;
                Assert.AreEqual(toastMessage,"New record added successfully.");
            }
            else
            {
                Assert.Fail("New record not added successfully");
            }
        }

        public void RecordAddedNotSuccess(int countAfterEvent, int countBeforeEvent , string toastMessage)
        {
            if (countAfterEvent == countBeforeEvent)
            {
                //var getMessage = WebDriver.FindElement(By.XPath("//*[@class='Toastify__toast-body']")).Text;
                Assert.AreEqual(toastMessage, "Multiple capacity events that start on the same day found.");
            }
            else
            {
                Assert.Fail("Multiple capacity events that start on the same day popup not found");
            }
        }

        public string IsDisplayed()
        {
           WebDriverWait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//*[@class='Toastify__toast-body']")));
            var getMessage = WebDriver.FindElement(By.XPath("//*[@class='Toastify__toast-body']")).Text;
            return getMessage;
        }

        public void GridVerification(int countBeforeEvent,int countAfterEvent, bool recordAdded)
        {
            string toastMessage = IsDisplayed();
            if (!toastMessage.Equals(""))
            {
                if (recordAdded)
                {
                    RecordAddedSuccess(countBeforeEvent, countAfterEvent, toastMessage);
                }
                else
                {
                    RecordAddedNotSuccess(countBeforeEvent, countAfterEvent, toastMessage);
                }
            }
            else
            {
                Assert.Fail("Error Message not Displayed ");
            }
        }


        public void ClickShowXBuckets()
        {
            //* Select X Buckets *//
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var selectXbuckets = WebDriver.FindElement(By.Id("toggle-capacity"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", selectXbuckets);

        }

        public void UnitMultiSelect()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var unitSelect = WebDriver.FindElement(By.XPath("//*[@class='capacity-event']//child::div[@Id='multiSelect']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(unitSelect));
            unitSelect.Click();
        }

        public void SelectUnitFromDropDownList(string unitName)
        {
            var selectUnit = WebDriver.FindElement(By.XPath("//*[@class='k-list-scroller']//li//*[contains(text(),'" + unitName + "')]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectUnit));
            selectUnit.Click();
        }

        public void HideDropDown()
        {
            var hideDropdown = WebDriver.FindElement(By.XPath("//*[@class='k-window-title']"));
            hideDropdown.Click();
            Thread.Sleep(1000);
        }

        public void SelectBasisDropDown()
        {
            var basisTypeDropdown = WebDriver.FindElement(By.XPath("//div[text()='Basis Type']/following-sibling::span//span[@class='k-input']/following-sibling::select"));
            var basisTypeSelect = WebDriver.FindElement(By.XPath("//div[text()='Basis Type']/following-sibling::span//span[@class='k-input']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(basisTypeSelect));
            basisTypeSelect.Click();
        }

        public void selectBasisType(string basisType)
        {
            var selectBasisType = WebDriver.FindElement(By.XPath("//ul[@role='listbox']//li/span[text()='" + basisType + "']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectBasisType));
            selectBasisType.Click();
        }

        public void SelectIntelligence()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var sourcedropDown = WebDriver.FindElement(By.XPath("//div[text()='Source of Intelligence']/following-sibling::span//span[@class='k-input']/following-sibling::select"));
            var sourceSelect = WebDriver.FindElement(By.XPath("//div[text()='Source of Intelligence']/following-sibling::span//span[@class='k-input']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(sourceSelect));
            sourceSelect.Click();
        }

        public void SelectIntelligenceFromDropDown(string intelligenceValue)
        {
            var selectSource = WebDriver.FindElement(By.XPath("//ul[@role='listbox']//li/span[text()='" + intelligenceValue + "']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectSource));
            selectSource.Click();
        }

        public void SelectProbabilityType()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var probabilitydropDown = WebDriver.FindElement(By.XPath("//div[text()='Probability Type']/following-sibling::span//span[@class='k-input']/following-sibling::select"));
            var probabilitySelect = WebDriver.FindElement(By.XPath("//div[text()='Probability Type']/following-sibling::span//span[@class='k-input']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(probabilitySelect));
            probabilitySelect.Click();
        }

        public void SelectProbabilityTypeFromDropDownList(string probabilityTypeValue)
        {
            var selectProbabilitytype = WebDriver.FindElement(By.XPath("//ul[@role='listbox']//li/span[text()='" + probabilityTypeValue + "']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectProbabilitytype));
            selectProbabilitytype.Click();

        }

        public void SelectStatus()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var statusdropDown = WebDriver.FindElement(By.XPath("//div[text()='Status Type']/following-sibling::span//span[@class='k-input']/following-sibling::select"));
            var statusSelect = WebDriver.FindElement(By.XPath("//div[text()='Status Type']/following-sibling::span//span[@class='k-input']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(statusSelect));
            statusSelect.Click();
        }

        public void SelectStatusFromDropDownList(string selectStatus)
        {
            var selectStatustype = WebDriver.FindElement(By.XPath("//ul[@role='listbox']//li/span[text()='" + selectStatus + "']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectStatustype));
            selectStatustype.Click();
            Thread.Sleep(1000);

        }

        public void selectIncrementalCapacity(string incrementalcapacity)
        {
            var selectCapacity = WebDriver.FindElement(By.XPath("//div[@class='input-group']/input"));
            selectCapacity.Clear();
            selectCapacity.SendKeys(incrementalcapacity);
            Thread.Sleep(1000);

        }

        public void SelectDate(string date)
        {

            var dateSelect = WebDriver.FindElement(By.XPath("//div[text()='Event Start Date']//following-sibling::span//child::span[@class='k-select']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(dateSelect));
            dateSelect.Click();
            SelectDMY(date);
        }

        public int GetGridCount()
        {
            //return WebDriver.FindElements(By.XPath("//div[@id='event-listing']//child::tbody/tr")).Count;
            //return WebDriver.FindElements(By.XPath("//div[@id='event-listing']//following-sibling::tbody/tr")).Count;
            return WebDriver.FindElements(By.XPath("//*[@id='event-listing']//div//table//tbody//tr")).Count;
        }

        public void ClickSaveEvent()
        {
            var saveEvent = WebDriver.FindElement(By.XPath("//*[@class='col-sm-auto']/child::button[contains(text(),'Save Capacity Event')]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(saveEvent));
            saveEvent.Click();

        }

       public Dictionary<string, ArrayList> verifyGridData()
        {
            Dictionary<string, ArrayList> Dic = new Dictionary<string, ArrayList>();

            int gridCount = WebDriver.FindElements(By.XPath("//div[@id='event-listing']//child::tbody/tr")).Count;
            if (gridCount > 0)
            {
                for (int i = 0; i < gridCount; i++)
                {
                    if (i != 0)
                    {
                        string startDate = WebDriver.FindElement(By.XPath("//div[@id='event-listing']//child::tbody/tr[" + i + "]/td[2]")).Text;
                        string incrementalCapacity = WebDriver.FindElement(By.XPath("//div[@id='event-listing']//child::tbody/tr[" + i + "]/td[7]")).Text;
                        string measurementValue = WebDriver.FindElement(By.XPath("//*[@id='basic-addon2']")).Text;
                        ArrayList list = new ArrayList();
                        list.Add(incrementalCapacity);
                        list.Add(measurementValue);
                        Dic.Add(startDate, list);
                    }
                    else
                    {
                        break;
                    }
                    
                }
            }
            return Dic;
        }

        public void ValidateGridData(string date, string incrementalcapacity)
        {
            ArrayList List = new ArrayList();
            Dictionary<string, ArrayList> Dict = verifyGridData();
            foreach (KeyValuePair<string, ArrayList> kvp in Dict) 
            {
                string capacity = "";
                string getDate = kvp.Key;
                List = kvp.Value;
                string[] getIncrementalcapacity = List[0].ToString().Split(".");
                if (Convert.ToInt32(getIncrementalcapacity[1]) > 1)
                {
                    capacity = getIncrementalcapacity[1];
                }
                else
                {
                    capacity = getIncrementalcapacity[0];
                }
                Assert.That(getDate.Equals(date.Replace(","," ")));
                Assert.That(incrementalcapacity.Equals(capacity));
            }
        }

        public void CreateNewEvent(string unitName, string basisType, string intelligenceValue, string probabilityTypeValue, string selectStatus, string incrementalcapacity, string date, bool eventRecorded = true)
        {
            if (basisType == "Closure")
            {
                ClickonNewEvent();
                UnitMultiSelect();
                int countBeforeEvent = GetGridCount();
                SelectUnitFromDropDownList(unitName);
                HideDropDown();
                SelectBasisDropDown();
                selectBasisType(basisType);
                SelectIntelligence();
                SelectIntelligenceFromDropDown(intelligenceValue);
                SelectProbabilityType();
                SelectProbabilityTypeFromDropDownList(probabilityTypeValue);
                SelectStatus();
                SelectStatusFromDropDownList(selectStatus);
                SelectDate(date);
                ClickSaveEvent();
                Thread.Sleep(2000);
                int countAfterEvent = GetGridCount();
                Console.WriteLine(countAfterEvent + " :" + countBeforeEvent);
                GridVerification(countBeforeEvent, countAfterEvent, eventRecorded);
                ValidateGridData(date, incrementalcapacity);
            }
            else
            {
                ClickonNewEvent();
                UnitMultiSelect();
                int countBeforeEvent = GetGridCount();
                SelectUnitFromDropDownList(unitName);
                HideDropDown();
                SelectBasisDropDown();
                selectBasisType(basisType);
                SelectIntelligence();
                SelectIntelligenceFromDropDown(intelligenceValue);
                SelectProbabilityType();
                SelectProbabilityTypeFromDropDownList(probabilityTypeValue);
                SelectStatus();
                SelectStatusFromDropDownList(selectStatus);
                selectIncrementalCapacity(incrementalcapacity);
                SelectDate(date);
                ClickSaveEvent();
                Thread.Sleep(2000);
                int countAfterEvent = GetGridCount();
                Console.WriteLine(countAfterEvent + " :" + countBeforeEvent);
                GridVerification(countBeforeEvent, countAfterEvent, eventRecorded);
                Thread.Sleep(15000);
            }

        }

        public Tuple<string, IWebElement> SelectHeader() 
        {
            var readCalenderHeader = WebDriver.FindElement(By.XPath("//div[@ class='k-calendar-header']/span"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(readCalenderHeader));
            var data = readCalenderHeader.Text;
            return new Tuple<string, IWebElement>(data, readCalenderHeader);
        }

        public Tuple<string, IWebElement> SelectCalenderMonth(string date)
        {
            var readCalenderHeader = WebDriver.FindElement(By.XPath("//div[@class='k-content k-scrollable']//child::tbody[1]//tr//td//span[contains(text(),'"+date+"')]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(readCalenderHeader));
            var data = readCalenderHeader.Text;
            return new Tuple<string, IWebElement>(data, readCalenderHeader);
        }
        public int SelectCalenderMonthCount(string date)
        {
            var readCalenderHeader = WebDriver.FindElements(By.XPath("//div[@class='k-content k-scrollable']//child::tbody[1]//tr//td//span[contains(text(),'" + date + "')]"));
            return readCalenderHeader.Count;
        }
  

        public void SelectDMY(string date)
        {
            selectYear(date);
            selectMonth(date);
        }

        public void selectMonth(string date)
        {
            String[] dateArray = date.Split(",");
            var selectMonth = SelectCalenderMonth(dateArray[1]);
            if (selectMonth.Item1.Contains(dateArray[1]))
            {
                selectMonth.Item2.Click();
                selectMonth = SelectCalenderMonth(dateArray[0]);
                if (selectMonth.Item1.Contains(dateArray[0]))
                {
                    selectMonth.Item2.Click();
                }
            }
        }

        public void selectYear(string date)
        {
            String[] dateArray = date.Split(",");
            var selectHeader = SelectHeader();
            selectHeader.Item2.Click();
            var selectYear = SelectHeader();
            if (!selectYear.Item1.Equals(dateArray[2]))
            {
                int Ele = WebDriver.FindElements(By.XPath("//div[@class='k-content k-scrollable']/ul/li")).Count;
                if (Convert.ToInt32(selectYear.Item1) > Convert.ToInt32(dateArray[2]))
                {
                    for (int i = Convert.ToInt32(selectYear.Item1); i >= Convert.ToInt32(dateArray[2]); i--)
                    {
                        WebDriver.FindElement(By.XPath("//div[@class='k-content k-scrollable']//ul//li//span[contains(text(),'"+ (i+1) +"')]")).Click();
                        string year = WebDriver.FindElement(By.XPath("//div[@class='k-content k-scrollable']//ul//li//span[contains(text(),'" + (i+1) + "')]")).Text;
                        if (year.Equals(dateArray[2]))
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    for (int i = Convert.ToInt32(selectYear.Item1); i <= Convert.ToInt32(dateArray[2]); i++)
                    {
                        WebDriver.FindElement(By.XPath("//div[@class='k-content k-scrollable']//ul//li//span[contains(text(),'" + (i+1) + "')]")).Click();
                        string year = WebDriver.FindElement(By.XPath("//div[@class='k-content k-scrollable']//ul//li//span[contains(text(),'" + (i+1) + "')]")).Text;
                        if (year.Equals(dateArray[2]))
                        {
                            break;
                        }
                    }
                }  
            }
        }
    }
}

