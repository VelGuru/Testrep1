﻿using System;
using GenevaUICommonUtils.Selenium;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using ExpectedConditions = OpenQA.Selenium.Support.UI.ExpectedConditions;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.PageObejct.Pages
{
    public class LoginPage
    {
        public static IWebDriver WebDriver = Driver.getDriver;
        public WebDriverWait WebDriverWait;
        public LoginPage(int waitInMilliSecond=90)
        {
             WebDriverWait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(waitInMilliSecond));
        }

        public IWebElement Login => WebDriver.FindElement(By.Id("signin_button"));
        public IWebElement UserName => WebDriver.FindElement(By.Id("user_login"));
        public IWebElement Password => WebDriver.FindElement(By.Id("user_password"));
        public IWebElement Login_Button => WebDriver.FindElement(By.Name("submit"));
        public IWebElement Account_Summary_Tab => WebDriver.FindElement(By.Id("account_summary_tab"));

        public void ClickLogin()
        {
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Login));
            Login.Click();
        } 

        public void EnterUserCredential(string userName, string password)
        {
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(UserName));
            UserName.Clear();
            UserName.SendKeys(userName);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Password));
            Password.Clear();
            Password.SendKeys(password);
        }

        public void ClickLoginButton()
        {
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Login_Button));
            Login_Button.Click();
        }
       
        public bool VerifyLoginSuccessful()
        {
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Account_Summary_Tab));
            return Account_Summary_Tab.Displayed;
        }

        public bool VerifyLogin(string userName, string password)
        {
            ClickLogin();
            EnterUserCredential(userName,password);
            ClickLoginButton();
            return VerifyLoginSuccessful();

        }
    }
}
