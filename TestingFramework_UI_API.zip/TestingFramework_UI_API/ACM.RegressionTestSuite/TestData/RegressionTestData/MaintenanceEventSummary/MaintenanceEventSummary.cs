﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RegressionTestSuite.RegressionTestData.MaintenanceEventSummary
{
    public class MaintenanceEventDataList
    {
        public int assetUnitEventKey { get; set; }
        public DateTime updateDate { get; set; }
        public int countryKey { get; set; }
        public string countryNm { get; set; }
        public int cityKey { get; set; }
        public string cityNm { get; set; }
        public int? ownerKey { get; set; }
        public string ownerNm { get; set; }
        public int assetClassKey { get; set; }
        public string assetClassDesc { get; set; }
        public int assetKey { get; set; }
        public string asset { get; set; }
        public int unitTypeKey { get; set; }
        public string unitType { get; set; }
        public int unitSubTypeKey { get; set; }
        public string unitSubType { get; set; }
        public int unitKey { get; set; }
        public string unit { get; set; }
        public double offlinePCT { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public int eventTypeKey { get; set; }
        public string eventType { get; set; }
        public int? eventCauseTypeKey { get; set; }
        public string eventCauseType { get; set; }
        public int dataProviderKey { get; set; }
        public string dataProviderName { get; set; }
        public string totalCapacity { get; set; }
        public string measureUnitCd { get; set; }
        public int measureUnitKey { get; set; }
        public int totalRows { get; set; }
    }

    public class MaintenenaceEventSummary
    {
        public int? pageNumber { get; set; }
        public int? pageSize { get; set; }
        public int? totalRows { get; set; }
        public List<MaintenanceEventDataList> maintenanceEventDataList { get; set; }
    }


}
