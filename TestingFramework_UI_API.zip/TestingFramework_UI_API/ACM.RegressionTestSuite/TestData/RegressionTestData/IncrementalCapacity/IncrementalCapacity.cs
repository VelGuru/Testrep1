﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RegressionTestSuite.RegressionTestData.IncrementalCapacity
{
     public class IncrementalCapacityDataList
    {
        public string updateDate { get; set; }
        public int dataProviderId { get; set; }
        public string dataProviderName { get; set; }
        public int versionTypeKey { get; set; }
        public string versionTypeKeyName { get; set; }
        public string capacityQty { get; set; }
        public int capacityUomId { get; set; }
        public string capacityUom { get; set; }
        public int assetUnitCapacityVerKey { get; set; }
        public int assetUnitCapacityKey { get; set; }
        public bool isLastUpdatedSince { get; set; }

    }

    public class IncrementalCapacitySubgroup
    {
        public int probTypeId { get; set; }
        public string probTypeName { get; set; }
        public string capacityStartDate { get; set; }
        public List<IncrementalCapacityDataList> incrementalCapacityDataList { get; set; }

    }

    public class IncrementalCapacityGroup
    {
        public int filterByTypeId { get; set; }
        public string filterByTypeValue { get; set; }
        public int unitSubtypeId { get; set; }
        public string unitSubtypeName { get; set; }
        public int unitTypeId { get; set; }
        public string unitTypeName { get; set; }
        public List<IncrementalCapacitySubgroup> incrementalCapacitySubgroups { get; set; }

    }

    public class IncrementalCapacityArray
    {
        public int countryId { get; set; }
        public string countryName { get; set; }
        public int cityId { get; set; }
        public string cityName { get; set; }
        public int ownerId { get; set; }
        public string ownerName { get; set; }
        public int assetTypeId { get; set; }
        public string assetTypeName { get; set; }
        public int assetId { get; set; }
        public string assetName { get; set; }
        public string filterByDMQ { get; set; }
        public string filterByType { get; set; }
        public object lastUpdateDateSince { get; set; }
        public List<IncrementalCapacityGroup> incrementalCapacityGroups { get; set; }

    }

    public class IncrementalCapacity
    {
        public List<IncrementalCapacityArray> IncrementalCapacityArray { get; set; }

    }
}
