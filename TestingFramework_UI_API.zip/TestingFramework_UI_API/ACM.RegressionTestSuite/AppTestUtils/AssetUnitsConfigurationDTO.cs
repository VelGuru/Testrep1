﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RegressionTestSuite.AppTestUtils
{
    public class AssetUnitsConfigurationDTO
    {
        public AssetDetails assetDetails { get; set; }
        public AssetUnitDetails assetUnitDetails { get; set; }
        public AssetUnitCapacityDetails assetUnitCapacityDetails { get; set; }
        public AssetUnitCrossRefDetails assetUnitCrossRefDetails { get; set; }
        public AssetUnitExternalIdsDetails assetUnitExternalIdsDetails { get; set; }

    }
    public class AssetDetails
    {
        public int assetKey { get; set; }
        /* public string assetName { get; set; }
         public int assetClassKey { get; set; }
         public string assetClassName { get; set; }
         public string assetCreatedDate { get; set; }
         public string assetStartDate { get; set; }
         public int assetConfigurationType { get; set; }
         public string assetConfigurationCd { get; set; }
         public int industryTypeKey { get; set; }
         public string industryTypeCd { get; set; } */

    }

    public class AssetUnitDetails
    {
        // public int assetUnitKey { get; set; }
        public string assetUnitName { get; set; }
        public int assetUnitSubTypeKey { get; set; }
        // public string assetUnitSubTypeCd { get; set; }
        public string startDate { get; set; }
        public string endDate { get; set; }
        // public decimal latitude { get; set; }
        //public decimal longtiude { get; set; }
        public int operationalStatusKey { get; set; }
        //public string operationalStatusCd { get; set; }
        //public string petchemProcessNm { get; set; }
        //public decimal sulphurAverageNum { get; set; }
        //public decimal apiGravityAverageNum { get; set; }
        public Boolean placeHolderInd { get; set; }
        public Boolean offlineLockedInd { get; set; }
        public int dataProviderKey { get; set; }
        //public string dataProviderCd { get; set; }
        public int dataSetKey { get; set; }
        //public string dataSetCd { get; set; }
        public int sourceTypeKey { get; set; }
        //public string sourceTypeCd { get; set; }
        public string intellegenceSourceText { get; set; }
        public string intellegenceSourceUrl { get; set; }
        public int assetKey { get; set; }
    }
    public class AssetUnitCapacityDetails
    {
        //public int id { get; set; }
        public int probabilityTypeKey { get; set; }
        //public int probabilityTypecd { get; set; }
        public int quantity { get; set; }
        public int measureUnitKey { get; set; }
        //public int measureUnitCd { get; set; }
        public string capacityStartDate { get; set; }
    }
    public class AssetUnitCrossRefDetails { }

    public class AssetUnitExternalIdsDetails { }
}
