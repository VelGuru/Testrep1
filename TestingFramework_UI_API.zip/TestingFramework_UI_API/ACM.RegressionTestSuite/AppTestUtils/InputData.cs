﻿
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace APITestSuite
{
    public class AppInputData
    {

        public string execute { get; set; }
        public string validateJsonSchema { get; set; }
        public string validateAPIVersion { get; set; }
        public string validateStatusCode { get; set; }
        public string addAssetUnitKey { get; set; }
        public string totalFirmUnitCapacity { get; set; }
        public string jsonSchemaFilePath { get; set; }
        public string versionAPIJsonSchemaPath { get; set; }
        public string apiName { get; set; }
        public string fields { get; set; }
        public string mandatoryFields { get; set; }
        public string uniqueFields { get; set; }
        public string cdInitials { get; set; }
        public string versionable { get; set; }
        public string assetName { get; set; }
        public string xpath { get; set; }
        public List<CrossRefFields> crossRefFields { get; set; }
        public List<AssetUnitsTestDataFields> defaultValueFields { get; set; }
        public List<DefaultValuesField> DefaultParameterValueFields { get; set; }
        public List<ParameterField> parameterFields { get; set; }
        public List<ParameterFieldForAssetUnit> parameterFieldsForAssetUnit { get; set; }
        public List<AssetUnitsTestDataFields> assetUnitsTestDataFields { get; set; }
        public List<ValidationParamFields> validationParamFields { get; set; }

        public List<InitialCapacityEventField> initialCapacityEventField { get; set; }
        public List<ExpansionCapacityEventField> expansionCapacityEventField { get; set; }
        public List<CreepCorrectionEventField> creepCorrectionEventField { get; set; }
        public List<ClosureEventField> closureEventField { get; set; }
        public List<MaintenanceEventField> maintenanceEventField1 { get; set; }
        public List<MaintenanceEventField> maintenanceEventField2 { get; set; }
        public List<MaintenanceEventField> maintenanceEventField3 { get; set; }
        public List<MaintenanceEventField> maintenanceEventField4 { get; set; }
        public List<ExpectedFieldValues> expectedFieldValues { get; set; }
        public List<FilterField> filterField { get; set; }

    }

    public class FilterField
    {
        public string field { get; set; }
        public string value { get; set; }

        public FilterField(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }
    public class CrossRefFields
    {
        public string apiName { get; set; }
        public string field { get; set; }

        public CrossRefFields(string apiName, string field)
        {
            this.apiName = apiName;
            this.field = field;
        }
    }

    public class ParameterField
    {
        public string apiName { get; set; }
        public string param { get; set; }

        public ParameterField(string apiName, string param)
        {
            this.apiName = apiName;
            this.param = param;
        }
    }

    public class ParameterFieldForAssetUnit
    {
        public string apiName { get; set; }
        public string param { get; set; }

        public ParameterFieldForAssetUnit(string apiName, string param)
        {
            this.apiName = apiName;
            this.param = param;
        }
    }

    public class AssetUnitsTestDataFields
    {
        public string field { get; set; }
        public string value { get; set; }

        public AssetUnitsTestDataFields(string field, string value)
        {
            this.field = field;
            this.value = value;
        }

    }
    public class DefaultValuesField
    {
        public string field { get; set; }
        public string value { get; set; }

        public DefaultValuesField(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }
    public class ValidationParamFields
    {
        public string field { get; set; }
        public string value { get; set; }

        public ValidationParamFields(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }

    public class InitialCapacityEventField
    {
        public string field { get; set; }
        public string value { get; set; }

        public InitialCapacityEventField(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }
    public class ExpansionCapacityEventField
    {
        public string field { get; set; }
        public string value { get; set; }

        public ExpansionCapacityEventField(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }
    public class CreepCorrectionEventField
    {
        public string field { get; set; }
        public string value { get; set; }

        public CreepCorrectionEventField(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }
    public class ClosureEventField
    {
        public string field { get; set; }
        public string value { get; set; }

        public ClosureEventField(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }

    public class MaintenanceEventField
    {
        public string field { get; set; }
        public string value { get; set; }

        public MaintenanceEventField(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }

    public class ExpectedFieldValues
    {
        public string field { get; set; }
        public string value { get; set; }

        public ExpectedFieldValues(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }

    public class TestDataGenerator : IEnumerable<object[]>
    {

        private readonly List<object[]> _data = loadInputData();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        private static List<object[]> loadInputData()
        {
            List<object[]> _inputDataList = new List<object[]>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            string masterDataFile = config["MasterDataTestConfigFile"];
            string text = System.IO.File.ReadAllText(@masterDataFile);

            JArray masterDataInputArray = JArray.Parse(text);
            foreach (JObject masterDateInputObject in masterDataInputArray)
            {
                AppInputData inputData = masterDateInputObject.ToObject<AppInputData>();
                if (inputData.execute == null || inputData.execute.ToUpper() == "y".ToUpper())
                    _inputDataList.Add(new object[] { inputData });
            }

            string crossRefDataFile = config["CrossRefDataTestConfigFile"];
            string text1 = System.IO.File.ReadAllText(@crossRefDataFile);

            JArray crossRefDataInputArray = JArray.Parse(text1);
            foreach (JObject crossRefDataInputObject in crossRefDataInputArray)
            {
                AppInputData inputData = crossRefDataInputObject.ToObject<AppInputData>();
                if (inputData.execute == null || inputData.execute.ToUpper() == "y".ToUpper())
                    _inputDataList.Add(new object[] { inputData });
            }
            return _inputDataList;
        }
    }

    public class SanityTestDataGenerator : IEnumerable<object[]>
    {

        private readonly List<object[]> _data = loadInputData();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        private static List<object[]> loadInputData()
        {
            List<object[]> _sanityInputDataList = new List<object[]>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            string capacityAndMaintenaceSanityDataFile = config["CapacityAndMaintenanceSanityTestConfigFile"];
            string text1 = System.IO.File.ReadAllText(@capacityAndMaintenaceSanityDataFile);

            JArray sanityDataInputArray = JArray.Parse(text1);
            foreach (JObject sanityDataInputObject in sanityDataInputArray)
            {
                AppInputData inputData = sanityDataInputObject.ToObject<AppInputData>();
                if (inputData.execute == null || inputData.execute.ToUpper() == "y".ToUpper())
                    _sanityInputDataList.Add(new object[] { inputData });
            }

            string masterDataCrossRefSanityFile = config["MasterDataCrossRefSanityTestConfigFile"];
            string text2 = System.IO.File.ReadAllText(@masterDataCrossRefSanityFile);

            JArray masterDataSanityInputArray = JArray.Parse(text2);
            foreach (JObject sanityDataInputObject in masterDataSanityInputArray)
            {
                AppInputData inputData = sanityDataInputObject.ToObject<AppInputData>();
                if (inputData.execute == null || inputData.execute.ToUpper() == "y".ToUpper())
                    _sanityInputDataList.Add(new object[] { inputData });
            }
            return _sanityInputDataList;
        }
    }
    public class TotalCapacityTestDataGenerator : IEnumerable<object[]>
    {

        public readonly List<object[]> _data = loadInputData(jsonfilename);
        private static string jsonfilename;

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        public static List<object[]> loadInputData(string jsonfilename)
        {
            List<object[]> _totalcapacityInputDataList = new List<object[]>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            string totalCapacityDataFile = config[jsonfilename];
            string text = System.IO.File.ReadAllText(@totalCapacityDataFile);

            JArray totalCapacityDataInputArray = JArray.Parse(text);
            foreach (JObject totalCapacityDataInputObject in totalCapacityDataInputArray)
            {
                AppInputData inputData = totalCapacityDataInputObject.ToObject<AppInputData>();
                if (inputData.execute == null || inputData.execute.ToUpper() == "y".ToUpper())
                    _totalcapacityInputDataList.Add(new object[] { inputData });
            }
            return _totalcapacityInputDataList;
        }

    }
}
