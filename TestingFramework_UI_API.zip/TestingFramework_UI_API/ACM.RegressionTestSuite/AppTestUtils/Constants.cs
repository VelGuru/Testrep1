﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APITestSuite
{
   public  class AppConstants
    {   

        // Added by siva for ACM
        public static readonly string ERROR_MESSAGE_ACTIVE_INITIAL_CAPACITY_EXISTS = "Active initial capacity already exists for this unit";
        public static readonly string ERROR_MESSAGE_UNIT_NOT_INITIALIZED = "Unit not initialized yet";
        public static readonly string ERROR_MESSAGE_MULTIPLE_CAPACITY_EVENTS_ON_SAMEDAY = "Multiple capacity events that start on the same day found";
        public static readonly string ERROR_MESSAGE_CANNOT_ADD_CAPACITY_AFTER_CLOSURE = "Cannot add capacity after closure date";
    }
}
