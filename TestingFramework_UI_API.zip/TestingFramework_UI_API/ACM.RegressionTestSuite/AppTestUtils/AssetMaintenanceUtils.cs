﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using APITestSuite;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.AppTestUtils
{
    public class AssetMaintenanceUtils
    {      
        public static SqlConnection DBConnection()
        {
            string connectionString = null;            
            SqlConnection conn;
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            connectionString = config["ConnectionStrings:GenevaSqlDbConn"];
            conn = new SqlConnection(connectionString);
            return conn;
        }


        public static int GetActiveMaintananceAssetUnitKeyData(string field)
        {
            int Key = 0;
            string query = @"	DECLARE @Date DATETIME
		                        SET @Date = GETDATE()
	 
		                        Select  distinct top 100 AUE.asset_unit_key
		                        From cns_cpo_mid_capacity.asset_unit_event AUE
		                        Inner Join cns_cpo_mid_capacity.asset_unit_event_ver AUEV on AUE.asset_unit_event_key = AUEV.asset_unit_event_key
		                        INNER JOIN cns_cpo_mid_capacity.asset_unit AU on AUE.asset_unit_key = AU.asset_unit_key 
		                        INNER join cns_cpo_mid_capacity.asset_unit_ver AUV on AUV.asset_unit_key = AU.asset_unit_key
		                        INNER JOIN cns_cpo_mid_reference.asset_unit_subtype AUST on AUV.asset_unit_subtype_key = AUST.asset_unit_subtype_key
		                        INNER JOIN cns_cpo_mid_reference.asset_unit_type AUT on AUT.asset_unit_type_key = AUST.asset_unit_type_key
		                        INNER JOIN cns_cpo_mid_capacity.asset_ver AV on AU.asset_key = AV.asset_key
		                        INNER JOIN cns_cpo_mid_capacity.asset A on A.asset_key = AV.asset_key
		                        INNER JOIN cns_cpo_mid_reference.asset_class AC on A.asset_class_key = AC.asset_class_key
		                        INNER JOIN cns_cpo_mid_capacity.asset_company ACO on ACO.asset_key = A.asset_key
		                        INNER JOIN cns_glb_reference.company C on ACO.company_key = C.company_key
		                        INNER JOIN cns_cpo_mid_reference.version_type VT on AUEV.version_type_key = VT.version_type_key
		                        INNER JOIN cns_glb_reference.geopolitical_entity GE on AV.location_key = GE.geopolitical_entity_key

		                        Where 	
		                        AUEV.delete_ind = 'N' AND AUEV.version_active_ind = 'Y' AND AUEV.version_type_key in (3) 
		                        AND AU.delete_ind = 'N' 
		                        AND AUV.delete_ind = 'N' AND AUV.version_active_ind = 'Y' AND AUV.version_type_key in (3) 
		                        AND AUST.delete_ind = 'N' 
		                        AND AUT.delete_ind = 'N'
		                        AND A.delete_ind = 'N' 
		                        AND AV.delete_ind = 'N' AND AV.version_active_ind = 'Y' AND AV.version_type_key in (3)
		                        AND AC.delete_ind = 'N'
		                        AND ACO.delete_ind = 'N' AND ACO.version_active_ind = 'Y' AND ACO.version_type_key in (3)
		                        AND C.delete_ind = 'N' 
		                        AND GE.delete_ind = 'N'

		                        and AUEV.version_effective_dt!= cast(getdate() as Date)
		                        and AUEV.event_start_dt < ( cast(getdate() as Date)) 
	   
               
		                        intersect

                                select AUC.asset_unit_key from cns_cpo_mid_capacity.asset_unit_capacity AUC 
                                INNER join cns_cpo_mid_capacity.asset_unit_capacity_ver AUCV on AUCV.asset_unit_capacity_key = AUC.asset_unit_capacity_key
                                INNER JOIN cns_cpo_mid_capacity.asset_unit AU on AUC.asset_unit_key = AU.asset_unit_key 

                                where AUC.asset_unit_key IN (select AUC.asset_unit_key from cns_cpo_mid_capacity.asset_unit_capacity_ver AUCV 
	                            INNER join cns_cpo_mid_capacity.asset_unit_capacity AUC on AUCV.asset_unit_capacity_key = AUC.asset_unit_capacity_key 
	                            INNER JOIN cns_cpo_mid_capacity.asset_unit AU on AUC.asset_unit_key = AU.asset_unit_key 
	                            INNER JOIN cns_cpo_mid_capacity.asset_unit_ver AUV on AUC.asset_unit_key = AUV.asset_unit_key 
	                            INNER JOIN cns_cpo_mid_reference.asset_unit_subtype AUST on AUV.asset_unit_subtype_key = AUST.asset_unit_subtype_key
	                            INNER JOIN cns_cpo_mid_reference.asset_unit_type AUT on AUT.asset_unit_type_key = AUST.asset_unit_type_key
	                            INNER JOIN cns_cpo_mid_capacity.asset_ver AV on AU.asset_key = AV.asset_key 
	                            INNER JOIN cns_cpo_mid_capacity.asset A on A.asset_key = AV.asset_key	
	                            INNER JOIN cns_cpo_mid_reference.asset_class AC on A.asset_class_key = AC.asset_class_key
	                            INNER JOIN cns_cpo_mid_capacity.asset_company ACO on ACO.asset_key = A.asset_key
	                            INNER JOIN cns_glb_reference.company C on ACO.company_key = C.company_key
	                            INNER JOIN cns_cpo_mid_reference.version_type VT on AUCV.version_type_key = VT.version_type_key
	                            INNER JOIN cns_glb_reference.geopolitical_entity GE on AV.location_key = GE.geopolitical_entity_key
	                            INNER JOIN cns_cpo_mid_reference.planning_probability_type PPT on AUCV.planning_probability_type_key = PPT.planning_probability_type_key
	                            INNER JOIN cns_glb_reference.measure_unit MU on AUCV.capacity_original_uom_key = MU.measure_unit_key
	                            Where AUCV.delete_ind = 'N' AND AUCV.version_active_ind = 'Y' AND AUCV.version_type_key in (3) 
	                            AND AU.delete_ind = 'N' 
	                            AND AUV.delete_ind = 'N' AND AUV.version_active_ind = 'Y' AND AUV.version_type_key in (3) 
	                            AND AUST.delete_ind = 'N' 
	                            AND AUT.delete_ind = 'N'
	                            AND A.delete_ind = 'N' 
	                            AND AV.delete_ind = 'N' AND AV.version_active_ind = 'Y' AND AV.version_type_key in (3)
	                            AND AC.delete_ind = 'N'
	                            AND ACO.delete_ind = 'N' AND ACO.version_active_ind = 'Y' AND ACO.version_type_key in (3)
	                            AND C.delete_ind = 'N' 
	                            AND GE.delete_ind = 'N' 
	                            Group by AUC.asset_unit_key
	                            Having count(AUC.asset_unit_key)=1 ) 
								 
                                and AUCV.version_active_ind = 'Y' AND AUCV.version_type_key = 3  AND AUCV.delete_ind = 'N'
                                and AUC.capacity_basis_type_key=1";

            Key = int.Parse(AssetCapacityUtils.ExecuteQueryAndGetFieldValue(query, field));
            return Key;
        }



        // Function         : GetlatestMaintenanceEventKeyWithAssetUnitKey
        // Input Parameters : field -Asset unit Capacity Event Key 
        //                    assetUnitKey - Asset unit Key                
        // Description      : To get latest Maintenance Event keys
        // Change History   : 
        public static int GetlatestMaintenanceEventKeyWithAssetUnitKey(string field, int AssetUnitKey)
        {
            int Key = 0;
            string query = @"Select distinct AUE.asset_unit_event_key

                                FROM cns_cpo_mid_capacity.asset_unit_event_ver  auev
                                    inner join cns_cpo_mid_capacity.asset_unit_event aue on auev.asset_unit_event_key = aue.asset_unit_event_key
                                    inner join cns_cpo_mid_capacity.asset_unit au on aue.asset_unit_key = au.asset_unit_key
                                Where aue.asset_unit_key in (" + AssetUnitKey + ") Order By AUEV.event_start_dt DESC";

            Key = int.Parse(AssetCapacityUtils.ExecuteQueryAndGetFieldValue(query, field));
            return Key;
        }



        // Function         : UpdateAssetUnitCapacityEvent
        // Input Parameters : capacityEventKey -Asset unit Capacity Event Key 
        //                    assetUnitKey - Asset unit Key
        //                    UpdateFieldName - field Name which we wanted to update
        //                    updateFieldValue - field value which we wanted to update
        // Description      : To update any capacity event
        // Change History   : 

        public static ResponseData UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            Dictionary<string, string> inputKeyValues = RestUtil.GetFirstRecord("AssetUnitCapacities/" + assetUnitKey);
            Dictionary<string, string> updatedInputKeyValues = new Dictionary<string, string>();

            foreach (string fieldName in inputKeyValues.Keys)
            {
                if (fieldName == UpdateFieldName)
                {
                    updatedInputKeyValues.Add(fieldName, updateFieldValue);
                }
                else if (fieldName == "capacityOriginalQty" || fieldName == "id" || fieldName == "capacityBasisTypeKey" || fieldName == "capacityStartDt" || fieldName == "planningProbabilityTypeKey" || fieldName == "dataProviderKey" || fieldName == "capacityOriginalUomKey" || fieldName == "planningStatusTypeKey")
                {
                    updatedInputKeyValues.Add(fieldName, inputKeyValues[fieldName]);
                }
            }

            ResponseData responseData = RestUtil.PutMethod("AssetUnitCapacities", updatedInputKeyValues, capacityEventKey);
            return responseData;
        }


        public static void UpdateMaintenanceEvent(int maintenanceEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            string apiName = "AssetUnitEvents/{MaintenanceEventId}/versions";
            apiName=apiName.Replace("{MaintenanceEventId}", maintenanceEventKey.ToString());
            Dictionary<string, string> inputKeyValues = RestUtil.GetFirstRecord(apiName);
            Dictionary<string,string> updatedInputKeyValues = new Dictionary<string,string>();

            foreach (string fieldName in inputKeyValues.Keys)
            {
                if(fieldName== "assetUnitEventKey")
                {
                    updatedInputKeyValues.Add(fieldName, "[" + maintenanceEventKey + "]");
                }
                else if (fieldName == UpdateFieldName)
                {
                    updatedInputKeyValues.Add(fieldName, updateFieldValue);
                }
                else if (fieldName== "eventTypeKey")
                {
                    updatedInputKeyValues.Add("assetEventTypeKey", inputKeyValues[fieldName]);
                }
                else if (fieldName == "offlineCapacityPct")
                {
                    if (UpdateFieldName == "offlineCapacityOriginal")
                    {
                        updatedInputKeyValues.Add("offlineCapacityOriginal", updateFieldValue);
                    }
                    else
                    {
                        updatedInputKeyValues.Add("offlineCapacityOriginal", inputKeyValues[fieldName]);
                    }
                }
                else if (fieldName == "measureUnitKey")
                {
                    updatedInputKeyValues.Add("offlineCapacityOriginalUomKey", inputKeyValues[fieldName]);
                }
                else if (fieldName == "eventStartDate")
                {
                    updatedInputKeyValues.Add("eventStartDt", inputKeyValues[fieldName]);
                }
                else if (fieldName == "eventEndDate")
                {
                    updatedInputKeyValues.Add("eventEndDt", inputKeyValues[fieldName]);
                }
                else if (fieldName == "dataProviderKey"  || fieldName == "eventLockInd")
                {
                    updatedInputKeyValues.Add(fieldName, inputKeyValues[fieldName]);
                }                
            }
            updatedInputKeyValues.Add("offlineDataType", "PCT");
            ResponseData responseData = RestUtil.PutMethodWithOutIdParam("AssetUnitEvents", updatedInputKeyValues);
            Boolean statusCodeValid = RestUtil.IsStatusCodeOk(responseData.StatusCode);
        }
    }
}
