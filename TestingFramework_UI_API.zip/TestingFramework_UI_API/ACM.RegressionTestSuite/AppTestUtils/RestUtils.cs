﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using APITestSuite;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.AppTestUtils
{
    class RestUtils
    {

        public static List<string> GetFieldList(string fields)
        {
             return Util.GetListFromCommaSepString(fields);
        }
        public static List<string> GetUniqueFieldList(string uniqueFields)
        {
            return Util.GetListFromCommaSepString(uniqueFields);
        }

        public static string getCurrentDate()
        {
            DateTime currentDateTime = DateTime.Now;
            string versionDate = currentDateTime.ToString("yyyy-MM-dd");
            return versionDate;
        }

        public static string getYesterdaysDate()
        {
            DateTime YesterdayDateTime = DateTime.Now.AddDays(-1);
            string YesterdaysDate = YesterdayDateTime.ToString("yyyy-MM-dd");
            return YesterdaysDate;
        }

        public static string QuarterEndDate()
        {

            int quarterNumber = (DateTime.Now.Month - 1) / 3 + 1;
            DateTime firstDayOfQuarter = new DateTime(DateTime.Now.Year, (quarterNumber - 1) * 3 + 1, 1);
            DateTime lastDayOfQuarter = firstDayOfQuarter.AddMonths(3).AddDays(-1);
            string endDate = lastDayOfQuarter.ToString("yyyy-MM-dd");
            return endDate;
        }
        public static AssetUnitsConfigurationDTO SetAssetUnitsParam(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            AssetDetails assetDetails = new AssetDetails();
            AssetUnitDetails assetUnitDetails = new AssetUnitDetails();
            AssetUnitCapacityDetails assetUnitCapacityDetails = new AssetUnitCapacityDetails();
            AssetUnitCrossRefDetails assetUnitCrossRefDetails = new AssetUnitCrossRefDetails();
            AssetUnitExternalIdsDetails assetUnitExternalIdsDetails = new AssetUnitExternalIdsDetails();

            if (inputKeyValues != null)
            {
                assetDetails.assetKey = int.Parse(inputKeyValues["assetKey"]);
                assetUnitDetails.assetUnitName = inputKeyValues["assetUnitName"];
                assetUnitDetails.assetUnitSubTypeKey = int.Parse(inputKeyValues["assetUnitSubTypeKey"]);
                assetUnitDetails.startDate = inputKeyValues["startDate"];
                assetUnitDetails.endDate = inputKeyValues["endDate"];
                assetUnitDetails.operationalStatusKey = int.Parse(inputKeyValues["operationalStatusKey"]);
                assetUnitDetails.placeHolderInd = bool.Parse(inputKeyValues["placeHolderInd"]);
                assetUnitDetails.offlineLockedInd = bool.Parse(inputKeyValues["offlineLockedInd"]);
                assetUnitDetails.dataProviderKey = int.Parse(inputKeyValues["dataProviderKey"]);
                assetUnitDetails.dataSetKey = int.Parse(inputKeyValues["dataSetKey"]);
                assetUnitDetails.sourceTypeKey = int.Parse(inputKeyValues["sourceTypeKey"]);
                assetUnitDetails.intellegenceSourceText = inputKeyValues["intellegenceSourceText"];
                assetUnitDetails.intellegenceSourceUrl = inputKeyValues["intellegenceSourceUrl"];
                assetUnitDetails.assetKey = int.Parse(inputKeyValues["assetKey"]);
                assetUnitCapacityDetails.probabilityTypeKey = int.Parse(inputKeyValues["probabilityTypeKey"]);
                assetUnitCapacityDetails.quantity = int.Parse(inputKeyValues["quantity"]);
                assetUnitCapacityDetails.measureUnitKey = int.Parse(inputKeyValues["measureUnitKey"]);
                assetUnitCapacityDetails.capacityStartDate = inputKeyValues["capacityStartDate"];
            }
            assetUnitsConfigurationDTO.assetUnitDetails = assetUnitDetails;
            assetUnitsConfigurationDTO.assetDetails = assetDetails;
            assetUnitsConfigurationDTO.assetUnitCapacityDetails = assetUnitCapacityDetails;

            return assetUnitsConfigurationDTO;
        }

        public static ResponseData PostMethodAssetUnits(string ApiName, object assetUnitsConfigurationDTO)
        {
            string jSONString = JsonConvert.SerializeObject(assetUnitsConfigurationDTO);
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            var BaseURL = config["TargetUri"];
            string URL = BaseURL + ApiName;           
            RestClient client = new RestClient(URL);
            RestRequest request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json-patch+json");
           request.AddJsonBody(jSONString);
           client.Authenticator = new CustomAuthenticator();
           IRestResponse restResponse = client.Execute(request);
           ResponseData responseData = new ResponseData();
           responseData.StatusCode = (int)restResponse.StatusCode;
           responseData.StatusLine = restResponse.ResponseStatus.ToString();
           responseData.ContentType = restResponse.ContentType;
           responseData.APIName = URL;
           responseData.RequestBody = jSONString;
           responseData.Content = restResponse.Content;

            return responseData;
        }

        public static ResponseData PostMethod(string ApiName, object Request)
        {
            string jSONString = JsonConvert.SerializeObject(Request);
           
            if (ApiName.Contains("AssetUnitEvents"))
            {
                jSONString = jSONString.Replace("\"[", "[");
                jSONString = jSONString.Replace("]\"", "]");
            }

            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            var BaseURL = config["TargetUri"];
            string URL = BaseURL + ApiName;
            RestClient client = new RestClient(URL);
            RestRequest request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json-patch+json");
            request.AddJsonBody(jSONString);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            responseData.APIName = URL;
            responseData.RequestBody = jSONString;
            responseData.Content = restResponse.Content;

            return responseData;
        }

        public static void RunTotalCapacityByAsset(string APIParameters, String Xpath, decimal totalUnitCapacity)
        {
            JArray APIResponseArray = new JArray();
            string ApiName = APIParameters;
            string Path = Xpath;
            decimal ExpectedResult = totalUnitCapacity;
            List<string> error = new List<string>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            var BaseURL = config["TargetUri"];
            string URL = BaseURL + ApiName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;

            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                APIResponseArray = JArray.Parse(restResponse.Content) as JArray;
                decimal ActualResult = decimal.Parse(APIResponseArray.SelectToken(Path).ToString());
                Assert.Equal(ActualResult, ExpectedResult, 2);
            }
            else
            {
                throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "API Request :" + responseData.RequestBody);
            }
        }

        public static string GetAPIFieldValue(string APIParameters, String Xpath)
        {
            JArray APIResponseArray = new JArray();
            JObject APIResponseObject = new JObject();
            string ApiName = APIParameters;
            string Path = Xpath;
            List<string> error = new List<string>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            var BaseURL = config["TargetUri"];
            string URL = BaseURL + ApiName;

            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData();

            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            responseData.Content = restResponse.Content;

            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                try
                {
                    APIResponseObject = JObject.Parse(restResponse.Content);
                    return APIResponseObject.SelectToken(Path).ToString();
                }
                catch (Exception)
                {
                    APIResponseArray = JArray.Parse(restResponse.Content) as JArray;
                    return APIResponseArray.SelectToken(Path).ToString();
                }
            }
            else
            {
                throw new Exception("API URL :" + URL + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine);
            } 
        }

        public static Dictionary<string, string> RunAssetUnitCapacities<T>(List<T> inputData, int unitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = new Dictionary<string, string>();
            int assetUnitKey = unitKey;

            PropertyInfo[] pi = typeof(T).GetProperties();
            foreach (var el in inputData)
            {
                if (pi[0].GetValue(el).ToString() == "assetUnitKey")
                {
                    assetUnitCapacitiesFields.Add(pi[0].GetValue(el).ToString(), assetUnitKey.ToString());
                }
                else
                {
                    assetUnitCapacitiesFields.Add(pi[0].GetValue(el).ToString(), pi[1].GetValue(el).ToString());
                }
            }
            return assetUnitCapacitiesFields;
        }
        public static string GetTotalCapacityByAssetRequestData<T>(List<T> inputData, List<int> assetUnitsList, List<string> optionalList = null)
        {                 
            string APIParameters = null;
            PropertyInfo[] pi = typeof(T).GetProperties();
            foreach (var el in inputData)
            {
                string paramField = pi[0].GetValue(el).ToString();
                string paramValue = pi[1].GetValue(el).ToString();
                if (paramField == "apiName")
                {
                    APIParameters = paramValue + "&";

                }
                else if (paramField == "VersionDate")
                {
                    if (string.IsNullOrEmpty(paramValue))
                    {
                        paramValue = getCurrentDate();
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                    else
                    {
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                }
                else if (paramField == "StartDate")
                {
                    {
                        if (optionalList != null && paramValue == "")
                        {
                            APIParameters = APIParameters + paramField + "=" + optionalList[0] + "&";
                        }
                        else
                        {
                            APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                        }
                    }
                }
                else if (paramField == "EndDate")
                {
                    if (string.IsNullOrEmpty(paramValue))
                    {
                        paramValue = QuarterEndDate();
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                    else
                    {
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }

                }
                else if (paramField == "Unit")
                {
                    if (assetUnitsList != null)
                    {
                        foreach (int assetUnit in assetUnitsList)
                        {
                            APIParameters = APIParameters + paramField + "=" + assetUnit.ToString() + "&";
                        }
                    }
                }
                else if (paramField == "Pt")
                {
                    if (optionalList != null && string.IsNullOrEmpty(paramValue))
                    {
                        foreach (string optionalValue in optionalList)
                        {
                            APIParameters = APIParameters + paramField + "=" + optionalValue + "&";
                        }
                    }
                    else
                    {
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                }
                else
                {
                    APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                }
            }
            return APIParameters;
        }
        public static string GetIncrementalCapacitiesRequestURLdata<T>(List<T> inputData, List<int> assetUnitsList, int assetKey,string startDate=null,string endDate=null,List<string> ptList = null)
        {
            string APIParameters = null;
            PropertyInfo[] pi = typeof(T).GetProperties();
            foreach (var el in inputData)
            {
                string paramField = pi[0].GetValue(el).ToString();
                string paramValue = pi[1].GetValue(el).ToString();
                if (paramField == "apiName")
                {
                    APIParameters = paramValue + "&";
                }
                else if (paramField == "VersionDate")
                {
                    if (string.IsNullOrEmpty(paramValue))
                    {
                        paramValue = getCurrentDate();
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                    else
                    {
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                }
                else if (paramField == "StartDate")
                {
                    {
                        if (!string.IsNullOrWhiteSpace(startDate) && paramValue == "")
                        {
                            APIParameters = APIParameters + paramField + "=" + startDate+ "&";
                        }
                        else
                        {
                            APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                        }
                    }
                }
                else if (paramField == "EndDate")
                {
                    if (!string.IsNullOrWhiteSpace(endDate) && paramValue == "")
                    {
                        APIParameters = APIParameters + paramField + "=" + endDate + "&";
                    }
                    else
                    {
                        paramValue = QuarterEndDate();
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                }
                else if (paramField == "Unit")
                {
                    if (assetUnitsList != null)
                    {
                        foreach (int assetUnit in assetUnitsList)
                        {
                            APIParameters = APIParameters + paramField + "=" + assetUnit.ToString() + "&";
                        }
                    }
                }
                else if (paramField == "Pt")
                {
                    if (ptList != null)
                    {
                        foreach (string optionalValue in ptList)
                        {
                            APIParameters = APIParameters + paramField + "=" + optionalValue + "&";
                        }
                    }
                    else
                    {
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                }
                else if (paramField == "groupformat")
                {
                    List<string> groupformatList = Util.GetListFromCommaSepString(paramValue);
                    APIParameters = APIParameters + paramField + "={\"assetId\":" + assetKey + ",\"dmqFilter\":" + "\"" + groupformatList[0] + "\"" + ",\"typeFilter\":" + "\"" + groupformatList[1] + "\"}&";
                }
                else
                {
                    APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                }
            }
            return APIParameters;
        }

        public static string GetMaintenanceEventSummaryRequestURLdata<T>(List<T> inputData, List<int> assetUnitsList, int assetKey=0, string startDate = null, string endDate = null, List<string> ptList = null)
        {
            string APIParameters = null;
            PropertyInfo[] pi = typeof(T).GetProperties();
            foreach (var el in inputData)
            {
                string paramField = pi[0].GetValue(el).ToString();
                string paramValue = pi[1].GetValue(el).ToString();
                if (paramField == "apiName")
                {
                    APIParameters = paramValue + "&";
                }
                else if (paramField == "VersionDate")
                {
                    if (string.IsNullOrEmpty(paramValue))
                    {
                        paramValue = getCurrentDate();
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                    else
                    {
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                }
                else if (paramField == "sinceLastUpdate")
                {
                    if (string.IsNullOrEmpty(paramValue))
                    {
                        paramValue = getCurrentDate();
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                    else
                    {
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                }
                else if (paramField == "unit")
                {
                    if (assetUnitsList != null)
                    {
                        foreach (int assetUnit in assetUnitsList)
                        {
                            APIParameters = APIParameters + paramField + "=" + assetUnit.ToString() + "&";
                        }
                    }
                }
                else if (paramField == "a")
                {
                    if (assetUnitsList != null)
                    {
                        foreach (int assetUnit in assetUnitsList)
                        {
                            APIParameters = APIParameters + paramField + "=" + assetKey.ToString() + "&";
                        }
                    }
                }
                else if (paramField == "dp")
                {
                    if (ptList != null)
                    {
                        foreach (string optionalValue in ptList)
                        {
                            APIParameters = APIParameters + paramField + "=" + optionalValue + "&";
                        }
                    }
                    else
                    {
                        APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                    }
                }
                else
                {
                    APIParameters = APIParameters + paramField + "=" + paramValue + "&";
                }
            }
            return APIParameters;
        }

        public static void RunIncrementalCapacities(string APIParameters, String Xpath, decimal totalUnitCapacity)
        {
            JArray APIResponseArray = new JArray();
            string ApiName = APIParameters;
            string Path = Xpath;
            decimal ExpectedResult = totalUnitCapacity;
            List<string> error = new List<string>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            var BaseURL = config["TargetUri"];
            string URL = BaseURL + ApiName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;

            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                APIResponseArray = JArray.Parse(restResponse.Content) as JArray;
                decimal ActualResult = decimal.Parse(APIResponseArray.SelectToken(Path).ToString());
                Assert.Equal(ActualResult, ExpectedResult, 2);
            }
        }

        public static Dictionary<string, string> RunAssetUnitMaintenanceEvents<T>(List<T> inputData)
        {
            Dictionary<string, string> maintenanceEventFields = new Dictionary<string, string>();

            PropertyInfo[] pi = typeof(T).GetProperties();
            foreach (var el in inputData)
            {
               maintenanceEventFields.Add(pi[0].GetValue(el).ToString(), pi[1].GetValue(el).ToString());
            }
            return maintenanceEventFields;
        }
    }
        
}

