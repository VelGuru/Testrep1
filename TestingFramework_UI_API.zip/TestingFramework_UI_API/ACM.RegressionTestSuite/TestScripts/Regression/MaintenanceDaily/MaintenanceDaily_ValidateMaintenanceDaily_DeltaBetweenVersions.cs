﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using APITestSuite;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RegressionTestSuite.RegressionTestData.MaintenanceEventSummary;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.MaintenanceEventSummary
{

    public class MaintenanceDaily_ValidateMaintenanceDaily_DeltaBetweenVersions
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        List<int> assetunits = new List<int>();
        int EventKey = 0;
        string ApiName = null;
        string xPath = null;
        string offlineCapacityPct = null;
       
        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_MaintenanceEventSummary_ValidateVersionEffective", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersionsTest(AppInputData inputData)
        {
            MaintenanceDaily_ValidateMaintenanceDaily_DeltaBetweenVersions ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions = new MaintenanceDaily_ValidateMaintenanceDaily_DeltaBetweenVersions();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
            ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.ApiName = inputData.apiName;
            ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.xPath = inputData.xpath;

            // Function Call to get asset unit which contains active maintenance events.
            ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.assetUnitKey = ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.GetAssetUnitKeyWithActiveMaintenanceEventKey("asset_unit_key");
            ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.assetunits.Add(ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.assetUnitKey);

            // Function Call to get recent maintenance Event key.
            ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.EventKey = ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.GetAssetUnitMaintenanceEventKey(ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.assetUnitKey, "assetUnitEventKey");

            // Function call to get event  OfflinePCT Value for before updating 
            ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.offlineCapacityPct = ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.GetAssetUnitCapacityEventValue(ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.EventKey, "$.[0].offlineCapacityPct");

            // code to update  OfflinePCT Value for existing event
            ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.UpdateAssetUnitCapacityEvent(ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.EventKey, ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.assetUnitKey, "offlineCapacityOriginal", "60");
                        
            // Code to validate OfflinePCT Value with version effective date as today's date.
            ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.ValidateMaintenanceEventSummaryAgainstVersionEffectiveDate(inputData.validationParamFields, ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.EventKey, ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.assetunits,"60", RestUtils.getCurrentDate());

            // Code to validate offlinePCT Value with version effective date as yesterday's date.
            ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.ValidateMaintenanceEventSummaryAgainstVersionEffectiveDate(inputData.validationParamFields, ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.EventKey, ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.assetunits, ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.offlineCapacityPct, RestUtils.getYesterdaysDate());

            Assert.True(ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.errors.Count == 0, ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.ApiName + ":" + "\n" + string.Join("\n ", ValidateMaintenanceDailyFunctionalityAgainstDeltaBetweenVersions.errors.Select(s => $"'{s}'")));

        }


        private int GetAssetUnitKeyWithActiveMaintenanceEventKey(string fieldName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetActiveMaintananceAssetUnitKeyData(fieldName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return assetUnitKey;
        }

        private int GetAssetUnitMaintenanceEventKey(int AssetUnitKey, string fieldName)
        {
            try
            {
                EventKey = int.Parse(RestUtil.GetFirstFieldValue("AssetUnitEvents?unitId=" + AssetUnitKey, "assetUnitEventKey"));
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return EventKey;
        }

        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null;

            String apiName = "AssetUnitEvents/{ MaintenanceEventId}/versions";
            apiName = apiName.Replace("{ MaintenanceEventId}", capacityEventKey.ToString());

            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateMaintenanceEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void ValidateMaintenanceEventSummaryAgainstVersionEffectiveDate<T>(List<T> validationParamFields, int maintenanceEventkey,List<int> assetUnitsList,string ExpectedofflineCapacityPct, String Date)
        {
            try
            {
                string APIParameters = RestUtils.GetMaintenanceEventSummaryRequestURLdata(validationParamFields, assetUnitsList);
                if (Date == RestUtils.getYesterdaysDate())
                { 
                    APIParameters = APIParameters.Replace("VersionDate="+RestUtils.getCurrentDate(), "VersionDate="+Date);
                }
                string ApiName = APIParameters;
                var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
                var BaseURL = config["TargetUri"];
                string URL = BaseURL + ApiName;
                var client = new RestClient(URL);
                var request = new RestRequest(Method.GET);
                client.Authenticator = new CustomAuthenticator();
                IRestResponse restResponse = client.Execute(request);

                if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
                {
                    var MaintenanceEventSummaryDataList = JsonConvert.DeserializeObject<MaintenenaceEventSummary>(restResponse.Content);
                    foreach (MaintenanceEventDataList dataitem in MaintenanceEventSummaryDataList.maintenanceEventDataList)
                    {
                        if (dataitem.assetUnitEventKey == maintenanceEventkey)
                        {
                            string ActualofflineCapacityPct = dataitem.offlinePCT.ToString();                            
                            Assert.True(ExpectedofflineCapacityPct == ActualofflineCapacityPct, string.Format("Field {0} expected {1} but got {2}", "offlineCapacityPct", ExpectedofflineCapacityPct, ActualofflineCapacityPct));
                        }
                    }
                 }             
          }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}

