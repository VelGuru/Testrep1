﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using APITestSuite;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RegressionTestSuite.RegressionTestData.MaintenanceEventSummary;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.MaintenanceEventSummary
{

    public class MaintenanceDaily_ValidateMaintenanceDailyAgainst_VersionEffective
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        List<int> assetunits = new List<int>();
        int EventKey = 0;
        string ApiName = null;
        string xPath = null;
        string offlineCapacityPct = null;
      
        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_MaintenanceDaily_ValidateMaintenanceDailyAgainst_VersionEffective", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void MaintenanceDailyValidateVersionEffectiveTest(AppInputData inputData)
        {
            MaintenanceDaily_ValidateMaintenanceDailyAgainst_VersionEffective MaintenanceDailyValidateVersionEffective = new MaintenanceDaily_ValidateMaintenanceDailyAgainst_VersionEffective();

            MaintenanceDailyValidateVersionEffective.ApiName = inputData.apiName;
            MaintenanceDailyValidateVersionEffective.xPath = inputData.xpath;

            // Function Call to get asset unit which contains active maintenance events.
            MaintenanceDailyValidateVersionEffective.assetUnitKey = MaintenanceDailyValidateVersionEffective.GetAssetUnitKeyWithActiveMaintenanceEventKey("asset_unit_key");
            MaintenanceDailyValidateVersionEffective.assetunits.Add(MaintenanceDailyValidateVersionEffective.assetUnitKey);
                         
            // Function Call to get recent maintenance Event key.
            MaintenanceDailyValidateVersionEffective.EventKey = MaintenanceDailyValidateVersionEffective.GetAssetUnitMaintenanceEventKey("asset_unit_event_key", MaintenanceDailyValidateVersionEffective.assetUnitKey);

            // Function call to get event OfflinePCT Value before update
            MaintenanceDailyValidateVersionEffective.offlineCapacityPct = MaintenanceDailyValidateVersionEffective.GetAssetUnitCapacityEventValue(MaintenanceDailyValidateVersionEffective.EventKey, "$.[0].offlineCapacityPct");

            // code to update  OfflinePCT Value for existing event
            MaintenanceDailyValidateVersionEffective.UpdateAssetUnitCapacityEvent(MaintenanceDailyValidateVersionEffective.EventKey, MaintenanceDailyValidateVersionEffective.assetUnitKey, "offlineCapacityOriginal", "60");











        }


        private int GetAssetUnitKeyWithActiveMaintenanceEventKey(string fieldName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetActiveMaintananceAssetUnitKeyData(fieldName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return assetUnitKey;
        }

        private int GetAssetUnitMaintenanceEventKey(string fieldName,int AssetUnitKey)
        {
            try
            {
                EventKey = AssetMaintenanceUtils.GetlatestMaintenanceEventKeyWithAssetUnitKey(fieldName, AssetUnitKey);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return EventKey;
        }


        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null;

            String apiName = "AssetUnitEvents/{ MaintenanceEventId}/versions";
            apiName = apiName.Replace("{ MaintenanceEventId}", capacityEventKey.ToString());

            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateMaintenanceEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}

