﻿using APITestSuite;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace APITestSuite
{
    public abstract class BaseMasterDataTest 
    {

        private protected abstract string fields { get; }
        private protected abstract string mandatoryFields { get; }
        private protected abstract string uniqueFields { get; }
        private protected abstract string apiName { get;}        
        private protected abstract string cdInitial { get; }
        private protected abstract Boolean versionable { get; }
        private protected abstract Dictionary<string,string> crossRefFields { get; }
        private protected abstract Dictionary<string, string> defaultValueFields { get; }
        private protected abstract int idForGet { get;}
        private protected abstract int idForUpdate { get;}
        private protected abstract int idForDelete { get;}        

        public List<string> GetTotalFieldList()
        {
            List<string> fieldList = GetBasicFieldList();
            fieldList.AddRange(Util.GetListFromCommaSepString(fields));
            if (versionable)
            {
                fieldList.AddRange(GetVersionFieldList());
            }
            return fieldList;
        }

        public List<string> GetFieldList()
        {
            return Util.GetListFromCommaSepString(fields);            
        }

        public List<string> GetMandatoryFieldList()
        {
            return Util.GetListFromCommaSepString(mandatoryFields);
        }

        public List<string> GetUniqueFieldList()
        {
            return Util.GetListFromCommaSepString(uniqueFields);
        }

        public List<string> GetBasicFieldList()
        {
            return Enum.GetNames(typeof(EnumMetaDataFields)).ToList();
        }

        public List<string> GetVersionFieldList()
        {
            return Enum.GetNames(typeof(EnumVersionMetaDataFields)).ToList();
        }

        private void FieldExistsInResponse(ResponseData responseData)
        {
            List<string> expectedFieldList = GetFieldList();
            List<Dictionary<string, string>> responseValues = responseData.ResponseValues;
            foreach (Dictionary<string, string> keyValues in responseValues)
            {               
                foreach (string fieldName in expectedFieldList)
                {
                    SoftAssert.True(keyValues.ContainsKey(fieldName), fieldName + " " + Constants.ERROR_MESSAGE_FIELD_DOESNT_EXISTS);
                }
                
            }
        }

        protected ResponseData RunGetTest()
        {
            ResponseData responseDataGetAll = RestUtil.GetMethod(apiName);
            SoftAssert.True(RestUtil.IsStatusCodeOk(responseDataGetAll.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_OK);

            // Code to display request and reponse details incase of error
            if (!RestUtil.IsStatusCodeOk((int)responseDataGetAll.StatusCode))
            {
                throw new Exception("API NAme :" + responseDataGetAll.APIName + System.Environment.NewLine +" Response : " + responseDataGetAll.Content); 
            }

            return responseDataGetAll;
        }

        protected ResponseData RunGetByIDTest()
        {
            ResponseData responseDataGetById = RestUtil.GetByIdMethod(apiName, idForGet);
            SoftAssert.True(RestUtil.IsStatusCodeOk(responseDataGetById.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_OK);
            
            // Code to display request and reponse details incase of error
            if (!RestUtil.IsStatusCodeOk((int)responseDataGetById.StatusCode))
            {
                throw new Exception("API NAme :" + responseDataGetById.APIName + System.Environment.NewLine + " Response : " + responseDataGetById.Content );
            }

            FieldExistsInResponse(responseDataGetById);
            return responseDataGetById;
        }

        protected ResponseData RunPostTest()
        {

            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();
            foreach (string fieldName in GetFieldList())
            {
                string randomString = Util.RandomString(8);
                if (GetUniqueFieldList().Contains(fieldName))
                {
                    inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                }
                else
                {   
                    if(crossRefFields != null && crossRefFields.ContainsKey(fieldName)){
                        int key = RestUtil.GetFirstId(crossRefFields[fieldName]);
                        inputKeyValues.Add(fieldName, key.ToString());
                    }else if(defaultValueFields != null && defaultValueFields.ContainsKey(fieldName))
                    {
                        inputKeyValues.Add(fieldName, defaultValueFields[fieldName]);
                    }
                    else 
                    {
                        inputKeyValues.Add(fieldName, "Regression Test Insert-" + randomString);
                    }
                    
                }
            }

            ResponseData responseData = RestUtil.PostMethod(apiName, inputKeyValues);
            SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);

            // Code to display request and reponse details incase of error
            if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
            {
                throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
            }


            List<string> expectedFieldList = GetTotalFieldList();
            List<Dictionary<string, string>> responseValues = responseData.ResponseValues;

            foreach (Dictionary<string, string> keyValues in responseValues)
            {
                foreach (string fieldName in expectedFieldList)
                {
                    SoftAssert.True(keyValues.ContainsKey(fieldName), fieldName + " " + Constants.ERROR_MESSAGE_FIELD_DOESNT_EXISTS);
                }

                foreach (string fieldName in keyValues.Keys)
                {
                    string value = keyValues[fieldName];
                    if (fieldName == EnumMetaDataFields.deleteInd.ToString())
                    {
                        SoftAssert.True(value == "N", Constants.ERROR_MESSAGE_DELETE_IND_NOT_N);
                    }else if (fieldName == EnumMetaDataFields.metaQualityCd.ToString()
                        || fieldName == EnumMetaDataFields.metaCreatedDttm.ToString()
                            || fieldName == EnumMetaDataFields.metaChangedDttm.ToString()
                                || fieldName == EnumMetaDataFields.recordEntryDttm.ToString())
                    {                        
                        SoftAssert.True(!String.IsNullOrEmpty(value), fieldName + " " + Constants.ERROR_MESSAGE_FIELD_VALUE_EMPTY);
                    }else if (fieldName == EnumMetaDataFields.metaActionCd.ToString())
                    {                        
                        SoftAssert.True(!String.IsNullOrEmpty(value), fieldName + " " + Constants.ERROR_MESSAGE_FIELD_VALUE_EMPTY);
                        SoftAssert.True(value == "I", "Meta Action Cd value is not 'I'");
                    }

                    if (inputKeyValues.ContainsKey(fieldName))
                    {                     
                        string inputValue = inputKeyValues[fieldName];
                        SoftAssert.True(value == inputValue, "Response Value doesnt not Equal to Input Value for Field : " + fieldName);
                    }

                }
            }
            return responseData;
        }


        protected ResponseData RunPostUniqueFieldsTest()
        {
            //SoftAssert.True(GetUniqueFieldList().Count > 0, "Not Executed.No Unique Field List to Test");
            if(GetUniqueFieldList().Count == 0)
            {
                return null;
            }

            ResponseData responseDataGetById = RestUtil.GetByIdMethod(apiName, idForGet);
            SoftAssert.True(responseDataGetById.ResponseCount > 0, "Not Executed.Not able to final record to Copy :" + idForGet);

            Dictionary<string, string> existingKeyValues = responseDataGetById.ResponseValues[0];


            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();
            foreach (string fieldName in GetFieldList())
            {
                if (GetUniqueFieldList().Contains(fieldName))
                {
                    inputKeyValues.Add(fieldName, existingKeyValues[fieldName]);
                }
                else
                {
                    inputKeyValues.Add(fieldName, "Regression Test Put Unique Field Test");
                }
                
            }

            ResponseData responseData = RestUtil.PostMethod(apiName, inputKeyValues);
            SoftAssert.True(RestUtil.IsStatusCodeBadRequest(responseData.StatusCode), "Allowed Duplicate Value ");
            
            return responseData;
        }

        protected ResponseData RunPostMandatoryFieldsTest()

        {
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();
            foreach (string fieldName in GetFieldList())
            {
                string randomString = Util.RandomString(8);
                if (GetUniqueFieldList().Contains(fieldName))
                {
                    inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                }
                else
                {
                    if (crossRefFields != null && crossRefFields.ContainsKey(fieldName))
                    {
                        int key = RestUtil.GetFirstId(crossRefFields[fieldName]);
                        inputKeyValues.Add(fieldName, key.ToString());
                    }
                    else
                    {
                        inputKeyValues.Add(fieldName, "Regression Test Put Mandatory Field Test");
                    }

                }                
            }

            ResponseData responseData = null;
            foreach (string fieldName in GetMandatoryFieldList())
            {
                Dictionary<string, string> inputKeyValuesTemp = new Dictionary<string, string>(inputKeyValues);
                inputKeyValuesTemp[fieldName] = null;
                responseData = RestUtil.PostMethod(apiName, inputKeyValuesTemp);
                SoftAssert.True(RestUtil.IsStatusCodeBadRequest(responseData.StatusCode), "Allowed Null value for Mandatory Field :" + fieldName );
            }
            
            return responseData;
        }

        protected ResponseData RunPutTest()
        {
            
            ResponseData responseDataGetById = RestUtil.GetByIdMethod(apiName, idForUpdate);

            Dictionary<string, string> inputKeyValues = responseDataGetById.ResponseValues[0];

            Dictionary<string, string> updatedInputKeyValues = new Dictionary<string, string>();

            foreach (string fieldName in inputKeyValues.Keys)
            {
                Boolean isCrossRefField = crossRefFields != null && crossRefFields.ContainsKey(fieldName);
                Boolean isDefaultValueField = defaultValueFields != null && defaultValueFields.ContainsKey(fieldName);
                if (!isDefaultValueField && !GetUniqueFieldList().Contains(fieldName) && !GetBasicFieldList().Contains(fieldName) && !isCrossRefField && !GetVersionFieldList().Contains(fieldName))
                {
                    updatedInputKeyValues.Add(fieldName, "Regression Test Update");
                }
                else
                {
                    updatedInputKeyValues.Add(fieldName, inputKeyValues[fieldName]);
                }
            }

            ResponseData responseData = RestUtil.PutMethod(apiName, updatedInputKeyValues, idForUpdate);
            Boolean newVersion = RestUtil.IsStatusCodeCreated(responseData.StatusCode);
            Boolean statusCodeValid = RestUtil.IsStatusCodeOk(responseData.StatusCode) || newVersion ;
            SoftAssert.True(statusCodeValid, Constants.ERROR_MESSAGE_STATUS_CODE_OK);

            // Code to display request and reponse details incase of error
            if (!(RestUtil.IsStatusCodeCreated((int)responseData.StatusCode) || RestUtil.IsStatusCodeOk((int)responseData.StatusCode)))
            {
                throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
            }


            List<string> expectedFieldList = GetTotalFieldList();
            List<Dictionary<string, string>> responseValues = responseData.ResponseValues;

            foreach (Dictionary<string, string> keyValues in responseValues)
            {
                foreach (string fieldName in expectedFieldList)
                {
                    SoftAssert.True(keyValues.ContainsKey(fieldName), fieldName + ":" + Constants.ERROR_MESSAGE_FIELD_DOESNT_EXISTS);
                }

                foreach (string fieldName in keyValues.Keys)
                {
                    string value = keyValues[fieldName];
                    if (fieldName == EnumMetaDataFields.id.ToString() && !newVersion)
                    {
                        SoftAssert.True(value == idForUpdate.ToString(), "Response Value doesnot not Equal to Input Value for Field : " + fieldName);
                    }else if (fieldName == EnumMetaDataFields.deleteInd.ToString())
                    {
                        SoftAssert.True(value == "N", Constants.ERROR_MESSAGE_DELETE_IND_NOT_N);
                    }else if (fieldName == EnumMetaDataFields.metaQualityCd.ToString()
                        || fieldName == EnumMetaDataFields.metaCreatedDttm.ToString()
                            || fieldName == EnumMetaDataFields.metaChangedDttm.ToString()
                                || fieldName == EnumMetaDataFields.recordEntryDttm.ToString())
                    {                       
                        SoftAssert.True(!String.IsNullOrEmpty(value), fieldName + " " + Constants.ERROR_MESSAGE_FIELD_VALUE_EMPTY);
                    }else if (fieldName == EnumMetaDataFields.metaActionCd.ToString())
                    {                        
                        SoftAssert.True(!String.IsNullOrEmpty(value), fieldName + " " + Constants.ERROR_MESSAGE_FIELD_VALUE_EMPTY);
                        if (newVersion)
                        {
                            SoftAssert.True(value == "I", "Meta Action Cd value is not 'I'");
                        }
                        else
                        {
                            SoftAssert.True(value == "U", "Meta Action Cd value is not 'U'");
                        }
                    }else if(fieldName == EnumVersionMetaDataFields.versionActiveInd.ToString())
                    {                        
                        SoftAssert.True(!String.IsNullOrEmpty(value), fieldName + " " + Constants.ERROR_MESSAGE_FIELD_VALUE_EMPTY);
                        SoftAssert.True(value == "Y", "Version Active Ind value is not 'Y'");
                    }else if(fieldName == EnumVersionMetaDataFields.versionEffectiveDt.ToString())
                    {
                        if (newVersion)
                        {                            
                            SoftAssert.True(!String.IsNullOrEmpty(value), fieldName + " " + Constants.ERROR_MESSAGE_FIELD_VALUE_EMPTY);
                            DateTime versionEffectiveDt = DateTime.Parse(value);
                            SoftAssert.True(DateTime.Now.Date.Equals(versionEffectiveDt.Date), "Version Effective Date is not correct.It should be " + DateTime.Now.Date);
                        }
                    }

                    if (GetFieldList().Contains(fieldName))
                    {                        
                        string inputValue = updatedInputKeyValues[fieldName];
                        SoftAssert.True(value == inputValue, "Response Value doesnt not Equal to Input Value for Field : " + fieldName);
                    }

                }
            }
            return responseData;

        }


        protected ResponseData RunPutUniqueFieldsTest()
        {
            if (GetUniqueFieldList().Count == 0)
            {
                return null;
            }

            int[] getResponseRecords = RestUtil.GetAllRecordIds(apiName);

            if (getResponseRecords.Length>1)
            {
                ResponseData responseDataGetById = RestUtil.GetByIdMethod(apiName, idForGet);
                SoftAssert.True(responseDataGetById.ResponseCount > 0, "Not Executed.Not able to final record to Copy :" + idForGet);
                Dictionary<string, string> existingKeyValues = responseDataGetById.ResponseValues[0];

                if (int.Parse(existingKeyValues["id"])==idForUpdate)
                {
                    responseDataGetById = RestUtil.GetByIdMethod(apiName, getResponseRecords[1]);
                    SoftAssert.True(responseDataGetById.ResponseCount > 0, "Not Executed.Not able to final record to Copy :" + idForGet);
                    existingKeyValues = responseDataGetById.ResponseValues[0];
                }
               

                ResponseData responseDataForUpdate = RestUtil.GetByIdMethod(apiName, idForUpdate);
                SoftAssert.True(responseDataForUpdate.ResponseCount > 0, "Not Executed.Not able to find record to Update :" + idForUpdate);
                Dictionary<string, string> inputKeyValues = responseDataForUpdate.ResponseValues[0];

                Dictionary<string, string> updatedInputKeyValues = new Dictionary<string, string>();
                updatedInputKeyValues = inputKeyValues;

                foreach (string fieldName in GetFieldList())
                {
                    if (GetUniqueFieldList().Contains(fieldName))
                    {
                        updatedInputKeyValues[fieldName] = existingKeyValues[fieldName];
                    }
                }

                ResponseData responseData = RestUtil.PutMethod(apiName, updatedInputKeyValues, idForUpdate);
                SoftAssert.True(RestUtil.IsStatusCodeBadRequest(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);

                return responseData;
            }
            else
            {
                Console.WriteLine("Not able to test PUT Unique field validations since API Returns only one record");
                return null;
            }

           
        }

        protected ResponseData RunPutMandatoryFieldsTest()

        {  
            ResponseData responseDataForUpdate = RestUtil.GetByIdMethod(apiName, idForUpdate);
            SoftAssert.True(responseDataForUpdate.ResponseCount > 0, "Not Executed.Not able to find record to Update :" + idForUpdate);
            Dictionary<string, string> inputKeyValues = responseDataForUpdate.ResponseValues[0];

            ResponseData responseData = null;
            foreach (string fieldName in GetMandatoryFieldList())
            {
                Dictionary<string, string> inputKeyValuesTemp = new Dictionary<string, string>(inputKeyValues);
                inputKeyValuesTemp[fieldName] = null;
                responseData = RestUtil.PutMethod(apiName, inputKeyValuesTemp, idForUpdate);
                SoftAssert.True(RestUtil.IsStatusCodeBadRequest(responseData.StatusCode), "Allowed Null value for Mandatory Field :" + fieldName);
            }
            return responseData;
        }

    protected ResponseData RunDeleteTest()
        {
            ResponseData responseData = RestUtil.DeleteMethod(apiName, idForDelete);
            SoftAssert.True(RestUtil.IsStatusCodeOk(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_OK);
            return responseData;
        }

    }
}
