﻿using APITestSuite;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace MasterDataTestSuite
{
    public class MasterDataTest : BaseMasterDataTest
    {
        private protected override string fields => Fields; 
        private protected override string mandatoryFields => MandatoryFields;
        private protected override string uniqueFields => UniqueFields;
        private protected override string apiName => ApiName;
        private protected override int idForGet => IdForGet;
        private protected override int idForUpdate => IdForUpdate;
        private protected override int idForDelete => IdForDelete;
        private protected override string cdInitial => CDInitials;
        private protected override Boolean versionable => Versionable;
        private protected override Dictionary<string, string> crossRefFields => CrossRefFields;
        private protected override Dictionary<string, string> defaultValueFields => DefaultValueFields;

        private string Fields = null;
        private string MandatoryFields = null;
        private string UniqueFields = null;
        private string ApiName = null;
        private int IdForGet = -1;
        private int IdForUpdate = -1;
        private int IdForDelete = -1;

        private string CDInitials = null;
        private Boolean Versionable = false;
        private Dictionary<string, string> CrossRefFields = null;
        private Dictionary<string, string> DefaultValueFields = null;

        private List<string> errors = new List<string>();
        private Boolean postSuccess = true;

        [Theory]
        [ClassData(typeof(TestDataGenerator))]
        public static void RunMasterDataTest(AppInputData inputData)
        {
            MasterDataTest masterDataTest = new MasterDataTest();

            masterDataTest.Fields = inputData.fields;
            masterDataTest.MandatoryFields = inputData.mandatoryFields;
            masterDataTest.UniqueFields = inputData.uniqueFields;
            masterDataTest.ApiName = inputData.apiName;
            masterDataTest.CDInitials = inputData.cdInitials;
            masterDataTest.Versionable = inputData.versionable != null && inputData.versionable == "Y";
            List<CrossRefFields> crossRefFieldList = inputData.crossRefFields;
            if (crossRefFieldList != null)
            {
                masterDataTest.CrossRefFields = new Dictionary<string, string>();
                foreach (CrossRefFields crossRefField in crossRefFieldList)
                {
                    masterDataTest.CrossRefFields.Add(crossRefField.field, crossRefField.apiName);
                }
            }

            List<AssetUnitsTestDataFields> defaultValueFieldList = inputData.defaultValueFields;
            if (defaultValueFieldList != null)
            {
                masterDataTest.DefaultValueFields = new Dictionary<string, string>();
                foreach (AssetUnitsTestDataFields defaultValueField in defaultValueFieldList)
                {
                    masterDataTest.DefaultValueFields.Add(defaultValueField.field, defaultValueField.value);
                }
            }

            masterDataTest.TestPost();

            masterDataTest.TestGet();
            masterDataTest.TestGetById();

            masterDataTest.TestPostUniqueFields();
            masterDataTest.TestPostMandatoryFields();

            masterDataTest.TestPut();
            masterDataTest.TestPutUniqueFields();
            masterDataTest.TestPutMandatoryFields();

            masterDataTest.TestDelete();
            
            Assert.True(masterDataTest.errors.Count == 0, masterDataTest.ApiName + ":" + "\n" + string.Join("\n ", masterDataTest.errors.Select(s => $"'{s}'")));
        }

        private void TestGet()
        {
            try
            {
                ResponseData responseDataGetAll = RunGetTest();
                Dictionary<string, string> responseValues = responseDataGetAll.ResponseValues[0];
                IdForGet = int.Parse(responseValues["id"]);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void TestGetById()
        {
            try
            {
                RunGetByIDTest();
            }
            catch (Exception e)
            {
                errors.Add("Get By Id : " + e.Message);
            }

        }
           
        private void TestPost()
        {
            try
            {
                ResponseData responseDataPost = RunPostTest();
                Dictionary<string, string> responseValues = responseDataPost.ResponseValues[0];
                int newIdCreated = int.Parse(responseValues["id"]);
                IdForUpdate = newIdCreated;
                IdForDelete = newIdCreated;
            }
            catch (Exception e)
            {
                errors.Add("Post : " + e.Message);
                postSuccess = false;
            }
        }

        private void TestPostUniqueFields()
        {
            try
            {
                RunPostUniqueFieldsTest();
            }
            catch (Exception e)
            {
                errors.Add("Post Unique Fields Test : " + e.Message);
            }
        }

        private void TestPostMandatoryFields()
        {
            try
            {
                
                RunPostMandatoryFieldsTest();
            }
            catch (Exception e)
            {
                errors.Add("Post Mandatory Fields Test : " + e.Message);
            }
        }

        private void TestPut()
        {
            if (postSuccess)
            {
                try
                {
                    RunPutTest();
                }
                catch (Exception e) { errors.Add("Put : " + e.Message); }
            }
            else
            {
                errors.Add("Put : Not Executed");
            }
        }

        private void TestPutUniqueFields()
        {
            try
            {
                RunPutUniqueFieldsTest();
            }
            catch (Exception e)
            {
                errors.Add("Put Unique Fields Test : " + e.Message);
            }
        }

        private void TestPutMandatoryFields()
        {
            try
            {
                RunPutMandatoryFieldsTest();
            }
            catch (Exception e)
            {
                errors.Add("Put Mandatory Fields Test : " + e.Message);
            }
        }

        private void TestDelete()
        {
            if (postSuccess)
            {
                try
                {
                    RunDeleteTest();
                }
                catch (Exception e) { errors.Add("Delete : " + e.Message); }
            }
            else
            {
                errors.Add("Delete : Not Executed");
            }
        }
    }
}

