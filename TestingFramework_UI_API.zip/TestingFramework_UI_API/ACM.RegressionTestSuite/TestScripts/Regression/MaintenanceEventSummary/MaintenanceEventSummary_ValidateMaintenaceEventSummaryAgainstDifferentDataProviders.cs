﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using APITestSuite;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RegressionTestSuite.RegressionTestData.MaintenanceEventSummary;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.MaintenanceEventSummary
{
    public class MaintenanceEventSummary_ValidateMaintenaceEventSummaryAgainstDifferentDPs
    {

        private List<string> errors = new List<string>();
        List<int> assetunits = new List<int>();
        string ApiName = null;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_MaintenanceEventSummary_ValidateMaintenaceEventSummaryAgainstDifferentDPs", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void AddMaintenanceEventSummaryValidateAgainstDPTest(AppInputData inputData)
        {

            MaintenanceEventSummary_ValidateMaintenaceEventSummaryAgainstDifferentDPs MaintenanceEventSummaryValidateAgainstDP = new MaintenanceEventSummary_ValidateMaintenaceEventSummaryAgainstDifferentDPs();
            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            List<MaintenanceEventField> maintenanceEventFieldList1 = inputData.maintenanceEventField1;
            List<MaintenanceEventField> maintenanceEventFieldList2 = inputData.maintenanceEventField2;

            MaintenanceEventSummaryValidateAgainstDP.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;            
            string cdInitial = inputData.cdInitials;
            string assetUnitName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();

            List<FilterField> filterFieldList = inputData.filterField;
            List<string> Filtervalue = null;
            Dictionary<string, List<string>> filterFieldsList = new Dictionary<string, List<string>>();
            
            foreach (FilterField fieldname in filterFieldList)
            {
                Filtervalue = Util.GetListFromCommaSepString(fieldname.value);
                filterFieldsList.Add(fieldname.field, Filtervalue);
            }

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            int assetkey = int.Parse(inputKeyValues["assetKey"]);

            //Creating New Asset Unit and to get asset unit key
            MaintenanceEventSummaryValidateAgainstDP.CreateNewAssetUnit(inputKeyValues);
            MaintenanceEventSummaryValidateAgainstDP.assetunits.Add(MaintenanceEventSummaryValidateAgainstDP.GetAssetUnitKey(assetUnitName));

            // Code to Add planned Maintenance Event With Dp = 1
            MaintenanceEventSummaryValidateAgainstDP.AddMaintenanceEvent(inputData.maintenanceEventField1,MaintenanceEventSummaryValidateAgainstDP.assetunits);
            
            // Code to add Unplanned Maintenance Event with Dp = 2
            MaintenanceEventSummaryValidateAgainstDP.AddMaintenanceEvent(inputData.maintenanceEventField2,MaintenanceEventSummaryValidateAgainstDP.assetunits);

            // Code to add longterm shutdown Maintenance Event with Dp = 9
            MaintenanceEventSummaryValidateAgainstDP.AddMaintenanceEvent(inputData.maintenanceEventField3, MaintenanceEventSummaryValidateAgainstDP.assetunits);

            // Validating Maintenance Event Summary response data after adding above Maintenance Events with default filters (year Range = 10 ; DP = 1,2,3)
            MaintenanceEventSummaryValidateAgainstDP.RunValidateResponseData(inputData.validationParamFields, MaintenanceEventSummaryValidateAgainstDP.assetunits, assetkey, inputData.expectedFieldValues, 0);

            // Validating Maintenance Event Summary response data after adding above Maintenance Events (year Range = 10 ; DP = 1)
            MaintenanceEventSummaryValidateAgainstDP.RunValidateResponseData(inputData.validationParamFields, MaintenanceEventSummaryValidateAgainstDP.assetunits, assetkey, inputData.expectedFieldValues, 0, dpList: new List<string> { filterFieldsList["dp"][0]});

            // Validating Maintenance Event Summary response data after adding above Maintenance Events (year Range = 10 ; DP = 2)
            MaintenanceEventSummaryValidateAgainstDP.RunValidateResponseData(inputData.validationParamFields, MaintenanceEventSummaryValidateAgainstDP.assetunits, assetkey, inputData.expectedFieldValues, 1, dpList: new List<string> { filterFieldsList["dp"][1] });

            // Validating Maintenance Event Summary response data after adding above Maintenance Events (year Range = 10 ; DP = 9)
            MaintenanceEventSummaryValidateAgainstDP.RunValidateResponseData(inputData.validationParamFields, MaintenanceEventSummaryValidateAgainstDP.assetunits, assetkey, inputData.expectedFieldValues, 2, dpList: new List<string> { filterFieldsList["dp"][2] });

            Assert.True(MaintenanceEventSummaryValidateAgainstDP.errors.Count == 0, MaintenanceEventSummaryValidateAgainstDP.ApiName + ":" + "\n" + string.Join("\n ", MaintenanceEventSummaryValidateAgainstDP.errors.Select(s => $"'{s}'")));
        }
           
        private int GetAssetUnitKey(string assetUnitName)
        {
            int assetUnitKey = 0;
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return assetUnitKey;
        }
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void AddMaintenanceEvent<T>(List<T> inputData, List<int> assetUnitKey)
        {
            String AssetUnitKeyList = "" ;
            Dictionary<string, string> assetUnitMaintenanceEventFields = RestUtils.RunAssetUnitMaintenanceEvents(inputData);
            ResponseData responseData = new ResponseData();

            string APIName = assetUnitMaintenanceEventFields["APIName"];
            assetUnitMaintenanceEventFields.Remove("APIName");

            foreach (int assetUnit in assetUnitKey)
            {
                if (AssetUnitKeyList == "")
                {
                    AssetUnitKeyList = assetUnit.ToString() ;
                }
                else
                {
                    AssetUnitKeyList = AssetUnitKeyList + "," +assetUnit.ToString();
                }
            }
            assetUnitMaintenanceEventFields.Remove("assetUnitKey");
            assetUnitMaintenanceEventFields.Add("assetUnitKey", "["+ AssetUnitKeyList + "]");

            try
            {
                responseData = RestUtils.PostMethod(APIName, assetUnitMaintenanceEventFields);
                if (!(RestUtil.IsStatusCodeCreated((int)responseData.StatusCode) || RestUtil.IsStatusCodeOk((int)responseData.StatusCode)))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "API Request :" + responseData.RequestBody);
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private int[] GetAssetUnitMaintenanceEventKey(int assetUnitKey, int yearRange)
        {
            int[] maintenanceEventKeys;
            String APIName = "AssetUnitEvents?" + "UnitId = " + assetUnitKey+"&yearRange="+yearRange;


            try
            {
                maintenanceEventKeys = RestUtil.GetAllRecordIds(APIName);
                return maintenanceEventKeys;
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return null;
        }

        private void RunValidateResponseData<T>(List<T> validationParamFields, List<int> assetUnitsList, int assetKey, List<ExpectedFieldValues> expectedFieldValues, int k, string startDate = " ", string endDate = " ", List<string> dpList = null)
        {
            try
            {
                string APIParameters = RestUtils.GetMaintenanceEventSummaryRequestURLdata(validationParamFields, assetUnitsList, assetKey, startDate, endDate, dpList);
                RunIncrementalCapacitiesAPI(APIParameters, assetUnitsList, expectedFieldValues, k);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private static void RunIncrementalCapacitiesAPI(string APIParameters, List<int> assetUnitsList, List<ExpectedFieldValues> expectedFieldValues, int F)
        {

            string ApiName = APIParameters;
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            var BaseURL = config["TargetUri"];
            string URL = BaseURL + ApiName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);

            DateTime dt = DateTime.Now;

            Dictionary<string, List<string>> expectedFieldList = AssetCapacityUtils.expectedFieldValuesList(expectedFieldValues);

            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                var MaintenanceEventSummaryDataList = JsonConvert.DeserializeObject<MaintenenaceEventSummary>(restResponse.Content);

                AssetCapacityUtils.RunValidateData(MaintenanceEventSummaryDataList.pageNumber.ToString(), expectedFieldList["pageNumber"][0], "Page Number is Incorrect or Empty");
                AssetCapacityUtils.RunValidateData(MaintenanceEventSummaryDataList.pageSize.ToString(), expectedFieldList["pageSize"][0], "Page Size is Incorrect or Empty");

                int i = F;
                foreach (MaintenanceEventDataList dataitem in MaintenanceEventSummaryDataList.maintenanceEventDataList)
                {
                    AssetCapacityUtils.RunValidateData(dataitem.countryNm, expectedFieldList["countryNm"][i], "countryNm is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.asset, expectedFieldList["assetName"][i], "assetName is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.unitSubType, expectedFieldList["unitSubtypeName"][i], "unitSubtypeName is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.unitTypeKey.ToString(), expectedFieldList["unitTypeKey"][i], "unitTypeKey is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.unitType, expectedFieldList["unitType"][i], "unitType is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.eventTypeKey.ToString(), expectedFieldList["eventTypeKey"][i], "eventTypeKey is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.eventType, expectedFieldList["eventType"][i], "eventType is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.startDate.ToString(), expectedFieldList["startDate"][i], "startDate is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.endDate.ToString(), expectedFieldList["endDate"][i], "endDate is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.offlinePCT.ToString(), expectedFieldList["offlinePCT"][i], "offlinePCT is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.dataProviderKey.ToString(), expectedFieldList["dataProviderKey"][i], "dataProviderKey is Incorrect or Empty");
                    AssetCapacityUtils.RunValidateData(dataitem.dataProviderName, expectedFieldList["dataProviderName"][i], "dataProviderName is Incorrect or Empty");
                    
                    i++;
                }
            }
        }

    }
}
