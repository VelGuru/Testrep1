﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using APITestSuite;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RegressionTestSuite.RegressionTestData.MaintenanceEventSummary;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.MaintenanceEventSummary
{
    public class MaintenanceEventSummary_ValidateLastUpdatedSince
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        List<int> assetunits = new List<int>();
        int EventKey = 0;
        string ApiName = null;
        string xPath = null;
        string offlineCapacityPct = null;



        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_MaintenanceEventSummary_ValidateLastUpdatedSince", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void MaintenanceEventSummaryValidateLastUpdatedSinceTest(AppInputData inputData)
        {
            MaintenanceEventSummary_ValidateLastUpdatedSince MaintenanceEventSummaryValidateLastUpdatedSince = new MaintenanceEventSummary_ValidateLastUpdatedSince();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
            MaintenanceEventSummaryValidateLastUpdatedSince.ApiName = inputData.apiName;
            MaintenanceEventSummaryValidateLastUpdatedSince.xPath = inputData.xpath;

            // Function Call to get asset unit which contains active maintenance events.
            MaintenanceEventSummaryValidateLastUpdatedSince.assetUnitKey = MaintenanceEventSummaryValidateLastUpdatedSince.GetAssetUnitKeyWithActiveMaintenanceEventKey("asset_unit_key");
            MaintenanceEventSummaryValidateLastUpdatedSince.assetunits.Add(MaintenanceEventSummaryValidateLastUpdatedSince.assetUnitKey);

            // Function Call to get recent maintenance Event key.
            MaintenanceEventSummaryValidateLastUpdatedSince.EventKey = MaintenanceEventSummaryValidateLastUpdatedSince.GetAssetUnitMaintenanceEventKey(MaintenanceEventSummaryValidateLastUpdatedSince.assetUnitKey, "assetUnitEventKey");

            // Function call to get event  OfflinePCT Value for before updating 
            MaintenanceEventSummaryValidateLastUpdatedSince.offlineCapacityPct = MaintenanceEventSummaryValidateLastUpdatedSince.GetAssetUnitCapacityEventValue(MaintenanceEventSummaryValidateLastUpdatedSince.EventKey, "$.[0].offlineCapacityPct");

            // code to update  OfflinePCT value for existing event
            MaintenanceEventSummaryValidateLastUpdatedSince.UpdateAssetUnitCapacityEvent(MaintenanceEventSummaryValidateLastUpdatedSince.EventKey, MaintenanceEventSummaryValidateLastUpdatedSince.assetUnitKey, "offlineCapacityOriginal", "85");

            // Code to validate OfflinePCT with LastUpdatedSince date as today's date
            MaintenanceEventSummaryValidateLastUpdatedSince.ValidateMaintenanceEventSummaryAgainstSinceLastUpdated(inputData.validationParamFields, MaintenanceEventSummaryValidateLastUpdatedSince.EventKey, MaintenanceEventSummaryValidateLastUpdatedSince.assetunits, "85", RestUtils.getCurrentDate());

            Assert.True(MaintenanceEventSummaryValidateLastUpdatedSince.errors.Count == 0, MaintenanceEventSummaryValidateLastUpdatedSince.ApiName + ":" + "\n" + string.Join("\n ", MaintenanceEventSummaryValidateLastUpdatedSince.errors.Select(s => $"'{s}'")));

        }

        private int GetAssetUnitKeyWithActiveMaintenanceEventKey(string fieldName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetActiveMaintananceAssetUnitKeyData(fieldName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return assetUnitKey;
        }

        private int GetAssetUnitMaintenanceEventKey(int AssetUnitKey, string fieldName)
        {
            try
            {
                EventKey = int.Parse(RestUtil.GetFirstFieldValue("AssetUnitEvents?unitId=" + AssetUnitKey, "assetUnitEventKey"));
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return EventKey;
        }

        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null;

            String apiName = "AssetUnitEvents/{ MaintenanceEventId}/versions";
            apiName = apiName.Replace("{ MaintenanceEventId}", capacityEventKey.ToString());

            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateMaintenanceEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void ValidateMaintenanceEventSummaryAgainstSinceLastUpdated<T>(List<T> validationParamFields, int maintenanceEventkey, List<int> assetUnitsList, string ExpectedofflineCapacityPct, string LastUpdateDate)
        {
            try
            {
                string APIParameters = RestUtils.GetMaintenanceEventSummaryRequestURLdata(validationParamFields, assetUnitsList);
                if (LastUpdateDate == RestUtils.getYesterdaysDate())
                {
                    APIParameters = APIParameters.Replace("sinceLastUpdate=" + RestUtils.getCurrentDate(), "sinceLastUpdate=" + LastUpdateDate);
                }
                string ApiName = APIParameters;
                var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
                var BaseURL = config["TargetUri"];
                string URL = BaseURL + ApiName;
                var client = new RestClient(URL);
                var request = new RestRequest(Method.GET);
                client.Authenticator = new CustomAuthenticator();
                IRestResponse restResponse = client.Execute(request);

                if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
                {
                    var MaintenanceEventSummaryDataList = JsonConvert.DeserializeObject<MaintenenaceEventSummary>(restResponse.Content);
                    foreach (MaintenanceEventDataList dataitem in MaintenanceEventSummaryDataList.maintenanceEventDataList)
                    {
                        if (dataitem.assetUnitEventKey == maintenanceEventkey)
                        {
                            string ActualofflineCapacityPct = dataitem.offlinePCT.ToString();
                            Assert.True(ExpectedofflineCapacityPct == ActualofflineCapacityPct, string.Format("Field {0} expected {1} but got {2}", "offlineCapacityPct", ExpectedofflineCapacityPct, ActualofflineCapacityPct));
                        }
                    }
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}

