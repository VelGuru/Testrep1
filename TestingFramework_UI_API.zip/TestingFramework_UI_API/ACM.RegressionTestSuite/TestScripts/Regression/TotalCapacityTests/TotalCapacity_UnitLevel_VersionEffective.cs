﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.TotalCapacityTests
{
    public class TotalCapacity_UnitLevel_VersionEffective
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        List<int> assetunits = new List<int>();
        int capacityEventKey = 0;
        string ApiName = null;
        string xPath = null;
        decimal totalCapacityBeforeUpdate = 0;
        decimal eventCapacityValue = 0;
        decimal totalCapacityAfterUpdate = 0;

      
        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_TotalCapacity_UnitLevel_VersionEffective", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void TCUnitLevelVersionEffectiveDateTest(AppInputData inputData)
        {
            TotalCapacity_UnitLevel_VersionEffective TCUnitLevelVersionEffective = new TotalCapacity_UnitLevel_VersionEffective();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
            TCUnitLevelVersionEffective.ApiName = inputData.apiName;
            TCUnitLevelVersionEffective.xPath = inputData.xpath;

            // Function Call to get asset unit which contains active capacity events.
            TCUnitLevelVersionEffective.assetUnitKey = TCUnitLevelVersionEffective.GetAssetUnitWithActiveCapacityEventsKey("asset_unit_key");
            TCUnitLevelVersionEffective.assetunits.Add(TCUnitLevelVersionEffective.assetUnitKey);

            // Function call to get total capacity value before updating capacity events.
            string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(inputData.validationParamFields, TCUnitLevelVersionEffective.assetunits);
            TCUnitLevelVersionEffective.totalCapacityBeforeUpdate = decimal.Parse(RestUtils.GetAPIFieldValue(APIParameters, TCUnitLevelVersionEffective.xPath));
             
            // Function Call to get recent capacity Event key.
            TCUnitLevelVersionEffective.capacityEventKey = TCUnitLevelVersionEffective.GetAssetUnitCapacityEventKey(TCUnitLevelVersionEffective.assetUnitKey);

            // Function call to get event capcaity value for before updating capacity event
            TCUnitLevelVersionEffective.eventCapacityValue = decimal.Parse(TCUnitLevelVersionEffective.GetAssetUnitCapacityEventValue(TCUnitLevelVersionEffective.capacityEventKey, "$.[0].capacityUniversalQty"));

            // code to update recent capacity event value.
            TCUnitLevelVersionEffective.UpdateAssetUnitCapacityEvent(TCUnitLevelVersionEffective.capacityEventKey, TCUnitLevelVersionEffective.assetUnitKey, "capacityUniversalQty", "50");

            TCUnitLevelVersionEffective.totalCapacityAfterUpdate = TCUnitLevelVersionEffective.totalCapacityBeforeUpdate - TCUnitLevelVersionEffective.eventCapacityValue + 50;

            // Code to validate Total capacity Value with version effective date as today's date.
            TCUnitLevelVersionEffective.ValidateTotalCapacityWithVersionEffectiveDate(inputData.validationParamFields, TCUnitLevelVersionEffective.totalCapacityAfterUpdate, TCUnitLevelVersionEffective.assetunits, TCUnitLevelVersionEffective.xPath, RestUtils.getCurrentDate());

            // Code to validate Total capacity Value with version effective date as yesterday's date.
            TCUnitLevelVersionEffective.ValidateTotalCapacityWithVersionEffectiveDate(inputData.validationParamFields, TCUnitLevelVersionEffective.totalCapacityBeforeUpdate, TCUnitLevelVersionEffective.assetunits, TCUnitLevelVersionEffective.xPath, RestUtils.getYesterdaysDate());

        }


        private int GetAssetUnitWithActiveCapacityEventsKey(string fieldName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetActiveAssetUnitKeyData(fieldName);    
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return assetUnitKey;
        }

        private int GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey; 
            try
            {
                capacityEventKey = RestUtil.GetFirstId(APIName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return capacityEventKey;
        }


        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null; 

            String apiName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void ValidateTotalCapacityWithVersionEffectiveDate<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, string Xpath, String Date)
        {
            try
            {
                string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(validationParamFields, assetUnitsList);
                if (Date == RestUtils.getYesterdaysDate())
                { 
                    APIParameters = APIParameters.Replace("VersionDate="+RestUtils.getCurrentDate(), "VersionDate="+Date);
                }

                RestUtils.RunTotalCapacityByAsset(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}

