﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.TotalCapacityTests
{
    public class TotalCapacity_DeltaFunctionality_DeltaBetweenDataProviders
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        List<int> assetunits = new List<int>();
        int capacityEventKey = 0;
        string ApiName = null;
        string xPath = null;
        decimal totalCapacityBeforeUpdate = 0;
        decimal eventCapacityValue = 0;
        decimal totalCapacityAfterUpdate = 0;


        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_TotalCapacity_DeltaBetweenDataProviders", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void TotalCapacityDeltaBetweenVersions(AppInputData inputData)
        {
            TotalCapacity_DeltaFunctionality_DeltaBetweenDataProviders TotalCapacityDeltaBetweenVersions = new TotalCapacity_DeltaFunctionality_DeltaBetweenDataProviders();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
            TotalCapacityDeltaBetweenVersions.ApiName = inputData.apiName;
            TotalCapacityDeltaBetweenVersions.xPath = inputData.xpath;

            // Function Call to get asset unit which contains active capacity events.
            TotalCapacityDeltaBetweenVersions.assetUnitKey = TotalCapacityDeltaBetweenVersions.GetAssetUnitWithOriginalAndBaselineCapacityEventsKey();
            TotalCapacityDeltaBetweenVersions.assetunits.Add(TotalCapacityDeltaBetweenVersions.assetUnitKey);

        }

        private int GetAssetUnitWithOriginalAndBaselineCapacityEventsKey()
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetActiveAssetUnitKeyData("asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return assetUnitKey;
        }
    }
}






