﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.TotalCapacityTests
{

    public class TotalCapacity_UnitSubTypeLevel_VersionEffective
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        List<int> assetunits = new List<int>();
        int capacityEventKey = 0;
        string ApiName = null;
        string xPath = null;
        decimal totalCapacityBeforeUpdate = 0;
        decimal eventCapacityValue = 0;
        decimal totalCapacityAfterUpdate = 0;

      
        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_TotalCapacity_UnitSubTypeLevel_VersionEffective", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void TCUnitSubTypeLevelVersionEffective(AppInputData inputData)
        {
            TotalCapacity_UnitSubTypeLevel_VersionEffective TCUnitSubTypeLevelVersionEffective = new TotalCapacity_UnitSubTypeLevel_VersionEffective();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
            TCUnitSubTypeLevelVersionEffective.ApiName = inputData.apiName;
            TCUnitSubTypeLevelVersionEffective.xPath = inputData.xpath;

            // Function Call to get asset unit which contains active capacity events.
            TCUnitSubTypeLevelVersionEffective.assetUnitKey = TCUnitSubTypeLevelVersionEffective.GetAssetUnitWithActiveCapacityEventsKey();
            TCUnitSubTypeLevelVersionEffective.assetunits.Add(TCUnitSubTypeLevelVersionEffective.assetUnitKey);

            // Function call to get total capacity value in Unit Level before updating capacity events.
            string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(inputData.validationParamFields, TCUnitSubTypeLevelVersionEffective.assetunits);
            TCUnitSubTypeLevelVersionEffective.totalCapacityBeforeUpdate = decimal.Parse(RestUtils.GetAPIFieldValue(APIParameters, TCUnitSubTypeLevelVersionEffective.xPath));

            // Function Call to get recent capacity Event key.
            TCUnitSubTypeLevelVersionEffective.capacityEventKey = TCUnitSubTypeLevelVersionEffective.GetAssetUnitCapacityEventKey(TCUnitSubTypeLevelVersionEffective.assetUnitKey);

            // Function call to get event capcaity value for before updating capacity event
            TCUnitSubTypeLevelVersionEffective.eventCapacityValue = decimal.Parse(TCUnitSubTypeLevelVersionEffective.GetAssetUnitCapacityEventValue(TCUnitSubTypeLevelVersionEffective.capacityEventKey, "$.[0].capacityUniversalQty"));

            // code to update recent capacity event value.
            TCUnitSubTypeLevelVersionEffective.UpdateAssetUnitCapacityEvent(TCUnitSubTypeLevelVersionEffective.capacityEventKey, TCUnitSubTypeLevelVersionEffective.assetUnitKey, "capacityUniversalQty", "50");

            TCUnitSubTypeLevelVersionEffective.totalCapacityAfterUpdate = TCUnitSubTypeLevelVersionEffective.totalCapacityBeforeUpdate - TCUnitSubTypeLevelVersionEffective.eventCapacityValue + 50;

            // Code to validate Total capacity Value with version effective date as today's date.
            TCUnitSubTypeLevelVersionEffective.ValidateTotalCapacityWithVersionEffectiveDate(inputData.validationParamFields, TCUnitSubTypeLevelVersionEffective.totalCapacityAfterUpdate, TCUnitSubTypeLevelVersionEffective.assetunits, TCUnitSubTypeLevelVersionEffective.xPath, RestUtils.getCurrentDate());

            // Code to validate Total capacity Value with version effective date as yesterday's date.
            TCUnitSubTypeLevelVersionEffective.ValidateTotalCapacityWithVersionEffectiveDate(inputData.validationParamFields, TCUnitSubTypeLevelVersionEffective.totalCapacityBeforeUpdate, TCUnitSubTypeLevelVersionEffective.assetunits, TCUnitSubTypeLevelVersionEffective.xPath, RestUtils.getYesterdaysDate());

        }


        private int GetAssetUnitWithActiveCapacityEventsKey()
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetActiveAssetUnitKeyData("asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return assetUnitKey;
        }

        private int GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey; 
            try
            {
                capacityEventKey = RestUtil.GetFirstId(APIName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return capacityEventKey;
        }


        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null; 

            String apiName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void ValidateTotalCapacityWithVersionEffectiveDate<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, string Xpath, String Date)
        {
            try
            {
                string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(validationParamFields, assetUnitsList);
                if (Date == RestUtils.getYesterdaysDate())
                { 
                    APIParameters = APIParameters.Replace("VersionDate="+RestUtils.getCurrentDate(), "VersionDate="+Date);
                }

                RestUtils.RunTotalCapacityByAsset(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}

