﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.TotalCapacityTests
{

    public class TotalCapacity_UnitTypeLevel_EventDate
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
        string Xpath = null;
        decimal totalCapacity = 0;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_TotalCapacity_UnitTypeLevel_EventDate", MemberType = typeof(TotalCapacityTestDataGenerator))]
        private static void tCUnitTypeLevelEventDatesTest(AppInputData inputData)
        {
            TotalCapacity_UnitTypeLevel_EventDate tCUnitTypeLevelEventDate = new TotalCapacity_UnitTypeLevel_EventDate();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            tCUnitTypeLevelEventDate.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;
            tCUnitTypeLevelEventDate.Xpath = inputData.xpath;
            string cdInitial = inputData.cdInitials;
            string assetUnit1Name = null;
            string assetUnit2Name = null;
            Dictionary<string, string> assetUnit1TestData = new Dictionary<string, string>();
            Dictionary<string, string> assetUnit2TestData = new Dictionary<string, string>();
            List<int> assetunits = new List<int>();

            List<FilterField> filterFieldList = inputData.filterField;
            List<string> Filtervalue = null;

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        assetUnit1TestData.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnit1Name = assetUnit1TestData["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                assetUnit1TestData.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                assetUnit1TestData.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        assetUnit2TestData.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnit2Name = assetUnit2TestData["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {

                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                assetUnit2TestData.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                assetUnit2TestData.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }
            foreach (FilterField fieldname in filterFieldList)
            {
                Filtervalue = Util.GetListFromCommaSepString(fieldname.value);
            }

            //Adding new Asset unit getting the UnitKey
            tCUnitTypeLevelEventDate.CreateNewAssetUnit(assetUnit1TestData);
            tCUnitTypeLevelEventDate.GetAssetUnitKey(assetUnit1Name);

            //Adding Initial Capacity
            int AssetUnit1Key = tCUnitTypeLevelEventDate.assetUnitKey;
            decimal Unit1InitialCapacity = tCUnitTypeLevelEventDate.RunAssetUnitCapacity(inputData.initialCapacityEventField, AssetUnit1Key);

            //Adding new Asset uni2 and getting the UnitKey
            tCUnitTypeLevelEventDate.CreateNewAssetUnit(assetUnit2TestData);
            tCUnitTypeLevelEventDate.GetAssetUnitKey(assetUnit2Name);

            //Adding Initial Capacity
            int AssetUnit2Key = tCUnitTypeLevelEventDate.assetUnitKey;
            decimal Unit2InitialCapacity = tCUnitTypeLevelEventDate.RunAssetUnitCapacity(inputData.initialCapacityEventField, AssetUnit2Key);

            decimal InitialCapacity = Unit1InitialCapacity + Unit2InitialCapacity;

            //Adding both the units to assetunits List
            assetunits.Add(AssetUnit1Key);
            assetunits.Add(AssetUnit2Key);


            // To  validate Total capacity value after adding initial capacity with StartDate=InitialCapcity StartDate
            tCUnitTypeLevelEventDate.RunValidateResponseData(inputData.validationParamFields, InitialCapacity, assetunits, tCUnitTypeLevelEventDate.Xpath, new List<string> { Filtervalue[0] });


            // Adding Expansion capacity to both the Units for both the Units
            decimal Unit1ExpansionCapacity = tCUnitTypeLevelEventDate.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AssetUnit1Key);
            decimal Unit2ExpansionCapacity = tCUnitTypeLevelEventDate.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AssetUnit2Key);
            decimal ExpansionCapacity = Unit1ExpansionCapacity + Unit2ExpansionCapacity;

            // To validate Total capacity value afteradding initial capacity event with StartDate=ExpansionCapacity StartDate
            tCUnitTypeLevelEventDate.RunValidateResponseData(inputData.validationParamFields, ExpansionCapacity, assetunits, tCUnitTypeLevelEventDate.Xpath, new List<string> { Filtervalue[1] });

            // To Validate Total Capacity Value for StartDate=InitialCapcity StartDate
            tCUnitTypeLevelEventDate.RunValidateResponseData(inputData.validationParamFields, InitialCapacity + ExpansionCapacity, assetunits, tCUnitTypeLevelEventDate.Xpath, new List<string> { Filtervalue[0]});

            // Adding creep capacity Event with P.Type value as 3 for both the Units
            decimal Unit1CreepCapacity = tCUnitTypeLevelEventDate.RunAssetUnitCapacity(inputData.creepCorrectionEventField, AssetUnit1Key);
            decimal Unit2CreepCapacity = tCUnitTypeLevelEventDate.RunAssetUnitCapacity(inputData.creepCorrectionEventField, AssetUnit2Key);
            decimal CreepCapacity = Unit1CreepCapacity + Unit1CreepCapacity;

            // To Validate Total Capacity Value for StartDate=CreepCapacity StartDate
            tCUnitTypeLevelEventDate.RunValidateResponseData(inputData.validationParamFields, CreepCapacity, assetunits, tCUnitTypeLevelEventDate.Xpath, new List<string> { Filtervalue[2] });

            // To Validate Total Capacity Value for StartDate=InitialCapcity StartDate
            tCUnitTypeLevelEventDate.RunValidateResponseData(inputData.validationParamFields, InitialCapacity + ExpansionCapacity + CreepCapacity, assetunits, tCUnitTypeLevelEventDate.Xpath, new List<string> { Filtervalue[0]});

            // Adding Closure Capacity Event with P.Type value as 4 for both the Units
            tCUnitTypeLevelEventDate.RunAssetUnitCapacity(inputData.closureEventField, AssetUnit1Key);
            tCUnitTypeLevelEventDate.RunAssetUnitCapacity(inputData.closureEventField, AssetUnit2Key);

            // To Validate Total Capacity Value for StartDate=Close Event StartDate
            tCUnitTypeLevelEventDate.RunValidateResponseData(inputData.validationParamFields, -(InitialCapacity + ExpansionCapacity + CreepCapacity), assetunits, tCUnitTypeLevelEventDate.Xpath, new List<string> { Filtervalue[3] });

            // To Validate Total Capacity Value for StartDate=InitialCapcity StartDate
            tCUnitTypeLevelEventDate.totalCapacity = 0;
            tCUnitTypeLevelEventDate.RunValidateResponseData(inputData.validationParamFields, tCUnitTypeLevelEventDate.totalCapacity, assetunits, tCUnitTypeLevelEventDate.Xpath, new List<string> { Filtervalue[0]});

            Assert.True(tCUnitTypeLevelEventDate.errors.Count == 0, tCUnitTypeLevelEventDate.ApiName + ":" + "\n" + string.Join("\n ", tCUnitTypeLevelEventDate.errors.Select(s => $"'{s}'")));
        }
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }

                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to add Initial, Expansion, Creep and Closure Events
        private decimal RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalQty"]);
        }

        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void RunValidateResponseData<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, string Xpath, List<string> Filtervalues)
        {
            try
            {
                string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(validationParamFields, assetUnitsList, Filtervalues);
                RestUtils.RunTotalCapacityByAsset(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
        }
}
