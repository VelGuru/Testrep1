﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.TotalCapacityTests
{
    public  class TotalCapacity_UnitLevel_CapacityBasisType
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
        string Xpath = null;
        decimal totalCapacity = 0;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_TotalCapacity_UnitLevel_CapacityBasisType", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void TCUnitLevelBasisTypeTest(AppInputData inputData)
        {

            TotalCapacity_UnitLevel_CapacityBasisType TCUnitLevelBasisType = new TotalCapacity_UnitLevel_CapacityBasisType();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
             TCUnitLevelBasisType.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;
            TCUnitLevelBasisType.Xpath = inputData.xpath;
            string cdInitial = inputData.cdInitials;
            string assetUnitName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();
            List<int> assetunits = new List<int>();


            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                            }
                            inputKeyValues.Add(fieldName, TestDataField.value);
                        }
                    }
                }
            }

            //Creating New Asset unit and adding Intial Capacity and getting the UnitKey and quantity
            TCUnitLevelBasisType.RunInitialCapacity(inputKeyValues);
            TCUnitLevelBasisType.GetAssetUnitKey(assetUnitName);

            decimal IntialCapacity = decimal.Parse(inputKeyValues["quantity"]);
            TCUnitLevelBasisType.totalCapacity = IntialCapacity;

            //Adding both the Unit to the List
            assetunits.Add(TCUnitLevelBasisType.assetUnitKey);

            //Validating totalcapacity value is equal to Initial capacity
            TCUnitLevelBasisType.RunValidateResponseData(inputData.validationParamFields, TCUnitLevelBasisType.totalCapacity, assetunits, TCUnitLevelBasisType.Xpath);

            //Adding Expansion capacity
            decimal ExpansionCapacity = TCUnitLevelBasisType.RunAssetUnitCapacity(inputData.expansionCapacityEventField, TCUnitLevelBasisType.assetUnitKey);
            TCUnitLevelBasisType.totalCapacity = IntialCapacity + ExpansionCapacity;

            //Validating total capacity value is sum of Intial and Expansion unit capacity
            TCUnitLevelBasisType.RunValidateResponseData(inputData.validationParamFields, TCUnitLevelBasisType.totalCapacity, assetunits, TCUnitLevelBasisType.Xpath);

            //Adding Creep correction capacity
            decimal CreepCapacity = TCUnitLevelBasisType.RunAssetUnitCapacity(inputData.creepCorrectionEventField, TCUnitLevelBasisType.assetUnitKey);
            TCUnitLevelBasisType.totalCapacity = IntialCapacity + ExpansionCapacity + CreepCapacity;

            //Validating total unit capacity is sum of IntialCapacity+Expansion capacity+Creep
            TCUnitLevelBasisType.RunValidateResponseData(inputData.validationParamFields, TCUnitLevelBasisType.totalCapacity, assetunits, TCUnitLevelBasisType.Xpath);

            //Adding Closure event
            decimal ClosureCapacity = TCUnitLevelBasisType.RunAssetUnitCapacity(inputData.closureEventField, TCUnitLevelBasisType.assetUnitKey);

            //Validating totalcapacity value is 0
            TCUnitLevelBasisType.RunValidateResponseData(inputData.validationParamFields,ClosureCapacity, assetunits, TCUnitLevelBasisType.Xpath);

            Assert.True(TCUnitLevelBasisType.errors.Count == 0, TCUnitLevelBasisType.ApiName + ":" + "\n" + string.Join("\n ", TCUnitLevelBasisType.errors.Select(s => $"'{s}'")));
        }

        //Method to get the Asset UnitKey
        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to Create New Asset Unit and Add Initial Capacity Event
        private void RunInitialCapacity(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);

                //Code to add request and error details if incase of error for validation
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "API Request :" + responseData.RequestBody);
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
   
        //Method to add Initial,Expansion,Creep and Closure Events
        private decimal RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "API Request :" + responseData.RequestBody);
                }               
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalQty"]);
        }

        private void RunValidateResponseData<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, string Xpath, string optionalstr = "default string")
        {
            try
            {
                string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(validationParamFields, assetUnitsList);
                RestUtils.RunTotalCapacityByAsset(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

        }
    }
}
