﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.TotalCapacityTests
{
    public class TotalCapacity_DeltaFunctionality_DeltaBetweenVersions
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        List<int> assetunits = new List<int>();
        int capacityEventKey = 0;
        string ApiName = null;
        string xPath = null;
        decimal totalCapacityBeforeUpdate = 0;
        decimal eventCapacityValue = 0;
        decimal totalCapacityAfterUpdate = 0;

      
        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_TotalCapacity_DeltaBetweenVersions", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void TotalCapacityDeltaBetweenVersions(AppInputData inputData)
        {
            TotalCapacity_DeltaFunctionality_DeltaBetweenVersions TotalCapacityDeltaBetweenVersions = new TotalCapacity_DeltaFunctionality_DeltaBetweenVersions();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
            TotalCapacityDeltaBetweenVersions.ApiName = inputData.apiName;
            TotalCapacityDeltaBetweenVersions.xPath = inputData.xpath;

            // Function Call to get asset unit which contains active capacity events.
            TotalCapacityDeltaBetweenVersions.assetUnitKey = TotalCapacityDeltaBetweenVersions.GetAssetUnitWithActiveCapacityEventsKey();
            TotalCapacityDeltaBetweenVersions.assetunits.Add(TotalCapacityDeltaBetweenVersions.assetUnitKey);

            // Function call to get total capacity value before updating capacity events.
            string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(inputData.validationParamFields, TotalCapacityDeltaBetweenVersions.assetunits);
            TotalCapacityDeltaBetweenVersions.totalCapacityBeforeUpdate = decimal.Parse(RestUtils.GetAPIFieldValue(APIParameters, TotalCapacityDeltaBetweenVersions.xPath));
             
            // Function Call to get recent capacity Event key.
            TotalCapacityDeltaBetweenVersions.capacityEventKey = TotalCapacityDeltaBetweenVersions.GetAssetUnitCapacityEventKey(TotalCapacityDeltaBetweenVersions.assetUnitKey);

            // Function call to get event capcaity value for before updating capacity event
            TotalCapacityDeltaBetweenVersions.eventCapacityValue = decimal.Parse(TotalCapacityDeltaBetweenVersions.GetAssetUnitCapacityEventValue(TotalCapacityDeltaBetweenVersions.capacityEventKey, "$.[0].capacityUniversalQty"));

            // code to update recent capacity event value.
            TotalCapacityDeltaBetweenVersions.UpdateAssetUnitCapacityEvent(TotalCapacityDeltaBetweenVersions.capacityEventKey, TotalCapacityDeltaBetweenVersions.assetUnitKey, "capacityUniversalQty", (TotalCapacityDeltaBetweenVersions.totalCapacityBeforeUpdate + 50).ToString());
   
            TotalCapacityDeltaBetweenVersions.totalCapacityAfterUpdate = TotalCapacityDeltaBetweenVersions.totalCapacityBeforeUpdate - TotalCapacityDeltaBetweenVersions.eventCapacityValue + (TotalCapacityDeltaBetweenVersions.totalCapacityBeforeUpdate + 50);

            // Code to validate Total capacity Value with Delta between dates.
            TotalCapacityDeltaBetweenVersions.ValidateTotalCapacityWithDeltaFunctionality(inputData.validationParamFields, TotalCapacityDeltaBetweenVersions.totalCapacityAfterUpdate-TotalCapacityDeltaBetweenVersions.totalCapacityBeforeUpdate, TotalCapacityDeltaBetweenVersions.assetunits, TotalCapacityDeltaBetweenVersions.xPath, RestUtils.getCurrentDate(), RestUtils.getYesterdaysDate());
        }

        private int GetAssetUnitWithActiveCapacityEventsKey()
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetActiveAssetUnitKeyData("asset_unit_key");              
            }
            catch (Exception e)
            { 
                errors.Add("Get : " + e.Message);
            }
            return assetUnitKey;
        }

        private int GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey; 
            try
            {
                capacityEventKey = RestUtil.GetFirstId(APIName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return capacityEventKey;
        }


        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null; 

            String apiName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void ValidateTotalCapacityWithVersionEffectiveDate<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, string Xpath, String Date)
        {
            try
            {
                string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(validationParamFields, assetUnitsList);
                if (Date == RestUtils.getYesterdaysDate())
                { 
                    APIParameters = APIParameters.Replace("VersionDate="+RestUtils.getCurrentDate(), "VersionDate="+Date);
                }

                RestUtils.RunTotalCapacityByAsset(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }


        private void ValidateTotalCapacityWithDeltaFunctionality<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, string Xpath,String VersionDate2, String VersionDate1)
        {
            try
            {
                string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(validationParamFields, assetUnitsList);
                APIParameters = APIParameters + "&versionDate1=" + VersionDate1 + "&versionDate2=" + VersionDate2 + "&isAbsolute=false&isDeltaByProvider=false&";

                RestUtils.RunTotalCapacityByAsset(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }



    }
}

