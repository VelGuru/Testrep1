﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.TotalCapacityTests
{
    public class TotalCapacity_UnitLevel_EventDates
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
        string Xpath = null;
        decimal totalCapacity = 0;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_TotalCapacity_UnitLevel_EventDates", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void TCUnitLevelEventDatesTest(AppInputData inputData)
        {

            TotalCapacity_UnitLevel_EventDates TCUnitLevelEventDates = new TotalCapacity_UnitLevel_EventDates();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            
            TCUnitLevelEventDates.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;
            TCUnitLevelEventDates.Xpath = inputData.xpath;
            string cdInitial = inputData.cdInitials;
            string assetUnitName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();
            List<FilterField> filterFieldList = inputData.filterField;
            List<string> Filtervalue = null;
            List<int> assetunits = new List<int>();

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            foreach (FilterField fieldname in filterFieldList)
            {
                Filtervalue = Util.GetListFromCommaSepString(fieldname.value);
            }

            //Creating New Event
            TCUnitLevelEventDates.CreateNewAssetUnit(inputKeyValues);
            TCUnitLevelEventDates.GetAssetUnitKey(assetUnitName);

            //Adding Initial Capacity
            decimal InitialCapacity = TCUnitLevelEventDates.RunAssetUnitCapacity(inputData.initialCapacityEventField, TCUnitLevelEventDates.assetUnitKey);
            TCUnitLevelEventDates.totalCapacity = InitialCapacity;

            //Adding the Unit to the List
            assetunits.Add(TCUnitLevelEventDates.assetUnitKey);

            //Validating totalcapacity value is equal to Intial Capacity
            TCUnitLevelEventDates.RunValidateResponseData(inputData.validationParamFields, TCUnitLevelEventDates.totalCapacity,assetunits, TCUnitLevelEventDates.Xpath, new List<string> {Filtervalue[0]});

            //Adding Expansion Capacity
            decimal ExpansionCapacity = TCUnitLevelEventDates.RunAssetUnitCapacity(inputData.expansionCapacityEventField, TCUnitLevelEventDates.assetUnitKey);
            TCUnitLevelEventDates.totalCapacity = InitialCapacity + ExpansionCapacity;

            //Validating totalcapacity value is equal to Intial Capacity and Expansion Capacity
            TCUnitLevelEventDates.RunValidateResponseData(inputData.validationParamFields, TCUnitLevelEventDates.totalCapacity,assetunits, TCUnitLevelEventDates.Xpath, new List<string> {Filtervalue[0]});

            //Validating totalcapacity value is equal to Expansion Capacity
            TCUnitLevelEventDates.RunValidateResponseData(inputData.validationParamFields, ExpansionCapacity,assetunits, TCUnitLevelEventDates.Xpath, new List<string> {Filtervalue[1]});

            //Adding Creep Correction Capacity
            decimal CreepCapacity = TCUnitLevelEventDates.RunAssetUnitCapacity(inputData.creepCorrectionEventField, TCUnitLevelEventDates.assetUnitKey);
            TCUnitLevelEventDates.totalCapacity = InitialCapacity + ExpansionCapacity + CreepCapacity;

            //Validating totalcapacity value is equal to Intial Capacity + Expansion Capacity + Creep capacity
            TCUnitLevelEventDates.RunValidateResponseData(inputData.validationParamFields, TCUnitLevelEventDates.totalCapacity, assetunits, TCUnitLevelEventDates.Xpath, new List<string> {Filtervalue[0]});

            //Validating totalcapacity value is equal to Creep Correction Capacity
            TCUnitLevelEventDates.RunValidateResponseData(inputData.validationParamFields, CreepCapacity,assetunits, TCUnitLevelEventDates.Xpath, new List<string> {Filtervalue[2]});

            //Adding Closure Event
            decimal ClosureCapacity = TCUnitLevelEventDates.RunAssetUnitCapacity(inputData.closureEventField, TCUnitLevelEventDates.assetUnitKey);

            //Validating totalcapacity value is 0
            TCUnitLevelEventDates.RunValidateResponseData(inputData.validationParamFields,ClosureCapacity, assetunits, TCUnitLevelEventDates.Xpath, new List<string> {Filtervalue[0]});

            //Validating totalcapacity value is equal to - (Intial Capacity +Expansion Capacity+Creep)
            TCUnitLevelEventDates.RunValidateResponseData(inputData.validationParamFields,-TCUnitLevelEventDates.totalCapacity, assetunits, TCUnitLevelEventDates.Xpath, new List<string> {Filtervalue[3]});

            Assert.True(TCUnitLevelEventDates.errors.Count == 0, TCUnitLevelEventDates.ApiName + ":" + "\n" + string.Join("\n ", TCUnitLevelEventDates.errors.Select(s => $"'{s}'")));
        }

        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to add Initial,Expansion,Creep and Closure Events
        private decimal RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalQty"]);
        }

        private void RunValidateResponseData<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, string Xpath, List<string> Filtervalues)
        {
            try
            {
                string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(validationParamFields, assetUnitsList, Filtervalues);
                RestUtils.RunTotalCapacityByAsset(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

        }
    }
}
