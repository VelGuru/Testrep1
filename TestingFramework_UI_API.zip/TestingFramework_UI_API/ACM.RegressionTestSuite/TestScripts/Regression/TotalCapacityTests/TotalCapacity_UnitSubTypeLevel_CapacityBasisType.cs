﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.TotalCapacityTests
{
    public class TotalCapacity_UnitSubTypeLevel_CapacityBasisType
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
        string Xpath = null;
        decimal totalCapacity = 0;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData),parameters: "TD_TotalCapacity_UnitSubTypeLevel_CapacityBasisType", MemberType =typeof(TotalCapacityTestDataGenerator))]
    

        public static void TCUnitSubtypeLevelBasisTypeTest(AppInputData inputData)
        {

            TotalCapacity_UnitSubTypeLevel_CapacityBasisType TCUnitSubtypeLevelBasisType = new TotalCapacity_UnitSubTypeLevel_CapacityBasisType();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            TCUnitSubtypeLevelBasisType.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;
            TCUnitSubtypeLevelBasisType.Xpath = inputData.xpath;
            string cdInitial = inputData.cdInitials;
            string assetUnit1Name = null;
            string assetUnit2Name = null;
            Dictionary<string, string> assetUnit1TestData = new Dictionary<string, string>();
            Dictionary<string, string> assetUnit2TestData = new Dictionary<string, string>();
            List<int> assetunits = new List<int>();


            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        assetUnit1TestData.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnit1Name = assetUnit1TestData["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                assetUnit1TestData.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                assetUnit1TestData.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        assetUnit2TestData.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnit2Name = assetUnit2TestData["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {

                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                assetUnit2TestData.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                assetUnit2TestData.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Adding new Asset unit getting the UnitKey
            TCUnitSubtypeLevelBasisType.CreateNewAssetUnit(assetUnit1TestData);
            TCUnitSubtypeLevelBasisType.GetAssetUnitKey(assetUnit1Name);

            //Adding Initial Capacity
            int AssetUnit1Key = TCUnitSubtypeLevelBasisType.assetUnitKey;
            decimal Unit1InitialCapacity = TCUnitSubtypeLevelBasisType.RunAssetUnitCapacity(inputData.initialCapacityEventField, AssetUnit1Key);

            //Adding new Asset uni2 and getting the UnitKey
            TCUnitSubtypeLevelBasisType.CreateNewAssetUnit(assetUnit2TestData);
            TCUnitSubtypeLevelBasisType.GetAssetUnitKey(assetUnit2Name);

            //Adding Initial Capacity
            int AssetUnit2Key = TCUnitSubtypeLevelBasisType.assetUnitKey;
            decimal Unit2InitialCapacity = TCUnitSubtypeLevelBasisType.RunAssetUnitCapacity(inputData.initialCapacityEventField, AssetUnit2Key);

            TCUnitSubtypeLevelBasisType.totalCapacity = Unit1InitialCapacity+ Unit2InitialCapacity;
            
            //Adding both the Units to the List
            assetunits.Add(AssetUnit1Key);
            assetunits.Add(AssetUnit2Key);

            //Validating totalcapacity value is sum of Initial capacity  of both the Units
            TCUnitSubtypeLevelBasisType.RunValidateResponseData(inputData.validationParamFields, TCUnitSubtypeLevelBasisType.totalCapacity, assetunits, TCUnitSubtypeLevelBasisType.Xpath);

            // Adding Expansion capacity to both the Units
            decimal Unit1ExpansionCapacity = TCUnitSubtypeLevelBasisType.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AssetUnit1Key);
            decimal Unit2ExpansionCapacity = TCUnitSubtypeLevelBasisType.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AssetUnit2Key);

            TCUnitSubtypeLevelBasisType.totalCapacity = TCUnitSubtypeLevelBasisType.totalCapacity + Unit1ExpansionCapacity + Unit2ExpansionCapacity;

            //Validating total capacity value is sum of Initial and Expansion unit capacity of both the Units
            TCUnitSubtypeLevelBasisType.RunValidateResponseData(inputData.validationParamFields, TCUnitSubtypeLevelBasisType.totalCapacity, assetunits, TCUnitSubtypeLevelBasisType.Xpath);
           
            //Adding Creep correction capacity for Unit1
            decimal Unit1CreepCapacity = TCUnitSubtypeLevelBasisType.RunAssetUnitCapacity(inputData.creepCorrectionEventField, AssetUnit1Key);

            TCUnitSubtypeLevelBasisType.totalCapacity = TCUnitSubtypeLevelBasisType.totalCapacity + Unit1CreepCapacity;

            //Validating total unit capacity is sum of InitialCapacity(U1+U2)+Expansion capacity(U1+U2)+Creep(U1)
            TCUnitSubtypeLevelBasisType.RunValidateResponseData(inputData.validationParamFields, TCUnitSubtypeLevelBasisType.totalCapacity, assetunits, TCUnitSubtypeLevelBasisType.Xpath);

            //Adding Closure event for  Unit2
            decimal Unit2ClosureCapacity = TCUnitSubtypeLevelBasisType.RunAssetUnitCapacity(inputData.closureEventField, AssetUnit2Key);

            TCUnitSubtypeLevelBasisType.totalCapacity = Unit1InitialCapacity+ Unit1ExpansionCapacity + Unit1CreepCapacity;

            //Validating total unit capacity value is  sum of InitialCapacity(U1)+Expansion capacity(U1)+Creep(U1)
            TCUnitSubtypeLevelBasisType.RunValidateResponseData(inputData.validationParamFields, TCUnitSubtypeLevelBasisType.totalCapacity, assetunits, TCUnitSubtypeLevelBasisType.Xpath);

            //Adding Closure event for  Unit1
            decimal Unit1ClosureCapacity = TCUnitSubtypeLevelBasisType.RunAssetUnitCapacity(inputData.closureEventField, AssetUnit1Key);
            TCUnitSubtypeLevelBasisType.totalCapacity = 0;

            //Validating total unit capacity value is  0
            TCUnitSubtypeLevelBasisType.RunValidateResponseData(inputData.validationParamFields, TCUnitSubtypeLevelBasisType.totalCapacity, assetunits, TCUnitSubtypeLevelBasisType.Xpath);

            Assert.True(TCUnitSubtypeLevelBasisType.errors.Count == 0, TCUnitSubtypeLevelBasisType.ApiName + ":" + "\n" + string.Join("\n ", TCUnitSubtypeLevelBasisType.errors.Select(s => $"'{s}'")));

        }

        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }

                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

       //Method to add Initial, Expansion, Creep and Closure Events
        private decimal RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalQty"]);
        }

        private void RunValidateResponseData<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, string Xpath, string optionalstr = "default string")
        {
            try
            {
                string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(validationParamFields, assetUnitsList);
                RestUtils.RunTotalCapacityByAsset(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

        }

    }

}
