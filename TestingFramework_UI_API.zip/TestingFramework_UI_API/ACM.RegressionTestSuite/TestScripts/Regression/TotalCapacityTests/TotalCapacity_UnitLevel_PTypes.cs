﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.TotalCapacityTests
{
    public class TotalCapacity_UnitLevel_PTypes
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
        string Xpath = null;
        decimal totalCapacity = 0;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_TotalCapacity_UnitLevel_PType", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void TC3UnitLevelProbabulityTypeTest(AppInputData inputData)
        {
            TotalCapacity_UnitLevel_PTypes TCUnitLevelPType = new TotalCapacity_UnitLevel_PTypes();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;            
            TCUnitLevelPType.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;
            TCUnitLevelPType.Xpath = inputData.xpath;
            string cdInitial = inputData.cdInitials;
            string assetUnitName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();
            List<int> assetunits = new List<int>();

            List<FilterField> filterFieldList = inputData.filterField;
            List<string> Filtervalue = null;

            if (assetUnitTestDataList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in assetUnitTestDataList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New AssetUnit
            TCUnitLevelPType.CreateNewAssetUnit(inputKeyValues);
            TCUnitLevelPType.GetAssetUnitKey(assetUnitName);

            //Adding Initial Capacity
            decimal InitialCapacity = TCUnitLevelPType.RunAssetUnitCapacity(inputData.initialCapacityEventField, TCUnitLevelPType.assetUnitKey);
            TCUnitLevelPType.totalCapacity = InitialCapacity;

            foreach (FilterField fieldname in filterFieldList)
            {
                Filtervalue = Util.GetListFromCommaSepString(fieldname.value);
            }

            assetunits.Add(TCUnitLevelPType.assetUnitKey);

            // Function call to verify Total capacity value after adding initial capacity event with P.Type value as "1"
            TCUnitLevelPType.RunValidateResponseData(inputData.validationParamFields, InitialCapacity,assetunits, TCUnitLevelPType.Xpath, new List<string>{Filtervalue[0]});

            // Code to verify Total capacity value after adding initial capacity event with P.Type value as "1" and Expansion event with P.Type value as "2"
            decimal ExpansionCapacity = TCUnitLevelPType.RunAssetUnitCapacity(inputData.expansionCapacityEventField, TCUnitLevelPType.assetUnitKey);
            TCUnitLevelPType.RunValidateResponseData(inputData.validationParamFields, ExpansionCapacity, assetunits, TCUnitLevelPType.Xpath, new List<string> { Filtervalue[1] });
            
            // Code to verify Total Capacity Value by selecting P.typpe values as 1 and 2
            TCUnitLevelPType.RunValidateResponseData(inputData.validationParamFields, InitialCapacity+ExpansionCapacity, assetunits, TCUnitLevelPType.Xpath, new List<string> { Filtervalue[0], Filtervalue[1]});

            // Code to add creep capacity Event with P.Type value as 3
            decimal CreepCapacity = TCUnitLevelPType.RunAssetUnitCapacity(inputData.creepCorrectionEventField, TCUnitLevelPType.assetUnitKey);
            TCUnitLevelPType.RunValidateResponseData(inputData.validationParamFields, CreepCapacity, assetunits, TCUnitLevelPType.Xpath, new List<string> { Filtervalue[2] });

            // Code to verify Total Capacity Value by selecting P.typpe values as 1,2 & 3
            TCUnitLevelPType.RunValidateResponseData(inputData.validationParamFields, InitialCapacity + ExpansionCapacity + CreepCapacity, assetunits, TCUnitLevelPType.Xpath, new List<string> { Filtervalue[0], Filtervalue[1], Filtervalue[2] });

            // Code to add Closure Capacity Event with P.Type value as 3
            decimal ClosureCapacity = TCUnitLevelPType.RunAssetUnitCapacity(inputData.closureEventField, TCUnitLevelPType.assetUnitKey);
            
            // Code to verify Total Capacity Value by selecting P.type values as 1,2,3 
            TCUnitLevelPType.totalCapacity = 0;
            TCUnitLevelPType.RunValidateResponseData(inputData.validationParamFields, TCUnitLevelPType.totalCapacity, assetunits, TCUnitLevelPType.Xpath, new List<string> { Filtervalue[0], Filtervalue[1], Filtervalue[2]});
            
            Assert.True(TCUnitLevelPType.errors.Count == 0, TCUnitLevelPType.ApiName + ":" + "\n" + string.Join("\n ", TCUnitLevelPType.errors.Select(s => $"'{s}'")));
        }

        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);

                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }

                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }      

        //Method to add Initial,Expansion,Creep and Closure Events
        private decimal RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalQty"]);
        }

        private void RunValidateResponseData<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, string Xpath, List<string> Filtervalues)
        {
            try
            {
                string APIParameters = RestUtils.GetTotalCapacityByAssetRequestData(validationParamFields, assetUnitsList, Filtervalues);
                RestUtils.RunTotalCapacityByAsset(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

        }
    }
}
