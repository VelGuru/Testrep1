﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using APITestSuite;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{
    public class AddEditEvents_PlaceHolderUnit_ADD_CapacityEvents_And_Validate_TotalFirmCapacity
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
      

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_PlaceHolderUnit_ADD_CapacityEvents_And_Validate_TotalFirmCapacity", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void AddEventsForPlaceholderUnitAndValidateTotalFirmCapacityTest(AppInputData inputData)
        {

            AddEditEvents_PlaceHolderUnit_ADD_CapacityEvents_And_Validate_TotalFirmCapacity AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity = new AddEditEvents_PlaceHolderUnit_ADD_CapacityEvents_And_Validate_TotalFirmCapacity();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            
            AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;            
            string cdInitial = inputData.cdInitials;
            string Xpath = inputData.xpath;
            string assetUnitName = null;
            string apiName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();            

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New Placeholder Asset Unit and Getting the AssetUnitKey
            AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.CreateNewAssetUnit(inputKeyValues);
            AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.GetAssetUnitKey(assetUnitName);

            //Adding InitialCapacity for the above created Unit
            decimal initialCapacity=AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.initialCapacityEventField, AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.assetUnitKey);

            //Code to create AssetUnitCapacities/{UnitId}/TotalFirmUnitCapacity API
            foreach (ValidationParamFields TestField in inputData.validationParamFields)
            {
                if(TestField.field== "apiName")
                {
                    apiName = TestField.value.Replace("{UnitId}", AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.assetUnitKey.ToString());
                }
            }

            //Validating the TotalFirmCapacity should be equal to Initial Capacity of the Unit
            AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName, initialCapacity, Xpath);

            //Adding Expansion event 
            decimal expansionCapacity=AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.assetUnitKey);

            //Validating the TotalFirmCapacity after adding expansion event and Value should be equal to Units Initial Capacity+Expansion Capacity
            AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName,initialCapacity + expansionCapacity, Xpath);

            //Adding Creep event with Probability Type other than Firm
            decimal creepCapacity=AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.creepCorrectionEventField, AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.assetUnitKey);

            //Validating the TotalFirmCapacity after adding Creep event and Value should be equal to Units Initial Capacity+Expansion Capacity+Creep
            AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName,initialCapacity + expansionCapacity+ creepCapacity, Xpath);

            // Adding Closure event
            AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.closureEventField, AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.assetUnitKey);

            // Validating the TotalFirmCapacity after adding Closure and Value should be equal 0
             AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName,0, Xpath);       

            Assert.True(AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.errors.Count == 0, AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.ApiName + ":" + "\n" + string.Join("\n ", AddEventsForPlaceholderUnitAndValidateTotalFirmCapacity.errors.Select(s => $"'{s}'")));
        }

        //Method to query DB and Get AssetUnitKey
        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to Create New Asset Unit 
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
   
        //Method to add Initial,expansion,Creep and Closure events
        private decimal RunAssetUnitCapacity<T>(List<T>  inputData,int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalQty"]);
        }

        //Method to Validate the Unit's TotalFirmCapacity 
        private void ValidateTotalFirmUnitCapacityTest(string apiName, decimal expectedQty, string Xpath)
        {
            decimal ActualQty = decimal.Parse(RestUtils.GetAPIFieldValue(apiName, Xpath));            
            if (ActualQty != expectedQty)
            {
                throw new Exception("Mismatch in Actual and Expected Quantity" + "Actual Quantity is : " + ActualQty + " and Expected Quantity is : " + expectedQty);
            }              
        }
    }
}
