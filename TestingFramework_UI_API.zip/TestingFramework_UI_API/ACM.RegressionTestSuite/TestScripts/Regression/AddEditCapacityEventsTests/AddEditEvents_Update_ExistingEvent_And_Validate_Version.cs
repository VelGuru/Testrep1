﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{
    public class AddEditEvents_Update_ExistingEvent_And_Validate_Version
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string apiName = null;
        List<int> assetunits = new List<int>();
        int capacityEventKey = 0;       
        decimal eventCapacityValue = 0;
        string eventVersionEffectiveDate = null;


        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_Update_ExistingEvent_And_Validate_Version", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void UpdateExistingEventAndValidateVersionTest(AppInputData inputData)
        {
            AddEditEvents_Update_ExistingEvent_And_Validate_Version UpdateExistingEventAndValidateVersion = new AddEditEvents_Update_ExistingEvent_And_Validate_Version();
            UpdateExistingEventAndValidateVersion.apiName = inputData.apiName;
            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
             

            // Function Call to get asset unit which contains active capacity event
            UpdateExistingEventAndValidateVersion.assetUnitKey = UpdateExistingEventAndValidateVersion.GetAssetUnitWithActiveCapacityEventsKey();
            UpdateExistingEventAndValidateVersion.assetunits.Add(UpdateExistingEventAndValidateVersion.assetUnitKey);            
             
            // Function Call to get the capacity Event key.
            UpdateExistingEventAndValidateVersion.capacityEventKey = UpdateExistingEventAndValidateVersion.GetAssetUnitCapacityEventKey(UpdateExistingEventAndValidateVersion.assetUnitKey);

            // Function call to get event capacity value before updating capacity event
            UpdateExistingEventAndValidateVersion.eventCapacityValue = decimal.Parse(UpdateExistingEventAndValidateVersion.GetAssetUnitCapacityEventValue(UpdateExistingEventAndValidateVersion.capacityEventKey, "$.[0].capacityUniversalQty"));

            //Function call to get event versionEffectiveDate before updating capacity event
            UpdateExistingEventAndValidateVersion.eventVersionEffectiveDate = UpdateExistingEventAndValidateVersion.GetAssetUnitCapacityEventValue(UpdateExistingEventAndValidateVersion.capacityEventKey, "$.[0].versionEffectiveDt");

            // code to update recent capacity event value
            UpdateExistingEventAndValidateVersion.UpdateAssetUnitCapacityEvent(UpdateExistingEventAndValidateVersion.capacityEventKey, UpdateExistingEventAndValidateVersion.assetUnitKey, "capacityUniversalQty", "550");

            //Code to create AssetUnitCapacities/{UnitCapacityId}/versions API
            UpdateExistingEventAndValidateVersion.apiName= UpdateExistingEventAndValidateVersion.apiName.Replace("{UnitCapacityId}", UpdateExistingEventAndValidateVersion.capacityEventKey.ToString());
          
           UpdateExistingEventAndValidateVersion.RunAssetUnitCapacitiesVersionandValidateQty(UpdateExistingEventAndValidateVersion.apiName,UpdateExistingEventAndValidateVersion.eventVersionEffectiveDate,UpdateExistingEventAndValidateVersion.eventCapacityValue,550);


            Assert.True(UpdateExistingEventAndValidateVersion.errors.Count == 0, UpdateExistingEventAndValidateVersion.apiName + ":" + "\n" + string.Join("\n ", UpdateExistingEventAndValidateVersion.errors.Select(s => $"'{s}'")));
        }


        private int GetAssetUnitWithActiveCapacityEventsKey()
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetActiveAssetUnitKeyData("asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return assetUnitKey;
        }

        private int GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey; 
            try
            {
                capacityEventKey = RestUtil.GetFirstId(APIName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return capacityEventKey;
        }


        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null; 

            String apiName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void RunAssetUnitCapacitiesVersionandValidateQty(string ApiName,string VersionEffectiveDateBeforeUpdate,decimal CapacityQtyBeforeUpdate,decimal CapacityQtyAfterUpdate)
        {
            try
            {
                ResponseData responseData = new ResponseData();
                responseData = RestUtil.GetMethod(ApiName);
                if (responseData.ResponseValues.Count > 1)
                {
                    foreach (Dictionary<string, string> keyValues in responseData.ResponseValues)
                    {
                        DateTime VersionEffectiveDate = DateTime.ParseExact(keyValues["versionEffectiveDate"], "M/d/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                        string versionEffectiveDt = VersionEffectiveDate.ToString("yyyy-MM-dd");
                        DateTime versionEffectiveDateBeforeUpdate = DateTime.ParseExact(VersionEffectiveDateBeforeUpdate, "M/d/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                        string versionEffectiveDtBeforeUpdate = versionEffectiveDateBeforeUpdate.ToString("yyyy-MM-dd");
                        if (versionEffectiveDt == RestUtils.getCurrentDate())
                        {
                            Assert.True(CapacityQtyAfterUpdate == decimal.Parse(keyValues["capacityUniversalQty"]), string.Format("Field {0} expected {1} but got {2}", "capacityUniversalQty", CapacityQtyAfterUpdate, keyValues["capacityUniversalQty"]));
                        }
                        else if (versionEffectiveDt == versionEffectiveDtBeforeUpdate)
                        {
                            Assert.True(CapacityQtyBeforeUpdate == decimal.Parse(keyValues["capacityUniversalQty"]), string.Format("Field {0} expected {1} but got {2}", "capacityUniversalQty", CapacityQtyBeforeUpdate, keyValues["capacityUniversalQty"]));
                        }
                    }
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}

