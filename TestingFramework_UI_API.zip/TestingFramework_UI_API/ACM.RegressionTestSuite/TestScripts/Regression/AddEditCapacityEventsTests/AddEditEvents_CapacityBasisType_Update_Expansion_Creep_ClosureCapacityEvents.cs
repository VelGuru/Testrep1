﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using APITestSuite;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{
    public class AddEditEvents_CapacityBasisType_Update_Expansion_Creep_ClosureCapacityEvents
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
        int[] capacityEventKeys;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_AddEditEvents_CapacityBasisType_Update_Expansion_Creep_ClosureCapacityEvents", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void AddAddUpdateExpansionCreepClosureTest(AppInputData inputData)
        {

            AddEditEvents_CapacityBasisType_Update_Expansion_Creep_ClosureCapacityEvents AddUpdateExpansionCreepClosure = new AddEditEvents_CapacityBasisType_Update_Expansion_Creep_ClosureCapacityEvents();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            
            AddUpdateExpansionCreepClosure.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;            
            string cdInitial = inputData.cdInitials;
            string assetUnitName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();            

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New Asset Unit and Add Initial Capacity
            AddUpdateExpansionCreepClosure.CreateNewAssetUnit(inputKeyValues);
            AddUpdateExpansionCreepClosure.GetAssetUnitKey(assetUnitName);

            // Function Call to get capacity Event keys and to update Initial Capacity Event.
            AddUpdateExpansionCreepClosure.capacityEventKeys = AddUpdateExpansionCreepClosure.GetAssetUnitCapacityEventKey(AddUpdateExpansionCreepClosure.assetUnitKey);
            AddUpdateExpansionCreepClosure.UpdateAssetUnitCapacityEvent(AddUpdateExpansionCreepClosure.capacityEventKeys[0], AddUpdateExpansionCreepClosure.assetUnitKey, "capacityOriginalQty", "50");

            // Adding expansion event after creating New Asset Unit
            AddUpdateExpansionCreepClosure.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AddUpdateExpansionCreepClosure.assetUnitKey,(int)HttpStatusCode.Created);

            // Function Call to get capacity Event keys and to update Initial Capacity Event.
            AddUpdateExpansionCreepClosure.capacityEventKeys = AddUpdateExpansionCreepClosure.GetAssetUnitCapacityEventKey(AddUpdateExpansionCreepClosure.assetUnitKey);
            AddUpdateExpansionCreepClosure.UpdateAssetUnitCapacityEvent(AddUpdateExpansionCreepClosure.capacityEventKeys[1], AddUpdateExpansionCreepClosure.assetUnitKey, "capacityOriginalQty", "50");

            // Adding Creept after creating New Asset Unit
            AddUpdateExpansionCreepClosure.RunAssetUnitCapacity(inputData.creepCorrectionEventField, AddUpdateExpansionCreepClosure.assetUnitKey, (int)HttpStatusCode.Created);

            // Function Call to get capacity Event keys and to update Initial Capacity Event.
            AddUpdateExpansionCreepClosure.capacityEventKeys = AddUpdateExpansionCreepClosure.GetAssetUnitCapacityEventKey(AddUpdateExpansionCreepClosure.assetUnitKey);
            AddUpdateExpansionCreepClosure.UpdateAssetUnitCapacityEvent(AddUpdateExpansionCreepClosure.capacityEventKeys[2], AddUpdateExpansionCreepClosure.assetUnitKey, "capacityOriginalQty", "50");

            // Adding Closure event after creating New Asset Unit
            AddUpdateExpansionCreepClosure.RunAssetUnitCapacity(inputData.closureEventField, AddUpdateExpansionCreepClosure.assetUnitKey, (int)HttpStatusCode.Created);

            // Function Call to get capacity Event keys and to update Initial Capacity Event.
            AddUpdateExpansionCreepClosure.capacityEventKeys = AddUpdateExpansionCreepClosure.GetAssetUnitCapacityEventKey(AddUpdateExpansionCreepClosure.assetUnitKey);
            AddUpdateExpansionCreepClosure.UpdateAssetUnitCapacityEvent(AddUpdateExpansionCreepClosure.capacityEventKeys[3], AddUpdateExpansionCreepClosure.assetUnitKey, "capacityOriginalQty", "50");

            Assert.True(AddUpdateExpansionCreepClosure.errors.Count == 0, AddUpdateExpansionCreepClosure.ApiName + ":" + "\n" + string.Join("\n ", AddUpdateExpansionCreepClosure.errors.Select(s => $"'{s}'")));
        }

        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

      private void RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey, int StatusCode)
        {
            Dictionary<string, string> assetUnitCapacitiesFields =RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);

            // Code to verify Status Code
            Assert.Equal(responseData.StatusCode, StatusCode);
        }

        private void RunUpdateAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey, int StatusCode)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            responseData = RestUtil.PostMethod(APIName, assetUnitCapacitiesFields);

            // Code to verify Status Code
            Assert.Equal(responseData.StatusCode, StatusCode);
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private int[] GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            int[] capacityEventKeys;
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;


            try
            {
                capacityEventKeys = RestUtil.GetAllRecordIds(APIName);
                Array.Sort(capacityEventKeys);

                return capacityEventKeys;
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return null;
        }

    }
}
