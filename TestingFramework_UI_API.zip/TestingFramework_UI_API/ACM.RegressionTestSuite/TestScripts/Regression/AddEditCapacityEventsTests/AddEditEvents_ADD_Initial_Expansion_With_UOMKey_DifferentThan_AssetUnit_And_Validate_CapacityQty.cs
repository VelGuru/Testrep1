﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using APITestSuite;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{
    public class AddEditEvents_ADD_Initial_Expansion_With_UOMKey_DifferentThan_AssetUnit_And_Validate_CapacityQty
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
      

        [Theory(Skip = "API is not allowing original UOM Key and Original capacity to test UOM conversion Scenarios")]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_ADD_Initial_Expansion_With_UOMKey_DifferentThan_AssetUnit_And_Validate_CapacityQty", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQtyTest(AppInputData inputData)
        {

            AddEditEvents_ADD_Initial_Expansion_With_UOMKey_DifferentThan_AssetUnit_And_Validate_CapacityQty AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty = new AddEditEvents_ADD_Initial_Expansion_With_UOMKey_DifferentThan_AssetUnit_And_Validate_CapacityQty();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            
            AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;            
            string cdInitial = inputData.cdInitials;
            string Xpath = inputData.xpath;
            string assetUnitName = null;
            string apiName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();            

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New Asset Unit and adding Initial Capacity with different UOMKey than AssetUnit
            AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.CreateNewAssetUnit(inputKeyValues);
            AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.GetAssetUnitKey(assetUnitName);            

            //Code to create AssetUnitCapacities/{AssetUnitId} API
            foreach (ValidationParamFields TestField in inputData.validationParamFields)
            {
                if(TestField.field== "apiName")
                {
                    apiName = TestField.value.Replace("{AssetUnitId}", AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.assetUnitKey.ToString());
                }
            }

            AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.RunAssetUnitCapacitiesandValidateCapacityUOMFields(apiName,inputData.expectedFieldValues);

            //Adding Expansion event with different UOMKey than AssetUnit
            AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.assetUnitKey);

            AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.RunAssetUnitCapacitiesandValidateCapacityUOMFields(apiName,inputData.expectedFieldValues);

            Assert.True(AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.errors.Count == 0, AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.ApiName + ":" + "\n" + string.Join("\n ", AddInitialExpansionWithUOMKeyDifferentThanAssetUnitAndValidateCapacityQty.errors.Select(s => $"'{s}'")));
        }

        //Method to query DB and Get AssetUnitKey
        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to Create New Asset Unit 
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
   
        //Method to add Initial and expansion events
        private void RunAssetUnitCapacity<T>(List<T>  inputData,int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtil.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }           
        }

        //Method to Validate the CapacityUOM Fields
        private void RunAssetUnitCapacitiesandValidateCapacityUOMFields(string apiName, List<ExpectedFieldValues> expectedFieldValues)
        {
            ResponseData responseData = new ResponseData();
            responseData=RestUtil.GetMethod(apiName);

            Dictionary<string, List<string>> expectedFieldList = AssetCapacityUtils.expectedFieldValuesList(expectedFieldValues);

            foreach (Dictionary<string,string> keyValues in responseData.ResponseValues)
            {
                int i = 0;
                if (keyValues["capacityBasisTypeCd"] == "E")
                {
                    i++;
                }
                Assert.True(expectedFieldList["capacityOriginalUOMKey"][0] == keyValues["capacityOriginalUomKey"], string.Format("for Field {0} expected {1} but got {2}", "CapacityOriginalUomKey", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityOriginalUOMCd"][0] == keyValues["capacityOriginalUomCd"], string.Format("for Field {0} expected {1} but got {2}", "capacityOriginalUOMCd", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityUniversalUOMKey"][0] == keyValues["capacityUniversalUomKey"], string.Format("for Field {0} expected {1} but got {2}", "capacityUniversalUOMKey", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityUniversalUOMCd"][0] == keyValues["capacityUniversalUomCd"], string.Format("for Field {0} expected {1} but got {2}", "capacityUniversalUOMCd", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityPlatformUOMKey"][0] == keyValues["capacityPlatformUomKey"], string.Format("for Field {0} expected {1} but got {2}", "capacityPlatformUOMKey", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityPlatformUOMCd"][0] == keyValues["capacityPlatformUomCd"], string.Format("for Field {0} expected {1} but got {2}", "capacityPlatformUOMCd", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityOriginalQty"][i] == keyValues["capacityOriginalQty"], string.Format("for Field {0} expected {1} but got {2}", "capacityOriginalQty", expectedFieldList["capacityOriginalUOMKey"][i], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityUniversalQty"][i] == keyValues["capacityUniversalQty"], string.Format("for Field {0} expected {1} but got {2}", "capacityUniversalQty", expectedFieldList["capacityOriginalUOMKey"][i], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityPlatformQty"][i] == keyValues["capacityPlatformQty"], string.Format("for Field {0} expected {1} but got {2}", "capacityPlatformQty", expectedFieldList["capacityOriginalUOMKey"][i], keyValues["capacityOriginalUomKey"]));           
            }
        }
    }
}
