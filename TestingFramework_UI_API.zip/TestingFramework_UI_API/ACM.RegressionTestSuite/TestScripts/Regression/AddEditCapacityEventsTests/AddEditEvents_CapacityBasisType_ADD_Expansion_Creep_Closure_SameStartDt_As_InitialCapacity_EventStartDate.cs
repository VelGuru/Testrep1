﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using APITestSuite;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{
    public class AddEditEvents_CapacityBasisType_ADD_Expansion_Creep_Closure_SameStartDt_As_InitialCapacity_EventStartDate
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
      

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_CapacityBasisType_ADD_Expansion_Creep_Closure_SameStartDt_As_InitialCapacity_EventStartDate", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void AddExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDtTest(AppInputData inputData)
        {

            AddEditEvents_CapacityBasisType_ADD_Expansion_Creep_Closure_SameStartDt_As_InitialCapacity_EventStartDate ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt = new AddEditEvents_CapacityBasisType_ADD_Expansion_Creep_Closure_SameStartDt_As_InitialCapacity_EventStartDate();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            
            ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;            
            string cdInitial = inputData.cdInitials;
            string assetUnitName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();            

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New Asset Unit and Add Initial Capacity
            ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.CreateNewAssetUnit(inputKeyValues);
            ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.GetAssetUnitKey(assetUnitName);

            // Trying to Add expansion event with EventStart Date Same Date as Initial Capacity EventStartdate 
            ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.RunAssetUnitCapacity(inputData.expansionCapacityEventField, ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.assetUnitKey,(int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_MULTIPLE_CAPACITY_EVENTS_ON_SAMEDAY);

            // Trying to Add Creep with EventStart Date Same Date as Initial Capacity EventStartdate 
            ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.RunAssetUnitCapacity(inputData.creepCorrectionEventField, ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.assetUnitKey, (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_MULTIPLE_CAPACITY_EVENTS_ON_SAMEDAY);

            // Trying to Add Closure with EventStart Date Same Date as Initial Capacity EventStartdate 
            ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.RunAssetUnitCapacity(inputData.closureEventField, ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.assetUnitKey, (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_MULTIPLE_CAPACITY_EVENTS_ON_SAMEDAY);

            //Updating the Expansion Capacity event StartDate to InitialCapacityStartDate+2 Days
            foreach (ExpansionCapacityEventField datafield in inputData.expansionCapacityEventField)
            {
                if (datafield.field == "capacityStartDt")
                {
                    DateTime capacityStartDate = DateTime.ParseExact(datafield.value, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    string capacityStartDt = capacityStartDate.AddDays(2).ToString("yyyy-MM-dd");

                    datafield.value = capacityStartDt;
                }
            }

            //Adding Expansion Capacity after updating the Capacity StartDate
            ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.RunAssetUnitCapacity(inputData.expansionCapacityEventField, ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.assetUnitKey, (int)HttpStatusCode.Created, null);

            //Updating the Creep Capacity event StartDate same as Expansion CapacityStartDate
            foreach (CreepCorrectionEventField datafield in inputData.creepCorrectionEventField)
            {
                if (datafield.field == "capacityStartDt")
                {
                    DateTime capacityStartDate = DateTime.ParseExact(datafield.value, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    string capacityStartDt = capacityStartDate.AddDays(2).ToString("yyyy-MM-dd");

                    datafield.value = capacityStartDt;
                }
            }
            // Trying to Add Creep with EventStart Date Same Date as Expansion Capacity EventStartdate 
            ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.RunAssetUnitCapacity(inputData.creepCorrectionEventField, ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.assetUnitKey, (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_MULTIPLE_CAPACITY_EVENTS_ON_SAMEDAY);

            //Updating the Closure event StartDate same as Expansion CapacityStartDate
            foreach (ClosureEventField datafield in inputData.closureEventField)
            {
                if (datafield.field == "capacityStartDt")
                {
                    DateTime capacityStartDate = DateTime.ParseExact(datafield.value, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    string capacityStartDt = capacityStartDate.AddDays(2).ToString("yyyy-MM-dd");

                    datafield.value = capacityStartDt;
                }
            }
            // Trying to Add Closure with EventStart Date Same Date as Expansion Capacity EventStartdate 
            ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.RunAssetUnitCapacity(inputData.closureEventField, ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.assetUnitKey, (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_MULTIPLE_CAPACITY_EVENTS_ON_SAMEDAY);

            Assert.True(ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.errors.Count == 0, ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.ApiName + ":" + "\n" + string.Join("\n ", ExpansionCreepClosureToUnitSameStartDtAsInitialCapacityEventStartDt.errors.Select(s => $"'{s}'")));
        }

        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

      private void RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey, int StatusCode,string expectedErrorMessage)
        {
            string ErrorMessage = null;
            Dictionary<string, string> assetUnitCapacitiesFields =RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);

            if (!string.IsNullOrEmpty(responseData.Content))
            {
                JObject json = JObject.Parse(responseData.Content);
                ErrorMessage = json["errors"]["ErrorMessage"][0].ToString();
            }
            if (responseData.StatusCode != StatusCode || ErrorMessage != expectedErrorMessage)
            {
                throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Actual Status Code and ErrorMessage : " + responseData.StatusCode + "," + ErrorMessage + System.Environment.NewLine + " Expected Status Code and ErrorMessage : " + StatusCode + "," + expectedErrorMessage + System.Environment.NewLine + "API Request :" + responseData.RequestBody);
            }
        }       
    }
}
