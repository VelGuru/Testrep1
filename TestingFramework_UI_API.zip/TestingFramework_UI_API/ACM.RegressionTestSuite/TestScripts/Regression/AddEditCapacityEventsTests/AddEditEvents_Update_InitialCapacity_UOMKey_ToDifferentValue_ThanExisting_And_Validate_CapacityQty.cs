﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using APITestSuite;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{

    public class AddEditEvents_Update_InitialCapacity_UOMKey_ToDifferentValue_ThanExisting_And_Validate_CapacityQty
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
        int capacityEventKey = 0;

        [Theory(Skip = "API is not allowing original UOM Key and Original capacity to test UOM conversion Scenarios")]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_Update_InitialCapacity_UOMKey_ToDifferentValue_ThanExisting_And_Validate_CapacityQty", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQtyTest(AppInputData inputData)
        {

            AddEditEvents_Update_InitialCapacity_UOMKey_ToDifferentValue_ThanExisting_And_Validate_CapacityQty UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty = new AddEditEvents_Update_InitialCapacity_UOMKey_ToDifferentValue_ThanExisting_And_Validate_CapacityQty();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            
            UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;            
            string cdInitial = inputData.cdInitials;
            string Xpath = inputData.xpath;
            string assetUnitName = null;
            string apiName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();            

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New Asset Unit and adding Initial Capacity 
            UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.CreateNewAssetUnit(inputKeyValues);
            UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.GetAssetUnitKey(assetUnitName);            

            //Code to create AssetUnitCapacities/{AssetUnitId} API
            foreach (ValidationParamFields TestField in inputData.validationParamFields)
            {
                if(TestField.field== "apiName")
                {
                    apiName = TestField.value.Replace("{AssetUnitId}", UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.assetUnitKey.ToString());
                }
            }

            UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.RunAssetUnitCapacitiesandValidateCapacityUOMFields(apiName, inputData.expectedFieldValues,0);

            //Function call to get CapacityEventKey
            UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.capacityEventKey = UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.GetAssetUnitCapacityEventKey(UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.assetUnitKey);

            // Function call to  update initial capacity event value
            UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.UpdateAssetUnitCapacityEvent(UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.capacityEventKey, UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.assetUnitKey, "capacityOriginalUomKey", "1");

            UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.RunAssetUnitCapacitiesandValidateCapacityUOMFields(apiName,inputData.expectedFieldValues,1);

            Assert.True(UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.errors.Count == 0, UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.ApiName + ":" + "\n" + string.Join("\n ", UpdateInitialCapacityUOMKeyToDifferentValueThanExistingAndValidateCapacityQty.errors.Select(s => $"'{s}'")));
        }

        //Method to query DB and Get AssetUnitKey
        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to Create New Asset Unit 
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private int GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                capacityEventKey = RestUtil.GetFirstId(APIName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return capacityEventKey;
        }
        //Method to update Initial Capacity
        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
        //Method to Validate the CapacityUOM Fields
        private void RunAssetUnitCapacitiesandValidateCapacityUOMFields(string apiName, List<ExpectedFieldValues> expectedFieldValues,int i)
        {
            ResponseData responseData = new ResponseData();
            responseData=RestUtil.GetMethod(apiName);

            Dictionary<string, List<string>> expectedFieldList = AssetCapacityUtils.expectedFieldValuesList(expectedFieldValues);

            foreach (Dictionary<string,string> keyValues in responseData.ResponseValues)
            {                
                Assert.True(expectedFieldList["capacityOriginalUOMKey"][i] == keyValues["capacityOriginalUomKey"], string.Format("for Field {0} expected {1} but got {2}", "CapacityOriginalUomKey", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityOriginalUOMCd"][i] == keyValues["capacityOriginalUomCd"], string.Format("for Field {0} expected {1} but got {2}", "capacityOriginalUOMCd", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityUniversalUOMKey"][i] == keyValues["capacityUniversalUomKey"], string.Format("for Field {0} expected {1} but got {2}", "capacityUniversalUOMKey", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityUniversalUOMCd"][i] == keyValues["capacityUniversalUomCd"], string.Format("for Field {0} expected {1} but got {2}", "capacityUniversalUOMCd", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityPlatformUOMKey"][i] == keyValues["capacityPlatformUomKey"], string.Format("for Field {0} expected {1} but got {2}", "capacityPlatformUOMKey", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityPlatformUOMCd"][i] == keyValues["capacityPlatformUomCd"], string.Format("for Field {0} expected {1} but got {2}", "capacityPlatformUOMCd", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityOriginalQty"][i] == keyValues["capacityOriginalQty"], string.Format("for Field {0} expected {1} but got {2}", "capacityOriginalQty", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityUniversalQty"][i] == keyValues["capacityUniversalQty"], string.Format("for Field {0} expected {1} but got {2}", "capacityUniversalQty", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));
                Assert.True(expectedFieldList["capacityPlatformQty"][i] == keyValues["capacityPlatformQty"], string.Format("for Field {0} expected {1} but got {2}", "capacityPlatformQty", expectedFieldList["capacityOriginalUOMKey"][0], keyValues["capacityOriginalUomKey"]));           
            }
        }
    }
}
