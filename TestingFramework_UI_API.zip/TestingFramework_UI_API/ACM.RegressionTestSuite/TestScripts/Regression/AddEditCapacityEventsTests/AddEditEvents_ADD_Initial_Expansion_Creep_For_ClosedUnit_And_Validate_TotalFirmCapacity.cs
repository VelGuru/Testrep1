﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using APITestSuite;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{
    public class AddEditEvents_ADD_Initial_Expansion_Creep_For_ClosedUnit_And_Validate_TotalFirmCapacity
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
      

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_ADD_Initial_Expansion_Creep_For_ClosedUnit_And_Validate_TotalFirmCapacity", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacityTest(AppInputData inputData)
        {

            AddEditEvents_ADD_Initial_Expansion_Creep_For_ClosedUnit_And_Validate_TotalFirmCapacity InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity = new AddEditEvents_ADD_Initial_Expansion_Creep_For_ClosedUnit_And_Validate_TotalFirmCapacity();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            
            InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;            
            string cdInitial = inputData.cdInitials;
            string Xpath = inputData.xpath;
            string assetUnitName = null;
            string apiName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();            

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New Asset Unit and Adding InitialCapacity
            InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.CreateNewAssetUnit(inputKeyValues);
            InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.GetAssetUnitKey(assetUnitName);

            //Code to create AssetUnitCapacities/{UnitId}/TotalFirmUnitCapacity API            
            foreach (ValidationParamFields TestField in inputData.validationParamFields)
            {
                if(TestField.field== "apiName")
                {
                    apiName = TestField.value.Replace("{UnitId}", InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.assetUnitKey.ToString());
                }
            }

            // Validating the TotalFirmCapacity should be equal to Initial Capacity of the Unit
            InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName, decimal.Parse(inputKeyValues["quantity"]), Xpath);

            // Adding Closure event 
            InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.closureEventField, InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.assetUnitKey,(int)HttpStatusCode.Created,null);
           
            // Validating the TotalFirmCapacity after adding closure Event
            InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName,0, Xpath);

            // Trying to Add ExpansionEvent after Closing the Unit without Initial Capacity
            InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.expansionCapacityEventField, InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.assetUnitKey, (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_CANNOT_ADD_CAPACITY_AFTER_CLOSURE);

            // Trying Creep after after Closing the Unit without Initial Capacity
            InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.creepCorrectionEventField, InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.assetUnitKey, (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_CANNOT_ADD_CAPACITY_AFTER_CLOSURE);

            // Adding Initial Capacity again after Closing the Unit    
            System.Threading.Thread.Sleep(2000);
            decimal InitialCapacityAfterUnitReopen=InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.initialCapacityEventField, InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.assetUnitKey,(int)HttpStatusCode.Created, null);

            // Validating the TotalFirmCapacity after reopening the Unit by adding Initial Capacity
            InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName,InitialCapacityAfterUnitReopen, Xpath);

            Assert.True(InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.errors.Count == 0, InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.ApiName + ":" + "\n" + string.Join("\n ", InitialExpansionCreepForClosedUnitAndValidateTotalFirmCapacity.errors.Select(s => $"'{s}'")));
        }

        //Method to Get the AssetUnitKey
        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to Create New Asset Unit and add Initial Capacity
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to add Initial,Expansion,Creep and Closure Capacity events
        private decimal RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey, int expectedStatusCode, string expectedErrorMessage)
        {
            string ErrorMessage = null;
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);

            if (!string.IsNullOrEmpty(responseData.Content))
            {
                JObject json = JObject.Parse(responseData.Content);
                ErrorMessage = json["errors"]["ErrorMessage"][0].ToString();
            }

            if (responseData.StatusCode != expectedStatusCode || ErrorMessage != expectedErrorMessage)
            {
                throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Actual Status Code and ErrorMessage : " + responseData.StatusCode + "," + ErrorMessage + System.Environment.NewLine + " Expected Status Code and ErrorMessage : " + expectedStatusCode + "," + expectedErrorMessage + System.Environment.NewLine + "API Request :" + responseData.RequestBody);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalQty"]);
        }        

        //Method to Validate the Unit's TotalFirmCapacity 
        private void ValidateTotalFirmUnitCapacityTest(string apiName, decimal expectedQty, string Xpath)
        {
            decimal ActualQty = decimal.Parse(RestUtils.GetAPIFieldValue(apiName, Xpath));
            if (ActualQty != expectedQty)
            {
                throw new Exception("Mismatch in Actual and Expected Quantity" + "Actual Quantity is : " + ActualQty + " and Expected Quantity is : " + expectedQty);
            }
        }
    }
}
