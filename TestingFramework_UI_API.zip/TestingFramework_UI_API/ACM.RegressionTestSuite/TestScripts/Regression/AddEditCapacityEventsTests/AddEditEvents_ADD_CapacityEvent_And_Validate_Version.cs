﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using APITestSuite;
using RegressionTestSuite.AppTestUtils;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{
    public class AddEditEvents_ADD_CapacityEvent_And_Validate_Version
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
        List<int> assetunits = new List<int>();
        int capacityEventKey = 0;              


        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_ADD_CapacityEvent_And_Validate_Version", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void AddCapacityventAndValidateVersionTest(AppInputData inputData)
        {
            AddEditEvents_ADD_CapacityEvent_And_Validate_Version AddCapacityventAndValidateVersion= new AddEditEvents_ADD_CapacityEvent_And_Validate_Version();
            AddCapacityventAndValidateVersion.ApiName = inputData.apiName;
            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;

            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;
            string cdInitial = inputData.cdInitials;
            string Xpath = inputData.xpath;
            string assetUnitName = null;
            string apiName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New Asset Unit and Adding InitialCapacity
            AddCapacityventAndValidateVersion.CreateNewAssetUnit(inputKeyValues);
            AddCapacityventAndValidateVersion.GetAssetUnitKey(assetUnitName);      
             
            // Function Call to get the capacity Event key.
            AddCapacityventAndValidateVersion.capacityEventKey = AddCapacityventAndValidateVersion.GetAssetUnitCapacityEventKey(AddCapacityventAndValidateVersion.assetUnitKey);

            //Code to create AssetUnitCapacities/{UnitCapacityId}/versions API
            foreach (ValidationParamFields TestField in inputData.validationParamFields)
            {
                if (TestField.field == "apiName")
                {
                    apiName = TestField.value.Replace("{UnitCapacityId}", AddCapacityventAndValidateVersion.capacityEventKey.ToString());
                }
            }

            AddCapacityventAndValidateVersion.RunAssetUnitCapacitiesVersionandValidateQty(apiName, inputData.expectedFieldValues,0);

            // Code to update recent capacity event value
            AddCapacityventAndValidateVersion.UpdateAssetUnitCapacityEvent(AddCapacityventAndValidateVersion.capacityEventKey, AddCapacityventAndValidateVersion.assetUnitKey, "capacityUniversalQty", "550");

            AddCapacityventAndValidateVersion.RunAssetUnitCapacitiesVersionandValidateQty(apiName, inputData.expectedFieldValues, 1);

            Assert.True(AddCapacityventAndValidateVersion.errors.Count == 0, AddCapacityventAndValidateVersion.ApiName + ":" + "\n" + string.Join("\n ", AddCapacityventAndValidateVersion.errors.Select(s => $"'{s}'")));
        }


        //Method to Get the AssetUnitKey
        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to Create New Asset Unit and add Initial Capacity
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                System.Threading.Thread.Sleep(3000);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }      

        private int GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;

            try
            {
                capacityEventKey = RestUtil.GetFirstId(APIName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return capacityEventKey;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void RunAssetUnitCapacitiesVersionandValidateQty(string ApiName, List<ExpectedFieldValues> expectedFieldValues, int i)
        {
            try
            {
                ResponseData responseData = new ResponseData();
                responseData = RestUtil.GetMethod(ApiName);
                Dictionary<string, List<string>> expectedFieldList = AssetCapacityUtils.expectedFieldValuesList(expectedFieldValues);
                if (RestUtil.IsStatusCodeOk((int)responseData.StatusCode))
                {
                    foreach (Dictionary<string, string> keyValues in responseData.ResponseValues)
                    {
                        DateTime VersionEffectiveDate = DateTime.ParseExact(keyValues["versionEffectiveDate"], "M/d/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                        string versionEffectiveDt = VersionEffectiveDate.ToString("yyyy-MM-dd");
                        string currentDate = RestUtils.getCurrentDate();

                        Assert.True(expectedFieldList["capacityStartDate"][0] == keyValues["capacityStartDate"], string.Format("Field {0} expected {1} but got {2}", "capacityStartDate", expectedFieldList["capacityStartDate"][0], keyValues["capacityStartDate"]));
                        Assert.True(currentDate == versionEffectiveDt, string.Format("Field {0} expected {1} but got {2}", "versionEffectiveDate", currentDate, versionEffectiveDt));
                        Assert.True(expectedFieldList["planningProbabilityTypeDesc"][0] == keyValues["planningProbabilityTypeDesc"], string.Format("Field {0} expected {1} but got {2}", "planningProbabilityTypeDesc", expectedFieldList["planningProbabilityTypeDesc"][0], keyValues["planningProbabilityTypeDesc"]));
                        Assert.True(expectedFieldList["capacityBasisTypeDesc"][0] == keyValues["capacityBasisTypeDesc"], string.Format("Field {0} expected {1} but got {2}", "capacityBasisTypeDesc", expectedFieldList["capacityBasisTypeDesc"][0], keyValues["capacityBasisTypeDesc"]));
                        Assert.True(expectedFieldList["capacityUniversalQty"][i] == keyValues["capacityUniversalQty"], string.Format("Field {0} expected {1} but got {2}", "capacityUniversalQty", expectedFieldList["capacityUniversalQty"][i], keyValues["capacityUniversalQty"]));
                        Assert.True(expectedFieldList["measureUnitCd"][0] == keyValues["measureUnitCd"], string.Format("Field {0} expected {1} but got {2}", "measureUnitCd", expectedFieldList["measureUnitCd"][0], keyValues["measureUnitCd"]));
                        Assert.True(expectedFieldList["dataProviderAbbr"][0] == keyValues["dataProviderAbbr"], string.Format("Field {0} expected {1} but got {2}", "dataProviderAbbr", expectedFieldList["dataProviderAbbr"][0], keyValues["dataProviderAbbr"]));                      
                    }
                }
                                   
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}
