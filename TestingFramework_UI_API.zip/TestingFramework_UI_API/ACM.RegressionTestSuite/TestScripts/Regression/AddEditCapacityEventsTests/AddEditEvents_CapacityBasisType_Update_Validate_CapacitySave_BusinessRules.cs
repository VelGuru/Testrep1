﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using APITestSuite;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{
    public class AddEditEvents_CapacityBasisType_Update_Validate_CapacitySave_BusinessRules
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
        int[] capacityEventKeys;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_AddEditEvents_CapacityBasisType_UpdateCapacityEvents_Validate_CapacitySave_BusinessRules", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void AddUpdateValidateCapacitySaveBusinessRulesTest(AppInputData inputData)
        {

            AddEditEvents_CapacityBasisType_Update_Validate_CapacitySave_BusinessRules AddUpdateValidateCapacitySaveBusinessRules = new AddEditEvents_CapacityBasisType_Update_Validate_CapacitySave_BusinessRules();
            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            
            AddUpdateValidateCapacitySaveBusinessRules.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;            
            string cdInitial = inputData.cdInitials;
            string assetUnitName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();
            List<FilterField> filterFieldList = inputData.filterField;
            List<string> Filtervalue = null;
            Dictionary<string, List<string>> filterFieldsList = new Dictionary<string, List<string>>();
            foreach (FilterField fieldname in filterFieldList)
            {
                Filtervalue = Util.GetListFromCommaSepString(fieldname.value);
                filterFieldsList.Add(fieldname.field, Filtervalue);
            }

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New Asset Unit and Add Initial Capacity
            AddUpdateValidateCapacitySaveBusinessRules.CreateNewAssetUnit(inputKeyValues);
            AddUpdateValidateCapacitySaveBusinessRules.GetAssetUnitKey(assetUnitName);

            // Function Call to get capacity Event keys and to update Initial Capacity Event.
            AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys = AddUpdateValidateCapacitySaveBusinessRules.GetAssetUnitCapacityEventKey(AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey);
    
            // Code to Validate - changing Capacity Basis Type value from "Initial Capacity" to "Expansion/Creep/Closure" should Throw error message "Unit Not Yet Initialized"
            AddUpdateValidateCapacitySaveBusinessRules.UpdateAssetUnitCapacityEvent(AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys[0], AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, "capacityBasisTypeKey", filterFieldsList["capacityBasisTypeKey"][0], (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_UNIT_NOT_INITIALIZED);
            AddUpdateValidateCapacitySaveBusinessRules.UpdateAssetUnitCapacityEvent(AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys[0], AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, "capacityBasisTypeKey", filterFieldsList["capacityBasisTypeKey"][1], (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_UNIT_NOT_INITIALIZED);
            AddUpdateValidateCapacitySaveBusinessRules.UpdateAssetUnitCapacityEvent(AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys[0], AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, "capacityBasisTypeKey", filterFieldsList["capacityBasisTypeKey"][2], (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_UNIT_NOT_INITIALIZED);

            // Adding expansion event and to get capacity Event key
            AddUpdateValidateCapacitySaveBusinessRules.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, (int)HttpStatusCode.Created);
            AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys = AddUpdateValidateCapacitySaveBusinessRules.GetAssetUnitCapacityEventKey(AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey);

            // Code to Validate - changing Expansion Event Start Date value to date equal to and before to Initial Capacity Start Date should Throw error message "Unit Not Yet Initialized"
            AddUpdateValidateCapacitySaveBusinessRules.UpdateAssetUnitCapacityEvent(AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys[1], AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, "capacityStartDt", filterFieldsList["capacityStartDt"][0], (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_UNIT_NOT_INITIALIZED);
            AddUpdateValidateCapacitySaveBusinessRules.UpdateAssetUnitCapacityEvent(AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys[1], AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, "capacityStartDt", filterFieldsList["capacityStartDt"][1], (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_MULTIPLE_CAPACITY_EVENTS_ON_SAMEDAY);

            // Adding Creep after creating New Asset Unit
            AddUpdateValidateCapacitySaveBusinessRules.RunAssetUnitCapacity(inputData.creepCorrectionEventField, AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, (int)HttpStatusCode.Created);
            AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys = AddUpdateValidateCapacitySaveBusinessRules.GetAssetUnitCapacityEventKey(AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey);

            // Code to Validate - changing Creep Event Start Date value to date equal to and before to Initial Capacity Start Date should Throw error message "Unit Not Yet Initialized"
            AddUpdateValidateCapacitySaveBusinessRules.UpdateAssetUnitCapacityEvent(AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys[2], AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, "capacityStartDt", filterFieldsList["capacityStartDt"][0], (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_UNIT_NOT_INITIALIZED);
            AddUpdateValidateCapacitySaveBusinessRules.UpdateAssetUnitCapacityEvent(AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys[2], AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, "capacityStartDt", filterFieldsList["capacityStartDt"][1], (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_MULTIPLE_CAPACITY_EVENTS_ON_SAMEDAY);

            // Adding Closure event after creating New Asset Unit
            AddUpdateValidateCapacitySaveBusinessRules.RunAssetUnitCapacity(inputData.closureEventField, AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, (int)HttpStatusCode.Created);
            AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys = AddUpdateValidateCapacitySaveBusinessRules.GetAssetUnitCapacityEventKey(AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey);

            // Code to Validate - changing Closure Event Start Date value to equal to and before to before Initial Capacity Start Date should Throw error message "Unit Not Yet Initialized"
            AddUpdateValidateCapacitySaveBusinessRules.UpdateAssetUnitCapacityEvent(AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys[3], AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, "capacityStartDt", filterFieldsList["capacityStartDt"][0], (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_UNIT_NOT_INITIALIZED);
            AddUpdateValidateCapacitySaveBusinessRules.UpdateAssetUnitCapacityEvent(AddUpdateValidateCapacitySaveBusinessRules.capacityEventKeys[3], AddUpdateValidateCapacitySaveBusinessRules.assetUnitKey, "capacityStartDt", filterFieldsList["capacityStartDt"][1], (int)HttpStatusCode.BadRequest, AppConstants.ERROR_MESSAGE_MULTIPLE_CAPACITY_EVENTS_ON_SAMEDAY);

            Assert.True(AddUpdateValidateCapacitySaveBusinessRules.errors.Count == 0, AddUpdateValidateCapacitySaveBusinessRules.ApiName + ":" + "\n" + string.Join("\n ", AddUpdateValidateCapacitySaveBusinessRules.errors.Select(s => $"'{s}'")));
        }

        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

      private void RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey, int StatusCode)
        {
            Dictionary<string, string> assetUnitCapacitiesFields =RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);

            // Code to verify Status Code
            Assert.Equal(responseData.StatusCode, StatusCode);
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue, int expectedStatusCode, string expectedErrorMessage)
        {
            string ErrorMessage = null;
            ResponseData responseData = AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            
            if (expectedStatusCode == (int)HttpStatusCode.OK)
            {
                if (responseData.StatusCode != expectedStatusCode)
                {
                    throw new Exception("API Name :" + responseData.APIName + System.Environment.NewLine + " Actual Status Code and ErrorMessage : " + responseData.StatusCode + "," + ErrorMessage + System.Environment.NewLine + " Expected Status Code and ErrorMessage : " + expectedStatusCode + "," + expectedErrorMessage + System.Environment.NewLine + "API Request :" + responseData.RequestBody);
                }
            }
            else if (expectedStatusCode == (int)HttpStatusCode.BadRequest)
            {
                if (responseData.StatusCode != expectedStatusCode || !(responseData.Content.Contains(expectedErrorMessage)))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Actual Status Code and ErrorMessage : " + responseData.StatusCode + "," + ErrorMessage + System.Environment.NewLine + " Expected Status Code and ErrorMessage : " + expectedStatusCode + "," + expectedErrorMessage + System.Environment.NewLine + "API Request :" + responseData.RequestBody);
                }
            }
        }

        private int[] GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            int[] capacityEventKeys;
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;

            try
            {
                capacityEventKeys = RestUtil.GetAllRecordIds(APIName);
                Array.Sort(capacityEventKeys);

                return capacityEventKeys;
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return null;
        }

    }
}
