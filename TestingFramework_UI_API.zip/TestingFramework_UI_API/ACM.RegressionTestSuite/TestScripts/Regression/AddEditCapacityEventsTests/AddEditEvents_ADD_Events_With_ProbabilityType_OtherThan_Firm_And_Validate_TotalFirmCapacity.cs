﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using APITestSuite;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace RegressionTestSuite.TestScripts.AddEditCapacityEventsTests
{

    public class AddEditEvents_ADD_Events_With_ProbabilityType_OtherThan_Firm_And_Validate_TotalFirmCapacity
    {
        
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;
      

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_ADD_Events_With_ProbabilityType_OtherThan_Firm_And_Validate_TotalFirmCapacity", MemberType = typeof(TotalCapacityTestDataGenerator))]

        private static void EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacityTest(AppInputData inputData)
        {

            AddEditEvents_ADD_Events_With_ProbabilityType_OtherThan_Firm_And_Validate_TotalFirmCapacity EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity = new AddEditEvents_ADD_Events_With_ProbabilityType_OtherThan_Firm_And_Validate_TotalFirmCapacity();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            
            EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;            
            string cdInitial = inputData.cdInitials;
            string Xpath = inputData.xpath;
            string assetUnitName = null;
            string apiName = null;
            Dictionary<string, string> inputKeyValues = new Dictionary<string, string>();            

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        inputKeyValues.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnitName = inputKeyValues["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                inputKeyValues.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            //Creating New Asset Unit and Adding InitialCapacity with probability type as "Firm"
            EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.CreateNewAssetUnit(inputKeyValues);
            EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.GetAssetUnitKey(assetUnitName);

            //Code to create AssetUnitCapacities/{UnitId}/TotalFirmUnitCapacity API
            foreach (ValidationParamFields TestField in inputData.validationParamFields)
            {
                if(TestField.field== "apiName")
                {
                    apiName = TestField.value.Replace("{UnitId}", EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.assetUnitKey.ToString());
                }
            }

            //Validating the TotalFirmCapacity should be equal to Initial Capacity of the Unit
            EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName, decimal.Parse(inputKeyValues["quantity"]), Xpath);

            //Adding Expansion event with Probability Type other than Firm
            EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.expansionCapacityEventField, EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.assetUnitKey);

            //Validating the TotalFirmCapacity after adding expansion event and Value should be equal to Units Initial Capacity
            EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName, decimal.Parse(inputKeyValues["quantity"]), Xpath);

            //Adding Creep event with Probability Type other than Firm
            EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.creepCorrectionEventField, EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.assetUnitKey);

            //Validating the TotalFirmCapacity after adding Creep event and Value should be equal to Units Initial Capacity
            EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName, decimal.Parse(inputKeyValues["quantity"]), Xpath);

            // Adding Closure event with Probability Type other than Firm
            EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.RunAssetUnitCapacity(inputData.closureEventField, EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.assetUnitKey);

            // Validating the TotalFirmCapacity after adding Closure and Value should be equal to Units Initial Capacity
             EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.ValidateTotalFirmUnitCapacityTest(apiName, decimal.Parse(inputKeyValues["quantity"]), Xpath);       

            Assert.True(EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.errors.Count == 0, EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.ApiName + ":" + "\n" + string.Join("\n ", EventsWithProbabilityTypeOtherThanFirmAndValidateTotalFirmCapacity.errors.Select(s => $"'{s}'")));
        }

        //Method to Get the AssetUnitKey
        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to Create New Asset Unit and add Initial Capacity
        private void CreateNewAssetUnit(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
   
        //Method to add expansion,Creep and Closure events
        private decimal RunAssetUnitCapacity<T>(List<T>  inputData,int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalQty"]);
        }

        //Method to Validate the Unit's TotalFirmCapacity 
        private void ValidateTotalFirmUnitCapacityTest(string apiName, decimal expectedQty, string Xpath)
        {
            decimal ActualQty = decimal.Parse(RestUtils.GetAPIFieldValue(apiName, Xpath));
            if (ActualQty != expectedQty)
            {
                throw new Exception("Mismatch in Actual and Expected Quantity" + "Actual Quantity is : " + ActualQty + " and Expected Quantity is : " + expectedQty);
            }
        }
    }
}
