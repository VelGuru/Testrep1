﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using APITestSuite;
using Microsoft.VisualBasic;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace AssetCapacityAndMaintenance.RegressionTestSuite.TestScripts.IncrementalCapacityTest
{

    public class IncrementalCapacity_MonthlyUnitLevel_Versioneffective
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string capacityStartDateInstring = null;
        int assetKey = 0;
        int capacityOriginalUomKey = 0;
        List<int> assetunits = new List<int>();
        int capacityEventKey = 0;
        string ApiName = null;
        string xPath = null;
        decimal totalCapacityBeforeUpdate = 0;
        decimal eventCapacityValue = 0;
        decimal totalCapacityAfterUpdate = 0;
        int fieldKeyValue = 0;


        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_IncrementalCapacity_MonthlyUnitLevel_VersionEffective", MemberType = typeof(TotalCapacityTestDataGenerator))]

        public static void IncrementalCapacityMonthlyUnitLevelVersioneffectiveTest(AppInputData inputData) 
        {
            IncrementalCapacity_MonthlyUnitLevel_Versioneffective incrementalCapacityMonthlyUnitLevelVersioneffective = new IncrementalCapacity_MonthlyUnitLevel_Versioneffective();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
            incrementalCapacityMonthlyUnitLevelVersioneffective.ApiName = inputData.apiName;
            incrementalCapacityMonthlyUnitLevelVersioneffective.xPath = inputData.xpath;
            List<ExpansionCapacityEventField> expansionCapacityFieldList = inputData.expansionCapacityEventField;


            // Function Call to get asset unit key which contains active capacity event
            incrementalCapacityMonthlyUnitLevelVersioneffective.assetUnitKey = incrementalCapacityMonthlyUnitLevelVersioneffective.GetFieldKeyValueWithActiveCapacityEvent("asset_unit_key");
            incrementalCapacityMonthlyUnitLevelVersioneffective.assetunits.Add(incrementalCapacityMonthlyUnitLevelVersioneffective.assetUnitKey);

            // Function Call to get asset key of the active asset unit key
            incrementalCapacityMonthlyUnitLevelVersioneffective.assetKey= incrementalCapacityMonthlyUnitLevelVersioneffective.GetFieldKeyValueWithActiveCapacityEvent("asset_key");                      

            // Function Call to get capacity Event key of the active asset unit key
            incrementalCapacityMonthlyUnitLevelVersioneffective.capacityEventKey = incrementalCapacityMonthlyUnitLevelVersioneffective.GetAssetUnitCapacityEventKey(incrementalCapacityMonthlyUnitLevelVersioneffective.assetUnitKey);

            // Function call to get event capcaity StartDate of the active asset unit key
            incrementalCapacityMonthlyUnitLevelVersioneffective.capacityStartDateInstring = incrementalCapacityMonthlyUnitLevelVersioneffective.GetAssetUnitCapacityEventValue(incrementalCapacityMonthlyUnitLevelVersioneffective.capacityEventKey, "$.[0].capacityStartDt");

            // Function call to get event capacityOriginalUomKey of the active asset unit key
            incrementalCapacityMonthlyUnitLevelVersioneffective.capacityOriginalUomKey =int.Parse(incrementalCapacityMonthlyUnitLevelVersioneffective.GetAssetUnitCapacityEventValue(incrementalCapacityMonthlyUnitLevelVersioneffective.capacityEventKey, "$.[0].capacityUniversalUomKey"));

            // Function call to get total capacity value before updating capacity event
            string APIParameters = RestUtils.GetIncrementalCapacitiesRequestURLdata(inputData.validationParamFields, incrementalCapacityMonthlyUnitLevelVersioneffective.assetunits, incrementalCapacityMonthlyUnitLevelVersioneffective.assetKey);
            incrementalCapacityMonthlyUnitLevelVersioneffective.totalCapacityBeforeUpdate = decimal.Parse(RestUtils.GetAPIFieldValue(APIParameters, incrementalCapacityMonthlyUnitLevelVersioneffective.xPath));

            // Function call to get event capacity value for before updating capacity event
            incrementalCapacityMonthlyUnitLevelVersioneffective.eventCapacityValue = decimal.Parse(incrementalCapacityMonthlyUnitLevelVersioneffective.GetAssetUnitCapacityEventValue(incrementalCapacityMonthlyUnitLevelVersioneffective.capacityEventKey, "$.[0].capacityUniversalUomKey"));

            // code to update initial capacity event value
            incrementalCapacityMonthlyUnitLevelVersioneffective.UpdateAssetUnitCapacityEvent(incrementalCapacityMonthlyUnitLevelVersioneffective.capacityEventKey, incrementalCapacityMonthlyUnitLevelVersioneffective.assetUnitKey, "capacityUniversalUomKey", "50");

            // Code to add Initial Capacity Startdate and UOM Key to expansionCapacityEventField
            foreach(ExpansionCapacityEventField datafield in inputData.expansionCapacityEventField) 
            {
                if (datafield.field== "capacityStartDt")
                {
                DateTime capacityStartDate = DateTime.ParseExact(incrementalCapacityMonthlyUnitLevelVersioneffective.capacityStartDateInstring, "M/d/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                 string capacityStartDt = capacityStartDate.AddDays(1).ToString("yyyy-MM-dd");

                    datafield.value = capacityStartDt;
                }

            if (datafield.field== "capacityOriginalUomKey")
              {
                    datafield.value = (incrementalCapacityMonthlyUnitLevelVersioneffective.capacityOriginalUomKey).ToString();
              }

            }

            // Code to add expansion capacity for the Unit in the same month as of Initial Capacity Event
            decimal ExpansionCapacity = incrementalCapacityMonthlyUnitLevelVersioneffective.RunAssetUnitCapacity(inputData.expansionCapacityEventField, incrementalCapacityMonthlyUnitLevelVersioneffective.assetUnitKey);


            incrementalCapacityMonthlyUnitLevelVersioneffective.totalCapacityAfterUpdate = incrementalCapacityMonthlyUnitLevelVersioneffective.totalCapacityBeforeUpdate - incrementalCapacityMonthlyUnitLevelVersioneffective.eventCapacityValue + 50+ ExpansionCapacity;

            // Code to validate Total capacity Value with version effective date as today's date.
            incrementalCapacityMonthlyUnitLevelVersioneffective.ValidateIncrementalCapacityWithVersionEffectiveDate(inputData.validationParamFields, incrementalCapacityMonthlyUnitLevelVersioneffective.totalCapacityAfterUpdate, incrementalCapacityMonthlyUnitLevelVersioneffective.assetunits, incrementalCapacityMonthlyUnitLevelVersioneffective.assetKey, incrementalCapacityMonthlyUnitLevelVersioneffective.xPath, RestUtils.getCurrentDate());

            // Code to validate Total capacity Value with version effective date as yesterday's date.
            incrementalCapacityMonthlyUnitLevelVersioneffective.ValidateIncrementalCapacityWithVersionEffectiveDate(inputData.validationParamFields, incrementalCapacityMonthlyUnitLevelVersioneffective.totalCapacityBeforeUpdate, incrementalCapacityMonthlyUnitLevelVersioneffective.assetunits, incrementalCapacityMonthlyUnitLevelVersioneffective.assetKey, incrementalCapacityMonthlyUnitLevelVersioneffective.xPath, RestUtils.getYesterdaysDate());

        }
        private int GetFieldKeyValueWithActiveCapacityEvent(string field)
        {
            try
            {
                fieldKeyValue = AssetCapacityUtils.GetActiveAssetUnitKeyData(field);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return fieldKeyValue;
        }

        private int GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                capacityEventKey = RestUtil.GetFirstId(APIName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return capacityEventKey;
        }


        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null;

            String apiName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
        //Method to add Initial, Expansion, Creep and Closure Events
        private decimal RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtil.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalUomKey"]);
        }
        private void ValidateIncrementalCapacityWithVersionEffectiveDate<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList,int assetKey, string Xpath, String Date)
        {
            try
            {
                string APIParameters = RestUtils.GetIncrementalCapacitiesRequestURLdata(validationParamFields, assetUnitsList,assetKey);
                if (Date == RestUtils.getYesterdaysDate())
                {
                    APIParameters = APIParameters.Replace("VersionDate=" + RestUtils.getCurrentDate(), "VersionDate=" + Date);
                }

                RestUtils.RunIncrementalCapacities(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}
