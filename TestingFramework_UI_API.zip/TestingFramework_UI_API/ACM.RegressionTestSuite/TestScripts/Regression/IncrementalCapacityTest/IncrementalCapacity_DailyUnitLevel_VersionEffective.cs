﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using APITestSuite;
using Microsoft.VisualBasic;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace AssetCapacityAndMaintenance.RegressionTestSuite.TestScripts.IncrementalCapacityTest
{
    public class IncrementalCapacity_DailyUnitLevel_VersionEffective
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string capacityStartDateInstring = null;
        int assetKey = 0;
        int capacityUniversalUomKey = 0;
        List<int> assetunits = new List<int>();
        int capacityEventKey = 0;
        string ApiName = null;
        string xPath = null;
        decimal totalCapacityBeforeUpdate = 0;
        decimal eventCapacityValue = 0;
        decimal totalCapacityAfterUpdate = 0;
        int fieldKeyValue = 0;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_IncrementalCapacity_DailyUnitLevel_VersionEffective", MemberType = typeof(TotalCapacityTestDataGenerator))]

        public static void IncrementalCapacityDailyUnitSubTypeLevelVersioneffectiveTest(AppInputData inputData)
        {
            IncrementalCapacity_DailyUnitLevel_VersionEffective incrementalCapacityDailyUnitVersionEffective = new IncrementalCapacity_DailyUnitLevel_VersionEffective();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
            incrementalCapacityDailyUnitVersionEffective.ApiName = inputData.apiName;
            incrementalCapacityDailyUnitVersionEffective.xPath = inputData.xpath;
            List<ExpansionCapacityEventField> expansionCapacityFieldList = inputData.expansionCapacityEventField;


            // Function Call to get asset unit key which contains active capacity event
            incrementalCapacityDailyUnitVersionEffective.assetUnitKey = incrementalCapacityDailyUnitVersionEffective.GetFieldKeyValueWithActiveCapacityEvent("asset_unit_key");
            incrementalCapacityDailyUnitVersionEffective.assetunits.Add(incrementalCapacityDailyUnitVersionEffective.assetUnitKey);

            // Function Call to get asset key of the active asset unit key
            incrementalCapacityDailyUnitVersionEffective.assetKey = incrementalCapacityDailyUnitVersionEffective.GetFieldKeyValueWithActiveCapacityEvent("asset_key");

            // Function Call to get capacity Event key of the active asset unit key
            incrementalCapacityDailyUnitVersionEffective.capacityEventKey = incrementalCapacityDailyUnitVersionEffective.GetAssetUnitCapacityEventKey(incrementalCapacityDailyUnitVersionEffective.assetUnitKey);

            // Function call to get total capacity value before updating capacity event
            string APIParameters = RestUtils.GetIncrementalCapacitiesRequestURLdata(inputData.validationParamFields, incrementalCapacityDailyUnitVersionEffective.assetunits, incrementalCapacityDailyUnitVersionEffective.assetKey);
            incrementalCapacityDailyUnitVersionEffective.totalCapacityBeforeUpdate = decimal.Parse(RestUtils.GetAPIFieldValue(APIParameters, incrementalCapacityDailyUnitVersionEffective.xPath));

            // Function call to get event capacity value for before updating capacity event
            incrementalCapacityDailyUnitVersionEffective.eventCapacityValue = decimal.Parse(incrementalCapacityDailyUnitVersionEffective.GetAssetUnitCapacityEventValue(incrementalCapacityDailyUnitVersionEffective.capacityEventKey, "$.[0].capacityUniversalQty"));

            // code to update initial capacity event value
            incrementalCapacityDailyUnitVersionEffective.UpdateAssetUnitCapacityEvent(incrementalCapacityDailyUnitVersionEffective.capacityEventKey, incrementalCapacityDailyUnitVersionEffective.assetUnitKey, "capacityUniversalQty", "50");           

            incrementalCapacityDailyUnitVersionEffective.totalCapacityAfterUpdate = incrementalCapacityDailyUnitVersionEffective.totalCapacityBeforeUpdate - incrementalCapacityDailyUnitVersionEffective.eventCapacityValue + 50;

            // Code to validate Total capacity Value with version effective date as today's date.
            incrementalCapacityDailyUnitVersionEffective.ValidateIncrementalCapacityWithVersionEffectiveDate(inputData.validationParamFields, incrementalCapacityDailyUnitVersionEffective.totalCapacityAfterUpdate, incrementalCapacityDailyUnitVersionEffective.assetunits, incrementalCapacityDailyUnitVersionEffective.assetKey, incrementalCapacityDailyUnitVersionEffective.xPath, RestUtils.getCurrentDate());

            // Code to validate Total capacity Value with version effective date as yesterday's date.
            incrementalCapacityDailyUnitVersionEffective.ValidateIncrementalCapacityWithVersionEffectiveDate(inputData.validationParamFields, incrementalCapacityDailyUnitVersionEffective.totalCapacityBeforeUpdate, incrementalCapacityDailyUnitVersionEffective.assetunits, incrementalCapacityDailyUnitVersionEffective.assetKey, incrementalCapacityDailyUnitVersionEffective.xPath, RestUtils.getYesterdaysDate());

        }
        private int GetFieldKeyValueWithActiveCapacityEvent(string field)
        {
            try
            {
                fieldKeyValue = AssetCapacityUtils.GetActiveAssetUnitKeyData(field);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return fieldKeyValue;
        }

        private int GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                capacityEventKey = RestUtil.GetFirstId(APIName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return capacityEventKey;
        }


        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null;

            String apiName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void ValidateIncrementalCapacityWithVersionEffectiveDate<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, int assetKey, string Xpath, String Date)
        {
            try
            {
                string APIParameters = RestUtils.GetIncrementalCapacitiesRequestURLdata(validationParamFields, assetUnitsList, assetKey);
                if (Date == RestUtils.getYesterdaysDate())
                {
                    APIParameters = APIParameters.Replace("VersionDate=" + RestUtils.getCurrentDate(), "VersionDate=" + Date);
                }

                RestUtils.RunIncrementalCapacities(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}
