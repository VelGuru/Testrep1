﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using APITestSuite;
using Microsoft.VisualBasic;
using RegressionTestSuite.AppTestUtils;
using RestSharp;
using Xunit;

namespace AssetCapacityAndMaintenance.RegressionTestSuite.TestScripts.IncrementalCapacityTest
{

    public class IncrementalCapacity_QuarterlyUnitTypeLevel_VersionEffective
    {

        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string capacityStartDateInstring = null;
        int assetKey = 0;
        int capacityOriginalUomKey = 0;
        List<int> assetunits = new List<int>();
        int capacityEventKey = 0;
        string ApiName = null;
        string xPath = null;
        decimal totalCapacityBeforeUpdate = 0;
        decimal eventCapacityValue = 0;
        decimal totalCapacityAfterUpdate = 0;
        int fieldKeyValue = 0;


        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_IncrementalCapacity_QuarterlyUnitTypeLevel_VersionEffective", MemberType = typeof(TotalCapacityTestDataGenerator))]

        public static void incrementalCapacityQuarterlyUnitTypeLevelVersioneffectiveTest(AppInputData inputData)
        {
            IncrementalCapacity_QuarterlyUnitTypeLevel_VersionEffective incrementalCapacityQuarterlyUnitTypeLevelVersion = new IncrementalCapacity_QuarterlyUnitTypeLevel_VersionEffective();

            List<AssetUnitsTestDataFields> assetUnitTestDataList = inputData.assetUnitsTestDataFields;
            incrementalCapacityQuarterlyUnitTypeLevelVersion.ApiName = inputData.apiName;
            incrementalCapacityQuarterlyUnitTypeLevelVersion.xPath = inputData.xpath;
            List<ExpansionCapacityEventField> expansionCapacityFieldList = inputData.expansionCapacityEventField;


            // Function Call to get asset unit key which contains active capacity event
            incrementalCapacityQuarterlyUnitTypeLevelVersion.assetUnitKey = incrementalCapacityQuarterlyUnitTypeLevelVersion.GetFieldKeyValueWithActiveCapacityEvent("asset_unit_key");
            incrementalCapacityQuarterlyUnitTypeLevelVersion.assetunits.Add(incrementalCapacityQuarterlyUnitTypeLevelVersion.assetUnitKey);

            // Function Call to get asset key of the active asset unit key
            incrementalCapacityQuarterlyUnitTypeLevelVersion.assetKey = incrementalCapacityQuarterlyUnitTypeLevelVersion.GetFieldKeyValueWithActiveCapacityEvent("asset_key");

            // Function Call to get capacity Event key of the active asset unit key
            incrementalCapacityQuarterlyUnitTypeLevelVersion.capacityEventKey = incrementalCapacityQuarterlyUnitTypeLevelVersion.GetAssetUnitCapacityEventKey(incrementalCapacityQuarterlyUnitTypeLevelVersion.assetUnitKey);

            // Function call to get event capcaity StartDate of the active asset unit key
            incrementalCapacityQuarterlyUnitTypeLevelVersion.capacityStartDateInstring = incrementalCapacityQuarterlyUnitTypeLevelVersion.GetAssetUnitCapacityEventValue(incrementalCapacityQuarterlyUnitTypeLevelVersion.capacityEventKey, "$.[0].capacityStartDt");

            // Function call to get event capacityOriginalUomKey of the active asset unit key
            incrementalCapacityQuarterlyUnitTypeLevelVersion.capacityOriginalUomKey = int.Parse(incrementalCapacityQuarterlyUnitTypeLevelVersion.GetAssetUnitCapacityEventValue(incrementalCapacityQuarterlyUnitTypeLevelVersion.capacityEventKey, "$.[0].capacityUniversalQty"));

            // Function call to get total capacity value before updating capacity event
            string APIParameters = RestUtils.GetIncrementalCapacitiesRequestURLdata(inputData.validationParamFields, incrementalCapacityQuarterlyUnitTypeLevelVersion.assetunits, incrementalCapacityQuarterlyUnitTypeLevelVersion.assetKey);
            incrementalCapacityQuarterlyUnitTypeLevelVersion.totalCapacityBeforeUpdate = decimal.Parse(RestUtils.GetAPIFieldValue(APIParameters, incrementalCapacityQuarterlyUnitTypeLevelVersion.xPath));

            // Function call to get event capacity value for before updating capacity event
            incrementalCapacityQuarterlyUnitTypeLevelVersion.eventCapacityValue = decimal.Parse(incrementalCapacityQuarterlyUnitTypeLevelVersion.GetAssetUnitCapacityEventValue(incrementalCapacityQuarterlyUnitTypeLevelVersion.capacityEventKey, "$.[0].capacityUniversalQty"));

            // code to update initial capacity event value
            incrementalCapacityQuarterlyUnitTypeLevelVersion.UpdateAssetUnitCapacityEvent(incrementalCapacityQuarterlyUnitTypeLevelVersion.capacityEventKey, incrementalCapacityQuarterlyUnitTypeLevelVersion.assetUnitKey, "capacityOriginalQty", "50");

            // Code to add Initial Capacity Startdate and UOM Key to expansionCapacityEventField
            foreach (ExpansionCapacityEventField datafield in inputData.expansionCapacityEventField)
            {
                if (datafield.field == "capacityStartDt")
                {
                    DateTime capacityStartDate = DateTime.ParseExact(incrementalCapacityQuarterlyUnitTypeLevelVersion.capacityStartDateInstring, "M/d/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                    string capacityStartDt = capacityStartDate.AddMonths(1).ToString("yyyy-MM-dd");

                    datafield.value = capacityStartDt;
                }

                if (datafield.field == "capacityOriginalUomKey")
                {
                    datafield.value = (incrementalCapacityQuarterlyUnitTypeLevelVersion.capacityOriginalUomKey).ToString();
                }

            }

            // Code to add expansion capacity for the Unit in the same month as of Initial Capacity Event
            decimal ExpansionCapacity = incrementalCapacityQuarterlyUnitTypeLevelVersion.RunAssetUnitCapacity(inputData.expansionCapacityEventField, incrementalCapacityQuarterlyUnitTypeLevelVersion.assetUnitKey);


            incrementalCapacityQuarterlyUnitTypeLevelVersion.totalCapacityAfterUpdate = incrementalCapacityQuarterlyUnitTypeLevelVersion.totalCapacityBeforeUpdate - incrementalCapacityQuarterlyUnitTypeLevelVersion.eventCapacityValue + 50 + ExpansionCapacity;

            // Code to validate Total capacity Value with version effective date as today's date.
            incrementalCapacityQuarterlyUnitTypeLevelVersion.ValidateIncrementalCapacityWithVersionEffectiveDate(inputData.validationParamFields, incrementalCapacityQuarterlyUnitTypeLevelVersion.totalCapacityAfterUpdate, incrementalCapacityQuarterlyUnitTypeLevelVersion.assetunits, incrementalCapacityQuarterlyUnitTypeLevelVersion.assetKey, incrementalCapacityQuarterlyUnitTypeLevelVersion.xPath, RestUtils.getCurrentDate());

            // Code to validate Total capacity Value with version effective date as yesterday's date.
            incrementalCapacityQuarterlyUnitTypeLevelVersion.ValidateIncrementalCapacityWithVersionEffectiveDate(inputData.validationParamFields, incrementalCapacityQuarterlyUnitTypeLevelVersion.totalCapacityBeforeUpdate, incrementalCapacityQuarterlyUnitTypeLevelVersion.assetunits, incrementalCapacityQuarterlyUnitTypeLevelVersion.assetKey, incrementalCapacityQuarterlyUnitTypeLevelVersion.xPath, RestUtils.getYesterdaysDate());

        }
        private int GetFieldKeyValueWithActiveCapacityEvent(string field)
        {
            try
            {
                fieldKeyValue = AssetCapacityUtils.GetActiveAssetUnitKeyData(field);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return fieldKeyValue;
        }

        private int GetAssetUnitCapacityEventKey(int assetUnitKey)
        {
            String APIName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                capacityEventKey = RestUtil.GetFirstId(APIName);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return capacityEventKey;
        }


        private string GetAssetUnitCapacityEventValue(int capacityEventKey, string xPath)
        {
            string eventCapacityValue = null;

            String apiName = "AssetUnitCapacities?AssetUnitId=" + assetUnitKey;
            try
            {
                eventCapacityValue = RestUtils.GetAPIFieldValue(apiName, xPath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

            return eventCapacityValue;
        }

        private void UpdateAssetUnitCapacityEvent(int capacityEventKey, int assetUnitKey, string UpdateFieldName, string updateFieldValue)
        {
            try
            {
                AssetCapacityUtils.UpdateAssetUnitCapacityEvent(capacityEventKey, assetUnitKey, UpdateFieldName, updateFieldValue);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
        //Method to add Initial, Expansion, Creep and Closure Events
        private decimal RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtil.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
            return decimal.Parse(assetUnitCapacitiesFields["capacityUniversalQty"]);
        }
        private void ValidateIncrementalCapacityWithVersionEffectiveDate<T>(List<T> validationParamFields, decimal totalCapacity, List<int> assetUnitsList, int assetKey, string Xpath, String Date)
        {
            try
            {
                string APIParameters = RestUtils.GetIncrementalCapacitiesRequestURLdata(validationParamFields, assetUnitsList, assetKey);
                if (Date == RestUtils.getYesterdaysDate())
                {
                    APIParameters = APIParameters.Replace("VersionDate=" + RestUtils.getCurrentDate(), "VersionDate=" + Date);
                }

                RestUtils.RunIncrementalCapacities(APIParameters, Xpath, totalCapacity);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}
