﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using APITestSuite;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RegressionTestSuite.AppTestUtils;
using RegressionTestSuite.RegressionTestData.IncrementalCapacity;
using RestSharp;
using Xunit;

namespace AssetCapacityAndMaintenance.RegressionTestSuite.TestScripts.IncrementalCapacityTest
{

    public class IncrementalCapacity_MonthlyUnitTypeLevel_EventStartDate_PType
    {
        private List<string> errors = new List<string>();
        int assetUnitKey = 0;
        string ApiName = null;

        [Theory]
        [MemberData(nameof(TotalCapacityTestDataGenerator.loadInputData), parameters: "TD_IncrementalCapacity_MonthlyUnitTypeLevel_EventStartDate_PType", MemberType = typeof(TotalCapacityTestDataGenerator))]

        public static void incrementalCapacityMonthlyUnitTypeTest(AppInputData inputData)
        {
            IncrementalCapacity_MonthlyUnitTypeLevel_EventStartDate_PType incrementalCapacityMonthlyUnitType = new IncrementalCapacity_MonthlyUnitTypeLevel_EventStartDate_PType();

            List<AssetUnitsTestDataFields> AssetUnitsTestDataFieldsList = inputData.assetUnitsTestDataFields;
            incrementalCapacityMonthlyUnitType.ApiName = inputData.apiName;
            string Fields = inputData.fields;
            string uniqueFields = inputData.uniqueFields;
            string cdInitial = inputData.cdInitials;
            string assetUnit1Name = null;
            string assetUnit2Name = null;
            Dictionary<string, string> assetUnit1TestData = new Dictionary<string, string>();
            Dictionary<string, string> assetUnit2TestData = new Dictionary<string, string>();
            List<int> assetunits = new List<int>();
            List<FilterField> filterFieldList = inputData.filterField;
            List<string> Filtervalue = null;
            Dictionary<string, List<string>> filterFieldsList = new Dictionary<string, List<string>>();

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        assetUnit1TestData.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnit1Name = assetUnit1TestData["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {
                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                assetUnit1TestData.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                assetUnit1TestData.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }

            if (AssetUnitsTestDataFieldsList != null)
            {
                foreach (string fieldName in RestUtils.GetFieldList(Fields))
                {
                    if (RestUtils.GetUniqueFieldList(uniqueFields).Contains(fieldName))
                    {
                        string randomString = Util.RandomString(4);
                        assetUnit2TestData.Add(fieldName, cdInitial + "-" + randomString);
                        assetUnit2Name = assetUnit2TestData["assetUnitName"];
                    }
                    foreach (AssetUnitsTestDataFields TestDataField in AssetUnitsTestDataFieldsList)
                    {
                        if (TestDataField.field == fieldName)
                        {

                            if (TestDataField.field == "assetKey")
                            {
                                TestDataField.value = AssetCapacityUtils.GetAssetKey(inputData.assetName, "asset_key").ToString();
                                assetUnit2TestData.Add(fieldName, TestDataField.value);
                            }
                            else
                            {
                                assetUnit2TestData.Add(fieldName, TestDataField.value);
                            }
                        }
                    }
                }
            }
            int assetkey = int.Parse(assetUnit1TestData["assetKey"]);
            
            foreach (FilterField fieldname in filterFieldList)
            {
                Filtervalue = Util.GetListFromCommaSepString(fieldname.value);
                filterFieldsList.Add(fieldname.field, Filtervalue);
            }

            //Creating New Asset Unit(Unit1) and adding Initial Capacity
            incrementalCapacityMonthlyUnitType.RunInitialCapacity(assetUnit1TestData);
            incrementalCapacityMonthlyUnitType.GetAssetUnitKey(assetUnit1Name);
            int AssetUnit1Key =incrementalCapacityMonthlyUnitType.assetUnitKey;

            //Creating New Asset Unit(Unit2) and adding Initial Capacity
            incrementalCapacityMonthlyUnitType.RunInitialCapacity(assetUnit2TestData);
           incrementalCapacityMonthlyUnitType.GetAssetUnitKey(assetUnit2Name);
           int AssetUnit2Key =incrementalCapacityMonthlyUnitType.assetUnitKey;

            //Adding both the Units to the List
            assetunits.Add(AssetUnit1Key);
            assetunits.Add(AssetUnit2Key);

            //Validating response data after adding initial capacity to both the Units with default filter values
            incrementalCapacityMonthlyUnitType.RunValidateResponseData(inputData.validationParamFields, assetunits, assetkey, inputData.expectedFieldValues,0);

            //Validating response data after adding initial capacity to both the Units with StartDate and P.type equal to Initial Capacity StartDate and Ptype
            incrementalCapacityMonthlyUnitType.RunValidateResponseData(inputData.validationParamFields, assetunits, assetkey, inputData.expectedFieldValues, 0, filterFieldsList["StartDate"][0], ptList: new List<string> { filterFieldsList["pt"][0] });

            // Adding Expansion capacity to both the Units
            incrementalCapacityMonthlyUnitType.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AssetUnit1Key);
            incrementalCapacityMonthlyUnitType.RunAssetUnitCapacity(inputData.expansionCapacityEventField, AssetUnit2Key);

            //Validating response data after adding initial and expansion capacity to both the Units with StartDate and P.type equal to  expansion Capacity StartDate and Ptype  
            incrementalCapacityMonthlyUnitType.RunValidateResponseData(inputData.validationParamFields, assetunits, assetkey, inputData.expectedFieldValues,1, filterFieldsList["StartDate"][1], ptList: new List<string> { filterFieldsList["pt"][1] });

            ///Validating response data after adding initial and expansion capacity to both the Units with StartDate = Initial Capacity StartDate ,Ptype =1,2 and EndDate=Expansion Capacity StartDate
            incrementalCapacityMonthlyUnitType.RunValidateResponseData(inputData.validationParamFields, assetunits, assetkey, inputData.expectedFieldValues,2, filterFieldsList["StartDate"][2], filterFieldsList["EndDate"][1], ptList: new List<string> { filterFieldsList["pt"][0], filterFieldsList["pt"][1] });

            //Adding Creep correction capacity to both the Units
            incrementalCapacityMonthlyUnitType.RunAssetUnitCapacity(inputData.creepCorrectionEventField, AssetUnit1Key);
            incrementalCapacityMonthlyUnitType.RunAssetUnitCapacity(inputData.creepCorrectionEventField, AssetUnit2Key);


            //Validating response data after adding Creep with  StartDate and P.type equal to  Creep Capacity StartDate and Ptype
            incrementalCapacityMonthlyUnitType.RunValidateResponseData(inputData.validationParamFields, assetunits, assetkey, inputData.expectedFieldValues,3, filterFieldsList["StartDate"][2], ptList: new List<string> { filterFieldsList["pt"][2] });

            //Validating response data after adding Creep for Unit1 with StartDate = Initial Capacity StartDate ,Ptype =1,2,3 and EndDate=Creep Capacity StartDate
            incrementalCapacityMonthlyUnitType.RunValidateResponseData(inputData.validationParamFields, assetunits, assetkey, inputData.expectedFieldValues,2, filterFieldsList["StartDate"][0], filterFieldsList["EndDate"][2], ptList: new List<string> { filterFieldsList["pt"][0], filterFieldsList["pt"][1], filterFieldsList["pt"][2] });

            //Adding Closure event for both the Units
            incrementalCapacityMonthlyUnitType.RunAssetUnitCapacity(inputData.closureEventField, AssetUnit1Key);
            incrementalCapacityMonthlyUnitType.RunAssetUnitCapacity(inputData.closureEventField, AssetUnit2Key);

            //Validating response data after adding closure event  with  StartDate = Initial Capacity StartDate ,Ptype =1,2,3,4 and EndDate=closure StartDate
             incrementalCapacityMonthlyUnitType.RunValidateResponseData(inputData.validationParamFields, assetunits, assetkey, inputData.expectedFieldValues, 2, filterFieldsList["StartDate"][0], filterFieldsList["EndDate"][3], ptList: new List<string> { filterFieldsList["pt"][0], filterFieldsList["pt"][1], filterFieldsList["pt"][2]});
                       
           Assert.True(incrementalCapacityMonthlyUnitType.errors.Count == 0, incrementalCapacityMonthlyUnitType.ApiName + ":" + "\n" + string.Join("\n ", incrementalCapacityMonthlyUnitType.errors.Select(s => $"'{s}'")));

        }
        private void RunInitialCapacity(Dictionary<string, string> inputKeyValues)
        {
            AssetUnitsConfigurationDTO assetUnitsConfigurationDTO = new AssetUnitsConfigurationDTO();
            assetUnitsConfigurationDTO = RestUtils.SetAssetUnitsParam(inputKeyValues);

            try
            {
                ResponseData responseData = RestUtils.PostMethodAssetUnits(ApiName, assetUnitsConfigurationDTO);
                SoftAssert.True(RestUtil.IsStatusCodeCreated(responseData.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_CREATED);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        //Method to add Initial, Expansion, Creep and Closure Events
        private void RunAssetUnitCapacity<T>(List<T> inputData, int assetUnitKey)
        {
            Dictionary<string, string> assetUnitCapacitiesFields = RestUtils.RunAssetUnitCapacities(inputData, assetUnitKey);
            ResponseData responseData = new ResponseData();
            string APIName = assetUnitCapacitiesFields["APIName"];
            assetUnitCapacitiesFields.Remove("APIName");
            try
            {
                responseData = RestUtils.PostMethod(APIName, assetUnitCapacitiesFields);
                if (!RestUtil.IsStatusCodeCreated((int)responseData.StatusCode))
                {
                    throw new Exception("API NAme :" + responseData.APIName + System.Environment.NewLine + " Response : " + responseData.Content + System.Environment.NewLine + "AP Request :" + responseData.RequestBody);
                }
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void GetAssetUnitKey(string assetUnitName)
        {
            try
            {
                assetUnitKey = AssetCapacityUtils.GetAssetUnitKey(assetUnitName, "asset_unit_key");
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void RunValidateResponseData<T>(List<T> validationParamFields, List<int> assetUnitsList, int assetKey, List<ExpectedFieldValues> expectedFieldValues, int k, string startDate = " ", string endDate = " ", List<string> ptList = null)
        {
            try
            {
                string APIParameters = RestUtils.GetIncrementalCapacitiesRequestURLdata(validationParamFields, assetUnitsList, assetKey, startDate, endDate, ptList);
                RunIncrementalCapacitiesAPI(APIParameters, assetUnitsList, expectedFieldValues, k);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }

        }
        private static void RunIncrementalCapacitiesAPI(string APIParameters, List<int> assetUnitsList, List<ExpectedFieldValues> expectedFieldValues, int F)
        {
            string ApiName = APIParameters;
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            var BaseURL = config["TargetUri"];
            string URL = BaseURL + ApiName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            DateTime dt = DateTime.Now;

            Dictionary<string, List<string>> expectedFieldList = AssetCapacityUtils.expectedFieldValuesList(expectedFieldValues);

            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {

                var IncrementalCapacityList = JsonConvert.DeserializeObject<List<IncrementalCapacityArray>>(restResponse.Content);                          
                
                AssetCapacityUtils.RunForNullOrEmptyCheck(IncrementalCapacityList[0].assetId.ToString(), "assetId is Empty");
                AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].assetName, expectedFieldList["assetName"][0], "assetName is Incorrect or Empty");
                AssetCapacityUtils.RunForNullOrEmptyCheck(IncrementalCapacityList[0].assetTypeId.ToString(), "assetTypeId is Empty");
                AssetCapacityUtils.RunForNullOrEmptyCheck(IncrementalCapacityList[0].assetTypeName, "assetTypeName is Empty");
                AssetCapacityUtils.RunForNullOrEmptyCheck(IncrementalCapacityList[0].cityId.ToString(), "cityId is Empty");
                AssetCapacityUtils.RunForNullOrEmptyCheck(IncrementalCapacityList[0].cityName, "cityName is Empty");
                AssetCapacityUtils.RunForNullOrEmptyCheck(IncrementalCapacityList[0].countryId.ToString(), "countryId is Empty");
                AssetCapacityUtils.RunForNullOrEmptyCheck(IncrementalCapacityList[0].countryName, "countryName is Empty");
                AssetCapacityUtils.RunForNullOrEmptyCheck(IncrementalCapacityList[0].ownerId.ToString(), "ownerId is Empty");
                AssetCapacityUtils.RunForNullOrEmptyCheck(IncrementalCapacityList[0].ownerName, "ownerName is Empty");
                AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].filterByDMQ, expectedFieldList["filterByDMQ"][0], "filterByDMQ is Incorrect or Empty");
                AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].filterByType, expectedFieldList["filterByType"][0], "filterByType is Incorrect or Empty");

                if (IncrementalCapacityList[0].incrementalCapacityGroups != null)
                {
                    int i = 0;
                    foreach (IncrementalCapacityGroup groupitem in IncrementalCapacityList[0].incrementalCapacityGroups)
                    {
                        int j = 0; int k = F;
                                      
                        AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].incrementalCapacityGroups[i].filterByTypeValue, expectedFieldList["filterByTypeValue"][0], "filterByTypeValue is Incorrect or Empty");
                        //AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].incrementalCapacityGroups[i].unitSubtypeId.ToString(), expectedFieldList["unitSubtypeId"][0], "unitSubtypeId is Incorrect or Empty");
                        //AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].incrementalCapacityGroups[i].unitSubtypeName, expectedFieldList["unitSubtypeName"][0], "unitSubtypeId is Incorrect or Empty");
                        //AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].incrementalCapacityGroups[i].unitTypeId.ToString(), expectedFieldList["unitTypeId"][0], "unitTypeId is Incorrect or Empty");
                        //AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].incrementalCapacityGroups[i].unitTypeName, expectedFieldList["unitTypeName"][0], "unitTypeName is Incorrect or Empty");

                        foreach (IncrementalCapacitySubgroup subgroupitem in IncrementalCapacityList[0].incrementalCapacityGroups[i].incrementalCapacitySubgroups)
                        {
                            AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].incrementalCapacityGroups[i].incrementalCapacitySubgroups[j].probTypeId.ToString(), expectedFieldList["probTypeId"][k], "probTypeId is Incorrect or Empty");
                            AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].incrementalCapacityGroups[i].incrementalCapacitySubgroups[j].probTypeName, expectedFieldList["probTypeName"][k], "probTypeName is Incorrect or Empty");
                            AssetCapacityUtils.RunValidateData(IncrementalCapacityList[0].incrementalCapacityGroups[i].incrementalCapacitySubgroups[j].capacityStartDate, expectedFieldList["capacityStartDate"][k], "capacityStartDate is Incorrect or Empty");

                            foreach (IncrementalCapacityDataList dataitem in IncrementalCapacityList[0].incrementalCapacityGroups[i].incrementalCapacitySubgroups[j].incrementalCapacityDataList)
                            {
                                AssetCapacityUtils.RunValidateData(dataitem.capacityQty, expectedFieldList["capacityQty"][k], "capacityQty is Incorrect or Empty");
                                AssetCapacityUtils.RunValidateData(dataitem.capacityUom, expectedFieldList["capacityUom"][0], "capacityUom is Incorrect or Empty");
                                AssetCapacityUtils.RunValidateData(dataitem.capacityUomId.ToString(), expectedFieldList["capacityUomId"][0], "capacityUomId is Incorrect or Empty");
                                AssetCapacityUtils.RunValidateData(dataitem.dataProviderId.ToString(), expectedFieldList["dataProviderId"][k], "dataProviderId is Incorrect or Empty");
                                AssetCapacityUtils.RunValidateData(dataitem.dataProviderName, expectedFieldList["dataProviderName"][k], "dataProviderName is Incorrect or Empty");
                                AssetCapacityUtils.RunValidateData(dataitem.updateDate, dt.ToString("dd MMM yyyy"), "updateDate is Incorrect or Empty");
                                AssetCapacityUtils.RunValidateData(dataitem.versionTypeKey.ToString(), "3", "versionTypeKey is Incorrect or Empty");
                                AssetCapacityUtils.RunValidateData(dataitem.versionTypeKeyName, "Baseline; the official Shell version", "versionTypeKeyName is Incorrect or Empty");
                            }
                            j++; k++;
                        }
                        i++;
                    }
                }
            }
        }
       
    }
}
