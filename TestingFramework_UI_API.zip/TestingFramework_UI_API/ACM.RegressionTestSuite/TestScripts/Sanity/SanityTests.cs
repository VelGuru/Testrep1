﻿using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using RegressionTestSuite.AppTestUtils;

namespace APITestSuite
{
    public class SanityTest : BaseSanityTests
    {
        private protected override string fields => Fields;
        private protected override string apiName => ApiName;
        private protected override Dictionary<string, string> parameterFields => ParameterFields;
        private protected override Dictionary<string, string> parameterFieldsForAssetUnit => ParameterFieldsForAssetUnit;
        private protected override Dictionary<string, string> defaultValueFields => DefaultValueFields;

        private string Fields = null;
        private string ApiName = null;
        private String APIParameters = null;
        private Dictionary<string, string> DefaultValueFields = null;
        private Dictionary<string, string> ParameterFields = null;
        private Dictionary<string, string> ParameterFieldsForAssetUnit = null;

        private List<string> errors = new List<string>();

        private string ApiUrl;
        private int UnitId;

        [Theory]
        [ClassData(typeof(SanityTestDataGenerator))]
        public static void RunSanityTests(AppInputData inputData)
        {
            SanityTest sanityTest = new SanityTest();
            List<ParameterField> parametersList = inputData.parameterFields;
            List<AssetUnitsTestDataFields> defaultparamList = inputData.defaultValueFields;
            List<DefaultValuesField> defaultParamValueList = inputData.DefaultParameterValueFields;
            List<ParameterFieldForAssetUnit> parameterFieldsForAssetUnit = inputData.parameterFieldsForAssetUnit;

            sanityTest.Fields = inputData.fields;
            sanityTest.ApiName = inputData.apiName;
            sanityTest.ApiUrl = sanityTest.ApiName;
            int assetId = 0;

            if (parameterFieldsForAssetUnit != null)
            {
                foreach (ParameterFieldForAssetUnit parameterField in parameterFieldsForAssetUnit)
                {
                    int paramvalue = sanityTest.RunGetFirstId(parameterField.apiName + sanityTest.APIParameters);
                    string paramKey = parameterField.param;

                    sanityTest.ApiUrl = sanityTest.ApiUrl + paramKey + "=" + paramvalue + "&";
                    sanityTest.APIParameters = sanityTest.ApiUrl + paramKey + "=" + paramvalue + "&";
                }

                sanityTest.UnitId = sanityTest.RunGetFirstId("AssetUnits/AssetUnitFilter?" + sanityTest.APIParameters);
            }

            // Code to add Asset unit key to resource section - We are doing this for maintenance Daily 
            if (inputData.addAssetUnitKey != null && inputData.addAssetUnitKey.ToUpper() == "Y")
            {
                if (defaultParamValueList != null)
                {
                    foreach (DefaultValuesField defaultField in defaultParamValueList)
                    {
                        if (defaultField.field == "UnitId" || defaultField.field == "unit")
                        {
                            if (sanityTest.ApiName.Contains("Maintenance") || sanityTest.ApiName.Contains("AssetUnitEvents"))
                            {
                                sanityTest.UnitId = int.Parse(AssetCapacityUtils.GetActiveMaintananceAssetUnitKeyData("asset_unit_key").ToString());
                            }
                            else if (sanityTest.ApiName.Contains("Capacity"))
                            {
                                sanityTest.UnitId = int.Parse(AssetCapacityUtils.GetActiveAssetUnitKeyData("asset_unit_key").ToString());
                            }
                            else
                            {
                                sanityTest.UnitId = int.Parse(AssetCapacityUtils.GetActiveAssetUnitKeyData("asset_unit_key").ToString());
                            }
                        }
                    }
                }

                if (inputData.totalFirmUnitCapacity != null && inputData.totalFirmUnitCapacity.ToUpper() == "Y")
                {
                    sanityTest.ApiName = sanityTest.ApiName + "/" + sanityTest.UnitId + "/TotalFirmUnitCapacity";
                }
                else
                {
                    sanityTest.ApiName = sanityTest.ApiName + "/" + sanityTest.UnitId + "?";
                }
            }


            // Code to check "DefaultParameterValueFields" section in test data json and to add parameters to the API URL
            if (defaultParamValueList != null && inputData.totalFirmUnitCapacity == null)
            {
                sanityTest.DefaultValueFields = new Dictionary<string, string>();
                foreach (DefaultValuesField defaultField in defaultParamValueList)
                {

                    // Code to add "?" after API Resource Name so that we can concatenate parameters 
                    if (!sanityTest.ApiName.Contains("?"))
                    {
                        sanityTest.ApiName = sanityTest.ApiName + "?";
                    }

                    // Code to check each and every field in "DefaultParameterValueFields" section and to add it to the API URL as a parameter
                    string paramKey = defaultField.field;
                    string paramValue = defaultField.value;
                    if (paramKey == "versionDate")
                    {
                        paramValue = sanityTest.getCurrentDate();
                        sanityTest.ApiName = sanityTest.ApiName + paramKey + "=" + paramValue + "&";
                    }
                    else if (paramKey == "EndDate")
                    {
                        paramValue = sanityTest.QuarterEndDate();
                        sanityTest.ApiName = sanityTest.ApiName + paramKey + "=" + paramValue + "&";
                    }
                    else if (paramKey == "groupformat")
                    {
                        assetId = AssetCapacityUtils.GetAssetKeyWithAssetUnitKey("asset_key", AssetCapacityUtils.GetActiveAssetUnitKeyData("asset_unit_key"));

                        List<string> groupformatList = Util.GetListFromCommaSepString(paramValue);
                        sanityTest.ApiName = sanityTest.ApiName + paramKey + "={\"assetId\":" + assetId + ",\"dmqFilter\":" + "\"" + groupformatList[0] + "\"" + ",\"typeFilter\":" + "\"" + groupformatList[1] + "\"}&a=" + assetId;
                    }
                    else if (paramKey == "UnitId" || paramKey == "unit" || paramKey == "AssetUnitId")
                    {
                        if (paramValue == "" && sanityTest.UnitId == 0)
                        {
                            // To Test Maintenance API's we need to get unit which has active Maintenance events.
                            // To test Capacity API's we need to get unit which has active Capacity events
                            if (sanityTest.ApiName.Contains("Maintenance") || sanityTest.ApiName.Contains("AssetUnitEvents"))
                            {
                                paramValue = AssetCapacityUtils.GetActiveMaintananceAssetUnitKeyData("asset_unit_key").ToString();
                            }
                            else if (sanityTest.ApiName.Contains("Capacity"))
                            {
                                paramValue = AssetCapacityUtils.GetActiveAssetUnitKeyData("asset_unit_key").ToString();
                            }
                            else
                            {
                                paramValue = AssetCapacityUtils.GetActiveAssetUnitKeyData("asset_unit_key").ToString();
                            }

                        }
                        else if (sanityTest.UnitId != 0)
                        {
                            paramValue = sanityTest.UnitId.ToString();
                        }

                        sanityTest.ApiName = sanityTest.ApiName + paramKey + "=" + paramValue + "&";
                    }
                    else
                    {
                        if (paramValue != "")
                        {
                            sanityTest.ApiName = sanityTest.ApiName + paramKey + "=" + paramValue + "&";
                            sanityTest.APIParameters = sanityTest.APIParameters + paramKey + "=" + paramValue + "&";
                        }
                    }
                }
            }


            // Code to check Validate JSON Schema parameter and to trigger functions accordingly
            if (inputData.validateJsonSchema == "Y")
            {

                // For capacity Event Versions and Maintanenace Event Versions we need call API in a different Format
                // Below code is to check test case is related to Event versions and also to change API format accordingly
                if (inputData.validateAPIVersion != null && inputData.validateAPIVersion == "Y")
                {
                    int eventId;
                    if (sanityTest.ApiName.Contains("AssetUnitEvents"))
                    {
                        eventId = int.Parse(sanityTest.RunGetFirstFieldValue(sanityTest.ApiName, "assetUnitEventKey"));
                    }
                    else
                    {
                        eventId = sanityTest.RunGetFirstId(sanityTest.ApiName);
                    }

                    sanityTest.ApiName = sanityTest.ApiUrl + "/" + eventId + "/versions";
                    sanityTest.TestGetAndValidateJSONSchema(inputData.versionAPIJsonSchemaPath);
                }
                else
                {
                    sanityTest.TestGetAndValidateJSONSchema(inputData.jsonSchemaFilePath);
                }
            }
            else if (inputData.validateStatusCode == "Y")
            {
                sanityTest.ValidateGetStatusCode();
            }
            else
            {
                sanityTest.TestGet();
            }
            Assert.True(sanityTest.errors.Count == 0, sanityTest.ApiName + ":" + "\n" + string.Join("\n ", sanityTest.errors.Select(s => $"'{s}'")));
        }

        private void TestGet()
        {
            try
            {
                ResponseData responseDataGetAll = RunGetTest();
                FieldExistsInResponse(responseDataGetAll);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void TestGetAndValidateJSONSchema(String jsonSchemaFilePath)
        {
            try
            {
                RunGetAndValidateJSONSchema(jsonSchemaFilePath);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        private void ValidateGetStatusCode()
        {
            try
            {
                RunGetAndValidateStatusCode();
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }
    }
}

