﻿namespace APITestSuite
{
    internal class TestDataFields
    {
    }
}