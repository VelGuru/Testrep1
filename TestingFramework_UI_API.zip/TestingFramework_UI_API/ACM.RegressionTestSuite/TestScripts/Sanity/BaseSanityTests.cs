﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace APITestSuite
{

    public abstract class BaseSanityTests
    {
        private protected abstract string fields { get; }
        private protected abstract string apiName { get; }

        private protected abstract Dictionary<string, string> defaultValueFields { get; }
        private protected abstract Dictionary<string, string> parameterFields { get; }
        private protected abstract Dictionary<string, string> parameterFieldsForAssetUnit { get; }

        public List<string> GetTotalFieldList()

        {
            List<string> fieldList = GetBasicFieldList();
            fieldList.AddRange(Util.GetListFromCommaSepString(fields));

            return fieldList;
        }

        public List<string> GetBasicFieldList()
        {
            return Enum.GetNames(typeof(EnumMetaDataFields)).ToList();
        }

        public List<string> GetFieldList()
        {
            return Util.GetListFromCommaSepString(fields);
        }

        protected ResponseData RunGetTest()
        {
            ResponseData responseDataGetAll = RestUtil.GetMethod(apiName);
            SoftAssert.True(RestUtil.IsStatusCodeOk(responseDataGetAll.StatusCode), Constants.ERROR_MESSAGE_STATUS_CODE_OK);
            return responseDataGetAll;
        }

        protected void RunGetAndValidateJSONSchema(String jsonSchemaFilePath)
        {
             RestUtil.RunGetValidateJSONSchema(apiName, jsonSchemaFilePath);    
        }

        protected void RunGetAndValidateStatusCode()
        {
            RestUtil.ValidateGetStatusCode(apiName);
        }

        protected int RunGetFirstId(string apiName)
        {
            return RestUtil.GetFirstId(apiName);
        }

        protected string RunGetFirstFieldValue(string apiName, String FieldName)
        {
            return RestUtil.GetFirstFieldValue(apiName, FieldName);
        }

        public void FieldExistsInResponse(ResponseData responseData)
        {
            List<string> expectedFieldList = GetFieldList();
            List<Dictionary<string, string>> responseValues = responseData.ResponseValues;
            foreach (Dictionary<string, string> keyValues in responseValues)
            {
                foreach (string fieldName in expectedFieldList)
                {
                    SoftAssert.True(keyValues.ContainsKey(fieldName), fieldName + " " + Constants.ERROR_MESSAGE_FIELD_DOESNT_EXISTS);
                }

            }
        }

        public string getCurrentDate()
        {
            DateTime currentDateTime = DateTime.Now;
            string versionDate = currentDateTime.ToString("yyyy-MM-dd");
            return versionDate;
        }

        public string QuarterEndDate()
        {

            int quarterNumber = (DateTime.Now.Month - 1) / 3 + 1;
            DateTime firstDayOfQuarter = new DateTime(DateTime.Now.Year, (quarterNumber - 1) * 3 + 1, 1);
            DateTime lastDayOfQuarter = firstDayOfQuarter.AddMonths(3).AddDays(-1);
            string endDate = lastDayOfQuarter.ToString("yyyy-MM-dd");
            return endDate;
        }

    }
}
