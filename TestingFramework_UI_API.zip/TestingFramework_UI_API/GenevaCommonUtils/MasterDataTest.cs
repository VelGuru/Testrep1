﻿using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace APITestSuite
{
    public class MasterDataTest : BaseMasterDataTest
    {
        private protected override string fields => Fields; 
        private protected override string mandatoryFields => MandatoryFields;
        private protected override string uniqueFields => UniqueFields;
        private protected override string apiName => ApiName;
        private protected override int idForGet => IdForGet;
        private protected override int idForUpdate => IdForUpdate;
        private protected override int idForDelete => IdForDelete;
        private protected override string cdInitial => CDInitials;
        private protected override Boolean versionable => Versionable;
        private protected override Dictionary<string, string> crossRefFields => CrossRefFields;
        private protected override Dictionary<string, string> defaultValueFields => DefaultValueFields;

        protected string Fields = null;
        protected string MandatoryFields = null;
        protected string UniqueFields = null;
        protected string ApiName = null;
        protected int IdForGet = -1;
        protected int IdForUpdate = -1;
        protected int IdForDelete = -1;

        protected string CDInitials = null;
        protected Boolean Versionable = false;
        protected Dictionary<string, string> CrossRefFields = null;
        protected Dictionary<string, string> DefaultValueFields = null;

        protected List<string> errors = new List<string>();
        protected Boolean postSuccess = true;


        protected void TestGet()
        {
            try
            {
                ResponseData responseDataGetAll = RunGetTest();
                Dictionary<string, string> responseValues = responseDataGetAll.ResponseValues[0];
                IdForGet = int.Parse(responseValues["id"]);
            }
            catch (Exception e)
            {
                errors.Add("Get : " + e.Message);
            }
        }

        protected void TestGetById()
        {
            try
            {
                RunGetByIDTest();
            }
            catch (Exception e)
            {
                errors.Add("Get By Id : " + e.Message);
            }

        }

        protected void TestPost()
        {
            try
            {
                ResponseData responseDataPost = RunPostTest();
                Dictionary<string, string> responseValues = responseDataPost.ResponseValues[0];
                int newIdCreated = int.Parse(responseValues["id"]);
                IdForUpdate = newIdCreated;
                IdForDelete = newIdCreated;
            }
            catch (Exception e)
            {
                errors.Add("Post : " + e.Message);
                postSuccess = false;
            }
        }

        protected void TestPostUniqueFields()
        {
            try
            {
                RunPostUniqueFieldsTest();
            }
            catch (Exception e)
            {
                errors.Add("Post Unique Fields Test : " + e.Message);
            }
        }

        protected void TestPostMandatoryFields()
        {
            try
            {
                
                RunPostMandatoryFieldsTest();
            }
            catch (Exception e)
            {
                errors.Add("Post Mandatory Fields Test : " + e.Message);
            }
        }

        protected void TestPut()
        {
            if (postSuccess)
            {
                try
                {
                    RunPutTest();
                }
                catch (Exception e) { errors.Add("Put : " + e.Message); }
            }
            else
            {
                errors.Add("Put : Not Executed");
            }
        }

        protected void TestPutUniqueFields()
        {
            try
            {
                RunPutUniqueFieldsTest();
            }
            catch (Exception e)
            {
                errors.Add("Put Unique Fields Test : " + e.Message);
            }
        }

        protected void TestPutMandatoryFields()
        {
            try
            {
                RunPutMandatoryFieldsTest();
            }
            catch (Exception e)
            {
                errors.Add("Put Mandatory Fields Test : " + e.Message);
            }
        }

        protected void TestDelete()
        {
            if (postSuccess)
            {
                try
                {
                    RunDeleteTest();
                }
                catch (Exception e) { errors.Add("Delete : " + e.Message); }
            }
            else
            {
                errors.Add("Delete : Not Executed");
            }
        }
    }
}

