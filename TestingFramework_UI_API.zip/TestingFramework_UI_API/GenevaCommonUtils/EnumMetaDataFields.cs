﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APITestSuite
{
    public enum EnumMetaDataFields
    {
        id,
        deleteInd,
        metaQualityCd,
        metaActionCd,
        metaCreatedDttm,
        metaCreatorNm,
        metaChangedDttm,
        metaChangedByNm,
        recordEntryDttm
    }

    public enum EnumVersionMetaDataFields
    {
        versionEffectiveDt,
        versionTerminationDt,
        versionActiveInd
    }
}
