﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APITestSuite
{
    public class SoftAssert
    {
        public static void True(bool condition,string errorMessage)
        {
            if (!condition)
            {
                throw new Exception(errorMessage);
            }
        }

        public static void Skip(string reason)
        {
            //throw new SkipException(reason);            
        }
    }


    public class SkipException : Exception
    {
        public SkipException(string reason)
        {
            Reason = reason;
        }

        public string Reason { get; set; }
    }

}
