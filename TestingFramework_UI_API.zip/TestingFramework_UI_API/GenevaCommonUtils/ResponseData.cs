﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APITestSuite
{
   public class ResponseData
    {
        public int ResponseCount { get; set; }
        public int StatusCode { get; set; }

        public string StatusLine { get; set; }

        public string ContentType { get; set; }

        public List<Dictionary<string,string>> ResponseValues { get; set; }

        //Added by Siva for ACM
        public string APIName { get; set; }
        public string Content { get; set; }
        public string RequestBody { get; set; }
    }
}
