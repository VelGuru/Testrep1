﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APITestSuite
{
   public  class Constants
    {   

        public static readonly string ERROR_MESSAGE_STATUS_CODE_OK = "Return Status Code is Not 'OK' ";
        public static readonly string ERROR_MESSAGE_STATUS_CODE_CREATED = "Return Status Code is Not 'CREATED' ";
        public static readonly string ERROR_MESSAGE_DELETE_IND_NOT_N = "Delete Ind is Not 'N'";
        public static readonly string ERROR_MESSAGE_FIELD_VALUE_EMPTY = " Is Empty or Null";
        public static readonly string ERROR_MESSAGE_FIELD_DOESNT_EXISTS = " Doesnot exists in Response";
 }
}
