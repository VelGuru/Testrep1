﻿
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace APITestSuite
{
    public class InputData
    {
        public string execute { get; set; }
        public string apiName { get; set; }
        public string fields { get; set; }
        public string mandatoryFields { get; set; }
        public string uniqueFields { get; set; }
        public string cdInitials { get; set; }
        public string versionable { get; set; }
        public List<CrossRefField> crossRefFields { get; set; }
        public List<DefaultValueField> defaultValueFields { get; set; }

    }
    public class CrossRefField
    {
        public string apiName { get; set; }
        public string field { get; set; }

        public CrossRefField(string apiName, string field)
        {
            this.apiName = apiName;
            this.field = field;
        }
    }

  

   

    public class DefaultValueField
    {
        public string field { get; set; }
        public string value { get; set; }

        public DefaultValueField(string field, string value)
        {
            this.field = field;
            this.value = value;
        }
    }
  
    
    
    
}
