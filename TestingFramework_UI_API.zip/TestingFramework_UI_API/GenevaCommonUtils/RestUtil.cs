﻿using RestSharp;
using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Net;
using Xunit;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Schema;
using System.IO;
using System.Linq;
using APITestSuite;

namespace APITestSuite
{
    public class RestUtil
    {
        private static string BaseURL = null;
        private static string BaseUpdateURL = null;
        private static string PromoteToBaselineUri = null;

        public static string GetURL(string param)
        {
            string URL;
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            URL = config[param];
            return URL;
        }

        private static void LoadURL()
        {
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            BaseURL = config["TargetUri"];
            BaseUpdateURL = config["TargetUpdateUri"];
            PromoteToBaselineUri = config["PromoteToBaselineUri"];
        }

        public static string GetBaseURL()
        {
            if(BaseURL == null)
            {
                LoadURL();
            }
            return BaseURL;
        }

        public static string GetBaseUpdateURL()
        {
            if (BaseUpdateURL == null)
            {
                LoadURL();
            }
            return BaseUpdateURL;
        }
        public static string GetPromoteToBaselineURL()
        {
            if (PromoteToBaselineUri == null)
            {
                LoadURL();
            }
            return PromoteToBaselineUri;
        }
        


        public static Boolean IsStatusCodeOk(int statusCode)
        {
            return statusCode == (int)HttpStatusCode.OK;
        }

        public static Boolean IsStatusCodeCreated(int statusCode)
        {
            return statusCode == (int)HttpStatusCode.Created;
        }

        public static Boolean IsStatusCodeBadRequest(int statusCode)
        {
            return statusCode == (int)HttpStatusCode.BadRequest;
        }

        public static ResponseData GetByIdMethod(string APIName,int id)
        {
            string URL = GetBaseURL() + APIName + "/" + id;
            var client = new RestClient(URL);      
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);         
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                responseData.ResponseCount = 1;
                JToken jToken = JToken.Parse(restResponse.Content);

                List<Dictionary<string, string>> responseValues = new List<Dictionary<string, string>>();

                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                foreach (JProperty property in jToken)
                {
                    keyValues.Add(property.Name, property.Value.ToString());
                }
                responseValues.Add(keyValues);
                responseData.ResponseValues = responseValues;
            }
            return responseData;
        }


        public static void ValidateGetStatusCode(string APIName)
        {
            List<string> errorList = new List<string>();

            string URL = GetBaseURL() + APIName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            if (!(responseData.StatusCode == 200))
            {
                errorList.Add(APIName + " Status code validation failed");
            }
            Assert.True(errorList.Count == 0, "Status Code Validation Error" + ":" + "\n" + string.Join("\n ", errorList.Select(s => $"'{s}'")));
        }


        public static ResponseData GetMethod(string APIName)
        {
            string URL = GetBaseURL() + APIName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);           
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int) restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                JArray responseArray = JArray.Parse(restResponse.Content) as JArray;
                responseData.ResponseCount = responseArray.Count;
                List<Dictionary<string, string>> responseValues = new List<Dictionary<string, string>>();
                

                foreach (JToken obj in responseArray)
                {
                    Dictionary<string, string> keyValues = new Dictionary<string, string>();
                    foreach (JProperty property in obj)
                    {
                        keyValues.Add(property.Name, property.Value.ToString());
                    }
                    responseValues.Add(keyValues);
                }
                responseData.ResponseValues = responseValues;
            }
            return responseData;
        }

        public static void RunGetValidateJSONSchema(string APIName,String JSONSchemaFilePath)
        {
            JObject APIResponseObject= new JObject();
            JArray APIResponseArray = new JArray();
            Boolean JObjectInitializationStatus = false, validSchema= false;
            IList<ValidationError> messages;
            List<string> errorList = new List<string>();

            string URL = GetBaseURL() + APIName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);

            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;

            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                JSchema schema = JSchema.Parse(File.ReadAllText(JSONSchemaFilePath));
                try
                {
                    APIResponseObject = JObject.Parse(restResponse.Content);
                    JObjectInitializationStatus = true;
                }
                catch (Exception)
                {
                    APIResponseArray = JArray.Parse(restResponse.Content) as JArray;
                }

                if (JObjectInitializationStatus)
                {
                    validSchema = APIResponseObject.IsValid(schema, out messages);
                }
                else
                {
                    validSchema = APIResponseArray.IsValid(schema, out messages);
                    }
                
                foreach(ValidationError error in messages)
                {
                    for (int i = 0; i < error.ChildErrors.Count; i++)
                    {
                        errorList.Add(error.ChildErrors[i].Message);
                    }
                   
                }
                Assert.True(messages.Count == 0, "Schema Validation Error" + ":" + "\n" + string.Join("\n ", errorList.Select(s => $"'{s}'")));
            }
        }

        public static ResponseData PostMethod(string APIName, Dictionary<string,string> inputKeyValues)
        {
           String jSONString = Util.GetJSONStringFromDictionary(inputKeyValues);
            string URL = GetBaseURL() + APIName;
            RestClient client = new RestClient(URL);            
            RestRequest request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json-patch+json");
            request.AddJsonBody(jSONString);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);               
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            if (RestUtil.IsStatusCodeCreated((int)restResponse.StatusCode))
            {
                JToken jToken = JToken.Parse(restResponse.Content);

                List<Dictionary<string, string>> responseValues = new List<Dictionary<string, string>>();

                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                foreach (JProperty property in jToken)
                {
                    keyValues.Add(property.Name, property.Value.ToString());
                }
                responseValues.Add(keyValues);
                responseData.ResponseValues = responseValues;
            }
            return responseData;
        }

        public static ResponseData PutMethod(string APIName, Dictionary<string, string> inputKeyValues,int id)
        {
            String jSONString = Util.GetJSONStringFromDictionary(inputKeyValues);
            string URL = GetBaseURL() + APIName + "/" + id;
            RestClient client = new RestClient(URL);
            RestRequest request = new RestRequest(Method.PUT);
            request.AddHeader("Content-Type", "application/json-patch+json");
            request.AddJsonBody(jSONString);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);                   
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode) || RestUtil.IsStatusCodeCreated((int)restResponse.StatusCode))
            {
                JToken jToken = JToken.Parse(restResponse.Content);

                List<Dictionary<string, string>> responseValues = new List<Dictionary<string, string>>();

                Dictionary<string, string> keyValues = new Dictionary<string, string>();
                foreach (JProperty property in jToken)
                {
                    keyValues.Add(property.Name, property.Value.ToString());
                }
                responseValues.Add(keyValues);
                responseData.ResponseValues = responseValues;
            }
            return responseData;
        }

        public static ResponseData DeleteMethod(string APIName,int id)
        {            
            string URL = GetBaseURL() + APIName + "/" + id;
            RestClient client = new RestClient(URL);
            RestRequest request = new RestRequest(Method.DELETE);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);                          
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            return responseData;
        }

        public static int GetFirstId(string APIName)
        {
            string URL = GetBaseURL() + APIName;
            var client = new RestClient(URL);          
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);            
            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                JArray responseArray = JArray.Parse(restResponse.Content) as JArray;
                foreach (JToken obj in responseArray)
                {                    
                    foreach (JProperty property in obj)
                    {
                        if(property.Name == EnumMetaDataFields.id.ToString())
                        {
                            return int.Parse(property.Value.ToString());
                        }
                        
                    }                    
                }
            }
            return -1;
        }

        public static string GetFirstFieldValue(string APIName, String FieldName)
        {
            string URL = GetBaseURL() + APIName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);

            //Code to print request and error details if incase of error
            if (!RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                throw new Exception("API NAme :" + URL + System.Environment.NewLine + " Response : " + restResponse.Content);
            }

            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                JArray responseArray = JArray.Parse(restResponse.Content) as JArray;
                foreach (JToken obj in responseArray)
                {
                    foreach (JProperty property in obj)
                    {
                        if (property.Name == FieldName)
                        {
                            return property.Value.ToString();
                        }

                    }
                }
            }
            return null;
        }
        public static Dictionary<string, string> GetFirstRecord(string APIName)
        {
            JArray APIResponseArray = new JArray();
            Dictionary<string, string> keyValues = new Dictionary<string, string>();

            string URL = GetBaseURL() + APIName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.APIName = URL;
            responseData.Content = restResponse.Content;

            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                APIResponseArray = JArray.Parse(restResponse.Content) as JArray;
                foreach (JProperty property in APIResponseArray[0])
                {
                    keyValues.Add(property.Name, property.Value.ToString());
                }

            }

            return keyValues;
        }

        public static ResponseData PutMethodWithOutIdParam(string APIName, Dictionary<string, string> inputKeyValues)
        {
            String jSONString = Util.GetJSONStringFromDictionary(inputKeyValues);
            if (APIName.Contains("AssetUnitEvents"))
            {
                jSONString = jSONString.Replace("\"[", "[");
                jSONString = jSONString.Replace("]\"", "]");
            }
            string URL = GetBaseURL() + APIName;
            RestClient client = new RestClient(URL);
            RestRequest request = new RestRequest(Method.PUT);
            request.AddHeader("Content-Type", "application/json-patch+json");
            request.AddJsonBody(jSONString);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            responseData.APIName = URL;
            responseData.RequestBody = jSONString;
            responseData.Content = restResponse.Content;

            return responseData;
        }

        public static int[] GetAllRecordIds(string APIName)
        {

            int i = 0;
            int[] recordIds;
            string URL = GetBaseURL() + APIName;
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);

            //Code to print request and error details if incase of error
            if (!RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                throw new Exception("API Name :" + URL + System.Environment.NewLine + " Response : " + restResponse.Content);
            }

            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                JArray responseArray = JArray.Parse(restResponse.Content) as JArray;
                recordIds = new int[responseArray.Count];

                foreach (JToken obj in responseArray)
                {
                    foreach (JProperty property in obj)
                    {
                        if (property.Name == EnumMetaDataFields.id.ToString())
                        {
                            recordIds[i] = int.Parse(property.Value.ToString());
                            i++;
                        }
                    }
                }
                return recordIds;
            }
            return null;
        }
    }
}
