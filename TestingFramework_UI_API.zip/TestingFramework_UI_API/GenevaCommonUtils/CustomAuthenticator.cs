﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using RestSharp;
using RestSharp.Authenticators;
using Microsoft.Extensions.Configuration;


namespace APITestSuite
{
    public class CustomAuthenticator : IAuthenticator
    {
        public void Authenticate(IRestClient client, IRestRequest request)
        {
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            request.Credentials = new NetworkCredential(config["Credentials:UserName"], config["Credentials:Password"], config["Credentials:Domain"]);
        }
    }
}
