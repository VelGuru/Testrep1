﻿using System;
using System.Collections;
using TechTalk.SpecFlow;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using SupplyUIRegressionTestSuite.PageObject.Pages;
using GenevaUICommonUtils.Selenium;
using Connections=GenevaUICommonUtils.Connections;
using SupplyUIRegressionTestSuite.SpecFlow.Hooks;
using SupplyUIRegressionTestSuite.TestData.Reader;


namespace SupplyUIRegressionTestSuite.StepDefinition
{
    [Binding]
    public class SupplyProduction : SetUp
    {

        Dictionary<string, ArrayList> baselineDataBeforeUpdate = new Dictionary<string, ArrayList>();
        Dictionary<string, ArrayList> expectedBaselineData = new Dictionary<string, ArrayList>();
        Dictionary<string, ArrayList> actualBaselineData = new Dictionary<string, ArrayList>();
        Dictionary<string, ArrayList> condensateBaselineData = new Dictionary<string, ArrayList>();
        Dictionary<string, ArrayList> actualBoVData = new Dictionary<string, ArrayList>();

        //Step definitions
        [Scope(Feature = "SupplyProduction")]

        [Given(@"I launch the application")]
        public void GivenILaunchTheApplication()
        {
            Utilities.LaunchUrl(Connections.EndPoints.SupplyUrl);
        }

        [Then(@"I verify the page title")]
        public void ThenIVerifyThePageTitle()
        {
            Assert.That(new SupplyProductionPage().GetSupplyProductionText().Contains("Supply Production"), "Page title has not matched");
        }

        [Then(@"I click on filter")]
        public void ThenIClickOnFilter()
        {
            new SupplyProductionPage().ClickFilter();
        }

        [When(@"I enter Region name (.*) and select it from list")]
        public void WhenIEnterRegionNameAndSelectItFromList(string p0)
        {
            new SupplyProductionPage().SelectRegionFromList(p0);
        }

        [When(@"I enter Trade Organization name (.*) and select it from list")]
        public void WhenIEnterTradeOrganizationNameAndSelectItFromList(string p0)
        {
            new SupplyProductionPage().SelectTradeOrganizationsFromList(p0);
        }

        [When(@"I enter country name (.*) and select it from list")]
        public void WhenIEnterCountryNameAndSelectItFromList(string p0)
        {
            new SupplyProductionPage().SelectCountryFromList(p0);
        }

        [Then(@"I verify correct Trade Organizations are loaded for Region selected (.*)")]
        public void ThenIVerifyCorrectTradeOrganizationsAreLoadedForRegionSelected(string p0)
        {
            new SupplyProductionPage().ValidateCorrectTradeOrganizationsLoaded(p0);
        }

        [Then(@"I verify correct Countries are loaded for Region selected (.*)")]
        public void ThenIVerifyCorrectCountriesAreLoadedForRegionSelected(string p0)
        {
            new SupplyProductionPage().ValidateCorrectCountriesLoadedForAGivenRegion(p0);
        }

        [Then(@"I verify correct Countries are loaded for TO selected (.*)")]
        public void ThenIVerifyCorrectCountriesAreLoadedForTOSelected(string p0)
        {
            new SupplyProductionPage().ValidateCorrectCountriesLoadedForAGivenTO(p0);
        }

        [Then(@"I verify correct Material Grades are loaded for Country selected (.*)")]
        public void ThenIVerifyCorrectMaterialGradesAreLoadedForCountrySelected(string p0)
        {
            new SupplyProductionPage().ValidateCorrectMaterialGradesLoaded(p0);
        }


        [Then(@"I click on search Regions")]
        public void ThenIClickOnSearchRegions()
        {
            new SupplyProductionPage().ClickSearchRegion();
        }

        [Then(@"I enter Region name and select it from list")]
        public void ThenIEnterRegionNameAndSelectItFromList()
        {
            new SupplyProductionPage().SelectRegionFromList(Reader.Regions);
        }

        [Then(@"I verify correct Trade Organizations are loaded")]
        public void ThenIVerifyCorrectTradeOrganizationsAreLoaded()
        {
            new SupplyProductionPage().ValidateCorrectTradeOrganizationsLoaded(Reader.Regions);
        }

        [Then(@"I verify correct Countries are loaded for Region selected")]
        public void ThenIVerifyCorrectCountriesAreLoadedForRegionSelected()
        {
            new SupplyProductionPage().ValidateCorrectCountriesLoadedForAGivenRegion(Reader.Regions);
        }

        [Then(@"I click on Reset")]
        public void ThenIClickOnReset()
        {
            new SupplyProductionPage().ClickResetButton();
        }

        [Then(@"I click on search Trade Organizations")]
        public void ThenIClickOnSearchTradeOrganizations()
        {
            new SupplyProductionPage().ClickSearchTradeOrganizations();
        }

        [Then(@"I enter Trade Organization name and select it from list")]
        public void ThenIEnterTradeOrganizationNameAndSelectItFromList()
        {
            new SupplyProductionPage().SelectTradeOrganizationsFromList(Reader.TradeOrganizations);
        }

        [Then(@"I verify correct Countries are loaded for TO selected")]
        public void ThenIVerifyCorrectCountriesAreLoadedForTOSelected()
        {
            new SupplyProductionPage().ValidateCorrectCountriesLoadedForAGivenTO(Reader.TradeOrganizations);
         }

        [Then(@"I click on search Countries")]
        public void ThenIClickOnSearchCountries()
        {
            new SupplyProductionPage().ClickSearchCountries();
        }

        [Then(@"I enter country name and select it from list")]
        public void ThenIEnterCountryNameAndSelectItFromList()
        {
            new SupplyProductionPage().SelectCountryFromList(Reader.Countries);
        }

        [Then(@"I verify correct Material Grades are loaded")]
        public void ThenIVerifyCorrectMaterialGradesAreLoaded()
        {
            new SupplyProductionPage().ValidateCorrectMaterialGradesLoaded(Reader.Countries);
        }

        [Then(@"I click on Apply Button")]
        public void ThenIClickOnApplyButton()
        {
            new SupplyProductionPage().ClickApplyButton();
        }

        [Then(@"I verify page loaded correctly")]
        public void ThenIVerifyPageLoadedCorrectly()
        {
            new SupplyProductionPage().VerifyPageLoadedCompletely();
        }

        [Then(@"I update the baseline value of one of the record and verify the value updated successfully")]
        public void ThenIUpdateTheBaselineValueOfOneOfTheRecordAndVerifyTheValueUpdatedSuccessfully()
        {
            new SupplyProductionPage().UpdateBaselineRecordAndVerifyValue();
        }

        [Then(@"I read the baseline records")]
        public void ThenIReadTheBaselineRecords()
        {
            baselineDataBeforeUpdate=new SupplyProductionPage().ReadBaselineData();
        }

        [Then(@"I click on EditIcon")]
        public void ThenIClickOnEditIcon()
        {
            new SupplyProductionPage().ClickEditIcon();
        }

        [Then(@"I update the baseline value of the records with Locked to Baselinecheckbox unchecked")]
        public void ThenIUpdateTheBaselineValueOfTheRecordsWithLockedToBaselinecheckboxUnchecked()
        {
            expectedBaselineData=new SupplyProductionPage().UpdateBaselineDataWithLockIndUnchecked(baselineDataBeforeUpdate);
        }

        [Then(@"I verify the baseline value has updated correctly and has no locked indicator to it")]
        public void ThenIVerifyTheBaselineValueHasUpdatedCorrectlyAndHasNoLockedIndicatorToIt()
        {
            actualBaselineData = new SupplyProductionPage().ReadBaselineData();
            new SupplyProductionPage().VerifyBaselineRecords(expectedBaselineData, actualBaselineData);          
        }

        [Then(@"I update the baseline value of the records with Locked to Baselinecheckbox checked")]
        public void ThenIUpdateTheBaselineValueOfTheRecordsWithLockedToBaselinecheckboxChecked()
        {
            expectedBaselineData = new SupplyProductionPage().UpdateBaselineDataWithLockIndChecked(baselineDataBeforeUpdate);
        }

        [Then(@"I verify the baseline value has updated correctly and has a locked indicator to it")]
        public void ThenIVerifyTheBaselineValueHasUpdatedCorrectlyAndHasALockedIndicatorToIt()
        {
            actualBaselineData = new SupplyProductionPage().ReadBaselineData();
            new SupplyProductionPage().VerifyBaselineRecords(expectedBaselineData, actualBaselineData);            
        }     

        [Then(@"I click on Promote to baseline option for single month")]
        public void ThenIClickOnPromoteToBaselineOptionForSingleMonth()
        {
            new SupplyProductionPage().ClickPromoteToBaselineSingleMonth();
        }

        [Then(@"I verify the New Record Added Successful Message")]
        public void ThenIVerifyTheNewRecordAddedSuccessfulMessage()
        {
            new SupplyProductionPage().VerifyRecordAddedsuccessfulMessage();
        }

        [Then(@"I click on Promote to baseline option for entire period")]
        public void ThenIClickOnPromoteToBaselineOptionForEntirePeriod()
        {
            new SupplyProductionPage().ClickPromoteToBaselineEntireMonth();
        }
        
        [Then(@"I verify the Shell Baseline record for First Month is updated to BoV at Country Level")]
        public void ThenIVerifyTheShellBaselineRecordForFirstMonthIsUpdatedToBoVAtCountryLevel()
        {
            actualBaselineData = new SupplyProductionPage().ReadBaselineData();
            actualBoVData = new SupplyProductionPage().ReadBovData();
            new SupplyProductionPage().VerifyBaselineRecords(actualBaselineData, actualBoVData, 1);
        }

        [Then(@"I verify the Shell Baseline records are updated to Bov at Country Level")]
        public void ThenIVerifyTheShellBaselineRecordsAreUpdatedToBovAtCountryLevel()
        {
            actualBaselineData = new SupplyProductionPage().ReadBaselineData();
            actualBoVData = new SupplyProductionPage().ReadBovData();
            new SupplyProductionPage().VerifyBaselineRecords(actualBaselineData, actualBoVData);
        }

        [Then(@"I verify all Grades for that period has unlocked")]
        public void ThenIVerifyAllGradesForThatPeriodHasUnlocked()
        {
            new SupplyProductionPage().ValidateLockingForAllMaterialGrades("");
        }

        [Then(@"I verify all Grades for that period has a lock")]
        public void ThenIVerifyAllGradesForThatPeriodHasALock()
        {
            new SupplyProductionPage().ValidateLockingForAllMaterialGrades("fa fa-lock");
        }

        [Then(@"I verify the Shell Baseline record for First Month is updated to BoV at Grade Level")]
        public void ThenIVerifyTheShellBaselineRecordForFirstMonthIsUpdatedToBoVAtGradeLevel()
        {
            new SupplyProductionPage().ValidatePromoteToBaselineAtGradeLevelSingleMonth();
        }

        [Then(@"I verify the Shell Baseline records are updated to Bov at Grade Level")]
        public void ThenIVerifyTheShellBaselineRecordsAreUpdatedToBovAtGradeLevel()
        {
            new SupplyProductionPage().ValidatePromoteToBaselineAtGradeLevelEntirePeriod();
        }

        [Then(@"I click on search Material Grades")]
        public void ThenIClickOnSearchMaterialGrades()
        {
            new SupplyProductionPage().ClickSearchMaterialGrades();
        }

        [Then(@"I enter Material Grades and select it from list")]
        public void ThenIEnterMaterialGradesAndSelectItFromList()
        {
            new SupplyProductionPage().SelectMaterialGradesFromList(Reader.MaterialGrades);
        }

        [Then(@"I Select All grades from Material Grades list")]
        public void ThenISelectAllGradesFromMaterialGradesList()
        {
            new SupplyProductionPage().SelectAllMaterialGrades();
        }

        [Then(@"I click on search Material Products")]
        public void ThenIClickOnSearchMaterialProducts()
        {
            new SupplyProductionPage().ClickSearchMaterialProducts();
        }

        [Then(@"I enter Material Product name and select it from list")]
        public void ThenIEnterMaterialProductNameAndSelectItFromList()
        {
            new SupplyProductionPage().SelectMaterialProductsFromList(Reader.MaterialProducts);
        }

        [Then(@"I enter Material Product name as Condensate and select it from list")]
        public void ThenIEnterMaterialProductNameAsCondensateAndSelectItFromList()
        {
            List<string> list = SupplyProductionPage.GetListFromCommaSepString(Reader.MaterialProducts);
            new SupplyProductionPage().SelectMaterialProductsFromList(list[0]);
        }

        [Then(@"I verify the MaterialGrades dropdown lists atleast one grade")]
        public void ThenIVerifyTheMaterialGradesDropdownListsAtleastOneGrade()
        {
            new SupplyProductionPage().VerifyMaterialGradesList();
        }

        [Then(@"I read the baseline records for Condensate Material Products")]
        public void ThenIReadTheBaselineRecordsForCondensateMaterialProducts()
        {
            condensateBaselineData = new SupplyProductionPage().ReadBaselineData();
        }

        [Then(@"I enter Material Product name as Crude  and select it from list")]
        public void ThenIEnterMaterialProductNameAsCrudeAndSelectItFromList()
        {
            List<string> list = SupplyProductionPage.GetListFromCommaSepString(Reader.MaterialProducts);
            new SupplyProductionPage().SelectMaterialProductsFromList(list[1]);
        }

        [Then(@"I update the baseline value of the records with Scaled Condensate checkbox checked")]
        public void ThenIUpdateTheBaselineValueOfTheRecordsWithScaledCondensateCheckboxChecked()
        {
            new SupplyProductionPage().UpdateBaselineDataWithScaleCondensateIndChecked(baselineDataBeforeUpdate);
        }

        [Then(@"I verify the baseline value has updated correctly for Condensate records and has a locked indicator to it")]
        public void ThenIVerifyTheBaselineValueHasUpdatedCorrectlyForCondensateRecordsAndHasALockedIndicatorToIt()
        {
            actualBaselineData = new SupplyProductionPage().ReadBaselineData();
            foreach (KeyValuePair<string, ArrayList> keyValuePair in condensateBaselineData)
            {
                string valueToUpdate = (int.Parse(keyValuePair.Value[0].ToString()) + (int.Parse(keyValuePair.Value[0].ToString()) * 1) / 100).ToString();
                keyValuePair.Value[0] = valueToUpdate;
                keyValuePair.Value[1] = "fa fa-lock";

            }
            new SupplyProductionPage().VerifyBaselineRecords(condensateBaselineData, actualBaselineData);
        }

        [Then(@"I update the baseline value of the records with Scaled Condensate checkbox Unchecked")]
        public void ThenIUpdateTheBaselineValueOfTheRecordsWithScaledCondensateCheckboxUnchecked()
        {
            new SupplyProductionPage().UpdateBaselineDataWithScaleCondensateIndUnChecked(baselineDataBeforeUpdate);
        }

        [Then(@"I verify the baseline value for condensate records is not updated")]
        public void ThenIVerifyTheBaselineValueForCondensateRecordsIsNotUpdated()
        {
            actualBaselineData = new SupplyProductionPage().ReadBaselineData();
            new SupplyProductionPage().VerifyBaselineRecords(condensateBaselineData, actualBaselineData);
        }

        [Then(@"I click on Calendar to enter Start Date")]
        public void ThenIClickOnCalendarToEnterStartDate()
        {
            new SupplyProductionPage().ClickOnStartCalendarIcon();
        }

        [Then(@"I select the StartYear (.*) and StartMonth(.*)")]
        public void ThenISelectTheStartYearAndStartMonth(string p0, string p1)
        {
            new SupplyProductionPage().SelectDate11(p0, p1);
        }

        [Then(@"I click on Calendar to enter End Date")]
        public void ThenIClickOnCalendarToEnterEndDate()
        {
            new SupplyProductionPage().ClickOnEndCalendarIcon();
        }

        [Then(@"I select the EndYear (.*) and EndMonth (.*)")]
        public void ThenISelectTheEndYearAndEndMonth(string p0, string p1)
        {
            new SupplyProductionPage().SelectDate11(p0, p1);
        }

        [Then(@"I enter country name (.*) and select it from list")]
        public void ThenIEnterCountryNameAndSelectItFromList(string p0)
        {
            new SupplyProductionPage().SelectCountryFromList(p0);
        }

        [Then(@"I enter Material Grades (.*) and select it from list")]
        public void ThenIEnterMaterialGradesAndSelectItFromList(string p0)
        {
            new SupplyProductionPage().SelectMaterialGradesFromList(p0);
        }

        [Then(@"I verify all the dataproviders (.*) are listed")]
        public void ThenIVerifyAllTheDataprovidersAreListed(string p0)
        {
            new SupplyProductionPage().VerifyDataProviders(p0);
        }

        [Then(@"I select the Date (.*) from the calendar")]
        public void ThenISelectTheDateFromTheCalendar(string p0)
        {
            new SupplyProductionPage().SelectDate(p0);
        }


    }


}


