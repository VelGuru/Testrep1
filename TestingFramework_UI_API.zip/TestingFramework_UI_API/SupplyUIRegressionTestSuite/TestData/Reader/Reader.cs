﻿using System.Collections.Concurrent;
using System.Threading.Tasks;
using GenevaUICommonUtils.Controller;


namespace SupplyUIRegressionTestSuite.TestData.Reader
{
    public class Reader : IReader
    {
        private static ConcurrentDictionary<string, dynamic> _configurationData = new ConcurrentDictionary<string, dynamic>();
        private readonly ReaderController readerController = new ReaderController();
        public static string Regions => _configurationData["Regions"];

        public static string TradeOrganizations => _configurationData["TradeOrganizations"];

        public static string Countries => _configurationData["Countries"];

        public static string MaterialGroups => _configurationData["Material Groups"];

        public static string MaterialProducts => _configurationData["Material Products"];

        public static string MaterialGrades => _configurationData["Material Grades"];
       
        public async Task<dynamic> LoadConfigurationJson(string scenarioName, string jsonFilePath)
        {
            _configurationData.Clear();
            _configurationData = await readerController.ReadJasonData(scenarioName, jsonFilePath);
            return _configurationData;
        }
    }
}
