﻿using System;
using System.Collections.Generic;
using System.Text;
using GenevaUICommonUtils.Selenium;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using NUnit.Framework;
using System.Threading;
using System.Collections;
using System.Linq;
using OpenQA.Selenium.Interactions;
using Microsoft.Extensions.Configuration;
using GenevaUICommonUtils.DataBase;

namespace SupplyUIRegressionTestSuite.PageObject.Pages
{
    class SupplyProductionPage
    {

        public static IWebDriver WebDriver = Driver.getDriver;
        public WebDriverWait WebDriverWait;
        IJavaScriptExecutor executor = (IJavaScriptExecutor)WebDriver;

        //By ClickonSupplyLogo = By.XPath("//div[1]/a/img[@alt='shell-logo']");
        By ClickonSupplyLogo = By.XPath(" //*[@id='dropdown']/img");
        By GetSupplyProductionTitle = By.XPath("//*/div/main/div/div[2]/div[1]/div/div[1]/h3");
        By ReadSupplyProduction = By.XPath("//*[contains(text(),'Supply Production')]");
        By ClickonFilterButton = By.XPath("//*[@class='k-icon k-i-filter k-icon']");
        By SearchRegions = By.XPath("//*[@Id='regions-search-box']");
        By SearchTradeOrganizations = By.XPath("//*[@Id='tradeOrganizations-search-box']");
        By SearchCountries = By.XPath("//*[@Id='country-search-box']");
        By SearchMaterialGroups = By.XPath("//*[@Id='materialGroups-search-box']");
        By SearchMaterialProducts = By.XPath("//*[@Id='materialProducts-search-box']");
        By SearchMaterialGrades = By.XPath("//*[@Id='materialTypeNm-search-box']");
        By ApplyButtonClick = By.XPath("//*[@class='reset-clear apply']");
        By ResetButtonClick = By.XPath("//*[@class='reset-clear']");
        By GraphContainer = By.XPath("//*[@class='recharts-responsive-container']");
        By TableContainer = By.XPath("//*[@id='capacityscreen']//*[text()='SHELL-BASELINE']");
        By ClickonEditIcon = By.XPath("//*[@class='fa fa-pencil']");
        By BaselineRecordFirstcell = By.XPath("//*[@id='capacityscreen']//*/table/tbody/tr/tr[1]/td[1]/div/button/span");
        By BaselineRecordEditScreen = By.XPath("//*/div[1]/div/table/tbody/tr/td/table/thead/tr/td[1]/td/div/input");
        By ClickonSave = By.XPath("//*[text()='Save']");
        By ClickonClose = By.XPath("//*[text()='Close']");

        public static List<string> GetListFromCommaSepString(string commaSeparatedString)
        {
            if (commaSeparatedString != null && commaSeparatedString.Trim().Length > 0)
            {
                return commaSeparatedString.Split(',').ToList();
            }
            return new List<string>();
        }


        public SupplyProductionPage(int waitInMilliSecond = 50)
        {
            WebDriverWait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(waitInMilliSecond));
        }

        public void ClickOnSupplyLogo()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            var ProgramMenu = WebDriver.FindElement(ClickonSupplyLogo);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(ProgramMenu));
            ProgramMenu.Click();
        }

        public string GetSupplyProductionText()
        {
            string supplyProduction = WebDriver.FindElement(GetSupplyProductionTitle).Text;
            WebDriverWait.Until(ExpectedConditions.ElementIsVisible(ReadSupplyProduction));
            return supplyProduction;
        }

        public void ClickFilter()
        {
            var Filter = WebDriver.FindElement(ClickonFilterButton);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Filter));
            Filter.Click();
        }
        public void ClickSearchRegion()
        {
            var Search_Region = WebDriver.FindElement(SearchRegions);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Region));
            Search_Region.Click();

        }

        public bool Click(string elementpath)
        {
            bool status = false;
            int i = 0;
            while (i == 0)
                try
                {                   
                    var findregioncheckbox = WebDriver.FindElement(By.XPath(elementpath));
                    executor = (IJavaScriptExecutor)WebDriver;
                    executor.ExecuteScript("arguments[0].click();", findregioncheckbox);
                    status = true;
                    break;
                }
                catch (StaleElementReferenceException e)
                {
                }
            return status;
        }

        public void SelectRegionFromList(string Region)
        {
            var Search_Region = WebDriver.FindElement(SearchRegions);
            Search_Region.SendKeys(Region);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);        
            var findregioncheckboxelement = "//*[input[contains(@name,'Region')]]/label[contains(@for,'" + Region + "')]";
            Click(findregioncheckboxelement);
        }

        public void ClickSearchTradeOrganizations()
        {
            var Search_TradeOrganizations = WebDriver.FindElement(SearchTradeOrganizations);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_TradeOrganizations));
            Search_TradeOrganizations.Click();
        }

        public void SelectTradeOrganizationsFromList(string TradeOrganizations)
        {
            var Search_TradeOrganizations = WebDriver.FindElement(SearchTradeOrganizations);
            Search_TradeOrganizations.SendKeys(TradeOrganizations);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(50);
            var findtradeorgcheckboxelement = "//*[input[contains(@name,'TradeOrganization')]]/label[contains(@for,'" + TradeOrganizations + "')]";
            Click(findtradeorgcheckboxelement);            
        }
        public void ClickSearchCountries()
        {
            var Search_Countries = WebDriver.FindElement(SearchCountries);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Countries));
            Search_Countries.Click();
        }

        public void SelectCountryFromList(string Country)
        {
            var Search_Country = WebDriver.FindElement(SearchCountries);
            Search_Country.SendKeys(Country);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(50);
            var findcountrycheckboxelement = "//*[input[contains(@name,'Countries')]]/label[contains(@for,'" + Country + "')]";
            Click(findcountrycheckboxelement);
            Thread.Sleep(1000);
        }
        public void ClickMaterialGroups()
        {
            var Search_MaterialGroups = WebDriver.FindElement(SearchMaterialGroups);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_MaterialGroups));
            Search_MaterialGroups.Click();
        }

        public void SelectMaterialGroupsFromList(string MaterialGroups)
        {
            var Search_MaterialGroups = WebDriver.FindElement(SearchMaterialGroups);
            Search_MaterialGroups.SendKeys(MaterialGroups);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(40);
            var findMGcheckboxelement = "//*[input[contains(@name,'MaterialGroupClass')]]/label[contains(@for,'" + MaterialGroups + "')]";
            Click(findMGcheckboxelement);         
        }
        public void ClickSearchMaterialProducts()
        {
            var Search_MaterialProducts = WebDriver.FindElement(SearchMaterialProducts);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_MaterialProducts));
            Search_MaterialProducts.Click();
        }

        public void SelectMaterialProductsFromList(string MaterialProducts)
        {
            var Search_MaterialProducts = WebDriver.FindElement(SearchMaterialProducts);
            Search_MaterialProducts.SendKeys(MaterialProducts);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(40);
            var findMPcheckboxelement = "//*[input[contains(@name,'MaterialProductClass')]]/label[contains(@for,'" + MaterialProducts + "')]";
            Click(findMPcheckboxelement);            
        }
        public void ClickSearchMaterialGrades()
        {
            Thread.Sleep(3500);
            var Search_MaterialGrades = WebDriver.FindElement(SearchMaterialGrades);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_MaterialGrades));
            Search_MaterialGrades.Click();
        }

        public void SelectMaterialGradesFromList(string MaterialGrades)
        {
            Thread.Sleep(3000);
            var Search_MaterialGrades = WebDriver.FindElement(SearchMaterialGrades);
            Search_MaterialGrades.SendKeys(MaterialGrades);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(50);
            var count = WebDriver.FindElements(By.XPath("//*[input[contains(@name,'MaterialGrade')]]/label[contains(@for,'" + MaterialGrades + "')]")).Count;
            if (count > 0)
            {
                // Assert.IsTrue(WebDriver.Equals(By.XPath("//*[text()='No Data...']")), "MaterialGrades not found");
                var findMGRcheckboxelement = "//*[input[contains(@name,'MaterialGrade')]]/label[contains(@for,'" + MaterialGrades + "')]";
                Click(findMGRcheckboxelement);
            }
            else
            {
                Console.WriteLine(MaterialGrades + "MaterialGrade not found");
            }

        }

        public void SelectAllMaterialGrades()
        {
            Thread.Sleep(10000);
            var findSelectAllcheckboxelement = "//label[contains(@for,'Select All')]";
            Click(findSelectAllcheckboxelement);
        }

        public void VerifyMaterialGradesList()
        {
            Thread.Sleep(5000);
            //int count = WebDriver.FindElements(By.XPath("//*[@id='filterPanel']/div[6]/div/div/div[2]")).Count;
            //var element = WebDriver.FindElement(By.XPath("//*[text()='No Data...']"));
            //if (count<1)
            //{
            //    Console.WriteLine("MaterialGrades not found");
            //}

            Assert.IsFalse(WebDriver.Equals(By.XPath("//*[text()='No Data...']")));


        }
        public void ClickApplyButton()
        {
            var Apply_Button = WebDriver.FindElement(ApplyButtonClick);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Apply_Button));
            Apply_Button.Click();
        }

        public void ClickResetButton()
        {
            var Reset_Button = WebDriver.FindElement(ResetButtonClick);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Reset_Button));
            Reset_Button.Click();
        }

        public void ClickPromoteToBaselineSingleMonth()
        {
            var firstmonth = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[2]/td[1]/div/button"));
            var builder = new Actions(WebDriver);
            builder.ContextClick(firstmonth);
            builder.Perform();
            Thread.Sleep(500);
            var promoteToBaseline = WebDriver.FindElement(By.XPath("//*/div[26]/div/button"));
            promoteToBaseline.Click();
        }

        public void ClickPromoteToBaselineEntireMonth()
        {
            var entiremonth = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//tbody/tr[2]/td/div/button"));
            var builder = new Actions(WebDriver);
            builder.ContextClick(entiremonth);
            builder.Perform();
            Thread.Sleep(500);
            var promoteToBaseline = WebDriver.FindElement(By.XPath("//*/div[3]/div/button"));
            promoteToBaseline.Click();
        }

        public void VerifyPageLoadedCompletely()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1000);
            var Graph_Container = WebDriver.FindElement(GraphContainer);
            Graph_Container.Click();
            WebDriverWait.Until(ExpectedConditions.ElementIsVisible(GraphContainer));
            var Table_Container = WebDriver.FindElement(TableContainer);
            Table_Container.Click();
            WebDriverWait.Until(ExpectedConditions.ElementIsVisible(TableContainer));
        }
        public void ClickEditIcon()
        {
            var Edit_Icon = WebDriver.FindElement(ClickonEditIcon);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Edit_Icon));
            Edit_Icon.Click();
        }

        public void VerifyRecordAddedsuccessfulMessage()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(200);
            WebDriverWait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(By.XPath("//*[@class='Toastify__toast-body']")));
            var alert_message = WebDriver.FindElement(By.XPath("//*[text()='New record added successfully.']")).Text;
            Assert.AreEqual("New record added successfully.", alert_message);
            WebDriverWait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//*[@class='Toastify__toast-body']")));
            Thread.Sleep(10000);
        }

        public void EditBaselineRecord(string Updatedvalue)
        {
            var Baseline_Record = WebDriver.FindElement(BaselineRecordEditScreen);
            Baseline_Record.Clear();
            Baseline_Record.SendKeys(Updatedvalue);
            var Clickon_Save = WebDriver.FindElement(ClickonSave);
            Clickon_Save.Click();
            VerifyRecordAddedsuccessfulMessage();
            var Clickon_Close = WebDriver.FindElement(ClickonClose);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(ClickonClose));
            Clickon_Close.Click();          

        }

        public void UpdateBaselineRecordAndVerifyValue()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(50);
            var BaselineValue_BeforeUpdate = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//tr[1]/td[1]/div/button/span")).Text;
            var updated_BaselineValue = int.Parse(BaselineValue_BeforeUpdate) + 10;

            ClickEditIcon();
            EditBaselineRecord(updated_BaselineValue.ToString());
            Thread.Sleep(1000);
            var BaselineValue_AfterUpdate = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//tr[1]/td[1]/div/button/span")).Text;

            if (updated_BaselineValue - int.Parse(BaselineValue_AfterUpdate) > 1)
            {
                Assert.Fail("Baseline value has not updated");
            }              
            //Assert.AreEqual(updated_BaselineValue.ToString(), BaselineValue_AfterUpdate);
        }

        public Dictionary<string, ArrayList> ReadBaselineData()
        {
            Dictionary<string, ArrayList> Dic = new Dictionary<string, ArrayList>();
            Thread.Sleep(1000);
            int rowCount = WebDriver.FindElements(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[1]")).Count;
            if (rowCount > 0)
            {
                //for (int i = 1; i <= rowCount; i++)
                //{                    
                int dataCount = WebDriver.FindElements(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[1]/td")).Count;
                if (dataCount > 0)
                {
                    for (int j = 1; j <= 12; j++)
                    {
                        string month = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[1]/td[" + j + "]/div/button")).GetAttribute("selectmonth");
                        string baselinevalue = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[1]/td[" + j + "]/div/button/span")).Text;
                        string lockedind = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[1]/td[" + j + "]/div/button/i")).GetAttribute("class");
                        string Style = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[1]/td[" + j + "]/div/button/i")).GetAttribute("style");
                        ArrayList list = new ArrayList();
                        list.Add(baselinevalue);
                        list.Add(lockedind);
                        list.Add(Style);
                        Dic.Add(month, list);
                    }
                }
                //}
            }
            return Dic;
        }
        public Dictionary<string, ArrayList> ReadBovData()
        {
            Dictionary<string, ArrayList> Dic = new Dictionary<string, ArrayList>();

            int rowCount = WebDriver.FindElements(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[2]")).Count;
            if (rowCount > 0)
            {
                int dataCount = WebDriver.FindElements(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[2]/td")).Count;
                if (dataCount > 0)
                {
                    for (int j = 1; j <= 12; j++)
                    {
                        string month = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[2]/td[" + j + "]/div/button")).GetAttribute("selectmonth");
                        string baselinevalue = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[2]/td[" + j + "]/div/button/span")).Text;
                        string lockedind = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[2]/td[" + j + "]/div/button/i")).GetAttribute("class");
                        string Style = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//child::table//tr/tr[2]/td[" + j + "]/div/button/i")).GetAttribute("style");
                        ArrayList list = new ArrayList();
                        list.Add(baselinevalue);
                        list.Add(lockedind);
                        list.Add(Style);
                        Dic.Add(month, list);
                    }
                }
            }
            return Dic;
        }

        public Dictionary<string, ArrayList> UpdateBaselineDataWithLockIndUnchecked(Dictionary<string, ArrayList> Dic2)
        {
            int j = 1;
            foreach (KeyValuePair<string, ArrayList> keyValuePair in Dic2)
            {
                int dataCount = WebDriver.FindElements(By.XPath("//*/div[1]/div/table/tbody/tr/td/table/thead/tr/td")).Count;
                if (dataCount > 0)
                {

                    By BaselineRecordsEditScreen = By.XPath("//*/div[1]/div/table/tbody/tr/td/table/thead/tr/td[" + j + "]/td/div/input");
                    var Baseline_Records = WebDriver.FindElement(BaselineRecordsEditScreen);
                    Baseline_Records.Clear();
                    Baseline_Records.SendKeys((int.Parse(keyValuePair.Value[0].ToString()) + 1).ToString());
                    keyValuePair.Value[0] = (int.Parse(keyValuePair.Value[0].ToString()) + 1).ToString();
                    keyValuePair.Value[1] = "";
                    j++;
                }
            }
            var locked_ind = WebDriver.FindElement(By.XPath("//*/input[@name='lockStatus']"));
            locked_ind.Click();
            var Clickon_Save = WebDriver.FindElement(ClickonSave);
            Clickon_Save.Click();
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(200);
            WebDriverWait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(By.XPath("//*[@class='Toastify__toast-body']")));
            var alert_message = WebDriver.FindElement(By.XPath("//*[text()='New record added successfully.']")).Text;
            Assert.AreEqual("New record added successfully.", alert_message);
            WebDriverWait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//*[@class='Toastify__toast-body']")));
            var Clickon_Close = WebDriver.FindElement(ClickonClose);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(ClickonClose));
            Clickon_Close.Click();

            return Dic2;

        }
        public Dictionary<string, ArrayList> UpdateBaselineDataWithLockIndChecked(Dictionary<string, ArrayList> Dic2)
        {
            int j = 1;
            foreach (KeyValuePair<string, ArrayList> keyValuePair in Dic2)
            {
                int dataCount = WebDriver.FindElements(By.XPath("//*/div[1]/div/table/tbody/tr/td/table/thead/tr/td")).Count;
                if (dataCount > 0)
                {

                    By BaselineRecordsEditScreen = By.XPath("//*/div[1]/div/table/tbody/tr/td/table/thead/tr/td[" + j + "]/td/div/input");
                    var Baseline_Records = WebDriver.FindElement(BaselineRecordsEditScreen);
                    Baseline_Records.Clear();
                    Baseline_Records.SendKeys((int.Parse(keyValuePair.Value[0].ToString()) + 1).ToString());
                    keyValuePair.Value[0] = (int.Parse(keyValuePair.Value[0].ToString()) + 1).ToString();
                    keyValuePair.Value[1] = "fa fa-lock";
                    j++;
                }
            }
            var Clickon_Save = WebDriver.FindElement(ClickonSave);
            Clickon_Save.Click();
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(200);
            WebDriverWait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(By.XPath("//*[@class='Toastify__toast-body']")));
            var alert_message = WebDriver.FindElement(By.XPath("//*[text()='New record added successfully.']")).Text;
            Assert.AreEqual("New record added successfully.", alert_message);
            WebDriverWait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//*[@class='Toastify__toast-body']")));
            Thread.Sleep(10000);
            var Clickon_Close = WebDriver.FindElement(ClickonClose);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(ClickonClose));
            Clickon_Close.Click();

            return Dic2;

        }

        public void VerifyBaselineRecords(Dictionary<string, ArrayList> Dic1, Dictionary<string, ArrayList> Dic2, int optionalint = 0)
        {
            Dictionary<string, string> diff = new Dictionary<string, string>();

            if (optionalint == 1)
            {
                if (Dic1.Keys.First() == Dic2.Keys.First())
                {
                    Assert.AreEqual(Dic1.Values.First().ToArray().ElementAt(0), Dic2.Values.First().ToArray().ElementAt(0));
                    Assert.AreEqual(Dic1.Values.First().ToArray().ElementAt(1), Dic2.Values.First().ToArray().ElementAt(1));
                    Assert.AreEqual(Dic1.Values.First().ToArray().ElementAt(2), Dic2.Values.First().ToArray().ElementAt(2));
                }
            }
            else
            {
                foreach (KeyValuePair<string, ArrayList> keyValuePair in Dic1)
                {
                    foreach (KeyValuePair<string, ArrayList> keyValue in Dic2)
                    {
                        if (keyValuePair.Key == keyValue.Key)
                        {
                            for (int i = 0; i <= 2; i++)
                            {
                                if (keyValuePair.Value[i].ToString() != keyValue.Value[i].ToString())
                                {
                                    if (i == 0)
                                    {
                                        int delta = int.Parse(keyValuePair.Value[0].ToString()) - int.Parse(keyValue.Value[0].ToString());
                                        if (delta > 1)
                                        {
                                            diff.Add(keyValuePair.Key, keyValuePair.Value[i].ToString());
                                        }
                                    }
                                    else
                                    {
                                        diff.Add(keyValuePair.Key, keyValuePair.Value[i].ToString());
                                    }

                                }
                            }
                            break;
                        }

                    }
                }

                if (diff.Count() > 0)
                {
                    foreach (KeyValuePair<string, string> kvp in diff)
                    {

                        Console.WriteLine("Key = {0}, Value = {1}", kvp.Key, kvp.Value);
                    }
                    Assert.Fail("BaselineUpdate was not successful");

                }
            }

        }
        public void ValidateLockingForAllMaterialGrades(string lockInd)
        {
            string FirstMGName = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[1]/div/div[1]/div/div/div/p/strong")).Text;
            Dictionary<string, string> diff = new Dictionary<string, string>();
            int MGcount = WebDriver.FindElements(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div")).Count();

            for (int i = 1; i <= MGcount; i++)
            {
                string MGName = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[1]/div/div/div/p/strong")).Text;
                var element = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[1]/div/div/div/p/strong"));
                Actions actions = new Actions(WebDriver);
                actions.MoveToElement(element);
                actions.Perform();

                for (int j = 1; j <= 12; j++)
                {
                    string Month = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/thead/tr/table/tbody/tr/th[" + j + "]/div/button")).Text;
                    string SBlockedind = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[1]/td[" + j + "]/div/button/i")).GetAttribute("class");
                   
                    if (SBlockedind != lockInd)
                    {                        
                            diff.Add(MGName, Month);
                        }

                    }
                    
            }
            if (diff.Count > 0)
            {
                diff.Select(i => $"{i.Key}: {i.Value}").ToList().ForEach(Console.WriteLine);
                foreach (KeyValuePair<string, string> kvp in diff)
                {

                    Console.WriteLine("Key = {0}, Value = {1}", kvp.Key, kvp.Value);
                }
                Assert.Fail("SB and BOV records doesnot match");

            }
        }

        public Dictionary<string, ArrayList> UpdateBaselineDataWithScaleCondensateIndChecked(Dictionary<string, ArrayList> Dic2)
        {
            int j = 1;
            foreach (KeyValuePair<string, ArrayList> keyValuePair in Dic2)
            {
                int dataCount = WebDriver.FindElements(By.XPath("//*/div[1]/div/table/tbody/tr/td/table/thead/tr/td")).Count;
                if (dataCount > 0)
                {

                    By BaselineRecordsEditScreen = By.XPath("//*/div[1]/div/table/tbody/tr/td/table/thead/tr/td[" + j + "]/td/div/input");
                    var Baseline_Records = WebDriver.FindElement(BaselineRecordsEditScreen);
                    Baseline_Records.Clear();
                    string valueToUpdate = (int.Parse(keyValuePair.Value[0].ToString()) + (int.Parse(keyValuePair.Value[0].ToString()) * 1) / 100).ToString();
                    Baseline_Records.SendKeys(valueToUpdate);
                    keyValuePair.Value[0] = valueToUpdate;
                    keyValuePair.Value[1] = "fa fa-lock";
                    j++;
                }
            }
            var Clickon_Save = WebDriver.FindElement(ClickonSave);
            Clickon_Save.Click();
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(500);
            WebDriverWait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(By.XPath("//*[@class='Toastify__toast-body']")));
            var alert_message = WebDriver.FindElement(By.XPath("//*[text()='New record added successfully.']")).Text;
            Assert.AreEqual("New record added successfully.", alert_message);
            WebDriverWait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//*[@class='Toastify__toast-body']")));
            Thread.Sleep(10000);
            var Clickon_Close = WebDriver.FindElement(ClickonClose);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(ClickonClose));
            Clickon_Close.Click();

            return Dic2;

        }
        public Dictionary<string, ArrayList> UpdateBaselineDataWithScaleCondensateIndUnChecked(Dictionary<string, ArrayList> Dic2)
        {
            int j = 1;
            foreach (KeyValuePair<string, ArrayList> keyValuePair in Dic2)
            {
                int dataCount = WebDriver.FindElements(By.XPath("//*/div[1]/div/table/tbody/tr/td/table/thead/tr/td")).Count;
                if (dataCount > 0)
                {

                    By BaselineRecordsEditScreen = By.XPath("//*/div[1]/div/table/tbody/tr/td/table/thead/tr/td[" + j + "]/td/div/input");
                    var Baseline_Records = WebDriver.FindElement(BaselineRecordsEditScreen);
                    Baseline_Records.Clear();
                    string valueToUpdate = (int.Parse(keyValuePair.Value[0].ToString()) + (int.Parse(keyValuePair.Value[0].ToString()) * 1) / 100).ToString();
                    Baseline_Records.SendKeys(valueToUpdate);
                    keyValuePair.Value[0] = valueToUpdate;
                    keyValuePair.Value[1] = "fa fa-lock";
                    j++;
                }
            }
            var scaledCond_ind = WebDriver.FindElement(By.XPath("//*/input[@name='scale']"));
            scaledCond_ind.Click();
            var Clickon_Save = WebDriver.FindElement(ClickonSave);
            Clickon_Save.Click();
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(500);
            WebDriverWait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(By.XPath("//*[@class='Toastify__toast-body']")));
            var alert_message = WebDriver.FindElement(By.XPath("//*[text()='New record added successfully.']")).Text;
            Assert.AreEqual("New record added successfully.", alert_message);
            WebDriverWait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//*[@class='Toastify__toast-body']")));
            Thread.Sleep(10000);
            var Clickon_Close = WebDriver.FindElement(ClickonClose);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(ClickonClose));
            Clickon_Close.Click();
            return Dic2;

        }


        public Dictionary<string, ArrayList> UpdateCondBaselineRecords(Dictionary<string, ArrayList> Dic2)
        {
            foreach (KeyValuePair<string, ArrayList> keyValuePair in Dic2)
            {
                string valueToUpdate = (int.Parse(keyValuePair.Value[0].ToString()) + (int.Parse(keyValuePair.Value[0].ToString()) * 1) / 100).ToString();
                keyValuePair.Value[0] = valueToUpdate;
                keyValuePair.Value[1] = "fa fa-lock";

            }
            return Dic2;
        }
       

        public void ValidatePromoteToBaselineAtGradeLevelSingleMonth()
        {
            string FirstMGName = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[1]/div/div[1]/div/div/div/p/strong")).Text;
            string FirstMonth = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[1]/div/div[2]/div/div/div/div/table/div/table/thead/tr/table/tbody/tr/th[1]/div/button")).Text;
            Dictionary<string, string> diff = new Dictionary<string, string>();
            int MGcount = WebDriver.FindElements(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div")).Count();

            for (int i = 1; i <= MGcount; i++)
            {
                string MGName = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[1]/div/div/div/p/strong")).Text;
                var element = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[1]/div/div/div/p/strong"));
                Actions actions = new Actions(WebDriver);
                actions.MoveToElement(element);
                actions.Perform();

                for (int j = 1; j <= 12; j++)
                {
                    string Month = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/thead/tr/table/tbody/tr/th[" + j + "]/div/button")).Text;

                    string SBvalue = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[1]/td[" + j + "]/div/button/span")).Text;
                    string SBlockedind = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[1]/td[" + j + "]/div/button/i")).GetAttribute("class");
                    string SBStyle = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[1]/td[" + j + "]/div/button")).GetAttribute("style");

                    string BoVvalue = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[2]/td[" + j + "]/div/button/span")).Text;
                    string BoVlockedind = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[2]/td[" + j + "]/div/button/i")).GetAttribute("class");
                    string BoVStyle = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[2]/td[" + j + "]/div/button")).GetAttribute("style");

                    if (Month == FirstMonth)
                    {
                        if (MGName == FirstMGName)
                        {
                           if(SBvalue!=BoVvalue || SBlockedind!=BoVlockedind || SBStyle!=BoVStyle)
                            {
                                diff.Add(MGName, Month);
                            }                           

                        }
                        else if (SBlockedind!= BoVlockedind || SBStyle!= BoVStyle)
                        {
                            diff.Add(MGName, Month);                         
                        }
                    }

                }

            }

            if(diff.Count>0)
            {
                diff.Select(i => $"{i.Key}: {i.Value}").ToList().ForEach(Console.WriteLine);
                foreach (KeyValuePair<string, string> kvp in diff)
                {    
                   
                   Console.WriteLine("Key = {0}, Value = {1}", kvp.Key, kvp.Value);      
                }
                Assert.Fail("SB and BOV records doesnot match");

            }
        }

        public void ValidatePromoteToBaselineAtGradeLevelEntirePeriod()
        {
            string FirstMGName = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[1]/div/div[1]/div/div/div/p/strong")).Text;
            Dictionary<string, string> diff = new Dictionary<string, string>();
            int MGcount = WebDriver.FindElements(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div")).Count();

            for (int i = 1; i <= MGcount; i++)
            {
                string MGName = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[1]/div/div/div/p/strong")).Text;
                var element = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[1]/div/div/div/p/strong"));
                Actions actions = new Actions(WebDriver);
                actions.MoveToElement(element);
                actions.Perform();

                for (int j = 1; j <= 12; j++)
                {
                    string Month = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/thead/tr/table/tbody/tr/th[" + j + "]/div/button")).Text;

                    string SBvalue = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[1]/td[" + j + "]/div/button/span")).Text;
                    string SBlockedind = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[1]/td[" + j + "]/div/button/i")).GetAttribute("class");
                    string SBStyle = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[1]/td[" + j + "]/div/button")).GetAttribute("style");

                    string BoVvalue = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[2]/td[" + j + "]/div/button/span")).Text;
                    string BoVlockedind = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[2]/td[" + j + "]/div/button/i")).GetAttribute("class");
                    string BoVStyle = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div[5]/div/div/div/div/div[2]/div/div/div[" + i + "]/div/div[2]/div/div/div/div/table/div/table/tbody/tr/table/tbody/tr/tr[2]/td[" + j + "]/div/button")).GetAttribute("style");

                    if (MGName == FirstMGName)
                    {
                        if (SBvalue != BoVvalue || SBlockedind != BoVlockedind || SBStyle != BoVStyle)
                        {
                            diff.Add(MGName, Month);
                        }

                    }
                    else if (SBlockedind != BoVlockedind || SBStyle != BoVStyle)
                    {
                        diff.Add(MGName, Month);
                    }
                }
            }
                if (diff.Count > 0)
                {
                    diff.Select(i => $"{i.Key}: {i.Value}").ToList().ForEach(Console.WriteLine);
                    foreach (KeyValuePair<string, string> kvp in diff)
                    {

                        Console.WriteLine("Key = {0}, Value = {1}", kvp.Key, kvp.Value);
                    }
                    Assert.Fail("SB and BOV records doesnot match");

                }
            }       

        public void ValidateCorrectTradeOrganizationsLoaded(string Regions)
        {
            Thread.Sleep(1000);
            String query = "select distinct tor.trade_organization_abbr from cns_glb_reference.hierarchy_vw hv join cns_glb_reference.geopolitical_entity ge on hv.geopolitical_entity_key=ge.geopolitical_entity_key join  cns_glb_reference.trade_organization_member tom on tom.country_key = ge.geopolitical_entity_key join cns_glb_reference.trade_organization tor on tor.trade_organization_key = tom.trade_organization_key where ge.geopolitical_entity_level_num = 1 and ge.delete_ind = 'N' and tom.delete_ind = 'N' and tom.version_active_ind = 'Y' and hv.Hierarchy_Name = 'Vienna' and hv.Region_Name =" + "\'" + Regions + "\'" + " ; ";
           List<string> SQLData= ExecuteDBScripts.ExecuteQueryAndGetFieldValues(query, "trade_organization_abbr");
            List<string> UIData = new List<string>();
            int count = WebDriver.FindElements(By.XPath("//*[@id='filterPanel']/div[2]/div/div/div[2]/div")).Count();
            for (int i = 1; i <= count; i++) 
            {
              string to_nm=  WebDriver.FindElement(By.XPath("//*[@id='filterPanel']/div[2]/div/div/div[2]/div["+i+"]/div/label")).Text;
                UIData.Add(to_nm);
             }         
            bool isEqual = !SQLData.Except(UIData).Any();

            Assert.IsTrue(isEqual, "TradeOrganizations listed for selected region is not correct");
        }

        public void ValidateCorrectCountriesLoadedForAGivenRegion(string Regions)
        {
            Thread.Sleep(1000);
            String query = "select distinct ge.geopolitical_entity_nm from cns_glb_reference.hierarchy_vw hv join cns_glb_reference.geopolitical_entity ge on hv.geopolitical_entity_key = ge.geopolitical_entity_key where ge.geopolitical_entity_level_num = 1 and hv.Hierarchy_Name = 'Vienna' and ge.delete_ind = 'N' and hv.Region_Name =" + "\'" + Regions + "\'" + " ; ";
            List<string> SQLData = ExecuteDBScripts.ExecuteQueryAndGetFieldValues(query, "geopolitical_entity_nm");
            List<string> UIData = new List<string>();
            int count = WebDriver.FindElements(By.XPath("//*[@id='filterPanel']/div[3]/div/div/div[2]/div")).Count();
            for (int i = 1; i <= count; i++)
            {
                string to_nm = WebDriver.FindElement(By.XPath("//*[@id='filterPanel']/div[3]/div/div/div[2]/div["+i+"]/div/label")).Text;
                UIData.Add(to_nm);
            }
            bool isEqual = !SQLData.Except(UIData).Any();

            Assert.IsTrue(isEqual, "Countries listed for selected region is not correct");
        }

        public void ValidateCorrectCountriesLoadedForAGivenTO(string TradeOrganization)
        {
            Thread.Sleep(1000);
            String query = "select distinct ge.geopolitical_entity_nm from cns_glb_reference.hierarchy_vw hv join cns_glb_reference.geopolitical_entity ge on hv.geopolitical_entity_key = ge.geopolitical_entity_key join cns_glb_reference.trade_organization_member tom on tom.country_key = ge.geopolitical_entity_key join cns_glb_reference.trade_organization tor on tor.trade_organization_key = tom.trade_organization_key where ge.geopolitical_entity_level_num = 1 and ge.delete_ind = 'N'and tom.delete_ind = 'N' and tom.version_active_ind = 'Y' and hv.Hierarchy_Name = 'Vienna' and tor.trade_organization_abbr = " + "\'" + TradeOrganization + "\'" + " ; ";
            List<string> SQLData = ExecuteDBScripts.ExecuteQueryAndGetFieldValues(query, "geopolitical_entity_nm");
            List<string> UIData = new List<string>();
            int count = WebDriver.FindElements(By.XPath("//*[@id='filterPanel']/div[3]/div/div/div[2]/div")).Count();
            for (int i = 1; i <= count; i++)
            {
                string to_nm = WebDriver.FindElement(By.XPath("//*[@id='filterPanel']/div[3]/div/div/div[2]/div[" + i + "]/div/label")).Text;
                UIData.Add(to_nm);
            }
            bool isEqual = !SQLData.Except(UIData).Any();

            Assert.IsTrue(isEqual, "Countries listed for selected Trade Organization is not correct");
        }

        public void ValidateCorrectMaterialGradesLoaded(string Country)
        {
            Thread.Sleep(15000);
            String query = "select distinct mtv.GRADE_NM from cns_cpo_mid_capacity.oil_gas_production ogp join cns_glb_reference.geopolitical_entity_vw gev on ogp.geopolitical_entity_key = gev.GEOPOLITICAL_ENTITY_KEY join cns_glb_reference.MATERIAL_TYPE_VW mtv on ogp.material_type_key = mtv.MATERIAL_TYPE_KEY join cns_cpo_mid_reference.version_type vt on vt.version_type_key = ogp.version_type_key where vt.version_type_cd = 'B' and ogp.version_active_ind = 'Y' and ogp.delete_ind = 'N' and gev.COUNTRY_NM = " + "\'" + Country + "\'" + " ; ";
            List<string> SQLData = ExecuteDBScripts.ExecuteQueryAndGetFieldValues(query, "GRADE_NM");
            List<string> UIData = new List<string>();
            int count = WebDriver.FindElements(By.XPath("//*[@id='filterPanel']/div[6]/div/div/div[2]/div")).Count();
            for (int i = 2; i <= count; i++)
            {
                string to_nm = WebDriver.FindElement(By.XPath("//*[@id='filterPanel']/div[6]/div/div/div[2]/div[" + i + "]/div/label")).Text;
                UIData.Add(to_nm);
            }
            bool isEqual = !SQLData.Except(UIData).Any();

            Assert.IsTrue(isEqual, "Material Grades listed for selected Country is not correct or Material Grades not Loaded");
        }

        public void VerifyDataProviders(string dataProviders)
        {
            List<string> actualDP = SupplyProductionPage.GetListFromCommaSepString(dataProviders);
            List<string> expectedDP = new List<string>();

            int count = WebDriver.FindElements(By.XPath("//*[@id='capacityscreen']/div/table/td/table/tbody/tr")).Count();
            for(int i=3;i<=count;i++)
            {
                string dataProvider = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']/div/table/td/table/tbody/tr["+i+"]/td/div/button")).Text;
                expectedDP.Add(dataProvider);
            }

            bool isEqual = !actualDP.Except(expectedDP).Any();

            Assert.IsTrue(isEqual, "Data Providers listed is not correct");
        }


        public void ClickOnStartCalendarIcon()
        {
            var calendar = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//div[3]/button[1]//span[3]/span"));
            calendar.Click();
        }
        public void ClickOnEndCalendarIcon()
        {
            var calendar = WebDriver.FindElement(By.XPath("//*[@id='capacityscreen']//div[3]/button[2]//span[3]/span"));
            calendar.Click();
        }

        public void SelectDate11(string Year,String Month)
        {
            if(Year=="CurrentYear")
            {
                Year= DateTime.Now.Year.ToString();
            }
            else if(Year=="CurrentYear+1")
             {
               int currentYear= DateTime.Now.Year;
                Year = (currentYear + 1).ToString();
            }

            int yearCount = WebDriver.FindElements(By.XPath("//*[@class='k-calendar-navigation']/div/ul/li")).Count();
            for (int i=1;i<= yearCount; i++)
            {
                string GetYear = WebDriver.FindElement(By.XPath("//*[@class='k-calendar-navigation']/div/ul/li[" + i + "]/span")).Text;
                if(GetYear==Year)
                {
                    WebDriver.FindElement(By.XPath("//*[@class='k-calendar-navigation']/div/ul/li[" + i + "]/span")).Click();
                    WebDriver.FindElement(By.XPath("//*[@title='" + Year + " " + Month + "']")).Click();
                    break;
                }
            }
            Thread.Sleep(1000);            
        }


        public void SelectDate(string Date)
        {
            int num;
            string Month="",Year="";
            
            if (Date == "CurrentMonth")
            {
                Year = DateTime.Now.Year.ToString();
                Month = DateTime.Now.ToString("MMM");
            }
            else if (Date.Contains('+') || Date.Contains('-'))
            {
                num = int.Parse(Date.Substring(12));
                Year = DateTime.Now.AddMonths(num).Year.ToString();
                Month = DateTime.Now.AddMonths(num).ToString("MMM");
            }          

            int yearCount = WebDriver.FindElements(By.XPath("//*[@class='k-calendar-navigation']/div/ul/li")).Count();
            for (int i = 1; i <= yearCount; i++)
            {
                string GetYear = WebDriver.FindElement(By.XPath("//*[@class='k-calendar-navigation']/div/ul/li[" + i + "]/span")).Text;
                if (GetYear == Year)
                {
                    WebDriver.FindElement(By.XPath("//*[@class='k-calendar-navigation']/div/ul/li[" + i + "]/span")).Click();
                    WebDriver.FindElement(By.XPath("//*[@title='" + Year + " " + Month + "']")).Click();
                    break;
                }
            }
            Thread.Sleep(1000);
        }
    }

    }




    
    

