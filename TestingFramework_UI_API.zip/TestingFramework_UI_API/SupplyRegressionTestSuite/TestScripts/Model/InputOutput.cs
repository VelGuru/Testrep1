﻿using APITestSuite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SupplyRegressionTestSuite.TestScripts.Model
{
    class InputOutput
    {
    }

    public class PromoteToBaselineInputData
    {
        public string testcase { get; set; }
        public string execute { get; set; }
        public PromoteToBaselineInputParameters inputData { get; set; }
     
        public override string ToString()
        {

            return "testcase=" + testcase + " " + "execute=" + execute + " " ;


        }

    }



    public class PromoteToBaselineInputParameters
    {

        public int Country { get; set; }
        public List<int> MaterialProduct { get; set; }
        public List<int> MaterialGroup { get; set; }
        public int MaterialGrade { get; set; }

        public DateTime StartMonth { get; set; }
        public DateTime EndMonth { get; set; }
    }
    public class ProductionGradeData
    {
        public List<ProductionGraphData> GraphData { get; set; }

        public List<ProductionGrade> TableData { get; set; }

        public ProductionGraphData GetProductionGraphDataForDataProvider(string dataProvider)
        {
            if (GraphData != null && GraphData.Count > 0)
            {
                IEnumerable<ProductionGraphData> list = GraphData.Select(o => o).Where(o => o.DataProvider == dataProvider);
                if (list != null)
                {
                    return list.FirstOrDefault();
                }

            }

            return null;
        }

    }

    public class ProductionGrade
    {
        public int CountryKey { get; set; }

        public string Country { get; set; }

        public List<ProductionGradeDetail> ProductionGradeDetails { get; set; }
    }

    public class ProductionGradeDetail
    {
        public int GradeKey { get; set; }

        public string Grade { get; set; }

        public List<ProductionBaselineComment> BaselineComments { get; set; }

        public List<ProductionQuantityMonth> QuantityMonths { get; set; }
    }


    public class ProductionData
    {
        public List<ProductionGraphData> GraphData { get; set; }
        public List<Production> TableData { get; set; }


        public ProductionGraphData GetProdcutionGraphDataForDataProvider(string dataProvider)
        {
            if(GraphData != null && GraphData.Count > 0)
            {
                IEnumerable<ProductionGraphData> list = GraphData.Select(o => o).Where(o => o.DataProvider == dataProvider);
                if(list != null)
                {
                    return list.FirstOrDefault();
                }

            }

            return null;
        }

            
    }

    public class Production
    {
        public int CountryKey { get; set; }
        public string Country { get; set; }
        public List<ProductionBaselineComment> BaselineComments { get; set; }
        public List<ProductionQuantityMonth> QuantityMonths { get; set; }
    }

    public class ProductionGraphData
    {
        public string DataProvider { get; set; } //RYSTAD    
        public List<ProductionGraphDataProviderData> DataProviderData { get; set; }

        public ProductionGraphDataProviderData GetProductionGraphDataForMonth(DateTime month)
        {   
            
            if (DataProviderData != null && DataProviderData.Count() > 0)
            {
                IEnumerable<ProductionGraphDataProviderData> list = DataProviderData.Select(o => o).Where(o => o.Month == month);
                if (list != null)
                {
                    return list.FirstOrDefault();
                }
            }

            return null;
        }
    }

    public class ProductionGraphDataProviderData
    {
        public DateTime Month { get; set; }
        public decimal Quantity { get; set; }
    }

    public class ProductionBaselineComment
    {
        public DateTime CommentDate { get; set; }
        public string Comment { get; set; }
        public string CommentUserName { get; set; }
        public int GeopoliticalEntityKey { get; set; }
        public int DateOrder { get; set; }
    }

    public class ProductionQuantityMonth
    {
        public DateTime Month { get; set; }
        public List<ProductionQuantity> Quantities { get; set; }
    }

    public class ProductionQuantity
    {
        public string DataProvider { get; set; } //RYSTAD
        public string VersionType { get; set; } //B
        public string LockStatus { get; set; } //Y
        public decimal Delta { get; set; }
        public string Status { get; set; } //Forecasting/Confirmed
        public string BaselineStatus { get; set; } //Current/Previous
        public decimal Quantity { get; set; }
        public string Uom { get; set; } //BBL
        public string CommentExists { get; set; }
        public DateTime LastCommentDate { get; set; }

    }


    public class SupplyProductionInputData
    {
        public string testcase { get; set; }
        public string execute { get; set; }
        public SupplyProductionInputParameters inputData { get; set; }
        public string validateGraphQuantity { get; set; }
        public string validateTableQuantity { get; set; }  
        public ProductionData sampleDataToValidate { get; set; }

        public ProductionGradeData sampleGradeDataToValidate { get; set; }

        public override string ToString() {

            return "testcase=" + testcase + " " + "execute=" + execute + " " + "validateGraphQuantity=" + validateGraphQuantity + " " + "validateTableQuantity=" + validateTableQuantity;


        }

    }

   

    public class SupplyProductionInputParameters
    {
        public DateTime startdate { get; set; } = new DateTime(2020, 01, 01);
        public DateTime enddate { get; set; } = new DateTime(2020, 12, 31);
        public int[] regions { get; set; } = null;
        public int[] tradeorganisation { get; set; } = null;
        public int[] countries { get; set; } = null;
        public int[] materialgroup { get; set; } = null;
        public int[] materialproduct { get; set; } = null;
        public int[] dp { get; set; } = null;

        public int[] materialgrade { get; set; } = null;
    }


    public class SupplyResponseData : ResponseData
    {
        public new ProductionData ResponseValues { get; set; }

        public ProductionGradeData ResponseGradeValues { get; set; }
    }



    public class SupplyProductionUpdateInputData
    {
        public string testcase { get; set; }
        public string execute { get; set; }
        public SupplyProductionUpdateInputParameters inputData { get; set; }

        public override string ToString()
        {

            return "testcase=" + testcase + " " + "execute=" + execute ;


        }

    }



    public class SupplyProductionUpdateInputParameters
    {
        public int Country { get; set; }
        public string ChangeByOperation { get; set; }
        public decimal ChangeBy { get; set; }
        public string PercentageOrAbsolute { get; set; }

        public Boolean IsProgessive { get; set; }
        public Boolean LockedToBaseline { get; set; }

        public List<int> MaterialProduct { get; set; }
        public List<int> MaterialGroup { get; set; }

        public Boolean ScaleAssociatedCondensate { get; set; }
        public List<ProductionAddEditMonth> ProductionAddEditMonths { get; set; }
    }


    public class ProductionAddEditMonth
    {
        public Boolean IsSelected { get; set; }

        public DateTime Month { get; set; }

        public decimal Quantity { get; set; }

        public decimal OriginalQuantity { get; set; }
    }
}
