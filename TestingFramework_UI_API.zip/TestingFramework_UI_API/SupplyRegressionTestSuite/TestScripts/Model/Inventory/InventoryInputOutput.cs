﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SupplyRegressionTestSuite.TestScripts.Model.Inventory
{
    public  class InventoryInputOutput
    {
    }

    public class StorageTankInputData
    {
        public string testcase { get; set; }
        public string execute { get; set; }

        public string update { get; set; }
        public StorageTankAggregateDto inputData { get; set; }
        
        public override string ToString()
        {

            return "testcase=" + testcase + " " + "execute=" + execute;


        }

    }



    public class StorageTankAggregateDto
    {
        public int StorageTankKey { get; set; }

        public int? StorageLocationKey { get; set; }
        public decimal LatitudeNum { get; set; }
        public decimal LongitudeNum { get; set; }
        //public int StorageTankVerKey { get; set; }
        public int Id { get; set; }
        public int? UserKey { get; set; }
        public int? DataSetKey { get; set; }
        public int? IntelligenceSourceTypeKey { get; set; }
        public string IntelligenceSourceTxt { get; set; }
        public string IntelligenceSourceUrl { get; set; }
        public int? IntelligenceSourceMimeTypeKey { get; set; }
        public byte[] IntelligenceSourceImg { get; set; }
        public DateTime VersionEffectiveDt { get; set; }
        public DateTime VersionTerminationDt { get; set; }
        public string VersionActiveInd { get; set; }
        public int? VersionTypeKey { get; set; }
        public int? DataProviderKey { get; set; }
        public DateTime ReportDt { get; set; }

        public string StorageTankNum { get; set; }
        public int? TankCommercialityTypeKey { get; set; }
        public int? TankOperationalStatusTypeKey { get; set; }
        public int? TankConstructionTypeKey { get; set; }
        public int? TankRatingTypeKey { get; set; }
        public int? MaterialTypeKey { get; set; }
        public decimal AverageRadiusQty { get; set; }
        public int? TankDimensionsUomKey { get; set; }
        public int? OriginalUomKey { get; set; }
        public int? UniversalUomKey { get; set; }
        public int? PlatformUomKey { get; set; }
        public decimal OriginalTotalCapacityQty { get; set; }
        public decimal UniversalTotalCapacityQty { get; set; }
        public decimal PlatformTotalCapacityQty { get; set; }
        public decimal OriginalHistoricMinimumQty { get; set; }
        public decimal UniversalHistoricMinimumQty { get; set; }
        public decimal PlatformHistoricMinimumQty { get; set; }
        public decimal OriginalHistoricMaximumQty { get; set; }
        public decimal UniversalHistoricMaximumQty { get; set; }
        public decimal PlatformHistoricMaximumQty { get; set; }
        public string MetaCheckSumId { get; set; }
        public int? ReportConfidenceTypeKey { get; set; }
    }

    public class StorageTankAggregateView
    {
        public int StorageTankKey { get; set; }

        public string DeleteInd { get; set; }
        public string MetaQualityCd { get; set; }
        public string MetaActionCd { get; set; }
        public DateTime? MetaCreatedDttm { get; set; }
        public string MetaCreatorNm { get; set; }
        public DateTime? MetaChangedDttm { get; set; }
        public string MetaChangedByNm { get; set; }
        public DateTime? RecordEntryDttm { get; set; }
        public string StorageTankName { get; set; }
        public int? StorageLocationKey { get; set; }

        public string StorageLocationNm { get; set; }

        public string GeoPoliticalEntityNm { get; set; }
        public decimal LatitudeNum { get; set; }
        public decimal LongitudeNum { get; set; }


        public int Id { get; set; }
        public int? UserKey { get; set; }
        public int? DataSetKey { get; set; }
        public int? IntelligenceSourceTypeKey { get; set; }
        public string IntelligenceSourceTxt { get; set; }
        public string IntelligenceSourceUrl { get; set; }
        public int? IntelligenceSourceMimeTypeKey { get; set; }
        public byte[] IntelligenceSourceImg { get; set; }
        public DateTime VersionEffectiveDt { get; set; }
        public DateTime VersionTerminationDt { get; set; }
        public string VersionActiveInd { get; set; }
        public int? VersionTypeKey { get; set; }

        public string VersionTypeName { get; set; }
        public int? DataProviderKey { get; set; }

        public string DataProviderName { get; set; }
        public DateTime ReportDt { get; set; }

        public string StorageTankNum { get; set; }
        public int? TankCommercialityTypeKey { get; set; }

        public string TankCommercialityTypeName { get; set; }
        public int? TankOperationalStatusTypeKey { get; set; }

        public string TankOperationalStatusTypeDesc { get; set; }

        public int? TankConstructionTypeKey { get; set; }
        public int? TankRatingTypeKey { get; set; }
        public int? MaterialTypeKey { get; set; }

        public string MaterialTypeNm { get; set; }
        public decimal AverageRadiusQty { get; set; }
        public int? TankDimensionsUomKey { get; set; }
        public int? OriginalUomKey { get; set; }
        public int? UniversalUomKey { get; set; }
        public string UniversalUomName { get; set; }
        public int? PlatformUomKey { get; set; }
        public decimal OriginalTotalCapacityQty { get; set; }
        public decimal UniversalTotalCapacityQty { get; set; }
        public decimal PlatformTotalCapacityQty { get; set; }
        public decimal OriginalHistoricMinimumQty { get; set; }
        public decimal UniversalHistoricMinimumQty { get; set; }
        public decimal PlatformHistoricMinimumQty { get; set; }
        public decimal OriginalHistoricMaximumQty { get; set; }
        public decimal UniversalHistoricMaximumQty { get; set; }
        public decimal PlatformHistoricMaximumQty { get; set; }
        public string MetaCheckSumId { get; set; }
        public int? ReportConfidenceTypeKey { get; set; }
    }
}
