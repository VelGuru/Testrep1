﻿using System.Collections.Generic;
using System.Linq;
using Xunit;
using Newtonsoft.Json.Linq;
using System.Collections;
using Microsoft.Extensions.Configuration;
using System;
using RestSharp;
using RestSharp.Authenticators;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using SupplyRegressionTestSuite.TestScripts;
using SupplyRegressionTestSuite;
using SupplyRegressionTestSuite.TestScripts.Model;

namespace APITestSuite
{
    public class TestPromoteToBaseline
    {
        

        [Theory]
        [ClassData(typeof(TestPTBDataGenerator))]
        public static void RunTest(PromoteToBaselineInputData supplyProductionInputData)
        {

            List<string> errors = new List<string>();

            ResponseData rd = SupplyRestUtil.PromoteToBaseline(supplyProductionInputData.inputData);

            
            Assert.True(RestUtil.IsStatusCodeOk(rd.StatusCode), "Error in Promote To Baseline");
            
            


        }                           
        //?startdate=01-01-2020&enddate=12-31-2020&tradeorganisation=3&tradeorganisation=4" 
                          
    }


    

  

    public class TestPTBDataGenerator : IEnumerable<object[]>
    {

        private readonly List<object[]> _data = loadInputData();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        private static List<object[]> loadInputData()
        {
            List<object[]> _inputDataList = new List<object[]>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            string masterDataFile = config["MasterPromoteToBaselineDataTestConfig"];
            string text = System.IO.File.ReadAllText(@masterDataFile);

            JArray masterDataInputArray = JArray.Parse(text);
            foreach (JObject masterDateInputObject in masterDataInputArray)
            {
                PromoteToBaselineInputData inputData = masterDateInputObject.ToObject<PromoteToBaselineInputData>();
                if (inputData.execute.IsValueY())
                    _inputDataList.Add(new object[] { inputData });
            }
            return _inputDataList;
        }
    }
}

