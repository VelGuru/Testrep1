﻿using APITestSuite;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using Xunit;
using System.Collections;
using System.Linq;
using RestSharp;
using SupplyRegressionTestSuite.TestScripts.Model.Inventory;

namespace SupplyRegressionTestSuite.TestScripts.MasterDataTests.Inventory
{

    public class TestStorageTank 
    {

        public static ResponseData GetMethod(string URL,int id)
        {
            if (id > -1)
            {
                URL = URL + "/" + id;
            }
            var client = new RestClient(URL);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData();
            responseData.StatusCode = (int)restResponse.StatusCode;
            responseData.StatusLine = restResponse.ResponseStatus.ToString();
            responseData.ContentType = restResponse.ContentType;
            if (RestUtil.IsStatusCodeOk((int)restResponse.StatusCode))
            {
                JArray responseArray = JArray.Parse(restResponse.Content) as JArray;
                responseData.ResponseCount = responseArray.Count;
                List<Dictionary<string, string>> responseValues = new List<Dictionary<string, string>>();


                foreach (JToken obj in responseArray)
                {
                    Dictionary<string, string> keyValues = new Dictionary<string, string>();
                    foreach (JProperty property in obj)
                    {
                        keyValues.Add(property.Name, property.Value.ToString());
                    }
                    responseValues.Add(keyValues);
                }
                responseData.ResponseValues = responseValues;
            }
            return responseData;
        }


        [Theory]
        [ClassData(typeof(TestDataGenerator))]
        public static void RunTest(StorageTankInputData inputData)
        {
            List<string> errors = new List<string>();

            string URL = RestUtil.GetURL("StorageTankTargetUri");

            ResponseData rd = GetMethod(URL,inputData.inputData.StorageTankKey);

            string errorMessage = inputData.testcase + " GetById for storage tank failed";
            
            Assert.True(RestUtil.IsStatusCodeOk((int)rd.StatusCode), errorMessage);

            ResponseData rdAll = GetMethod(URL,-1);

            errorMessage = inputData.testcase + " Get All for storage tank failed";

            Assert.True(RestUtil.IsStatusCodeOk((int)rdAll.StatusCode), errorMessage);
        }


    }

    

    public class TestDataGenerator : IEnumerable<object[]>
    {

        private readonly List<object[]> _data = loadInputData();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        private static List<object[]> loadInputData()
        {
            List<object[]> _inputDataList = new List<object[]>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            string masterDataFile = config["MasterInventoryDataTestConfigFile"];
            string text = System.IO.File.ReadAllText(@masterDataFile);

            JArray masterDataInputArray = JArray.Parse(text);
            foreach (JObject masterDateInputObject in masterDataInputArray)
            {
                StorageTankInputData inputData = masterDateInputObject.ToObject<StorageTankInputData>();
                if (inputData.execute == null || inputData.execute.ToUpper() == "y".ToUpper())
                    _inputDataList.Add(new object[] { inputData });
            }

            return _inputDataList;
        }
    }
}
