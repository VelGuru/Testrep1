﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SupplyRegressionTestSuite
{
    public static class Extenion
    {
        public static bool IsNullOrEmpty(this Array array)
        {
            return (array == null || array.Length == 0);
        }

        public static bool IsValueY(this string s)
        {
            return (!String.IsNullOrEmpty(s) && s.ToUpper() == "y".ToUpper());
        }


        public static bool CompareWithRounding(this decimal d1,decimal d2)
        {
            decimal d1RoundedTo4 = Decimal.Round(d1, 4);
            decimal d2RoundedTo4 = Decimal.Round(d2, 4);

            return Decimal.Compare(d1RoundedTo4, d2RoundedTo4) == 0;
        }
    }
}
