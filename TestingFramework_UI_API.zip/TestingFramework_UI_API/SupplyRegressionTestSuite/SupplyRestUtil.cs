﻿using APITestSuite;
using Newtonsoft.Json;
using RestSharp;
using SupplyRegressionTestSuite.TestScripts;
using System;
using System.Collections.Generic;
using System.Text;
using SupplyRegressionTestSuite.TestScripts.Model;

namespace SupplyRegressionTestSuite
{
    public class SupplyRestUtil:RestUtil
    {
        public static SupplyResponseData GetMethod(SupplyProductionInputParameters inputData,Boolean isMaterialGrade = false)
        {
            string url = GetBaseURL() + GenerateURLString(inputData);
            var client = new RestClient(url);
            var request = new RestRequest(Method.GET);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            SupplyResponseData responseData = new SupplyResponseData
            {
                StatusCode = (int)restResponse.StatusCode,
                StatusLine = restResponse.ResponseStatus.ToString(),
                ContentType = restResponse.ContentType
            };
            if (IsStatusCodeOk((int)restResponse.StatusCode))
            {
                responseData.ResponseCount = 1;
                if (isMaterialGrade)
                {
                    ProductionGradeData pd = JsonConvert.DeserializeObject<ProductionGradeData>(restResponse.Content);
                    responseData.ResponseGradeValues = pd;
                }
                else
                {
                    ProductionData pd = JsonConvert.DeserializeObject<ProductionData>(restResponse.Content);
                    responseData.ResponseValues = pd;
                }
                
            }
            return responseData;
        }

        public static ResponseData PostMethod(SupplyProductionUpdateInputParameters inputData)
        {
            String jSonString = Newtonsoft.Json.JsonConvert.SerializeObject(inputData);
            string url = GetBaseUpdateURL();
            RestClient client = new RestClient(url);
            RestRequest request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json-patch+json");
            request.AddJsonBody(jSonString);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData
            {
                StatusCode = (int)restResponse.StatusCode,
                StatusLine = restResponse.ResponseStatus.ToString(),
                ContentType = restResponse.ContentType
            };
            return responseData;
        }

        public static ResponseData PromoteToBaseline(PromoteToBaselineInputParameters inputData)
        {
            String jSonString = Newtonsoft.Json.JsonConvert.SerializeObject(inputData);
            string url = GetPromoteToBaselineURL();
            RestClient client = new RestClient(url);
            RestRequest request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json-patch+json");
            request.AddJsonBody(jSonString);
            client.Authenticator = new CustomAuthenticator();
            IRestResponse restResponse = client.Execute(request);
            ResponseData responseData = new ResponseData
            {
                StatusCode = (int)restResponse.StatusCode,
                StatusLine = restResponse.ResponseStatus.ToString(),
                ContentType = restResponse.ContentType
            };
            return responseData;
        }

        private static string GenerateURLString(SupplyProductionInputParameters inputData)
        {
            StringBuilder URLAppendString = new StringBuilder("?");
            URLAppendString.Append("startdate=");
            
            URLAppendString.Append(inputData.startdate.ToString("MM-dd-yyyy"));
            URLAppendString.Append("&");
            URLAppendString.Append("enddate=");
            URLAppendString.Append(inputData.enddate.ToString("MM-dd-yyyy"));

            URLAppendString.Append(GetURLForArrayInput("regions", inputData.regions));
            URLAppendString.Append(GetURLForArrayInput("tradeorganisation", inputData.tradeorganisation));
            URLAppendString.Append(GetURLForArrayInput("countries", inputData.countries));
            URLAppendString.Append(GetURLForArrayInput("materialgroup", inputData.materialgroup));
            URLAppendString.Append(GetURLForArrayInput("materialproduct", inputData.materialproduct));
            URLAppendString.Append(GetURLForArrayInput("materialgrade", inputData.materialgrade));
            URLAppendString.Append(GetURLForArrayInput("dp", inputData.dp));


            return URLAppendString.ToString();
        }


        private static string GetURLForArrayInput(string parameterName, int[] values)
        {
            StringBuilder urlForArrayInput = new StringBuilder("");
            if (!values.IsNullOrEmpty())
            {
                foreach (int i in values)
                {
                    urlForArrayInput.Append("&");
                    urlForArrayInput.Append(parameterName);
                    urlForArrayInput.Append("=");
                    urlForArrayInput.Append(i);
                }
            }

            return urlForArrayInput.ToString();
        }

    }
}
