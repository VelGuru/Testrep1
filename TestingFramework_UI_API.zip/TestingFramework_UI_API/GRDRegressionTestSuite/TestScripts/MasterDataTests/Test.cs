﻿using System.Collections.Generic;
using System.Linq;
using Xunit;
using Newtonsoft.Json.Linq;
using System.Collections;
using Microsoft.Extensions.Configuration;

namespace APITestSuite
{
    public class Test : MasterDataTest
    {
     
        [Theory]
        [ClassData(typeof(TestDataGenerator))]
        public static void RunTest(InputData inputData)
        {
            Test test = new Test();

            test.Fields = inputData.fields;
            test.MandatoryFields = inputData.mandatoryFields;
            test.UniqueFields = inputData.uniqueFields;
            test.ApiName = inputData.apiName;
            test.CDInitials = inputData.cdInitials;
            test.Versionable = inputData.versionable != null && inputData.versionable == "Y";
            List<CrossRefField> crossRefFieldList = inputData.crossRefFields;
            if (crossRefFieldList != null)
            {
                test.CrossRefFields = new Dictionary<string, string>();
                foreach (CrossRefField crossRefField in crossRefFieldList)
                {
                    test.CrossRefFields.Add(crossRefField.field, crossRefField.apiName);
                }
            }

            List<DefaultValueField> defaultValueFieldList = inputData.defaultValueFields;
            if (defaultValueFieldList != null)
            {
                test.DefaultValueFields = new Dictionary<string, string>();
                foreach (DefaultValueField defaultValueField in defaultValueFieldList)
                {
                    test.DefaultValueFields.Add(defaultValueField.field, defaultValueField.value);
                }
            }

            test.TestPost();

            test.TestGet();
            test.TestGetById();
           

            test.TestPostUniqueFields();
            test.TestPostMandatoryFields();

            test.TestPut();

            test.TestPutUniqueFields();
            test.TestPutMandatoryFields();
            test.TestDelete();
            
            Assert.True(test.errors.Count == 0, test.ApiName + ":" + "\n" + string.Join("\n ", test.errors.Select(s => $"'{s}'")));
        }

       
    }

    public class TestDataGenerator : IEnumerable<object[]>
    {

        private readonly List<object[]> _data = loadInputData();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        private static List<object[]> loadInputData()
        {
            List<object[]> _inputDataList = new List<object[]>();
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            string masterDataFile = config["MasterDataTestConfigFile"];
            string text = System.IO.File.ReadAllText(@masterDataFile);

            JArray masterDataInputArray = JArray.Parse(text);
            foreach (JObject masterDateInputObject in masterDataInputArray)
            {
                InputData inputData = masterDateInputObject.ToObject<InputData>();
                if (inputData.execute == null || inputData.execute.ToUpper() == "y".ToUpper())
                    _inputDataList.Add(new object[] { inputData });
            }

            string crossRefDataFile = config["CrossRefDataTestConfigFile"];
            string text1 = System.IO.File.ReadAllText(@crossRefDataFile);

            JArray crossRefDataInputArray = JArray.Parse(text1);
            foreach (JObject crossRefDataInputObject in crossRefDataInputArray)
            {
                InputData inputData = crossRefDataInputObject.ToObject<InputData>();
                if (inputData.execute == null || inputData.execute.ToUpper() == "y".ToUpper())
                    _inputDataList.Add(new object[] { inputData });
            }
            return _inputDataList;
        }
    }
}

