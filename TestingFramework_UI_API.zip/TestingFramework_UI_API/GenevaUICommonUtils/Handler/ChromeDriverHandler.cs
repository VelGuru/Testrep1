﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Microsoft.Extensions.Configuration;


namespace GenevaUICommonUtils.Handler
{
    public class ChromeDriverHandler
    {
        public IWebDriver GetCromeDriver()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--start-maximized");
            var config = new ConfigurationBuilder().AddJsonFile("UiappSettings.json").Build();        
            return new ChromeDriver(config["Browsers:DriverPath"], options);
        }

    }
}
