﻿using System;
using System.Collections.Generic;
using System.Text;
using GenevaUICommonUtils.Interface.DataBase;
using GenevaUICommonUtils.Interface.Driver;
using GenevaUICommonUtils.Interface.Setup;

namespace GenevaUICommonUtils.Interface.Reference
{
    public class AcmReference
    {
      
        public IExecuteDBQuries ExecuteDBQuries => new ExecuteDBQuries();

        public ISetup Setup => new SetUp();
    }
}
