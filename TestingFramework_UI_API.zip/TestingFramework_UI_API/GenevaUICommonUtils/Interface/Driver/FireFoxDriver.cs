﻿using GenevaUICommonUtils.Controller;
using OpenQA.Selenium;

namespace GenevaUICommonUtils.Interface.Driver
{
    class FireFoxDriver : IDriver
    {
        private readonly DriverController driverController = new DriverController();

        public IWebDriver GetDriver()
        {
            return driverController.FireFoxDriver();
        }
    }
}

