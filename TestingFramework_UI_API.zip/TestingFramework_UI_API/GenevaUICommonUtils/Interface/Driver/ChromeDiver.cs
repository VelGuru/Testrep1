﻿using System;
using System.Collections.Generic;
using System.Text;
using GenevaUICommonUtils.Controller;
using OpenQA.Selenium;

namespace GenevaUICommonUtils.Interface.Driver
{

    public class ChromeDiver : IDriver
    {
        private readonly DriverController driverController = new DriverController();
        public IWebDriver GetDriver()
        {
            return driverController.ChromeDriver();
        }
    }
}
