﻿using System;
using System.Collections.Generic;
using System.Text;
using GenevaUICommonUtils.Controller;
using OpenQA.Selenium;

namespace GenevaUICommonUtils.Interface.Driver
{
    public class EdgeDriver  : IDriver
    {
        private readonly DriverController driverController = new DriverController();

        public IWebDriver GetDriver()
        {
            return driverController.EdgeDriver();
        }
    }
}
