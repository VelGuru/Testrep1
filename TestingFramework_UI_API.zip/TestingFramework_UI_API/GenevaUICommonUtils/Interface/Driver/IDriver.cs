﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace GenevaUICommonUtils.Interface.Driver
{
    public interface IDriver
    {
        public IWebDriver GetDriver();
    }
}
