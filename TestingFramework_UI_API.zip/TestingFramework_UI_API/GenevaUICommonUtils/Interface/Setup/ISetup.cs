﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using GenevaUICommonUtils.Helper;

namespace GenevaUICommonUtils.Interface.Setup
{
    public interface ISetup
    {
        Task Initialize(Browsers browser = Browsers.Chrome);
    }
}
