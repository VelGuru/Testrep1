﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using GenevaUICommonUtils.Helper;

namespace GenevaUICommonUtils.Interface.Setup
{
    public class SetUp : ISetup    {
        
        public async Task Initialize(Browsers browser)
        {
            await Task.Run(()=>Selenium.Driver.GetDrive(browser));
        }
    }
}
