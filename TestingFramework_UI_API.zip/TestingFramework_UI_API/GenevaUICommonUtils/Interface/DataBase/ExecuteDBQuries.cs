﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenevaUICommonUtils.Interface.DataBase
{
    public class ExecuteDBQuries : IExecuteDBQuries
    {
        public System.Threading.Tasks.Task<dynamic> ExecuteMultipleQuery(string script = null, string connectionString = null, int? userID = null)
        {
            throw new NotImplementedException();
        }

        public System.Threading.Tasks.Task<dynamic> ExecuteSingleQuery(string script, string connectionString = null)
        {
            throw new NotImplementedException();
        }
    }
}
