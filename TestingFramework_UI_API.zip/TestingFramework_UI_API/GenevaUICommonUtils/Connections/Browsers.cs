﻿using GenevaUICommonUtils.Model.AppSettings;

namespace GenevaUICommonUtils.Connections
{
    public class Browsers
    {
        public static string Browser { get; set; } = GetBrowserBy("Browser");

        private static string GetBrowserBy(string BrowserConfigKey)
        {
            return AppSettings.GetValue<string>($"EndPoint:{BrowserConfigKey}");
        }
    }
}
