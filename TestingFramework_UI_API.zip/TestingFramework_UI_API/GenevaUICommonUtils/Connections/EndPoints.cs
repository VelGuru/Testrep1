﻿using GenevaUICommonUtils.Model.AppSettings;

namespace GenevaUICommonUtils.Connections
{
    public class EndPoints
    {
        public static string Url { get; set; } = GetEndPointBy("ACM");
        public static string SupplyUrl { get; set; } = GetEndPointBy("Supply");

        private static string GetEndPointBy(string EndPointConfigKey)
        {
            return AppSettings.GetValue<string>($"DevUrl:{EndPointConfigKey}");
        }

    }
}
