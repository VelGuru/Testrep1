﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace GenevaUICommonUtils.Helper.DataBase
{
    public class Fetch
    {
        public async Task<string> DatabaseScript(string ScriptName)
        {
            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = assembly.GetManifestResourceNames().Single(str => str.EndsWith($"{ScriptName}.sql"));
            using (var stream = assembly.GetManifestResourceStream(resourceName))
            {
                using (var reader = new StreamReader(stream ?? throw new InvalidOperationException()))
                {
                    return await reader.ReadToEndAsync();
                }
            }
        }

        public Dictionary<string, string> DatabaseScripts(string[] ScriptNames)
        {
            var assembly = Assembly.GetExecutingAssembly();
            Dictionary<string, string> scripts = new Dictionary<string, string>();
            foreach (var script in ScriptNames)
            {
                string resourceName = assembly.GetManifestResourceNames().Single(str => str.EndsWith($"{script}.sql"));
                using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                {
                    using (StreamReader reader = new StreamReader(stream ?? throw new InvalidOperationException()))
                    {
                        scripts.Add(script, reader.ReadToEnd());
                    }
                }
            }
            return scripts;
        }
    }
}

