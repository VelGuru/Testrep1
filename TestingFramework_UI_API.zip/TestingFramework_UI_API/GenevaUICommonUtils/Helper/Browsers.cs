﻿namespace GenevaUICommonUtils.Helper
{
    public enum Browsers
    {
        Chrome,
        FireFox,
        Edge
    }
}
