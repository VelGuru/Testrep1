﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenevaUICommonUtils.Helper.Readers
{
    public class JsonFieldCollection
    {
        private readonly Dictionary<string, JValue> fields;

        public JsonFieldCollection(JToken token)
        {
            fields = new Dictionary<string, JValue>();
            CollectFields(token);
        }

        private void CollectFields(JToken jToken)
        {
            //fields.Clear();
            switch (jToken.Type)
            {
                case JTokenType.Object:
                    foreach (var child in jToken.Children<JProperty>())
                    {
                        CollectFields(child);
                    }
                    break;
                case JTokenType.Array:
                    foreach (var child in jToken.Children())
                    {
                        CollectFields(child);
                    }
                    break;
                case JTokenType.Property:
                    CollectFields(((JProperty)jToken).Value);
                    break;
                default:
                    fields.Add(jToken.Path, (JValue)jToken);
                    break;
            }
        }
        public IEnumerable<KeyValuePair<string, JValue>> GetAllFields() => fields;
    }
}
