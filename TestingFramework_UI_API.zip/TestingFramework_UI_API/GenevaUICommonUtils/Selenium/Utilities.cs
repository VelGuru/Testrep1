﻿using System;
using System.Collections.Generic;
using System.Text;
using AventStack.ExtentReports;
using OpenQA.Selenium;

namespace GenevaUICommonUtils.Selenium
{
    public class Utilities
    {
        public static IWebDriver WebDriver = Driver.getDriver;
        public static void LaunchUrl(string url)
        {
            WebDriver.Url = url;
            WebDriver.Navigate().Refresh();
            WebDriver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
        }
        public MediaEntityModelProvider CaptureScreenShotAndReturnModel(string name)
        {
            string screenshot = ((ITakesScreenshot)WebDriver).GetScreenshot().AsBase64EncodedString;
            return MediaEntityBuilder.CreateScreenCaptureFromBase64String(screenshot, name).Build();
        }

        public static void LaunchUrl(object url)
        {
            throw new NotImplementedException();
        }
    }
}
