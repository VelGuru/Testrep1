﻿namespace GenevaUICommonUtils.Model.AppSettings
{
    public class Browsers
    {
        public string Browser { get; set; } = GetBrowsersBy("Browser");

        private static string GetBrowsersBy(string BrowsersConfigKey)
        {
            return AppSettings.GetValue<string>($"EndPoints:{BrowsersConfigKey}");
        }
    }
}
