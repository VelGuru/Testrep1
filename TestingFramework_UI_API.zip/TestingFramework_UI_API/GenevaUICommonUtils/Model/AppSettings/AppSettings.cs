﻿using Microsoft.Extensions.Configuration;
using System.IO;
using System.Reflection;

namespace GenevaUICommonUtils.Model.AppSettings
{
    public class AppSettings
    {
        
       // private static readonly string path = Paths.path;
        private static readonly IConfiguration _configuration = new ConfigurationBuilder().AddJsonFile("//UiAppSettings.json").Build();

        public static T GetValue<T>(string key)
        {
            return _configuration.GetValue<T>(key);
        }
    }
}
