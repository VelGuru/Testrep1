﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenevaUICommonUtils.Controller
{
    public class DatabaseController
    {

    }
}
