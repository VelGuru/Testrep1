﻿using System;
using System.Collections.Generic;
using System.Text;
using GenevaUICommonUtils.Handler;
using OpenQA.Selenium;

namespace GenevaUICommonUtils.Controller
{
    public class DriverController
    {
        private readonly ChromeDriverHandler chromeDriverHandler = new ChromeDriverHandler();
        public IWebDriver ChromeDriver()
        {
            return chromeDriverHandler.GetCromeDriver(); 
        }
        public IWebDriver FireFoxDriver()
        {
            return null;
        }
        public IWebDriver EdgeDriver()
        {
            return null;
        }
    }
}
