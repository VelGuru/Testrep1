﻿using System.Collections.Concurrent;
using System.Threading.Tasks;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper.Readers;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Controller
{
    public class ReaderController
    {
        public async Task<ConcurrentDictionary<string, dynamic>> ReadJasonData(string scenarioName, string jsonFilePath)
        {

            return await Task.Run(() => new JsonReader().GetJsonDataCollection(scenarioName, jsonFilePath));
        }
    }
}
