﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Controller
{
    public class DatabaseController
    {

    }
}
