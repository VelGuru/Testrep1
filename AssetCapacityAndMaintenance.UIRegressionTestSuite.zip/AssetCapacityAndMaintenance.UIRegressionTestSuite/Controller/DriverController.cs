﻿using System;
using System.Collections.Generic;
using System.Text;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Handler;
using OpenQA.Selenium;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Controller
{
    public class DriverController
    {
        private readonly ChromeDriverHandler chromeDriverHandler = new ChromeDriverHandler();
        public IWebDriver ChromeDriver()
        {
            return chromeDriverHandler.GetCromeDriver(); 
        }
        public IWebDriver FireFoxDriver()
        {
            return null;
        }
        public IWebDriver EdgeDriver()
        {
            return null;
        }
    }
}
