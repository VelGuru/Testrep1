﻿using System;
using Microsoft.Graph;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using ExpectedConditions = OpenQA.Selenium.Support.UI.ExpectedConditions;
using OpenQA.Selenium.Interactions;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using NUnit.Framework;
using TechTalk.SpecFlow.CommonModels;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Selenium.Pages;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper.Readers;
using TechTalk.SpecFlow;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Selenium.Pages.MasterDataScreens
{
    public class AssetUnitConfiguration
    {
        public static IWebDriver WebDriver = Driver.getDriver;
        public WebDriverWait WebDriverWait;
        IJavaScriptExecutor executor = (IJavaScriptExecutor)WebDriver;
        public static string unit;

        By ClickonConfigdata = By.XPath("//*[@class='k-icon k-i-expand']");
        By ClickonAssetConfig = By.XPath("//*[@class='k-content']/li[3]/div/span[@class='k-icon k-i-expand']");
        By ClickonAssetUnitConfiguration = By.XPath("//*[@class='k-content']/li[1]//child::div/span/div/a[text()='Asset Unit Configuration']");
        By ClickonNewUnit = By.XPath("//*[contains(text(),'New Unit')]");


        public AssetUnitConfiguration(int waitInMilliSecond = 90)
        {
            WebDriverWait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(waitInMilliSecond));
        }

        public void AssetUnitConfig()
        {
            var expandConfig = WebDriver.FindElement(ClickonConfigdata);
            expandConfig.Click();
            var assetConfig = WebDriver.FindElement(ClickonAssetConfig);
            assetConfig.Click();
            var selectAssetConfig = WebDriver.FindElement(ClickonAssetUnitConfiguration);
            selectAssetConfig.Click();

        }

        //div[@class='k-grid-container']//child::tr[1]//td[2]
        public void verifyGrid()
        {
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var selectFilter = WebDriver.FindElement(By.XPath("//div[@class='float-left']//child::button"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectFilter));
            selectFilter.Click();

            var selectCountries = WebDriver.FindElement(By.XPath("//input[@Id='Countries-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectCountries));
            selectCountries.Click();
            selectCountries.SendKeys("Algeria");
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findcheckbox = WebDriver.FindElement(By.XPath("//*[text()='Algeria']/preceding-sibling::input[@value='Algeria']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findcheckbox);

            var selectOwners = WebDriver.FindElement(By.XPath("//input[@Id='Companies-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectOwners));
            selectOwners.Click();
            selectOwners.SendKeys("Sonatrach");
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findOwner = WebDriver.FindElement(By.XPath("//*[text()='Sonatrach']/preceding-sibling::input[@value='Sonatrach']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findOwner);

            var selectAsset = WebDriver.FindElement(By.XPath("//input[@Id='Assets/AssetFilter-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectAsset));
            selectAsset.Click();
            selectAsset.SendKeys("Arzew");
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findAsset = WebDriver.FindElement(By.XPath("//*[text()='Arzew']/preceding-sibling::input[@value='Arzew']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findAsset);

            var selectUnitType = WebDriver.FindElement(By.XPath("//input[@Id='AssetUnitTypes-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectUnitType));
            selectUnitType.Click();
            selectUnitType.SendKeys("VDU");
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findUnitType = WebDriver.FindElement(By.XPath("//h6[contains(text(),'Unit Type')]//following-sibling::div//child::input[@value='VDU']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findUnitType);

            Thread.Sleep(2000);
            var selectUnitSubType = WebDriver.FindElement(By.XPath("//input[@Id='AssetUnitSubTypes-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectUnitSubType));
            selectUnitSubType.Click();
            selectUnitSubType.SendKeys("VDU");
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var findUnitSubType = WebDriver.FindElement(By.XPath("//h6[contains(text(),'Unit Subtype')]//following-sibling::div//child::input[@value='VDU']"));
            executor = (IJavaScriptExecutor)WebDriver;
            executor.ExecuteScript("arguments[0].click();", findUnitSubType);


            var saveApply = WebDriver.FindElement(By.XPath("//button[@class='reset-clear tab-focus apply']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(saveApply));
            saveApply.Click();
        }

        public void ClickonNew()
        {
            var newUnit = WebDriver.FindElement(ClickonNewUnit);
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(newUnit));
            newUnit.Click();
        }

        public int GetGridCount()
        {
            return WebDriver.FindElements(By.XPath("//*[@id='dailyeventListing']//div//table//tbody//tr")).Count;
        }


        public void DetailPage(string assetName, string unitName, string unitSubType, string assetUnitStartDate, string operationalStatus,string probabilityTypeValue, string quantity, string initialCapacityStartDate, string dataProvider, bool eventRecorded = true)
        {
            int countBeforeEvent = GetGridCount();
            var assetselect = WebDriver.FindElement(By.XPath("//div[text()='Asset Name']/following-sibling::span//span[@class='k-input']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(assetselect));
            assetselect.Click();
            var selectAsset = WebDriver.FindElement(By.XPath("//ul[@role='listbox']//li[text()='"+assetName+"']"));
            WebDriverWait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//ul[@role='listbox']//li[text()='"+assetName+"']")));
            selectAsset.Click();

            Thread.Sleep(2000);
            var unitname = WebDriver.FindElement(By.XPath("//div[text()='Unit Name']/following-sibling::input"));
            unit = unitName + "" + DateTime.Now.ToString("ddMMyyyyhhmmss");
            unitname.SendKeys(unit);

            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var unitSubtype = WebDriver.FindElement(By.XPath("//div[text()='Unit SubType']/following-sibling::span//span[@class='k-input']/following-sibling::select"));
            var subtypeSelect = WebDriver.FindElement(By.XPath("//div[text()='Unit SubType']/following-sibling::span//span[@class='k-input']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(subtypeSelect));
            subtypeSelect.Click();
            var selectUnitSubType = WebDriver.FindElement(By.XPath("//*[@class='k-list-scroller']//ul//*[contains(text(),'"+unitSubType+"')]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectUnitSubType));
            selectUnitSubType.Click();

            var clickCalenderIcon = WebDriver.FindElement(By.XPath("//div[text()='Start Date']//following-sibling::span//child::span[@class='k-select']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(clickCalenderIcon));
            clickCalenderIcon.Click();
            new AssetCapacityPage().SelectDMY(assetUnitStartDate);

            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var optStatus = WebDriver.FindElement(By.XPath("//div[text()='Operational Status']/following-sibling::span//span[@class='k-input']/following-sibling::select"));
            var optSelect = WebDriver.FindElement(By.XPath("//div[text()='Operational Status']/following-sibling::span//span[@class='k-input']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(optSelect));
            optSelect.Click();
            var optStatusSelect = WebDriver.FindElement(By.XPath("//ul[@role='listbox']//li[text()='"+operationalStatus+"']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(optStatusSelect));
            optStatusSelect.Click();

            Thread.Sleep(1500);
            //var probtype = WebDriver.FindElement(By.XPath("//div[text()='Probability Type']/following-sibling::span//span[@class='k-select']/following-sibling::select"));
            var probSelect = WebDriver.FindElement(By.XPath("//div[text()='Probability Type']/following-sibling::span//span[@class='k-select']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(probSelect));
            probSelect.Click();
            var selectDataProbType = WebDriver.FindElement(By.XPath("//*[@class='k-list-scroller']//ul//*[contains(text(),'"+probabilityTypeValue+"')]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(selectDataProbType));
            selectDataProbType.Click();

            var Quantity = WebDriver.FindElement(By.XPath("//span[@class= 'k-numeric-wrap']/input"));
            Quantity.SendKeys(quantity);

            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var clickCalender = WebDriver.FindElement(By.XPath("//div[text()='Initial Capacity']//following-sibling::div//child::span[@role='button']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(clickCalender));
            clickCalender.Click();

            Thread.Sleep(1500);
            new AssetCapacityPage().SelectDMY(initialCapacityStartDate);

            Thread.Sleep(2000);
            WebDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            var dataprovider = WebDriver.FindElement(By.XPath("//div[text()='Data Provider']/following-sibling::span//span[@class='k-input']/following-sibling::select"));
            var providerSelect = WebDriver.FindElement(By.XPath("//div[text()='Data Provider']/following-sibling::span//span[@class='k-input']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(providerSelect));
            providerSelect.Click();
            var selectDataProvider = WebDriver.FindElement(By.XPath("//*[@class='k-list-scroller']//ul//*[contains(text(),'"+dataProvider+"')]"));
            WebDriverWait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//*[@class='k-list-scroller']//ul//li[contains(text(),'"+dataProvider+"')]"))).Click();

            var clickSubmit = WebDriver.FindElement(By.XPath("//*[@id='tab-buttons']/button[2]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(clickSubmit));
            clickSubmit.Click();
            Thread.Sleep(3500);

            int countAfterEvent = GetGridCount();
            Console.WriteLine(countAfterEvent + " :" + countBeforeEvent);
            new AssetCapacityPage().GridVerification(countBeforeEvent, countAfterEvent, eventRecorded);
        }
    }
}

