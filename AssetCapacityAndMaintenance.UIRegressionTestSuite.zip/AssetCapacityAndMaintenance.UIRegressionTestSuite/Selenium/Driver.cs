﻿using System;
using System.Collections.Generic;
using System.Text;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Driver;
using OpenQA.Selenium;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Selenium
{
    public class Driver
    {
        private static Driver driver;
        public static IWebDriver getDriver;
        public static IWebDriver ImplicitWait;
        private Driver()
        {

        }

        public static Driver GetDrive(Browsers browser)
        {
            if(driver==null)
            {
                driver = new Driver();
                FactoryDriver factory = new FactoryDriver();
                IDriver drivers = factory.Factory(browser);
                getDriver = drivers.GetDriver();
            }

            return driver;
        }

    }
}
