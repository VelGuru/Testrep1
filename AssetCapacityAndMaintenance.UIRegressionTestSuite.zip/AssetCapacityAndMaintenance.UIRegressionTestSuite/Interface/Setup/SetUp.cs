﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Setup
{
    public class SetUp : ISetup
    {
        protected Reader.Reader Reader => new Reader.Reader();
        public async Task Initialize(Browsers browser)
        {
            await Task.Run(()=>Selenium.Driver.GetDrive(browser));
        }
    }
}
