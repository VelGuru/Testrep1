﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Setup
{
    public interface ISetup
    {
        Task Initialize(Browsers browser = Browsers.Chrome);
    }
}
