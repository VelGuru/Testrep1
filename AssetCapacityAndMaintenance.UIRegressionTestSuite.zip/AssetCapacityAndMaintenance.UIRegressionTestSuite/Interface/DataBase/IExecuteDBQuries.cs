﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.DataBase
{
    public interface IExecuteDBQuries
    {
        Task<dynamic> ExecuteSingleQuery(string script, string connectionString = null);
        Task<dynamic> ExecuteMultipleQuery(string script = null, string connectionString = null, int? userID = null);
    }
}
