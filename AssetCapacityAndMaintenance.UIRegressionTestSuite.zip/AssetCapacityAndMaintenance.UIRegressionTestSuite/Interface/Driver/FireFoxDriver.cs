﻿using AssetCapacityAndMaintenance.UIRegressionTestSuite.Controller;
using OpenQA.Selenium;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Driver
{
    class FireFoxDriver : IDriver
    {
        private readonly DriverController driverController = new DriverController();

        public IWebDriver GetDriver()
        {
            return driverController.FireFoxDriver();
        }
    }
}

