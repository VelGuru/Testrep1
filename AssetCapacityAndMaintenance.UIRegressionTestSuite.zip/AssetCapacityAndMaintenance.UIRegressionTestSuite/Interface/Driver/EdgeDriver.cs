﻿using System;
using System.Collections.Generic;
using System.Text;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Controller;
using OpenQA.Selenium;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Driver
{
    public class EdgeDriver  : IDriver
    {
        private readonly DriverController driverController = new DriverController();

        public IWebDriver GetDriver()
        {
            return driverController.EdgeDriver();
        }
    }
}
