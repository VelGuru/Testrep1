﻿using System;
using System.Collections.Generic;
using System.Text;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.DataBase;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Driver;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Reader;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Setup;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Reference
{
    public class AcmReference
    {
        public IReader Reader => new Reader.Reader();
        public IExecuteDBQuries ExecuteDBQuries => new ExecuteDBQuries();

        public ISetup Setup => new SetUp();
    }
}
