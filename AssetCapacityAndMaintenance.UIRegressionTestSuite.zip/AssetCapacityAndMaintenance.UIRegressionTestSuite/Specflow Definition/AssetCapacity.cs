﻿using System;
using System.Collections;
using System.Threading.Tasks;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Reader;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Selenium;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Selenium.Pages;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.SpecFlow.Hooks;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Selenium.Pages.MasterDataScreens;
using NUnit.Framework;
using TechTalk.SpecFlow;
using System.Collections.Generic;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper.Readers;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper;
using System.Threading;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.SpecFlow.StepDefinitions
{
    [Binding]
    public sealed class AssetsCapacity : SetUp
    {
        // Step Defininations

        [Scope(Feature = "AssetCapacity")]
        [Given(@"I launch the application")]
        public void GivenILaunchTheApplication()
        {
            Utilities.LaunchUrl(Connections.EndPoints.Url);
        }
        [Given(@"I click on program menu")]
        public void GivenIClickOnProgramMenu()
        {
            new AssetCapacityPage().ClickProgramMenu();
        }

        [Given(@"I create Asset Unit")]
        public void GivenICreateAssetUnit()
        {
            new AssetUnitConfiguration().AssetUnitConfig();
            new AssetUnitConfiguration().verifyGrid();
            new AssetUnitConfiguration().ClickonNew();
            AddAssetUnitConfigData();
        }
        public void AddAssetUnitConfigData()
        {
            string[] Array = { "AssetUnitConfigurationFields" };
            //new AssetCapacityPage().ClickonNewEvent();
            var dic = new JsonReader().GetJsonDataCollection(ScenarioContext.Current.ScenarioInfo.Title, Paths.JsonTestDataWorkbook);
            foreach (string key in Array)
            {
                String Dict = dic[key];
                var getdata = new JsonReader().JsonFieldCollections(Dict);
                string assetName = getdata["assetName"];
                string unitName = getdata["unitName"];
                string unitSubType = getdata["unitSubType"];
                string assetUnitStartDate = getdata["assetUnitStartDate"];
                string operationalStatus = getdata["operationalStatus"];
                string probabilityTypeValue = getdata["probabilityTypeValue"];
                string quantity = getdata["quantity"];
                string initialCapacityStartDate = getdata["initialCapacityStartDate"];
                string dataProvider = getdata["dataProvider"];
                new AssetUnitConfiguration().DetailPage(assetName, unitName, unitSubType, assetUnitStartDate, operationalStatus, probabilityTypeValue, quantity, initialCapacityStartDate, dataProvider);
            }
        }
        [Given(@"I Click on Capacity Total")]
        public void GivenIClickOnCapacityTotal()
        {
            new AssetCapacityPage().ClickProgramMenu();
            new AssetCapacityPage().ClickCapacityTotal();
        }
        [Then(@"I verify page title")]
        public void ThenIVerifyPageTitle()
        {
            Assert.That(new AssetCapacityPage().GetAssetCapacityText().Contains("Asset Capacity"), "Page title has not matched");
        }

        [Then(@"I click on filter")]
        public void ThenIClickOnFilter()
        {
            new AssetCapacityPage().ClickFilter();
        }

        [Then(@"I click on search country")]
        public void ThenILickOnSearchCountry()
        {
            new AssetCapacityPage().ClickSearchCountry();
        }

        [Then(@"I enter country name and select it from list")]
        public async Task ThenIEnterCountryNameAndSelectItFromList()
        {
            //await acmReference.Reader.LoadConfigurationJson("ACM.Capacity-Total-Scenario1");
            new AssetCapacityPage().SelectCountryFromList(Reader.Country);
        }

        [Then(@"I click on search city")]
        public void ThenILickOnSearchCity()
        {

            new AssetCapacityPage().ClickSearchCity();
        }

        [Then(@"I enter city name and select it from list")]
        public async Task ThenIEnterCityNameAndSelectItFromList()
        {
            //await acmReference.Reader.LoadConfigurationJson("ACM.Capacity-Total-Scenario1");
            new AssetCapacityPage().SelectCityFromList(Reader.City);
        }

        [Then(@"I click on search company")]
        public void ThenILickOnSearchCompany()
        {
            new AssetCapacityPage().ClickSearchCompany();
        }

        [Then(@"I enter company name and select it from list")]
        public void ThenIEnterCompanyNameAndSelectItFromList()
        {
            String[] Owner = Reader.Owners.Split(',');
            foreach (var company in Owner)
            {
                new AssetCapacityPage().SelectCompanyFromList(company);
            }
            //new AssetCapacityPage().SelectCompanyFromList(Reader.Owners);
        }

        [Then(@"I click on search AssetType")]
        public void ThenIClickOnSearchAssetType()
        {
            new AssetCapacityPage().ClickSearchAssetType();
        }

        [Then(@"I enter AssetTypee and select it from list")]
        public void ThenIEnterAssetTypeeAndSelectItFromList()
        {
            new AssetCapacityPage().SelectAssetTypeFromList(Reader.AssetType);
        }

        [Then(@"I click on search Assets")]
        public void ThenIClickOnSearchAssets()
        {
            new AssetCapacityPage().ClickSearchAsset();
        }

        [Then(@"I enter Assets and select it from list")]
        public void ThenIEnterAssetsAndSelectItFromList()
        {
            String[] Asset = Reader.Assets.Split(',');
            foreach (var asset in Asset)
            {
                new AssetCapacityPage().SelectAssetFromList(asset);
            }
        }

        [Then(@"I click on search UnitType")]
        public void ThenIClickOnSearchUnitType()
        {
            new AssetCapacityPage().ClickSearchUnitType();

        }

        [Then(@"I enter UnitType and select it from list")]
        public void ThenIEnterUnitTypeAndSelectItFromList()
        {
            new AssetCapacityPage().SelectUnitTypeFromList(Reader.UnitType);

        }

        [Then(@"I click on search UnitSubType")]
        public void ThenIClickOnSearchUnitSubType()
        {
            new AssetCapacityPage().ClickSearchUnitSubType();
        }

        [Then(@"I enter UnitSubType and select it from list")]
        public async Task ThenIEnterUnitSubTypeAndSelectItFromListAsync()
        {
            //await acmReference.Reader.LoadConfigurationJson("ACM.Capacity-Total-Scenario1");
            new AssetCapacityPage().SelectSubUnitFromList(Reader.UnitSubType);
        }

        [Then(@"I click on search Unit")]
        public void ThenIClickOnSearchUnit()
        {
            new AssetCapacityPage().ClickSearchUnit();
        }

        [Then(@"I enter Unit and select it from list")]
        public async Task ThenIEnterUnitAndSelectItFromListAsync()
        {
            //await acmReference.Reader.LoadConfigurationJson("ACM.Capacity-Total-Scenario1");
            string units = AssetUnitConfiguration.unit;
            if (units != null)
            {
                var unit = AssetUnitConfiguration.unit;
                new AssetCapacityPage().SelectUnitFromList(unit);
            }
            else
            {
                String[] Unit = Reader.Unit.Split(',');
                foreach (var unit in Unit)
                {
                    new AssetCapacityPage().SelectUnitFromList(unit);
                }
                
            }
        }

        [Then(@"I click on Apply Button")]
        public void ThenIClickOnApplyButton()
        {
            new AssetCapacityPage().ClickApplyButton();
        }

        [Then(@"I click on BaseLineUnitCapacityValue")]
        public void ThenIClickOnUnit()
        {
            ArrayList list = new AssetCapacityPage().GetListFromGrid();
            String[] Asset = Reader.Assets.Split(',');
            int Count = 0;
            foreach (var Value in list)
            {
                //String gridName = list[0].ToString();
                Assert.IsTrue(Value.Equals(Asset[0].ToString()), "Grid Has not Matched");
                Count++;
            }
            new AssetCapacityPage().ClickButtonBaseline();
        }
        [Then(@"Add NewExpansionEvent with true")]
        public void ThenIClickOnNewUnit()
        {
            string[] Array = { "ExpansionFields"};
            //new AssetCapacityPage().ClickonNewEvent();
            var dic = new JsonReader().GetJsonDataCollection(ScenarioContext.Current.ScenarioInfo.Title, Paths.JsonTestDataWorkbook);
            foreach (string key in Array)
            {
                String Dict = dic[key];
                var getdata = new JsonReader().JsonFieldCollections(Dict);
                string unitName = getdata["unitName"];
                string basisType = getdata["basisType"];
                string intelligenceValue = getdata["intelligenceValue"];
                string probabilityTypeValue = getdata["probabilityTypeValue"];
                string selectStatus = getdata["selectStatus"];
                string incrementalcapacity = getdata["incrementalcapacity"];
                string date = getdata["date"];
                new AssetCapacityPage().CreateNewEvent(unitName, basisType, intelligenceValue, probabilityTypeValue, selectStatus, incrementalcapacity, date);
                
            }
        }
        [Then(@"Add NewCreepEvent with true")]
        public void ThenAddNewCreepEventWithTrue()
        {
            string[] Array = {"CreepFields"};
            //new AssetCapacityPage().ClickonNewEvent();
            var dic = new JsonReader().GetJsonDataCollection(ScenarioContext.Current.ScenarioInfo.Title, Paths.JsonTestDataWorkbook);
            foreach (string key in Array)
            {
                String Dict = dic[key];
                var getdata = new JsonReader().JsonFieldCollections(Dict);
                string unitName = getdata["unitName"];
                string basisType = getdata["basisType"];
                string intelligenceValue = getdata["intelligenceValue"];
                string probabilityTypeValue = getdata["probabilityTypeValue"];
                string selectStatus = getdata["selectStatus"];
                string incrementalcapacity = getdata["incrementalcapacity"];
                string date = getdata["date"];
                new AssetCapacityPage().CreateNewEvent(unitName, basisType, intelligenceValue, probabilityTypeValue, selectStatus, incrementalcapacity, date);
            }
        }

        [Then(@"Add NewClouserEvent with true")]
        public void ThenAddNewClouserEventWithTrue()
        {
            string[] Array = {"ClousreFields"};
            var dic = new JsonReader().GetJsonDataCollection(ScenarioContext.Current.ScenarioInfo.Title, Paths.JsonTestDataWorkbook);
            foreach (string key in Array)
            {
                String Dict = dic[key];
                var getdata = new JsonReader().JsonFieldCollections(Dict);
                string unitName = getdata["unitName"];
                string basisType = getdata["basisType"];
                string intelligenceValue = getdata["intelligenceValue"];
                string probabilityTypeValue = getdata["probabilityTypeValue"];
                string selectStatus = getdata["selectStatus"];
                string incrementalcapacity = getdata["incrementalcapacity"];
                string date = getdata["date"];
                new AssetCapacityPage().CreateNewEvent(unitName, basisType, intelligenceValue, probabilityTypeValue, selectStatus, incrementalcapacity, date);
            }
        }
    }
}
