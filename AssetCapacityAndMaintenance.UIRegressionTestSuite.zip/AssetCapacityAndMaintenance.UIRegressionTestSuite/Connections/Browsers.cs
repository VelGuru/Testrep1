﻿using AssetCapacityAndMaintenance.UIRegressionTestSuite.Model.AppSettings;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Connections
{
    public class Browsers
    {
        public static string Browser { get; set; } = GetBrowserBy("Browser");

        private static string GetBrowserBy(string BrowserConfigKey)
        {
            return AppSettings.GetValue<string>($"EndPoint:{BrowserConfigKey}");
        }
    }
}
