﻿using AssetCapacityAndMaintenance.UIRegressionTestSuite.Model.AppSettings;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Connections
{
    public class DataBase
    {
        public static readonly string DataBaseName = GetDbStringBy("DBName");

        private static string GetDbStringBy(string DataBaseConfigKey, string InitialCatalog = "Shell")
        {
            string DataSource = AppSettings.GetValue<string>($"DataBase:{DataBaseConfigKey}");
            string Password = AppSettings.GetValue<string>("DataBase:DBPassword");

            return $"Data Source={DataSource};Initial Catalog={InitialCatalog};Persist Security Info=True;User ID=sa;Password={Password}";
        }
    }
}
