﻿namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper
{
    public enum Browsers
    {
        Chrome,
        FireFox,
        Edge
    }
}
