﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper.Readers
{
    public class JsonReader
    {
        private readonly ConcurrentDictionary<string, dynamic> dictionary = new ConcurrentDictionary<string, dynamic>();

        public ConcurrentDictionary<string, dynamic> GetJsonDataCollection(string scenarioName, string jsonFilePath)
        {
            jsonFilePath ??= Paths.JsonTestDataWorkbook;
            dictionary.Clear();
            try
            {
                using (var streamReader = new StreamReader(jsonFilePath))
                {
                    var reader = new JsonTextReader(streamReader);
                    var jsonToken = JObject.Load(reader).GetValue(scenarioName);
                    if (jsonToken.HasValues)
                    {
                        foreach (var child in jsonToken.Children<JProperty>())
                        {
                            var childKey = child.Name;
                            var childValue = child.Value;
                            dictionary.TryAdd(childKey, childValue.ToString());
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }

            return dictionary;
        }

        public ConcurrentDictionary<string, dynamic> JsonFieldCollections(string response)
        {
            dictionary.Clear();
            var json = JToken.Parse(response);
            var fieldsCollector = new JsonFieldCollection(json);
            var fields = fieldsCollector.GetAllFields();
            foreach (var field in fields)
            {
                dictionary.TryAdd(field.Key, field.Value);
            }
            return dictionary;
        }
    }
}
