﻿namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Model.AppSettings
{
    public class EndPoints
    {
        public static string Url { get; set; } = GetEndPointsBy("Url");
       
        private static string GetEndPointsBy(string EndPointsConfigKey)
        {
            return AppSettings.GetValue<string>($"EndPoints:{EndPointsConfigKey}");
        }
    }
}
