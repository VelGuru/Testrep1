﻿using CommonTestUtils;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Reflection;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Model.AppSettings
{
    public class AppSettings
    {
        
        private static readonly string path = Paths.path;
        private static readonly IConfiguration _configuration = new ConfigurationBuilder().AddJsonFile(path + "\\appsettings.json").Build();

        public static T GetValue<T>(string key)
        {
            return _configuration.GetValue<T>(key);
        }
    }
}
