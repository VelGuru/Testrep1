﻿using static AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper.Paths;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.Handler
{
    public class ChromeDriverHandler
    {
        public IWebDriver GetCromeDriver()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--start-maximized");
            return new ChromeDriver(ChromeDriverPath, options);
        }

    }
}
