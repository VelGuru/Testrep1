﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Threading.Tasks;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Interface.Reference;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Selenium;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper;
using NUnit.Framework;
using TechTalk.SpecFlow;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using AssetCapacityAndMaintenance.UIRegressionTestSuite.Helper.Readers;
using System.Collections.Concurrent;

namespace AssetCapacityAndMaintenance.UIRegressionTestSuite.SpecFlow.Hooks
{
    public class SetUp
    {
        public static AcmReference acmReference = new AcmReference();
        public static ConcurrentDictionary<string, dynamic> Dic = new ConcurrentDictionary<string, dynamic>();
    }

    [Binding]
    public sealed class Hooks
    {
        //Global Variable for Extend report
        private static ExtentTest featureName;
        private static ExtentTest scenario;
        private static ExtentReports extent;
        private static AcmReference acmReference = new AcmReference();
        ConcurrentDictionary<string, dynamic> Dic = new ConcurrentDictionary<string, dynamic>();

        [BeforeTestRun]
        public static async void InitializeReport()
        {
            var reportPath = Paths.ExtentReport + "ExtentReport_" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss") + ".html";
            //Initialize Extent report before test starts
            var htmlReporter = new ExtentV3HtmlReporter(reportPath);
            //Attach report to reporter
            extent = new ExtentReports();
            extent.AttachReporter(htmlReporter);
        }

        [AfterTestRun]
        public static void TearDownReport()
        {
            Driver.getDriver.Close();
            Driver.getDriver.Quit();
            //Flush report once test completes
            extent.Flush();


        }

        [BeforeFeature]
        public static void BeforeFeature()
        {
            //Create dynamic feature name
            featureName = extent.CreateTest<Feature>(FeatureContext.Current.FeatureInfo.Title);
        }

        [BeforeScenario]
        public async Task TearUp()
        {
            await acmReference.Setup.Initialize();
            scenario = featureName.CreateNode<Scenario>(ScenarioContext.Current.ScenarioInfo.Title);
            await acmReference.Reader.LoadConfigurationJson(ScenarioContext.Current.ScenarioInfo.Title);
            Dic = new JsonReader().GetJsonDataCollection(ScenarioContext.Current.ScenarioInfo.Title, Paths.JsonTestDataWorkbook);
            Assert.IsTrue(Driver.getDriver != null, "Browser has not launched successfully");
        }

        [AfterScenario]
        public void TearDown()
        {
            
        }

        [AfterStep]
        public static void InsertReportingSteps()
        {
            var stepType = ScenarioStepContext.Current.StepInfo.StepDefinitionType.ToString();
            PropertyInfo pInfo = typeof(ScenarioContext).GetProperty("ScenarioExecutionStatus", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
            MethodInfo getter = pInfo.GetGetMethod(nonPublic: true);
            object TestResult = getter.Invoke(ScenarioContext.Current, null);

            if (ScenarioContext.Current.TestError == null)
            {
                if (stepType == "Given")
                    scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text);
                else if (stepType == "When")
                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text);
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text);
                else if (stepType == "And")
                    scenario.CreateNode<And>(ScenarioStepContext.Current.StepInfo.Text);
            }
            else if (ScenarioContext.Current.TestError != null)
            {
                var mediaEntity = new Utilities().CaptureScreenShotAndReturnModel(ScenarioContext.Current.ScenarioInfo.Title.Trim());
                var error = ScenarioContext.Current.TestError;
                if (stepType == "Given")
                    scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message, mediaEntity);
                else if (stepType == "When")
                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message, mediaEntity);
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text).Fail(ScenarioContext.Current.TestError.Message, mediaEntity);
            }

            //Pending Status
            if (TestResult.ToString() == "StepDefinitionPending")
            {
                if (stepType == "Given")
                    scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text).Skip("Step Definition Pending");
                else if (stepType == "When")
                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text).Skip("Step Definition Pending");
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text).Skip("Step Definition Pending");

            }

        }
    }
}
